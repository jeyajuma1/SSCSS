<?php namespace MSLST\Helpers;
      use MSLST\Constants\Dashboard as DashConstant;

use Carbon\Carbon;

class Dashboard {
    
    /**
     * Format all audits as json array to be used with Morris.js
     *
     * @param integer $count
     * @return string
     */
    public static function getJSFormattedAudits($count = 12)
    {
        $user_id = \Auth::User()->id;
        $lsp_id = \Auth::User()->lsp->id;

        // Get the location list
       /* $locations = \Location::select(\DB::raw('COUNT(id) as total, DATE_FORMAT(created_at, \'%Y%m\') as span'))
                        ->orderBy('created_at', 'DESC')
                        ->groupBy('span')
                        ->limit($count); */

         $locations = \Location::select(\DB::raw('COUNT(id) as total, convert(varchar(6) , created_at, 112) as span'))
                        ->orderBy(\DB::raw('convert(varchar(6) , created_at, 112)'), 'DESC')
                        ->groupBy(\DB::raw('convert(varchar(6) , created_at, 112)'))
                        ->limit($count);

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $locations->where('auditor_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $locations->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }

        $locations = $locations->lists('total', 'span');

        // Get the routes list
     /*   $routes = \Routes::select(\DB::raw('COUNT(id) as total, DATE_FORMAT(created_at, \'%Y%m\') as span'))
                        ->orderBy('created_at', 'DESC')
                        ->groupBy('span')
                        ->limit($count); */
         $routes = \Routes::select(\DB::raw('COUNT(id) as total, convert(varchar(6) , created_at, 112) as span'))
                        ->orderBy(\DB::raw('convert(varchar(6) , created_at, 112)'), 'DESC')
                        ->groupBy(\DB::raw('convert(varchar(6) , created_at, 112)'))
                        ->limit($count);

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $routes->where('auditor_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $routes->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }

        $routes = $routes->lists('total', 'span');

        // Arrange the data
        $locations_first = key($locations);
        $routes_first = key($routes);

        $year = $locations_first > $routes_first ? $locations_first : $routes_first;
        $result = [];

        // If there are audits build the result array
        if ($year)
        {
            for ($i = 0; $i < $count; $i++)
            {
                $year_part = substr($year, 0, 4);
                $month_part = substr($year, 4, 2);
                $period = $year_part . '-' . $month_part;
                $location_count = isset($locations[$year]) ? $locations[$year] : 0;
                $route_count = isset($routes[$year]) ? $routes[$year] : 0;

                /*$result[] = [
                    'period' => $period,
                    'location' => $location_count,
                    'route' => $route_count,
                ]; */

                $result['period'][]   = $period;
                $result['location'][] = $location_count;
                $result['route'][]    = $route_count;

                if ($month_part == 1) 
                {
                    $year = ($year_part-1) .''. 12;
                }
                else
                {
                    $year--;
                }
            }

            sort($result['period']);
            krsort($result['location']);
            krsort($result['route']);

            $result['location'] = array_values($result['location']);
            $result['route'] = array_values($result['route']);
        }


        return json_encode($result);
    }

    /**
     * Format all incidents as json array to be used with Morris.js
     *
     * @param integer $count
     * @return string
     */
    public static function getJSFormattedIncidents($count = 12,$type='number')
    {
        //echo "If you cant then who can";exit;
        $user_id = \Auth::User()->id;
        $lsp_id = \Auth::User()->lsp->id;

        if($type == 'value'){
           /* $incidents = \Incident::leftjoin('products as p','incidents.id','=','p.incident_id')
                                ->select(\DB::raw('date_format(incidents.created_at,\'%Y%m\') as span,sum(p.total_value_of_lost_units) as total'))
                                //->where(\DB::raw('year(incidents.created_at)'), 2013)
                                ->orderBy('incidents.created_at','DESC')
                                ->groupBy('span')
                                ->limit($count);*/

             $incidents = \Incident::leftjoin('products as p','incidents.id','=','p.incident_id')
                                ->select(\DB::raw('convert(varchar(6) , incidents.incident_date, 112) as span,sum(p.total_value_of_lost_units) as total'))
                                //->where(\DB::raw('year(incidents.created_at)'), 2013)
                                ->orderBy(\DB::raw('convert(varchar(6) ,incidents.incident_date, 112)'),'DESC')
                                ->groupBy(\DB::raw('convert(varchar(6) ,incidents.incident_date, 112)'))
                                ->limit($count);
         // echo "<pre>"; print_r($incidents); exit;
        }  else  {
            /*$incidents = \Incident::select(\DB::raw('COUNT(id) as total, DATE_FORMAT(created_at, \'%Y%m\') as span'))
                        ->orderBy('created_at', 'DESC')
                        ->groupBy('span')
                        ->limit($count);*/

            $incidents = \Incident::select(\DB::raw('COUNT(id) as total, convert(varchar(6) ,incident_date, 112) as span'))
                        ->orderBy(\DB::raw('convert(varchar(6) ,incident_date, 112)'), 'DESC')
                        ->groupBy(\DB::raw('convert(varchar(6) ,incident_date, 112)'))
                        ->limit($count);
        }

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $incidents->where('user_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
           /* $incidents->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('user_id', $user_id)
                  ->orWhereHas('user', function($q1) use ($lsp_id) {
                      $q1->where('users.lsp_id', $lsp_id);
                  });
            });*/

           $regionChk = \UserRegion::select('region_id')
                                   ->where('user_id',\Auth::User()->id)
                                   ->lists('region_id');

           $incidents->whereIn('region_id', $regionChk);

           $lspChk    = \User::select('id')
                             ->where('lsp_id',\Auth::User()->lsp->id)
                             ->lists('id');
           $incidents->whereIn('user_id', $lspChk);
        }

        $incidents = $incidents->lists('total', 'span');
        
    
        $year = key($incidents);

       
        $result = [];
            

        // If there are incidents build the result array
      
        if ($year)
        {

            for ($i = 0; $i < $count; $i++)
            {
                //print_r($year);
                $year_part = substr($year, 0, 4);               
                $month_part = substr($year, 4, 2);

                $period = $year_part . '-' . $month_part;

                $incident_count = isset($incidents[$year]) ? $incidents[$year] : 0;                
              /*  $result[] = [
                    'period' => $period,
                    'incidents' => $incident_count,
                ];*/

                 $result['period'][] = $period;
                 $result['incidents'][] = $incident_count; 


                if ($month_part == 1) 
                {
                    $year = ($year_part-1) .''. 12;
                }
                else
                {
                    $year--;
                }
            }

        sort($result['period']);
        //print_r($result['period']);exit;
        krsort($result['incidents']);
        $result['incidents'] = array_values($result['incidents']);
        }

        //echo "<pre>"; print_r($result); exit;
      
        return json_encode($result);
    }

    /*To get Financial year from database*/

    public static function getFinancialYear(){
        $FinancialYear =  \Incident::select(\DB::raw("COUNT(id) as total, (CASE WHEN MONTH(incident_date)>=7 THEN  concat(YEAR(incident_date), '-',YEAR(incident_date)+1) ELSE concat(YEAR(incident_date)-1,'-', YEAR(incident_date))END) AS financial_year"))
                 ->groupBy(\DB::raw("(CASE WHEN MONTH(incident_date)>=7 THEN  concat(YEAR(incident_date), '-',YEAR(incident_date)+1) ELSE concat(YEAR(incident_date)-1,'-', YEAR(incident_date))END)"));

        $FYear   = $FinancialYear->lists('total', 'financial_year'); 
        $finyear = array_flip($FYear);
        $arrCnt  = array_values($finyear);         
        $count   = count($arrCnt);
        for ($i = 0; $i < $count; $i++)
        {                
         $FinYear[] =    explode("-",$arrCnt[$i]);
         
        }
          
         //print_r($FinYear);  

    }



    /**
     * Format incident status as json array to be used with Morris.js
     *
     * @return string
     */
    public static function getJSFormattedIncidentStatus()
    {
        $user_id = \Auth::User()->id;
        $lsp_id = \Auth::User()->lsp->id;

      /*  $incidents = \Incident::select(\DB::raw('COUNT(id) as total, IF(closed_at IS NOT NULL, "closed", "open") as status'))
                        ->groupBy('status'); */

        $incidents = \Incident::select(\DB::raw("COUNT(id) as total, (case WHEN closed_at IS NOT NULL THEN  'Closed' ELSE 'Open' END) as status"))
                     ->groupBy(\DB::raw("(case WHEN closed_at IS NOT NULL THEN  'Closed' ELSE 'Open' END)")); 



        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $incidents->where('user_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            /*$incidents->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('user_id', $user_id)
                  ->orWhereHas('user', function($q1) use ($lsp_id) {
                      $q1->where('users.lsp_id', $lsp_id);
                  });
            });*/
           $regionChk = \UserRegion::select('region_id')
                                   ->where('user_id',\Auth::User()->id)
                                   ->lists('region_id');

           $incidents->whereIn('region_id', $regionChk);

           $lspChk    = \User::select('id')
                             ->where('lsp_id',\Auth::User()->lsp->id)
                             ->lists('id');
           $incidents->whereIn('user_id', $lspChk);
        }

        $incidents = $incidents->lists('total', 'status');

        $result = [];

        foreach ($incidents as $status => $total)
        {
            $result[] = [
                'label' => $status,
                'value' => $total
            ];
        }

        return json_encode($result);
    }

    /**
     * Format incident category as json array to be used with Morris.js
     *
     * @return string
     */
    public static function getJSFormattedIncidentCategory()
    {
        $user_id = \Auth::User()->id;
        $lsp_id = \Auth::User()->lsp->id;

        $incidents = \Incident::select(\DB::raw('COUNT(id) as total, category'))
                        ->groupBy('category');

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $incidents->where('user_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            /*$incidents->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('user_id', $user_id)
                  ->orWhereHas('user', function($q1) use ($lsp_id) {
                      $q1->where('users.lsp_id', $lsp_id);
                  });
            });*/
           $regionChk = \UserRegion::select('region_id')
                                   ->where('user_id',\Auth::User()->id)
                                   ->lists('region_id');

           $incidents->whereIn('region_id', $regionChk);

           $lspChk    = \User::select('id')
                             ->where('lsp_id',\Auth::User()->lsp->id)
                             ->lists('id');
           $incidents->whereIn('user_id', $lspChk);
        }

        $incidents = $incidents->lists('total', 'category');

        $result = [];

        foreach ($incidents as $status => $total)
        {
            $result[] = [
                'label' => $status,
                'value' => $total
            ];
        }

        return json_encode($result);
    }
	
	 /**
     * Format User status as json array to be used with Morris.js
     *
     * @return string
     */
    public static function getJSFormatteduserStatus()
    {
        $user_id = \Auth::User()->id;
		$lsp_id = \Auth::User()->lsp->id;        
        /*$users = \User::select(\DB::raw('COUNT(id) as total, IIF(deleted_at IS NOT NULL, "Inactive", "Active") as status'))
                        ->groupBy('status')->withTrashed(); */

        $users = \User::select(\DB::raw("COUNT(id) as total,IIF(deleted_at IS NOT NULL, 'Inactive', 'Active') as status"))
                      ->groupBy(\DB::raw("IIF(deleted_at IS NOT NULL,'Inactive','Active')"))->withTrashed(); 
						
						
		if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $users->where(function ($q) use ($lsp_id) {
                $q->where('users.lsp_id', $lsp_id);
             });
            
        }
         $users = $users->lists('total', 'status'); 
        $result = [];

        foreach ($users as $status => $total)
        {
            $result[] = [
                'label' => $status,
                'value' => $total
            ];
        }
        return json_encode($result);
    }


    /**
     * Format recent users and login time as an array
     *
     * @param integer $count
     * @param string $format
     * @return array
     */
    public static function getFormattedRecentUsers($count = 10, $format = '%M %D, %Y %h:%i:%s %p')
    {
        $lsp_id = \Auth::User()->lsp->id;

        /*$users = \User::select('id', \DB::raw('id, first_name, last_name, DATE_FORMAT(last_login_at, \''. $format .'\') as login'))
                        ->orderBy('last_login_at', 'DESC')
                        ->WhereNotIn('email',DashConstant::$RESTRICTED_RECENT_USER_LIST)
                        ->limit($count); */

        /*$users = \User::select('id', \DB::raw("id, first_name, last_name, FORMAT(last_login_at,'dd MMMM,yyyy hh:mm:ss tt') as login"))
                        ->orderBy('last_login_at', 'DESC')
                        ->WhereNotIn('email',DashConstant::$RESTRICTED_RECENT_USER_LIST)
                        ->limit($count); */
						
		$users = \UserLog::select('id', \DB::raw("id, user_id, FORMAT(login_at,'dd MMMM,yyyy hh:mm:ss tt') as login"))
						  ->orderBy('login_at', 'DESC')
						  ->WhereNotIn('user_id',DashConstant::$RESTRICTED_RECENT_USER_LIST)
                          ->limit($count);

         /* If LSP supervisor, get only owned and LSP records
        //if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        //{
        // $users->where('lsp_id', $lsp_id);
        //} */

        $users = $users->get();

        $users = $users?:[];

        return $users;
    }

    /**
     * Format recent audits and incidents and return them as an array
     *
     * @param integer $count
     * @param string $format
     * @return array
     */
    public static function getFormattedRecentAuditsIncidents($count = 10, $format = "%b %D, %h:%i %p", $index = 0)
    {
        $user_id = \Auth::User()->id;
        $lsp_id = \Auth::User()->lsp->id;

        // If there is index, fetch more items
        $limit = $index ? ($index + 1) * $count : $count;

        //MYSQL
        /*$locations = \Location::select('id', 'site', \DB::raw('DATE_FORMAT(updated_at, \''. $format .'\') as formatted_date, UNIX_TIMESTAMP(updated_at) as unixtime'))
                        ->orderBy('created_at', 'DESC')
                        ->limit($limit);*/

        //MSSQL
        $formt = 'MMM dd, hh:mm tt';
        $locations = \Location::select('id', 'site', \DB::raw("FORMAT(updated_at,'".$formt."') as formatted_date,DATEDIFF(s,'19700101',updated_at) as unixtime"))
                        ->orderBy('created_at', 'DESC')
                        ->limit($limit);
        
        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $locations->where('auditor_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $locations->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }

        $locations = $locations->get();

        //MYSQL

        /*$routes = \Routes::select('id', 'start_site', 'end_site', \DB::raw('DATE_FORMAT(updated_at, \''. $format .'\') as formatted_date, UNIX_TIMESTAMP(updated_at) as unixtime'))
                        ->orderBy('created_at', 'DESC')
                        ->limit($limit); */
        //MSSQL 
        $routes = \Routes::select('id', 'start_site', 'end_site', \DB::raw("FORMAT(updated_at, '". $formt ."') as formatted_date, DATEDIFF(s,'19700101',updated_at) as unixtime"))
                        ->orderBy('created_at', 'DESC')
                        ->limit($limit); 
        
        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $routes->where('auditor_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $routes->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }

        $routes = $routes->get();

        //MYSQL
       /* $incidents = \Incident::with('country')
                        ->select('id', 'category','country_id','location_city','facility', \DB::raw('DATE_FORMAT(created_at, \''. $format .'\') as formatted_date, UNIX_TIMESTAMP(created_at) as unixtime'))
                        ->orderBy('created_at', 'DESC')
                        ->limit($limit); */

        //MSSQL
         $incidents = \Incident::with('country')
                        ->select('id', 'category','country_id','location_city','facility', \DB::raw("FORMAT(created_at,'". $formt ."') as formatted_date, DATEDIFF(s,'19700101',created_at) as unixtime"))
                        ->orderBy('created_at', 'DESC')
                        ->limit($limit);           


        

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $incidents->where('user_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $incidents->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('user_id', $user_id)
                  ->orWhereHas('user', function($q1) use ($lsp_id) {
                      $q1->where('users.lsp_id', $lsp_id);
                  });
            });
        }

        $incidents = $incidents->get();

       // echo "<pre>"; print_r($incidents); exit;

        $locations_array = [];
        foreach ($locations as $location)
        {
            $locations_array[$location->unixtime] = [
                'id' => $location->id,
                'url' => route('locations.show', [$location->id]),
                'type' => 'location',
                'icon' => 'fa-location-arrow',
                'text' => 'New location at '. substr($location->site,10),
                'date' => str_replace(",",",<span>",$location->formatted_date),
            ];
        }

        $routes_array = [];
        foreach ($routes as $route)
        {
            $routes_array[$route->unixtime] = [
                'id' => $route->id,
                'url' => route('routes.show', [$route->id]),
                'type' => 'route',
                'icon' => 'fa-location-arrow',
                'text' => 'New route from '. $route->start_site .' to '. substr($route->end_site,10),
                'date' => str_replace(",",",<span>",$route->formatted_date),
             ];
        }

        $incidents_array = [];
        foreach ($incidents as $incident)
        {
            $incidents_array[$incident->unixtime] = [
                'id' => $incident->id,
                'url' => route('incidents.show', [$incident->id]),
                'type' => 'incident',
                'icon' => 'fa-exclamation',
                'text' => 'New '.$incident->category.' incident in '. $incident->country->name.' , '. $incident->location_city,
                'date' => str_replace(",",",<span>",$incident->formatted_date),
            ];
        }

        $alerts = $locations_array + $routes_array + $incidents_array;

        // If the list is not empty, take $count items and 
        // sort it by key [timestamps] in descending order
        $items = [];
        if ($alerts)
        {
            krsort($alerts);

            foreach ($alerts as $alert)
            {
                $items[] = $alert;
            }

            $items = array_slice($items, $index, $count);
        }

        return $items;
    }

    /**
     * Format old audits  and return them as an array
     *
     * @param integer $count
     * @param string $format
     * @return array
     **/

    public static function getJSFormatedOldAudits($count, $format = "%b %D, %h:%i %p", $index = 0){

        $user_id = \Auth::User()->id;
        $lsp_id  = \Auth::User()->lsp_id;

        $limit   = ($index) ? ($index+1) * $count : $count;


        /* Fetch Location Old Audits */
        // MYSQL
        /*$locations = \Location::select('id','site',\DB::raw('datediff(curdate(),date_format(updated_at,"%Y-%m-%d")) as days') ,\DB::raw('DATE_FORMAT(updated_at,\''.$format.'\') as formatted_date,UNIX_TIMESTAMP(updated_at) as unixtime'))
                    ->orderBy('days','DESC')
                    ->limit($limit); */
        $mssqlformat = 'MMM dd"th", HH:mm tt';
        // MSSQL
        $locations = \Location::select('id','site',\DB::raw("datediff(day,format(updated_at,'yyyy-MM-dd'),getdate()) as days") ,\DB::raw("format(updated_at,'".$mssqlformat."') as formatted_date,DATEDIFF(s,'19700101',updated_at) as unixtime"))
                    ->orderBy('days','DESC');

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $locations->where('auditor_id', $user_id);
        }

         // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $locations->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }

        $locations->where(\DB::raw("datediff(day,format(updated_at,'yyyy-MM-dd'),getdate())"),'>=',365);
        $locations->where('status','!=','inactive');

        $locations = $locations->get();


        /* Fetch Route Old Audits */
        //MYSSQL
      /*  $routes = \Routes::select('id','start_site','end_site',\DB::raw('datediff(curdate(),date_format(updated_at,"%Y-%m-%d")) as days'),\DB::raw('DATE_FORMAT(updated_at,\''.$format.'\') as formatted_date,UNIX_TIMESTAMP(updated_at) as unixtime'))
                  ->orderBy('days')
                  ->limit($limit); */

        $routes = \Routes::select('id','start_site','end_site',\DB::raw("datediff(day,Format(updated_at,'yyyy-MM-dd'),getdate()) as days"),\DB::raw("Format(updated_at,'".$mssqlformat."') as formatted_date,datediff(s,'19700101',updated_at) as unixtime"))
                  ->orderBy('days');

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $routes->where('auditor_id', $user_id);
        }


        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $routes->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }
        //mysql
       // $routes->where(\DB::raw("datediff(curdate(),date_format(updated_at,'%Y-%m-%d'))"),'>=',365);
        //mssql
        $routes->where(\DB::raw("datediff(day,FORMAT(updated_at,'yyyy-MM-dd'),getdate())"),'>=',365);

        $routes->where('status','!=','inactive');

        $routes = $routes->get();          

        $locations_array = [];

        foreach ($locations as $location)
        {
            $locations_array[$location->unixtime] = [
                'id'   => $location->id,
                'url'  => route('locations.show', [$location->id]),
                'type' => 'location',
                'icon' => 'fa-location-arrow',
                'text' => 'Location Audit created for the site '. $location->site,
                'date' => $location->formatted_date,
                'days' => $location->days,
            ];
        }

        $routes_array  = [];

        foreach($routes as $route){
            $routes_array[$route->unixtime] = [
                'id'   => $route->id,
                'url'  => route('routes.show', [$route->id]),
                'type' => 'route',
                'icon' => 'fa-location-arrow',
                'text' => 'Route Audit created for the site '. $route->start_site.' to '.$route->end_site,
                'date' => $route->formatted_date,
                'days' => $route->days,
            ];
        }

        $auidts = $locations_array + $routes_array;

        ksort($auidts);

        $item = array_slice($auidts,$index,$count);

       // print "<pre>"; print_r($locations_array); exit;

        return $item;
    }


    /**
     *  Audit Change Status inactive
     *
     *  @var String
     **/
    public static function changeOldAuditStatus($audit){

        if(!empty($audit['route']) && isset($audit['route'])){
            \Routes::whereIn('id',$audit['route'])->update(array('status'=>'inactive'));
        }

        if(!empty($audit['location']) && isset($audit['location'])){
            \Location::whereIn('id',$audit['location'])->update(array('status'=>'inactive'));
        }

    }


     
    /**
     *  Inspect Audit Status
     *
     *
     **/

    public static function getJsFormatedInspectAudits(){

            $open_site= \SiteCorrectiveAction::select(\DB::raw('count(id) as open_site'))
                                                ->whereNull('vam_approval')
                                                ->orWhere('vam_approval', '=','')
                                                ->orWhere('vam_approval', '=','ignore')
                                                ->lists('open_site');

            $closed_site = \SiteCorrectiveAction::select(\DB::raw('count(id) as closed_site'))
                                                ->where('vam_approval', '=','accept')
                                                ->lists('closed_site');

            $request_site = \SiteCorrectiveAction::select(\DB::raw('count(id) as request_site'))
                                                ->where('supplier_request_closure', '=','inprogress')
                                                ->lists('request_site');


            $results = [ 
                        ['label'=>'Closed Site','value'=> (@$closed_site[0])?:'0' ],
                        ['label'=>'Open Site','value' => (@$open_site[0])?:'0' ],
                        ['label'=>'Request Due','value'=> (@$request_site[0])?:'0']
                      ];
             
            if($closed_site[0] == 0 && $open_site[0] == 0 &&  $request_site[0] == 0){
                 $results = [];
            }
  
           return json_encode($results);

    }


    /**
     *
     *
     *
     **/

    public static function getJsFormatInspectionData(){
      
        //echo "<pre>"; print_r(\Auth::user()->site_user_level);exit;
        $user = \Auth::user();
        $sitaca = [];

        switch($user->site_user_level){
               
               case 'vam':
                     $sit_id = explode(',',preg_replace('/[^0-9\,]/', '', $user->user_vam_site_id));   
                     $sitaca =  \SiteCorrectiveAction::with('sitemaster')->select(\DB::raw("count(case when vam_approval IS NOT NULL THEN 'closed' end) as closed,count(case when vam_approval is NULL Then 'open' end) as opens,sitemaster_id"))
                                        ->whereIn('sitemaster_id', $sit_id)
                                        ->groupBy(\DB::raw("sitemaster_id"));
                     $sitaca =  $sitaca->get();
               break;
               case 'csm':
                     $sitaca =  \SiteCorrectiveAction::with('sitemaster')->select(\DB::raw("count(case when days_past_due IS NOT NULL THEN 'closed' end) as closed,count(case when days_past_due is NULL Then 'open' end) as opens,sitemaster_id"))
                                        ->where('supplier_request_closure', 'inprogress')
                                        ->groupBy(\DB::raw("sitemaster_id"));
                     $sitaca =  $sitaca->get();
               break;
        }

       
        //echo "<pre>"; print_r((array)$sitaca->[]); exit;
        return $sitaca;
    }



    /**
     *
     *
     *
     **/
    public static function getJSFormattedIncidentsLsp($data=null){ 

         $select= "c.name as label,SUM(p.total_value_of_lost_units) as 'value'";  
        if(!empty($data)){
            if($data == 'value')
               $select = "c.name as label,count(incidents.id)  as 'value'";
        }

        $inc_lsp = \Incident::leftjoin('users as u','incidents.user_id','=','u.id')
                         ->leftjoin('lsps as c','u.lsp_id','=','c.id')
                         ->leftjoin('regions as r','incidents.region_id','=','r.id')
                         ->leftjoin('countries as l','incidents.country_id','=','l.id')
                         ->leftjoin('products as p','incidents.id','=','p.incident_id')
                          ->select(\DB::raw($select));
                        if(\Auth::user()->role !='admin')  
                         $inc_lsp->where('u.lsp_id',\Auth::user()->lsp_id);

                         $inc_lsp->groupby(\DB::raw('c.name'));

        $results = $inc_lsp->get()->toArray();

       // print "<pre>"; print_r(\Auth::user()->lsp_id); exit;

        return json_encode($results);
    }

   




}