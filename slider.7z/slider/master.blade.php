<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Microsoft Supply Chain Security Solutions</title>
	{{ HTML::style('css/style.min.css') }}
    {{ HTML::style('css/stylesheet.css') }}
    <link href="http://10.147.103.247:81/css/plugins/ionRangeSlider/ion.rangeSlider.css" rel="stylesheet">
    <link href="http://10.147.103.247:81/css/plugins/ionRangeSlider/ion.rangeSlider.skinFlat.css" rel="stylesheet">
   
    <script type='text/javascript' src="/js/ie/modernizr.min.js"></script>
    <script type='text/javascript' src="/js/ie/css3-mediaqueries.js"></script> 
    <script src="http://10.147.103.247:81/js/jquery-2.1.1.js"></script>                
    <script src="http://10.147.103.247:81/js/plugins/ionRangeSlider/ion.rangeSlider.min.js"></script>

    <!-- For IE8 -->
    <!--[if lt IE 10]>
      <script src="/js/ie/html5shiv.min.js"></script>
      <script src="/js/ie/respond.min.js"></script>
    <![endif]-->

</head>
<body class="{{ MSLST_Common::pageClasses() }}" id="loginBody">
       
    <div id="wrapper">
        @include('layouts.header')

        @if(Auth::check() && Route::getCurrentRoute()->getUri() != 'terms')

            @if(Auth::user()->isAdmin())

                @include('layouts.menu-admin')

            @elseif(Auth::user()->isSupervisor())

                @include('layouts.menu-supervisor')

            @else

                @include('layouts.menu-user')
                
            @endif
        
        @endif

       @if(Session::get('settings_site_alert_option') == 1)
            <nav class='marquebar alert alert-info'> <marquee>{{Session::get('settings_site_alert_message')}} </marquee></nav>
       @endif

        @yield('content')


    </div>
    <!-- /#wrapper -->

    @include('layouts.footer')

     @if(preg_match('/(sitemaster|incidents)\/((([0-9]+)\/(edit|(edit\/(0)))|create)|([0-9]+))/',Request::path()))
   <!--  <script type="text/javascript" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>-->
    @endif
    {{ HTML::script('js/scripts.min.js') }}

 
   

</body>
</html>