@extends('layouts.master')

@section('content')
 
<script type="text/javascript">
    var Dashboard = {};
    Dashboard.userrole = '{{Auth::User()->role}}';
    Dashboard.audits = JSON.parse('{{ $audits }}');
    @if(Auth::User()->access_incidents)
    Dashboard.incidents = JSON.parse('{{ $incidents }}');
    Dashboard.incidentStatus = JSON.parse('{{ $incident_status }}');
    Dashboard.incidentCategory = JSON.parse('{{ $incident_category }}');

    @endif
    Dashboard.userStatus = JSON.parse('{{ $user_status }}');
    Dashboard.inspect_audit_status = {};
    Dashboard.incidentLsp = JSON.parse('{{ $incident_lsp }}');
    @if(\Auth::User()->isAdmin())
     // Dashboard.inspect_audit_status = JSON.parse('{{ $inspect_audit_status }}');
   @endif   

    
</script>

<div id="page-wrapper">
<?php //echo "Am hauhdfsf"; print_r($incidentsFinancialYear); exit;?>
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">Dashboard</h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
        <div class="col-lg-8">
            <ul id="draggableLeftPanel" class="list-unstyled">
                    <!-- /.panel -->
             @if(isset($site_inspec_notification[0]))
               @if(\Auth::User()->site_user_level == 'vam' &&  !empty(\Auth::User()->site_user_level))
                <li  id="inspect_audit_status" class="panel panel-default" data-sort="{{ array_search('inspect_audit_status', $right_order) }}">
                    <div class="row">
                           <div class="col-lg-12">
                              
                              <div class="ibox float-e-margins">
                                  <div class="panel-heading">
                                   <i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold">Inspection Status - VAM Approvals</span>
                                 </div>
                                  <div class="ibox-content">
                                      <table class="table table-hover">
                                          <thead>
                                          <tr>
                                              <th>#</th>
                                              <th>Sitename</th>
                                              <th>Completed</th>
                                              <th>Status</th>
                                               <th>CAs</th>
                                               <th>Last Inspection Date</th>
                                          </tr>
                                          </thead>
                                          <tbody>
                                          @foreach($site_inspec_notification as $key=>$value)

                                          <tr class="clickable-row sitemasters-item" data-id="{{$value['sitemaster_id']}}">
                                              <td>{{$value['sitemaster_id']}}</td>
                                              <td>{{$value->sitemaster['site_name']}}</td>
                                              <td><span class="pie">{{$value['closed']}},{{$value['opens']}}</span></td>
                                              <td class="text-navy">  <?php $a = $value['closed']/($value['closed'] + $value['opens'])*100;  echo floor($a)."%"; ?></td>
                                              <td class="text-navy">  {{$value['closed'] + $value['opens']}}</td>
                                              <td class="text-navy">  {{($value->sitemaster['last_inspection_date'])?$value->sitemaster['last_inspection_date']->format('Y-M-d'):'NA'}}</td>
                                          </tr>
                                         @endforeach
                                          </tbody>
                                      </table>
                                  </div>
                              </div>
                           </div>
                    </div>
                </li>
               @elseif(\Auth::User()->site_user_level == 'csm')
                <li id="inspect_audit_status" class="panel panel-default" data-sort="{{ array_search('inspect_audit_status', $right_order) }}">
                    <div class="row">
                           <div class="col-lg-12">
                              <div class="ibox float-e-margins panel-default">
                                 <div class="panel-heading">
                                   <i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold"> Inspection Status - Request Due Date Extension</span>
                                 </div>
                                 <div class="ibox-content">
                                      <table class="table table-hover">
                                          <thead>
                                          <tr>
                                              <th>#</th>
                                              <th>Sitename</th>
                                              <th>Request</th>
                                              <th>Completed</th>
                                              <th>Next Scheduled Visit</th>
                                              <th>Remaining Time (in Days)</th>
                                          </tr>
                                          </thead>
                                          <tbody>
                                          @foreach($site_inspec_notification as $key=>$value)
                                          <tr class="clickable-row sitemasters-item" data-id="{{$value['sitemaster_id']}}">
                                              <td>{{$value['sitemaster_id']}}</td>
                                              <td>{{$value->sitemaster['site_name']}}</td>
                                              <td><span class="pie">{{$value['closed']}},{{$value['opens']}}</span></td>
                                              <td class="text-navy">  <?php $a = $value['closed']/($value['closed'] + $value['opens'])*100;  echo floor($a)."%"; ?></td>
                                              <td class="text-navy">{{($value->sitemaster['next_site_visit'])? $value->sitemaster['next_site_visit']->format('Y-M-d'):'NA'}}</td>
                                              <td class="text-navy">  {{($value->sitemaster['next_site_visit'])? $value->sitemaster['next_site_visit']->diffInDays(\Carbon\Carbon::now()):'NA' }}</td>
                                          </tr>
                                         @endforeach
                                          </tbody>
                                      </table>
                                  </div>
                              </div>
                           </div>
                    </div>
                </li>
               @endif
             @endif  
              @if(Auth::User()->access_incidents || Auth::User()->isAdmin())
              <li id="incident_trend" class="panel panel-default" data-sort="{{ array_search('incident_trend', $left_order) }}">
                  <div class="panel-heading">
                      <i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold">Incidents</span>
                      <div class="pull-right">
                          <div class="btn-group inc-dash-date">
                              {{Form::select('incidentcharttype' ,array('line'=>'Line','area'=>'Area','bar'=>'Bar'),'line',array('id'=>'incidentcharttype'))}}
                              {{Form::select('incidenttype' ,array('number'=>'Number','value'=>'Value'),'default',array('id'=>'incidenttype'))}}
                              {{--Form::select('incidentsdate' ,array('1#month'=>'1 Month','3#month'=>'3 Month','6#month'=>'6 Month','1#year'=>'1 Year'),'1#year',array('id'=>'incidentsdate'))--}}
                              {{Form::select('incidentsdate' ,array('3#month'=>'3 Month','6#month'=>'6 Month','1#year'=>'1 Year'),'1#year',array('id'=>'incidentsdate'))}}
                          </div>
                          <div class="btn-group">
                              <button type="button" class="btn btn-default btn-xs" href="{{ route('incidents.index') }}">
                                  View all Incidents
                              </button>
                          </div>
                      </div>
                  </div>
                  <!-- /.panel-heading -->
                  
                  <div class="panel-body">
                      <div id="incidents-area-chartdiv">
                         <canvas id="incidents-area-chart" ></canvas>
                    </div>

                    <div id="ionrange_1"></div>
                  </div>
                  <!-- /.panel-body -->
              </li>
            @endif

           @if(Auth::user()->access_audits || Auth::User()->isAdmin()) 

              <!-- /.panel -->
              <li id="audit_trend" class="panel panel-default" data-sort="{{ array_search('audit_trend', $left_order) }}">
                  <div class="panel-heading">
                      <i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold">Audits</span>
                      <div class="pull-right">
                          <div class="btn-group inc-dash-date">
                            {{Form::select('auditcharttype' ,array('line'=>'Line','area'=>'Area','bar'=>'Bar'),'line',array('id'=>'auditcharttype'))}}
                              {{Form::select('auditdate' ,array('3#month'=>'3 Month','6#month'=>'6 Month','1#year'=>'1 Year'),'1#year',array('id'=>'auditdate'))}}
                          </div>
                          <div class="btn-group">
                              <button type="button" class="btn btn-default btn-xs" href="{{ action('AuditsController@getIndex') }}">
                                  View all Audits
                              </button>
                          </div>
                      </div>
                  </div>
                  <!-- /.panel-heading -->
                  <div class="panel-body">
                     
                      <div id="audits-area-chartdiv">
                          <canvas id="audits-area-chart"></canvas>
                      </div>
                     
                  </div>
                  <!-- /.panel-body -->
              </li>
              <!-- /.panel -->
            @endif

              @if(\Auth::User()->isAdmin())
              <li id="recent_users" class="panel panel-default" data-sort="{{ array_search('recent_users', $left_order) }}">
                  <div class="panel-heading">
                      <i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold"> Recent Users</span>
                      <div class="pull-right">
                          <div class="btn-group">
                              <button type="button" class="btn btn-default btn-xs" href="{{ route('users.index') }}">
                                  View Users
                              </button>
                          </div>
                      </div>
                  </div>
                  <!-- /.panel-heading -->
                  <div class="panel-body">
                      <div class="list-group">
                          @foreach($recent_users as $user)
                          <a href="{{ route('users.edit', $user->user_id) }}" class="list-group-item">
                              <i class="fa fa-user fa-fw"></i> <small>{{ $user->user->name }}</small>
                              <span class="pull-right text-muted small"><em>{{ $user->login }}</em>
                              </span>
                          </a>
                          @endforeach
                      </div>
                      <!-- /.list-group -->
                  </div>
                  <!-- /.panel-body -->
               </li>
               <!-- /.panel -->
               @endif
            </ul>
        </div>
        <!-- /.col-lg-8 -->
        <div class="col-lg-4">
            <ul id="draggableRightPanel" class="list-unstyled">
              @if(Auth::user()->access_incidents || Auth::user()->access_audits || Auth::User()->isAdmin())
              <li id="recent_audits" class="panel panel-default" data-sort="{{ array_search('recent_audits', $right_order) }}">
                  <div class="panel-heading">
                      <i class="fa fa-bullhorn fa-fw"></i> <span class="font-bold">Recent Audits and Incidents</span>
                  </div>
                  <!-- /.panel-heading -->
                  <div class="panel-body recent-audits">
                      <div id="alerts-box" class="list-group">
                          @foreach($alerts as $alert)
                          <a href="{{ $alert['url'] }}" class="list-group-item">
                              <i class="fa {{ $alert['icon'] }} fa-fw"></i> <small>{{ $alert['text'] }}</small>
                              <span class="pull-right text-muted small"><em>{{ $alert['date'] }}</em>
                              </span>
                          </a>
                          @endforeach
                      </div>
                      <!-- /.list-group -->
                      <a href="javascript:void(0);" id="more-alerts" class="btn btn-default btn-block">View Older Alerts</a>
                  </div>
                  <!-- /.panel-body -->
              </li>
              @endif
              <!-- /.panel -->
              @if(Auth::user()->access_incidents || Auth::User()->isAdmin())
              <li id="incident_status" class="panel panel-default" data-sort="{{ array_search('incident_status', $right_order) }}">
                  <div class="panel-heading">
                      <i class="fa fa-pie-chart fa-fw"></i> <span class="font-bold">Incident Status</span>
                  </div>
                  <div class="panel-body">
                      <div id="incident-status-donut-chart"></div>
                      <a href="{{ route('incidents.index') }}" class="btn btn-default btn-block">View Details</a>
                  </div>
                  <!-- /.panel-body -->
              </li>
              @endif
              @if(Auth::user()->access_incidents || Auth::User()->isAdmin())
              <li id="incident_lsp" class="panel panel-default" data-sort="{{ array_search('incident_lsp', $right_order) }}">
                  <div class="panel-heading">
                      <i class="fa fa-pie-chart fa-fw"></i> <span class="font-bold">Incident Lsp</span>
                      <div class="pull-right">
                            <div class="btn-group inc-dash-date">
                               {{Form::select('incidenttype_lsp' ,array('number'=>'Number','value'=>'Value'),'default',array('id'=>'incidenttype_lsp'))}}
                              </div>
                      </div>
                  </div>
                  <div class="panel-body">
                      <div id="incident-lsp-donut-chart"></div>
                      <a href="{{ route('incidents.index') }}" class="btn btn-default btn-block">View Details</a>
                  </div>
                  <!-- /.panel-body -->
              </li>
              @endif
              <!-- /.panel -->
              @if(Auth::user()->access_incidents || Auth::User()->isAdmin())
              <li id="incident_category" class="panel panel-default" data-sort="{{ array_search('incident_category', $right_order) }}">
                  <div class="panel-heading">
                      <i class="fa fa-pie-chart fa-fw"></i> <span class="font-bold"> Incident Category</span>
                  </div>
                  <div class="panel-body">
                      <div id="incident-category-donut-chart"></div>
                      <a href="{{ route('incidents.index') }}" class="btn btn-default btn-block">View Details</a>
                  </div>
                  <!-- /.panel-body -->
              </li>
              <!-- /.panel -->
            @endif

               <!-- /.panel -->
        @if(\Auth::User()->isAdmin())
              <li id="user_status" class="panel panel-default" data-sort="{{ array_search('user_status', $right_order) }}">
                  <div class="panel-heading">
                      <i class="fa fa-pie-chart fa-fw"></i> <span class="font-bold"> User Status</span>
                  </div>
                  <div class="panel-body">
                      <div id="user-status-donut-chart"></div>
                      <a href="{{ route('users.index') }}" class="btn btn-default btn-block">View Details</a>
                  </div>
                  <!-- /.panel-body -->
              </li>
        @endif
              <!-- /.panel -->

        <!-- /.panel -->
        @if(\Auth::User()->isAdmin())
             <!-- <li id="inspect_audit_status" class="panel panel-default" data-sort="{{ array_search('inspect_audit_status', $right_order) }}">
                  <div class="panel-heading">
                      <i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold"> Inspection Audit Status</span>
                  </div>
                  <div class="panel-body">
                      <div id="inspect-audit-status-donut-chart"></div>
                  </div>
                  
              </li> -->
        @endif
            </ul>
        </div>
        <!-- /.col-lg-4 -->
    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->
<script>   
               
 $("#ionrange_1").ionRangeSlider({
             values: [
                        "Jan 2015", "Feb 2015", "Mar 2015",
                        "Apr 2015", "May 2015", "Jun 2015",
                        "Jul 2015", "Aug 2015", "Sep 2015",
                        "Oct 2015", "Nov 2015", "Dec 2015",
                        "Jan 2016", "Feb 2016", "Mar 2016",
                        "Apr 2016", "May 2016", "Jun 2016"                 
                         ],
            
             type: 'double',
             prefix: "FY - ",
             maxPostfix: "",
             prettify: false,
             hasGrid: false
         }); 

    var slider = $("#ionrange_1").data("ionRangeSlider");

        </script>
        <script type="text/javascript">
         $(document).on('click', '.irs-slider', function () {
          $FinYear = $('span.irs-single').text(); 
          var $resFinyear = $FinYear.split("—");
          alert($resFinyear);
          });
        </script>
@stop