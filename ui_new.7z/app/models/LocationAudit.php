<?php

class LocationAudit extends \Eloquent {
	protected $fillable = [
        'location_id',
        'question_id',
        'answer_id',
        'comment',
        'is_archived',
    ];

    /**
     * The location relationship data for this model.
     *
     * @var object
     */
    public function location()
    {
        return $this->belongsTo('Location');
    }

    /**
     * The question relationship data for this model.
     *
     * @var object
     */
    public function question()
    {
        return $this->belongsTo('Question');
    }

    /**
     * The answer relationship data for this model.
     *
     * @var object
     */
    public function answer()
    {
        return $this->belongsTo('Answer');
    }
}