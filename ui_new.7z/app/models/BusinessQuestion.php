<?php

class BusinessQuestion extends \Eloquent {
	protected $fillable = [
		'name',
		'order',
        'availability',
        'category',
        'activities'
	];
	use SoftDeletingTrait;

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $rules = [
        'text'           => 'required|unique:questions,text',
        'availability'   => 'required|in:',
        'order'          => 'required|integer|min:0',
        'activities'     => 'required',
    ];

    public function categories()
    {
        return $this->belongsTo('BusinessCategory');
    }
    
	/**
	 * Get Dates
	 *
	 **/
	
	 public function getDates()
    {
        return array('created_at', 'updated_at', 'deleted_at');
    }
}