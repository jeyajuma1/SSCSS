<?php

class SiteLpCorrectiveAction extends \Eloquent {
	
	protected $fillable = [
	'question_id',
	'site_master_id',
	'requirement_text',
	'category',
	'severity',
	'assessment_comments',
	'initial_due_date',
	'ext_due_date',
	'assement_user_id',
	'assement_user_comments',
	'pm_user_id',
	'pm_approval',
	'pm_comments'
	];

	use SoftDeletingTrait;



	/**
	 *
	 * return @belongs
	 **/

	public function user(){
     	return $this->belongsTo('User','assement_user_id')->select('id','first_name','last_name','role','site_user_level')->withTrashed();
    }

     /**
      * Get the format for database stored dates.
      *
      * @return string
      */
      public function getDateFormat()
      {
            return 'Y-m-d H:i:s.u';
      }

      /**
       * Convert a DateTime to a storable string.
       * SQL Server will not accept 6 digit second fragment (PHP default: see getDateFormat Y-m-d H:i:s.u)
       * trim three digits off the value returned from the parent.
       *
       * @param  \DateTime|int  $value
       * @return string
       */
      public function fromDateTime($value)
      {
          return substr(parent::fromDateTime($value), 0, -3);
      }



	/**
     * The get date mutoators for incidents table
     *
     * @return array
     */
    public function getDates()
    {
        return array('created_at', 'updated_at', 'deleted_at','initial_due_date','due_date_extension');
    }

}