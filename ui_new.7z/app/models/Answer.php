<?php

class Answer extends \Eloquent {
	protected $fillable = [];
}