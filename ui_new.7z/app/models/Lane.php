<?php

class Lane extends \Eloquent {
	protected $fillable = [];

	use SoftDeletingTrait;

	/**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'lanes';

     /**
     * The user relationship data for this model.
     *
     * @var object
     */

     public function user()
     {
     	return $this->belongsTo('user','user_id');
     }

     /**
     * The lsp relationship data for this model.
     *
     * @var object
     */

     public function lsp()
     {
     	retun $this->belongsTo('lsp','lsp_id');
     }

}