<?php

class Attachment extends \Eloquent {
	protected $fillable = [
        'attachment_type',
        'file_name',
        'file_description',
        'file_type',
        'description',
        'incident_id',
        'attachment_info'
    ];

    use SoftDeletingTrait;

    /**
     * The incident relationship data for this model.
     *
     * @var object
     */
    public function incident()
    {
        return $this->belongsTo('Incident');
    }
}