<?php

class LocationCertification extends \Eloquent {
	protected $fillable = [
		'certificate_file',
		'filename',
		'location_id',
		'certification_id',
	];
}