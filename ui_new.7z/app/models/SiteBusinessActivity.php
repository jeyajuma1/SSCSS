<?php

class SiteBusinessActivity extends \Eloquent {
	protected $fillable = ['name'];
	
	use SoftDeletingTrait;
}