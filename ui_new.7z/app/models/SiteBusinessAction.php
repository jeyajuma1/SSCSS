<?php

class SiteBusinessAction extends \Eloquent {
	protected $fillable = [];
}