<?php

class LocationCertificationDisabledGroup extends \Eloquent {
	protected $fillable = [
		'certification_group_id',
		'location_id',
	];
}