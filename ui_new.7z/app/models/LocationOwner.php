<?php

class LocationOwner extends \Eloquent {
	protected $fillable = [
		'location_id',
		'user_id',
	];
}
