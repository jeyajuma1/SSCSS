<?php

class LaneLocations extends \Eloquent {

	protected $fillable = [];

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'lane_locations';

    /**
     * The user relationship data for this model.
     *
     * @var object
     */
    public function location()
    {
        return $this->belongsTo('Location', 'location_id')->select('id','site','address','coordinates','tapa_needed','auditor_id','country_id','lsp_id','status');
    }
	
	/**
     * The user relationship data for this model.
     *
     * @var object
     */
    public function lane()
    {
        return $this->belongsTo('Lanes', 'lane_id');
    }
	
	

	 

  
}