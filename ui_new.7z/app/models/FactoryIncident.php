<?php
use MSLST\Constants\Site;
class FactoryIncident extends \Eloquent {
	protected $fillable = [
    'short_description',
    'facility',
    'coordinates',
    'persons_involved',
    'loss_discovered_by',
    'location_of_incident_within_sitepremises',
    'region_id',
    'country_id',
    'location_address',
    'city',
    'user_id',
    'incident_event_date'
    ];

	 use SoftDeletingTrait;

	/**
     * The rules to be applied to the data.
     *
     * @var array
    */

    public static $basic_information_rules = [
	    'incident_event_date' => 'required|date_format:Y-m-d',
	    'region' => 'required',
	    'country' => 'required',
        'city' => 'required|alpha_spaces',
         'coordinates' => 'required|coordinates',
    ];


    /**
     * The rules to be applied to data
     * @var array
     **/

    public static $incident_detail_rules = [
    	'persons_involved' => 'required',
    	'loss_discovered_by' =>'required',
    	'location_of_incident_within_sitepremises' => 'required',
        'product_description'  => 'array|required',
        'product_family'  => 'array|required|min:0',
        'part_number'  => 'array|required|min:0',
        'number_of_unit_missing'  => 'array|required|min:0',
        'value_per_unit'  => 'array|required|min:0',
        'serial_number'  => 'array|required|min:0',
        'total_value_of_loss_unit' => 'required|numeric|min:0'
    ];

    /**
     * The rules to be applied to data
     * @var array
     **/

    public static $investigation_attachment_rules = [
    	'name_of_investigation_authority' => 'required',
    	'contact_information' => 'required|Regex:/[0-9\-\(\)\+\s]+$/',
		'incident_refered_to' => 'required',
        'investigation_file_number' => 'required|min:0',
    	'on_date' => 'required|date_format:Y-m-d',
    	'investigation_description_and_action_taken' => 'required',
    	'final_investigation_findings_cause_analysis_corrective_actions' => 'required',
    	'current_investigation_status' => 'required',
    ];

    public static $messages = [
        'incident_event_date.required' => 'The date of event field is required',
        'incident_event_date.date'=>'The date of event does not match the format Y-m-d.',
        'investigation_description_and_action_taken.required' => 'The Investigation description and actions taken is required',
        'final_investigation_findings_cause_analysis_corrective_actions.required'=>'The Final investigation findings, root cause analysis & corrective actions is required',
        'city.alpha_spaces'=>'The city field may only contain letters and spaces.', 
    ];
    
    /**
     * Return the incident name.
     *
     * @return string
     */
    public function getNameAttribute() 
    {
        return Site::FACTORY_INCIDENT_PREFIX . $this->id;
    }


    /**
     *  
     *
     **/
    public function user(){
        return $this->belongsTo('User');
    }

    /**
     *  
     *
     **/
    public function country(){
        return $this->belongsTo('Country');
    }

    /**
     *  
     *
     **/
    public function region(){
        return $this->belongsTo('Region');
    }

     /**
     * The product relationship data for this model.
     *
     * @return object
     */
    public function product()
    {
        return $this->hasOne('ProductFactoryIncident');
    }

    /**
     *
     * The investigation relationship data for this model
     * @return object
     **/

    public function investigation(){
        return $this->hasOne('FactoryIncidentInvestigationDetail');
    }

    /**
     *
     * The Attachments relationship data for this model
     * @return object
     **/

    public function attachment(){
        return $this->hasMany('FactoryAttachments');
    }


    /**
     *
     * The factory incident_log relationship data for this model
     * @return object
     **/

    public function incidentlog(){
        return $this->hasMany('FactoryIncidentLog');
    }
     /**
     * The get date mutoators for incidents table
     *
     * @return array
     */
    public function getDates()
    {
        return array( 'incident_event_date', 'closed_at', 'created_at', 'updated_at', 'deleted_at');
    }
}