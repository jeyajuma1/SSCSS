<?php

class UserRegion extends \Eloquent {

	protected $Fillable = [];

	/**
     * The region relationship data for this model.
     *
     * @var object
     */
	public function region(){
		return $this->belongsTo('Region','region_id')->withTrashed();
	}

	/**
     * The user relationship data for this model.
     *
     * @var object
     */
	public function user(){
		return $this->belongsTo('User','user_id')->withTrashed();
	}

}

?>
