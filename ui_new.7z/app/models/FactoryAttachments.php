<?php

class FactoryAttachments extends \Eloquent {
	protected $fillable = [
		'attachment_type',
        'file_name',
        'file_description',
        'file_type',
        'description',
        'factory_incident_id'];

         use SoftDeletingTrait;

         /**
     * The incident relationship data for this model.
     *
     * @var object
     */
    public function factoryincident()
    {
        return $this->belongsTo('FactoryIncident');
    }
}