<?php

class SiteInspectionsAnswer extends \Eloquent {
	protected $fillable = [
							'ins_main_date',
							'ins_main_num_sep_buliding_at_this_site',
							'ins_main_num_buliding_ms_related_functions',
							'ins_main_inspectors',
							'ins_main_comments',
							'ins_main_num_full_time_emp_facility',
							'ins_main_supp_subcontract_handling_ms_product_ip',
							'ins_main_emp_ms_system_account',
							'ins_main_name_alias_access',
							'summ_company_background',
							'summ_overview_inspection_work',
							'summ_facility_site_desc',
							'summ_people_interview_during_inspec',
							'sc_pr_req_excepted',
							'sc_pr_req_required',
							'sc_pr_req_accumulated',
							'sc_pr_req_percent',
							'sc_pr_score_excepted',
							'sc_pr_score_required',
							'sc_pr_score_accumulated',
							'sc_pr_score_percent',
							'sc_calulated_score',
							'sc_scoring_rules_final_rating',
							'user_id',
							'sitemaster_id'
						];

		use SoftDeletingTrait;


		/**
	     * The get date mutoators for incidents table
	     *
	     * @return array
	     */
	    public function getDates()
	    {
	        return array('ins_main_date','created_at', 'updated_at', 'deleted_at');
	    }

}