<?php

class Region extends \Eloquent {
	protected $fillable = ['name'];

	use SoftDeletingTrait;

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
	public static $rules = [
        'name'    => 'required|unique:regions,name',
    ];

    /**
     * The countries relationship data for this model.
     *
     * @var object
     */
    public function countries()
    {
        return $this->hasMany('Country');
    }
}