<?php

class SiteBusinessRisk extends \Eloquent {
	protected $fillable = [];
	use SoftDeletingTrait;
}