<?php

class RouteLog extends \Eloquent {
	protected $fillable = [
        'route_id',
        'user_id',
    ];
	
    /**
     * The user relationship data for this model.
     *
     * @var object
     */
    public function user()
    {
        return $this->belongsTo('User')->withTrashed();
    }
}