<?php

class RouteCertificationDisabledGroup extends \Eloquent {
	protected $fillable = [
		'certification_group_id',
		'route_id',
	];
}