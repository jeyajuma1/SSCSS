<?php

class Setting extends \Eloquent {
	protected $fillable = [];
    
    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
	public static $rules = [
        MSLST_Email::SITE_EMAIL   => 'email',
    ];

}