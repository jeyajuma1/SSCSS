<?php

class LocationLog extends \Eloquent {
	protected $fillable = [
        'location_id',
        'user_id',
        'created_at',
        'updated_at'
    ];

    /**
     * The user relationship data for this model.
     *
     * @var object
     */
    public function user()
    {
        return $this->belongsTo('User')->withTrashed();
    }


     /**
     * The incident relationship data for this model.
     *
     * @var object
     */
    public function location()
    {
        return $this->belongsTo('Location');
    }

}