<?php

class IncidentOwner extends \Eloquent {
	protected $fillable = [
		'incident_id',
		'user_id',
	];
}
