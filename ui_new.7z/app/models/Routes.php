<?php

use MSLST\Constants\Site;

class Routes extends \Eloquent {
	protected $fillable = [
        'start_site',
        'end_site',
        'start_address',
        'end_address',
        'start_coordinates',
        'end_coordinates',
        'start_carrier',
        'end_carrier',
        'comment',
        'score',
        'ctpat_number',
        'aeo_number',
        'review',
        'tapa_needed',
        'auditor_id',
        'start_country_id',
        'end_country_id',
        'lsp_id',
        'status'
    ];

    use SoftDeletingTrait;
    
    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'routes';

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $basic_details_rules = [
        'start_site'          => 'required',
        'end_site'            => 'required',
        'start_address'       => 'required',
        'end_address'         => 'required',
        'start_coordinates'   => 'required|coordinates',
        'end_coordinates'     => 'required|coordinates',
        'start_country'       => 'required|exists:countries,id',
        'end_country'         => 'required|exists:countries,id',
    ];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $needed_certification_rules = [
        'tapa_needed'     => 'required|in:',
    ];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $actual_certification_rules = [
        'tapa'              => 'required|in:',
        'ctpat'             => 'required|in:',
        'aeo'               => 'required|in:',
        'tapa_certificate'  => 'mimes:pdf,jpg,jpeg,doc,docx|min:1|max:8192',
        'ctpat_certificate' => 'mimes:pdf,jpg,jpeg,doc,docx|min:1|max:8192',
        'aeo_certificate'   => 'mimes:pdf,jpg,jpeg,doc,docx|min:1|max:8192',
        'svi_num'           => 'Regex:/(?=.*\d)(?=.*[a-zA-Z]).{8,24}/',
        'aeo_num'           => 'Regex:/(?=.*\d)(?=.*[a-zA-Z]).{8,24}/',
    ];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $questions_rules = [
        'question'     => 'array',
    ];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $comments_rules = [
        'comments' => 'max:500'
    ];

    /**
     * Return the route name.
     *
     * @return string
     */
    public function getNameAttribute() 
    {
        return Site::ROUTE_PREFIX . $this->id;
    }

    /**
     * The user relationship data for this model.
     *
     * @var object
     */
    public function user()
    {
        return $this->belongsTo('User', 'auditor_id')->withTrashed();
    }

    /**
     * The country relationship data for this model.
     *
     * @var object
     */
    public function start_country()
    {
        return $this->belongsTo('Country', 'start_country_id');
    }

    /**
     * The country relationship data for this model.
     *
     * @var object
     */
    public function end_country()
    {
        return $this->belongsTo('Country', 'end_country_id');
    }

    /**
     * The lsp relationship data for this model.
     *
     * @var object
     */
    public function lsp()
    {
        return $this->belongsTo('Lsp');
    }

    /**
     * The question relationship data for this model.
     *
     * @var object
     */
    public function question()
    {
        return $this->belongsToMany('Question', 'route_audits', 'route_id')->withPivot('answer_id', 'comment', 'is_archived');
    }

    /**
     * The route certifications relationship data for this model.
     *
     * @var object
     */
    public function certification()
    {
        return $this->belongsToMany('Certification', 'route_certifications', 'route_id')->withPivot('id', 'certificate_file', 'filename');
    }

    /**
     * The disabled certifications relationship data for this model.
     *
     * @var object
     */
    public function disabled_certification()
    {
        return $this->hasMany('RouteCertificationDisabledGroup', 'route_id');
    }

    /**
     * The route logs relationship data for this model.
     *
     * @var object
     */
    public function route_log()
    {
        return $this->hasMany('RouteLog', 'route_id');
    }
}
