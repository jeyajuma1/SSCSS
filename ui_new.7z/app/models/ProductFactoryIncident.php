<?php

class ProductFactoryIncident extends \Eloquent {
	protected $fillable = [
				'product_description',
				'part_number',
				'serial_number',
				'product_family',
				'number_of_unit_missing',
				'value_per_unit',
				'total_value_of_loss_unit',
				'factory_incident_id'
			];
}