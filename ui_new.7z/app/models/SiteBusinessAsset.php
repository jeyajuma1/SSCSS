<?php

class SiteBusinessAsset extends \Eloquent {
	protected $fillable = [];
	use SoftDeletingTrait;
}