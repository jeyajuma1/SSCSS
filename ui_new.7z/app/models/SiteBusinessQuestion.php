<?php
use Illuminate\Database\Eloquent\SoftDeletingTrait;

class SiteBusinessQuestion extends \Eloquent {
	protected $fillable = [ 'name',
							'order',
        					'availability',
        					'category',
        					'activities',
                            'activity_id',
                            'severity_text',
                            'category_id'
						  ];

	use SoftDeletingTrait;

      protected $dates = ['deleted_at'];
	/**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $rules = [
        'text'           => 'required|unique:questions,text',
        'availability'   => 'required|in:',
        'order'          => 'required|integer|min:0',
        'activities'     => 'required',
    ];

    public function categories()
    {
        return $this->belongsTo('SiteBusinessCategory');
    }
    
	/**
	 * Get Dates
	 *
	 **/
	
	 public function getDates()
    {
        return array('created_at', 'updated_at', 'deleted_at');
    }
    
}