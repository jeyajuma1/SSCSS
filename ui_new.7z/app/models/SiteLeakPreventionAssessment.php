<?php

class SiteLeakPreventionAssessment extends \Eloquent {
	protected $fillable = ['sitemaster_id',
					   	  'leak_id',
					      'risk_id',
					      'risk',
                          'action_id',
					      'action_name',
					      'action_description',
					      'status',
					      'inc_id',
					      'file_name',
					      'file_description',
					      'file_type',
					      'sort',
                          'detail_comment_description'
					      ];

	 use SoftDeletingTrait;


	 /**
     * The leakprevent_assessment relationship data for this model.
     *
     * @var object
     */

     public function sitemaster(){
     	return $this->belongsTo('Sitemaster');
     }


     public function site_leak_risk_analysis(){
        return $this->belongsTo('SiteLeakRiskAnalysis','leak_id')->select('id','activity_id','sitemaster_id','asset_id','created_at');
    }

     /**
      *
      *
      **/
     public function site_business_risk(){
        return $this->belongsTo('SiteBusinessRisk','risk_id')->select('id');
     }


     public function user(){
     	return $this->belongsTo('User','verified_by');
     }

     /**
     * The get date mutoators for incidents table
     *
     * @return array
     */
    public function getDates()
    {
        return array( 'status_date', 'verified_date', 'created_at', 'updated_at', 'deleted_at');
    }

    /**
    * Get the format for database stored dates.
    *
    * @return string
    */
    public function getDateFormat()
    {
        return 'Y-m-d H:i:s.u';
    }

    /**
     * Convert a DateTime to a storable string.
     * SQL Server will not accept 6 digit second fragment (PHP default: see getDateFormat Y-m-d H:i:s.u)
     * trim three digits off the value returned from the parent.
     *
     * @param  \DateTime|int  $value
     * @return string
     */
    public function fromDateTime($value)
    {
        return substr(parent::fromDateTime($value), 0, -3);
    }

}