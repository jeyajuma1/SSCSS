<?php

class SiteBusinessCategory extends \Eloquent {
	protected $fillable = [];
	use SoftDeletingTrait;
}