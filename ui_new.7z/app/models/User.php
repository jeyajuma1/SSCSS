<?php

use Illuminate\Auth\UserTrait;
use Illuminate\Auth\UserInterface;
use Illuminate\Auth\Reminders\RemindableTrait;
use Illuminate\Auth\Reminders\RemindableInterface;

class User extends Eloquent implements UserInterface, RemindableInterface {

	use UserTrait, RemindableTrait, SoftDeletingTrait;

	/**
	 * The database table used by the model.
	 *
	 * @var string
	 */
	protected $table = 'users';

	/**
	 * The attributes excluded from the model's JSON form.
	 *
	 * @var array
	 */
	protected $hidden = ['password', 'remember_token'];

    /**
     * The fillable attributes of the User model.
     *
     * @var array
     */
    protected $fillable = [
        'first_name',
        'last_name',
        'email',
        'title',
        'password',
        'role',
		'username',
		'lspname',
        'site_user_level',
        'notification_audit_create',
        'notification_audit_edit',
		'access_suppliers',
        'access_sitemasters',
        'access_lanes',
        'access_audits',
        'access_incidents',
        'access_factory_incidents',
        'access_leak_prevention',
        'access_p_r' ,
        'notification_major',
        'notification_medium',
        'notification_minor',
        'notification_status',
        'notification_edit',
        'lsp_id',
        'password_updated_at',
		'incident_monthly_report',
    ];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
	public static $rules = [
        'first_name'            => 'required|alpha_spaces',
        'last_name'             => 'required|alpha_spaces',
        'email'                 => 'required|email|unique:users,email',
        'title'                 => 'required',
    ];

    /**
     * The rules to be applied to the profile data.
     *
     * @var array
     */
    public static $profileRules = [
        'first_name'            => 'required|alpha_spaces',
        'last_name'             => 'required|alpha_spaces',
        'email'                 => 'required|email|unique:users,email',
        'password'              => 'confirmed',
        'password_confirmation' => 'required|Regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&]{8,}/',
        'current_password'      => 'passcheck',
    ];

    /**
     * The administrator role identifier.
     *
     * @var string
     */
    const ADMIN_ROLE = 'admin';

    /**
     * The supervisor role identifier.
     *
     * @var string
     */
    const SUPERVISOR_ROLE = 'supervisor';

    /**
     * The user role identifier.
     *
     * @var string
     */
    const USER_ROLE = 'user';

    /**
     * Check if the user is administrator.
     *
     * @return bool
     */
    public function isAdmin()
    {
        if ($this->role == self::ADMIN_ROLE) return true;

        return false;
    }

    /**
     * Check if the user is MS manager.
     *
     * @return bool
     */
    public function isManager()
    {
        if ($this->role == self::SUPERVISOR_ROLE
            && $this->lsp->id == \MSLST\Constants\Site::HIGHEST_LEVEL_COMPANY) return true;

        return false;
    }

    /**
     * Check if the user is supervisor.
     *
     * @return bool
     */
    public function isSupervisor()
    {
        if ($this->role == self::SUPERVISOR_ROLE) return true;

        return false;
    }

    /**
     * Check if the user is normal user.
     *
     * @return bool
     */
    public function isUser()
    {
        if ($this->role == self::USER_ROLE) return true;

        return false;
    }

    /**
     * Return the user full name.
     *
     * @return string
     */
    public function getNameAttribute()
    {
        return utf8_decode($this->first_name) .' '. utf8_decode($this->last_name);
    }

    /**
     * The lsp relationship data for this model.
     *
     * @var object
     */
    public function lsp()
    {
        return $this->belongsTo('Lsp');
    }

    /**
     * The regions relationship data for this model.
     *
     * @var object
     */
    public function regions()
    {
        return $this->belongsToMany('Region', 'user_regions');
    }

	/**
	 * The location owner relationship data for this model.
	 *
	 * @var object
	 */
	public function location_owner()
	{
		return $this->hasMany('LocationOwner');
	}

	/**
	 * The route owner relationship data for this model.
	 *
	 * @var object
	 */
	public function route_owner()
	{
		return $this->hasMany('RouteOwner');
	}

	/**
	 * The incident owner relationship data for this model.
	 *
	 * @var object
	 */
	public function incident_owner()
	{
		return $this->hasMany('IncidentOwner');
	}

  
}
