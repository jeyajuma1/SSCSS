<?php

class Lsp extends \Eloquent {
	protected $fillable = ['name'];

	use SoftDeletingTrait;

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
	public static $rules = [
        'name'    => 'required|unique:lsps,name',
    ];

    /**
     * The users relationship data for this model.
     *
     * @var object
     */
    public function users()
    {
        return $this->hasMany('User');
    }
}