<?php

class FactoryIncidentLog extends \Eloquent {
	protected $fillable = [ 'factory_incident_id','user_id','created_at','updated_at'];

	/**
	 *  The user relation to Data Model
	 *  @return
	 **/
	public function user(){
		return $this->belongsTo('User')->withTrashed();
	}
}