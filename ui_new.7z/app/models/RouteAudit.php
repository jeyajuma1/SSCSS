<?php

class RouteAudit extends \Eloquent {
    protected $fillable = [
        'route_id',
        'question_id',
        'answer_id',
        'comment',
        'is_archived',
    ];


    /**
     * The route relationship data for this model.
     *
     * @var object
     */
    public function route()
    {
        return $this->belongsTo('Routes');
    }

    /**
     * The question relationship data for this model.
     *
     * @var object
     */
    public function question()
    {
        return $this->belongsTo('Question');
    }

    /**
     * The answer relationship data for this model.
     *
     * @var object
     */
    public function answer()
    {
        return $this->belongsTo('Answer');
    }
}