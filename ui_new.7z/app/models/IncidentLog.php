<?php

class IncidentLog extends \Eloquent {
   

  	protected $fillable = [
        'incident_id',
        'user_id',
        'created_at',
        'updated_at',
        'closure_requested_at',
        'closure_accepted_at',
        'closure_denied_at',
        'closure_re_open_at'
       ];

    /**
     * The user relationship data for this model.
     *
     * @var object
     */
    public function user()
    {
        return $this->belongsTo('User')->withTrashed();
    }

    /**
     * The incident relationship data for this model.
     *
     * @var object
     */
    public function incident()
    {
        return $this->belongsTo('Incident');
    }
}