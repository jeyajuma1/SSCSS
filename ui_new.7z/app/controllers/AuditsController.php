<?php
use MSLST\Helpers\Lists;
use MSLST\Helpers\Audits;
use MSLST\Helpers\Common;

class AuditsController extends \BaseController {

	/**
	 * Display a listing of the audits.
	 * GET /audits
	 *
	 * @return Response
	 */
	public function getIndex()
	{
		if (!Auth::User()->isAdmin() && ! Auth::User()->access_audits) App::abort(403);
		
		$usrregion =  [];
		$RequestData = Input::all();
				/* Checking date Filter Option */ 
		if(isset($RequestData['daterange'])){
			$daterange = preg_split('/ - /',$RequestData['daterange']);
			if(count($daterange) == 1) {
				$RequestData['daterange'] = '';
				Input::merge(array('daterange'=>''));
			}
		}

		
		$auditors = Lists::getAuditorsList();

		if (!Auth::User()->isAdmin() && !Auth::User()->isManager() ) {
			 $usrregion = Lists::getUserRegion(Auth::User()->id);
		}

		$lsps = Lists::getLspsList();

		$regions = Lists::getRegionsList($usrregion);
		
		$countries = Lists::getCountriesList();
 
		
		if(!empty($RequestData['region'])){
			$regions_country[]  = $RequestData['region'];
			$countries =  Lists::getCountriesList($regions_country[0]);
		}

		if (Input::get('type') == 'routes')
		{
			$audits = Audits::getFilteredRoutes($RequestData);
			$type = 'Route';
		}
		else
		{
			$audits = Audits::getFilteredLocations($RequestData);
			$type = 'Location';
		}

		return View::make('audits.index')
				->with('auditors', $auditors)
				->with('lsps', $lsps)
				->with('regions', $regions)
				->with('countries', $countries)
				->with('audits', $audits)
				->with('type', $type);
	}

	/**
	 * Download the audit attachment.
	 * GET /audits/download
	 *
	 * @return Response
	 */
	public function getDownload($fid, $id, $type)
	{
		return Common::downloadFile($fid, $id, $type);		
	}
}