<?php

class ProfileController extends \BaseController {

    /**
     * Instantiate a new ProfileController instance.
     */
	public function __construct()
	{
		$this->beforeFilter(function ($route){
			if ($route->getParameter('profile') != Auth::user()->id)
			{
				App::abort(404);
			}
		});
	}

	/**
	 * Show the form for editing profile resource.
	 * GET /profile/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$user = User::find($id);
		
		return View::make('profile.edit')
				->with('user', $user);
	}


	/**
	 * Update the profile resource in storage.
	 * PUT /profile/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$user = User::find($id);
		$data = Input::all();

		$user->first_name = $data['first_name'];
		$user->last_name = $data['last_name'];
		$user->email = $data['email'];
		$user->title = $data['title'];

		if (trim($data['current_password']) 
			|| trim($data['password'])
			|| trim($data['password_confirmation']))
		{
			// If password need to be updated, then 
			// update rule to include current password and error message.

			$user->password = Hash::make($data['password']);

			$messages = ['passcheck' => 'The current password is incorrect.','password_confirmation.regex'=> 'Password should be minimum 8 characters at least 1 Uppercase Alphabet, 1 Lowercase Alphabet, 1 Number and 1 Special Character'];

			$rules = User::$profileRules;
			$rules['email'] .= ','. $id; 

			$validator = Validator::make($data, $rules, $messages);
		}
		else
		{
			// switch rule to profile only validation

			$rules = User::$rules;
			$rules['email'] .= ','. $id; 

			$validator = Validator::make($data, $rules);
		}

		if ($validator->passes())
		{
			$user->save();

			return Redirect::route('profile.edit', [$id])
					->with('success', 'Profile updated.');
		}

		return Redirect::back()
				->withInput()
				->withErrors($validator->messages());
	}

}
