<?php

class SettingsController extends \BaseController {

    /**
     * Instantiate a new SettingsController instance.
     */
	public function __construct()
	{
		$this->beforeFilter(function ($route){
			if (!Auth::user()->isAdmin())
			{
				App::abort(404);
			}
		});
	}

	/**
	 * Display the settings form.
	 * GET /settings
	 *
	 * @return Response
	 */
	public function getSettings()
	{
		$settings = MSLST_Common::getFormattedSettings(Setting::all());

		return View::make('settings.edit')
				->with('settings', $settings);

	}

	/**
	 * Update the settings.
	 * PUT /settings
	 *
	 * @return Response
	 */
	public function putSettings()
	{
		$data = Input::all();
		$mslst_email = new ReflectionClass('MSLST_Email');


		$validator = Validator::make($data, Setting::$rules);


		if(empty($data['site_alert_option'])){
			$data['site_alert_option'] = 0;
		}

		if(empty($data['site_ask_agree_tnc'])){
			$data['site_ask_agree_tnc'] = 0;
		}

		if ($validator->passes())
		{
			$pass = true;
			foreach ($mslst_email->getConstants() as $key)
			{
				// Update each setting

				$affected = Setting::where('name', '=', $key)->update(['value' => $data[$key]]);
				if (! $affected)
				{
					$pass = false;
					$errors = "Error: Invalid data";
				}
			}

			if ($pass) 
			{
				Session::put('settings_site_alert_option', $data['site_alert_option']); 
				Session::put('settings_site_alert_message', $data['site_alert_message']); 
				return Redirect::to('settings')
						->with('success', 'Settings updated.');
			}
		}
		else
		{
			$errors = $validator->messages();
		}

		return Redirect::back()
				->withInput()
				->withErrors($errors);
	}

}