<?php
use MSLST\Helpers\Lists;
use MSLST\Helpers\Audits;
use MSLST\Helpers\Common;
use MSLST\Helpers\UserRegions;
use MSLST\Helpers\Incidents;
use MSLST\Helpers\Factoryincidents;
use MSLST\Helpers\Coordinate;

class StatisticsController extends \BaseController {

    /**
     * Instantiate a new UsersController instance.
     */
	public function __construct()
	{
		$this->beforeFilter(function ($route){

			if (!Auth::user()->isAdmin() && Auth::User()->lsp_id != 8)
			{
				App::abort(403);
			}
		});
	}

	/**
	 * Display a Chart and Map Plot of the audit.
	 * GET /audits
	 *
	 * @return Response
	 */
	public function getAudit()
	{	
		//$this->canViewStatisticsCheck();
		
		$result = [];
		$chart_image_data = NULL;
        $chart_image_name = NULL;
        $filter_SelOption = NULL;
		
		$ValuePrefix 	  = NULL;
		$DataConvert      = 'intval';
		$data_report      = array();
		$title            = NULL;         
		$data_result      = array();
		$data_label       = array();
		$data_resul       = array();
		$auditYaxais      = NULL;
		$routes_res 	  = array();
		$location_res     = array();
		$flashaxis        = NULL; 
		$common_result    = [];
		$chartjs_X		  = [];
		$chartjs_Y 		  = [];
		$chartjs_YOne     = [];
		$x_axis           = '';
		$chartjs_XOne     = [];
		Session::forget('message');

		

        $country_list =  Lists::getCountriesList();
        $region_list  =  Lists::getRegionsList();
        $lsp_list     =  Lists::getLspsList();
		
		$data = Input::get();
		$user = Auth::user();
		
	$filter_labels_map = array(
            'daterange' => 'Date Range',
            //'monthrange' => 'Month Range',
            'score' => 'Score',
            'review' => 'Review',
            'lsp' => 'LSP',
            'region' => 'Region',
            'country' => 'Country',
	);
	$filter_labels_chart = array(
            'daterange' => 'Date Range',
            'monthrange' => 'Month Range',
            'score' => 'Score',
            'review' => 'Review',
            'lsp' => 'LSP',
            'region' => 'Region',
            'country' => 'Country',
	);
	
		if(!empty($data)){

			if(!empty($data['flt_sel'])){
		 		$filter_selLabels = array_flip(explode(',',$data['flt_sel']));
		 		$filter_labels_map = array_merge($filter_selLabels,$filter_labels_map);
		    }

		    /* Selected Region has list of Country */
		    if(!empty($data['filters'])){
			    $filp_filter = array_flip($data['filters']);
			    $regionplac  = @$filp_filter['region'] || [] ;
			    $countryplac = @$filp_filter['country'] || [];
				
			    if(!empty($data['region']) && ($countryplac > $regionplac) ){
			    	$regions_country[]  = $data['region'];
			    	$country_list =  Lists::getCountriesList($regions_country);
			    }
			}
		
			if($user->role == 'user') {
					$data['user'] = $user->id;
			}
			// Default plotting type to chart, if nothing is set.
			$data['type'] = isset($data['type']) ? $data['type'] : 'chart';
			
			// Map Section
			// If current statistics type is maps -> generate the list of locations to be plotted.
			if($data['type'] == 'map'){

				// Apply the filters selected (if any) and get the list of locations
				if (isset($data['report']) && $data['report'] == 'route') {
					 $routes_result = Audits::findStatisticsMapRoutes($data);
				}
				// default to location
				else {
					$data['report'] = 'location';
					$location_result = Audits::findStatisticsMapLocations($data);
				}


				if(!empty($routes_result)){
				
					foreach($routes_result as $key=>$rout_item){
						//echo $rout_item['start_coordinates']; exit;
							$routes_res[$key]                       = $rout_item['original'];
							$routes_res[$key]['start_coordinates']  = Coordinate::convertToWGS84($rout_item['start_coordinates']);
							$routes_res[$key]['end_name']           = preg_replace('/[^A-Za-z0-9\s.\s-]/','',$rout_item['end_name']);
							$routes_res[$key]['end_coordinates']    = Coordinate::convertToWGS84($rout_item['end_coordinates']);
							$routes_res[$key]['auditor_name']       = preg_replace('/[^A-Za-z0-9\s.\s-]/','',$rout_item['auditor_name']);
							
				    }

				    $common_result =$routes_res;

				}elseif(!empty($location_result)){
					foreach ($location_result as $key => $locat_item) {
						# code...
							$location_res[$key]                     = $locat_item['original'];
							$location_res[$key]['coordinates']      = $locat_item['original']['coordinates'];
					}
					 $common_result = $location_res;
				}

			}


			if(!empty($data['filters'])){

				$statistics_filters = $data['filters'];

				//Chart Section
				// Set the default group by filters
				$x_axis = NULL;
				$y_axis = NULL;
				if(!empty($statistics_filters[0]) ) {
				 	$x_axis = $statistics_filters[0];
				}
				if(!empty($statistics_filters[1])) {
					$y_axis =$statistics_filters[1];
				}else{
					$y_axis = 'totalaudit';
				}

				if(in_array('daterange',$statistics_filters)){
					$x_axis = 'daterange';
					if(count($statistics_filters) > 1 && $statistics_filters[0] !='daterange'){
						$y_axis = $statistics_filters[0];
					}
				}else if(in_array('monthrange',$statistics_filters)){
					$x_axis = 'monthrange';
					if(count($statistics_filters) > 1 && $statistics_filters[0] !='monthrange'){
						$y_axis = $statistics_filters[0];
					}
				}
				
				
				
				// Current statistics type is Custom Chart -> with 2 variables
				  	
				if ($data['type'] == 'chart') {
				
									
					if(!empty($data['report']) && $data['report'] == 'location') {
					  		$data_report = Audits::findStatisticsGroupedByLocation($data,$x_axis,$y_axis);
							$title = 'Location Audits';
					}elseif (!empty($data['report']) && $data['report'] == 'route') {
						# code...
						    $data_report = Audits::findStatisticsGroupedByRoute($data,$x_axis,$y_axis);
						    $title = 'Route Audits';
					}
 
					if($y_axis == 'totalaudit') {
						if(empty($data_report[0]->total))  $data_report = [];
					}
					
					if(!empty($data_report)){
					     $monthsort = ['Jan'=>'01','Feb'=>'02','Mar'=>'03','Apr'=>'04','May'=>'05','Jun'=>'06','Jul'=>'07','Aug'=>'08','Sep'=>'09','Oct'=>'10','Nov'=>'11','Dec'=>'12'] ;
						 foreach($data_report as $data_key => $data_item) {
						 //	echo $data_item->$x_axis."##".$data_item->$y_axis."<br/>"; 
						 	   $data_result[$data_item->$x_axis][$x_axis] = $data_item->$x_axis;
						 	   $data_result[$data_item->$x_axis][$data_item->$y_axis] = $data_item->total;
						 	   $data_label[] = $x_axis;
						 	   $auditYaxais[] = $data_item->$y_axis;
						 	   $pattern = '/(\w+) (\d+)/i';
							   $replacement ='$1';
							   $replacementOne ='$2';

						 	   if($x_axis == 'monthrange'){
						 	  		 $chartjs_X[$x_axis][preg_replace($pattern, $replacementOne, $data_item->$x_axis).$monthsort[preg_replace($pattern, $replacement, $data_item->$x_axis)]] = $data_item->$x_axis;
						 	  	}else{
						 	  		 $chartjs_X[$x_axis][] = $data_item->$x_axis;
						 	  	}
							   $chartjs_X[$x_axis] = array_unique($chartjs_X[$x_axis]);
						 	   $chartjs_Y[$data_item->$y_axis][$data_item->$x_axis] = $data_item->total;
							}

						 foreach ($data_report as $key => $value) {
						 		$data_resul[] = $value;
						 }

						 

						 /* Chart JS */
						 ksort($chartjs_X[$x_axis]);

					
						 $montSort = array_flip($chartjs_X[$x_axis]);
                            foreach ($chartjs_Y as $key => $value) {
							 	 	$keyArray = array_keys($value);
							 		$mergeArray = array_unique(array_merge($keyArray,$chartjs_X[$x_axis]));
							 		$fillValues = array_fill_keys($mergeArray,0);
							 		$fillValues = $value + $fillValues;

							 		if($x_axis  == 'monthrange')
							 			$fillValues = self::monthsortfunction($fillValues,$montSort);
							 		/*else
							 			ksort($fillValues);*/

							 		$chartjs_YOne[$key] = $fillValues;
							 }

							
							 $chartjs_XOne  = array_values($chartjs_X[$x_axis]);

						  $data_result = array();
						  $data_result = $data_resul;

						  $data_label  = array_unique($data_label);
						  $auditYaxais = explode(',',implode(',',array_unique($auditYaxais)));
					}

					$common_result = $data_result;


				}

				if($data['type'] != 'map')	{
					if(in_array('daterange',$statistics_filters)) unset($filter_labels_chart['monthrange']);
					if(in_array('monthrange',$statistics_filters)) unset($filter_labels_chart['daterange']);
				}

			}
		
			if (count($data_result) > 24) {
			 	$flashaxis        = 'Too much data on x axis, please filter down.'; 
			 	$data_result = array();
			 	Session::flash('message', $flashaxis);
            }else if(count($auditYaxais) > 10) {
            	$flashaxis        = 'Too much data on Y axis, please filter down.';
			 	$data_result = array();
			 	Session::flash('message', $flashaxis);
            }

         

		   if( (empty($common_result)  && !empty($data['filters'])) ){
                if(empty($flashaxis)){
                    $flashaxis = 'The current filter selection does not have any results. Please use another filter combination';
                }
                $data_result = array();
                Session::flash('message', $flashaxis);
            }


		}
	
		return View::make('statistics.audit')
				   ->with('monthrangeOpt', Common::HelperMonthRange())
				   ->with('data',$data)
				   ->with('filter_labels_map',$filter_labels_map)
				   ->with('filter_labels_chart',$filter_labels_chart)
				   ->with('data_result',json_encode($data_result))
				   ->with('data_label',json_encode($data_label))
				   ->with('auditYaxais',json_encode($auditYaxais))
				   ->with('routes_res',json_encode($routes_res,JSON_PARTIAL_OUTPUT_ON_ERROR))
				   ->with('location_res',json_encode($location_res))
				   ->with('country_list',$country_list)
				   ->with('region_list',$region_list)
				   ->with('lsp_list',$lsp_list)
				   ->with('chartjsXaxis',json_encode($chartjs_XOne))
				   ->with('chartjsYaxis',json_encode($chartjs_YOne));
	}

	public static function monthsortfunction($a,$x){
						 
			  		$newarr = [];
			  		foreach($a as $ky=>$val){
			  			$newarr[$x[$ky]] = $val;
			  		}
			  		
			  		ksort($newarr);
			  		$y = array_flip($x);

			  		$chngarr = [];
			  		foreach($newarr as $ky=>$val){
			  			$chngarr[$y[$ky]] = $val;
			  		}

				 	return $chngarr;
	}
	
	
	/**
     * Check if the current user is permitted to view statistics
     */
    private function canViewStatisticsCheck() {
        
		$user = Auth::user();
		
        if ($user) {
            $viewable = FALSE;
            if ($user->role == 'admin') {
                $viewable = TRUE;
            }
            elseif ($user->role == 'supervisor' && $user->lsp_id == 8) {
                $viewable = TRUE;
            }
            if (! $viewable) {
                throw new AccessDeniedException();
            }
        } 
        else {
            throw new AccessDeniedException();
        } 
    }


    /**
     * Display a Chart and Map Plot of the incident.
	 * GET /incidents
	 *
	 * @return Response
	 */

    public function getIncidents(){

    	//$this->canViewStatisticsCheck();

    	
    	$data 		      = Input::get();
    	$user 			  = Auth::user();
    	$searchTerm       = '';
        $company_id       = 0;

        $chart_image_name = NULL;
        $chart_image_data = NULL;
        $statistics_filters = array();
        $map_incidents    = array();
        $locations        = array();
        $is_map           = FALSE;
        $incident_result  = array();
    	$incidentYaxis    = array();
    	$incidentXaxis	  = NULL;
    	$map_results      = array();
    	$flashaxis        = NULL; 
		$chartjs_XOne = [];
		$chartjs_YOne = [];
		$chartjs_X    = [];
		$chartjs_Y    = [];

		if(empty($data['filters'])){
			$data['filters'] = [];
			$data['flt_sel'] = Null;
		}
		

		$x_axis = NULL;
		$y_axis = NULL;
    	Session::forget('message');
    	
      	$country_list =  Lists::getCountriesList();
        $region_list  =  Lists::getRegionsList();
        $lsp_list     =  Lists::getLspsList();

        if(!empty($data['region'])){
			    	$regions_country[]  = $data['region'];
			    	$country_list =  Lists::getCountriesList($regions_country);
		}

        // Restrict access for supervisor
		$regions = array();
		$regionsArray = array();
		if ($user->role == 'admin') {
        	$regions = UserRegions::getRegionsByUserId($user->id);
        	$regionsArray = $regions;
        }
        if($data['incident_type']=='factory')
        { 
        	$filter_labels_map = array(
					            'daterange' => 'Date Range',
					        //    'monthrange' => 'Month Range',
					            'status'    => 'Incident Status',
					            'lsp'       => 'LSP',
					            'region'    => 'Region',
					            'country'   => 'Country'
        					  );
			  $filter_labels_chart = array(
				'daterange' => 'Date Range',
				'monthrange' => 'Month Range',
				'status'    => 'Incident Status',
				'lsp'       => 'LSP',
				'region'    => 'Region',
				'country'   => 'Country'
			  );
        }else if($data['incident_type'] == 'logistic')   {	
    		$filter_labels_map = array(
					            'daterange' => 'Date Range',
					            'category'  => 'Incident Severity',
					            'status'    => 'Incident Status',
					            'lsp'       => 'LSP',
					            'region'    => 'Region',
					            'country'   => 'Country',
					            'type_of_device'   => 'Type Of Device'
        					  );
	$filter_labels_chart = array(
					            'daterange' => 'Date Range',
					            'monthrange' => 'Month Range',
					            'category'  => 'Incident Severity',
					            'status'    => 'Incident Status',
					            'lsp'       => 'LSP',
					            'region'    => 'Region',
					            'country'   => 'Country',
					            'type_of_device'   => 'Type Of Device'
        					  );

    	}

		
    	if($data['incident_type'] == 'factory' ){	
					$data_remove = array_flip($data['filters']);
  
					if(isset($data_remove['type_of_device'])){
						unset($data_remove['type_of_device']);
						unset($data['type_of_device']);
						$data['filters'] = array_values(array_flip($data_remove));
						$data['flt_sel'] = str_replace('type_of_device','',$data['flt_sel']);
					}else if(isset($data_remove['category'])){
						unset($data_remove['category']);
						unset($data['category ']);
						$data['filters'] = array_values(array_flip($data_remove));
						$data['flt_sel'] = str_replace('category','',$data['flt_sel']);
					}
		} 

	 
	  
		if(!empty($data['flt_sel'])){
				$filter_selLabels = array_flip(array_values(array_filter(explode(',',$data['flt_sel']))));
				 $filter_labels_map = array_merge($filter_selLabels,$filter_labels_map);
		}
 

    	if(!empty($data)){
    		
    		if ($user->role == 'supervisor') {
            	$company_id = $user->lsp_id;
        	}

        	// Default plotting type to chart, if nothing is set.
            $data['type'] = isset($data['type']) ? $data['type'] : 'chart';

            //Map Section
            if($data['type'] =='map'){

            		$rids = array();
		            if ($regionsArray) {
		                foreach ($regionsArray as $rarray) {
		                    $rids[] = $rarray;
		                }
		            }
		            if(isset($data['incident_type']) && $data['incident_type']=='logistic') {
       				    	$Mapincidents_result = Incidents::findStatisticsMapLocations($data, $regionsArray);
       				}
		            else{
		            	$Mapincidents_result = Factoryincidents::findStatisticsMapLocations($data, $regionsArray);
		            }
		            
		            
		             foreach($Mapincidents_result as $key=>$mapincidents_val){

		             	/*$map_results[$key] = $mapincidents_val['original'];
		             	$map_results[$key]['coordinates'] = Coordinate::convertToWGS84($mapincidents_val['original']['coordinates']);
		             	$map_results[$key]['name']        = preg_replace('/[^A-Za-z0-9\s.\s-]/','',$mapincidents_val['original']['name']);
		             	$map_results[$key]['description'] = "";*/

		             	if(strstr($mapincidents_val->coordinates,',')){
			             	$map_results[$key] = ($data['incident_type']!='logistic')?($mapincidents_val['original']):((array)$mapincidents_val);
			             	$map_results[$key]['coordinates'] = Coordinate::convertToWGS84($mapincidents_val->coordinates);
			             	$map_results[$key]['name']        = preg_replace('/[^A-Za-z0-9\s.\s-]/','',$mapincidents_val->name);
			             	$map_results[$key]['description'] = "";
			             	$map_results[$key]['incident_type']=$data['incident_type'];
			             }
			         }

			        
			        $common_rest  = $map_results;
					if(empty($common_rest)){
	            	if(empty($flashaxis)){
	            		$flashaxis = 'The current filter selection does not have any results. Please use another filter combination';
	            	}
					Session::flash('message', $flashaxis);
		  	 	} 
            }


            if(!empty($data['filters'])){
            	
					$statistics_filters = $data['filters']; 
            		//Chart Section 
				if ($data['type'] == 'chart') {

						// Set the default group by filters
				        $current_items = array();

						if(!empty($statistics_filters[0]) ) {
							$x_axis = $statistics_filters[0];
						}
						if(!empty($statistics_filters[1])) {
							$y_axis =$statistics_filters[1];
						}else{
							$y_axis = 'Total Incidents';
						}

						if(in_array('daterange',$statistics_filters)){
							$x_axis = 'daterange';
							if(count($statistics_filters) > 1 && $statistics_filters[0] !='daterange'){
								$y_axis = $statistics_filters[0];
							}
						}else if(in_array('monthrange',$statistics_filters)){
							$x_axis = 'monthrange';
							if(count($statistics_filters) > 1 && $statistics_filters[0] !='monthrange'){
								$y_axis = $statistics_filters[0];
							}
						}

				         
				         $ValuePrefix = '';
				       if(isset($data['incident_type']) && $data['incident_type']=='logistic')
       				   { 
					       if (isset($data['report']) && $data['report'] == 'value') {
					       		$incidents_report = Incidents::findStatisticsGroupedByYears($data, $x_axis , $y_axis , TRUE);    
					            $title = 'Incident Value';
					            $ValuePrefix = 'USD';
					            $DataConvert = 'floatval';
					        }else {
				        	    $incidents_report = Incidents::findStatisticsGroupedByYears($data, $x_axis , $y_axis, FALSE);
				                $title = 'Number of incidents';
				                $DataConvert = 'intval';             
	            			}  
	            		}
	            		else
	            		{
	            			if (isset($data['report']) && $data['report'] == 'value') {
					       		$incidents_report = Factoryincidents::findStatisticsGroupedByYears($data, $x_axis , $y_axis , TRUE);    
					            $title = 'Incident Value';
					            $ValuePrefix = 'USD';
					            $DataConvert = 'floatval';
					        }else {
				        	    $incidents_report = Factoryincidents::findStatisticsGroupedByYears($data, $x_axis , $y_axis, FALSE);
				                $title = 'Number of Factory_incidents';
				                $DataConvert = 'intval';             
	            			}  
	            		}
            		
            			$xaxisplot = [];
            			$yaxisplot = [];
						$xaxisplotchk = [];
 						  
            			if(!empty($incidents_report) && $incidents_report->count() != 0){ 
            				foreach($incidents_report  as $inkey=>$inval){
            					if($x_axis == 'monthrange' && $y_axis != 'Total Incidents')  
            						$xaisplotval = $inval->sortmonth; 
            				   else
            				    	$xaisplotval =$inval->$x_axis;

            				        $yaxisplot[$inval->$y_axis][$xaisplotval] = $inval->total;
            				    	$zaxisplot[$y_axis][$xaisplotval] = $inval->$y_axis;
            				   		$xaxisplotchk[$x_axis][] = $xaisplotval;

            				   		$xaxisplot[$x_axis][] = $inval->$x_axis;
            				}
            				
            				if($y_axis != 'Total Incidents') {
            					$flip_xaxiplot  = array_fill_keys($xaxisplotchk[$x_axis],0);
            					$zaxisplot = [];
	            				foreach($yaxisplot as $yky=>$yvl){
	            					$zaxisplot[$yky] = $yvl + $flip_xaxiplot;
	            					ksort($zaxisplot[$yky]);
	            				}

	            				if($x_axis == 'monthrange'){
		            				$zyaxisplot = [];
		            				$monthsort = ['01'=>'Jan','02'=>'Feb','03'=>'Mar','04'=>'Apr','05'=>'May','06'=>'Jun','07'=>'Jul','08'=>'Aug','09'=>'Sep','10'=>'Oct','11'=>'Nov','12'=>'Dec'] ;
		            				foreach($zaxisplot as $mky=>$mvl){
		            				 	foreach ($mvl as $key => $value) {
		            						$zyaxisplot[$mky][$monthsort[substr($key,4)].' '.substr($key,0,4)]= $value;
		            					}
		            				}
		            				unset($zaxisplot);
		            				$zaxisplot = $zyaxisplot;
 								}
	            			} 

	            			$chartjs_XOne	= array_values(array_unique($xaxisplot[$x_axis]));

	            			//sort($chartjs_XOne);

							$chartjs_XOne  = $chartjs_XOne;
							$chartjs_YOne  = $zaxisplot;

            			}

            			$incident_result = $incidents_report;
			            $common_rest  =  $incidents_report->count();
				}

				
			    
			    if($common_rest == 0){
	            	if(empty($flashaxis)){
	            		$flashaxis = 'The current filter selection does not have any results. Please use another filter combination';
	            	}
					Session::flash('message', $flashaxis);
		  	 	} 
               
                if (count($chartjs_XOne) > 24) {
				 	$flashaxis        = 'Too much data on x axis, please filter down.'; 
				 	Session::flash('message', $flashaxis);
	            }else if(count($chartjs_YOne) > 20) {
	            	$flashaxis        = 'Too much data on Y axis, please filter down.';
				 	Session::flash('message', $flashaxis);
	            }

	            if(Session::has('message')){
		            	$incident_result = [];
					 	$chartjs_XOne  = [];
						$chartjs_YOne = [];
	            }
          
 
           }
    	}


    	if($data['type'] != 'map')	{
					if(in_array('daterange',$statistics_filters)) unset($filter_labels_chart['monthrange']);
					if(in_array('monthrange',$statistics_filters)) unset($filter_labels_chart['daterange']);

					if(!empty($data['report']) &&  $data['report'] == 'value'){
						if(!empty($chartjs_YOne['Total Incidents'])) {
							 $chartjs_YOne['Value'] = $chartjs_YOne['Total Incidents'];
							 $chartjs_YOne['Total Incidents'] = Null;
							 $chartjs_YOne = array_filter($chartjs_YOne);
							 $y_axis = 'Value';
					 	}
					}
		}
    	
    	
    	return View::make('statistics.incidents')
   				   ->with('monthrangeOpt', Common::HelperMonthRange())
    			   ->with('filter_labels_map',$filter_labels_map)
				   ->with('filter_labels_chart',$filter_labels_chart)
    			   ->with('filters',$data['filters'])
    			   ->with('filters_sel',$data['flt_sel'])
    			   ->with('incident_result',json_encode($incident_result))
    			   ->with('incidentYaxis',json_encode($y_axis))
    			   ->with('incidentXaxis',$x_axis)
    			   ->with('chartjsXaxis',json_encode($chartjs_XOne))
    			   ->with('chartjsYaxis',json_encode($chartjs_YOne))
    			   ->with('mapresults',json_encode($map_results))
    			   ->with('country_list',$country_list)
    			   ->with('region_list',$region_list)
    			   ->with('lsp_list',$lsp_list);
    }


  /**
     *
     * Get Suppliers
     *
     **/
    public function getSuppliers(){

    	  $results = Supplier::with(['region','user','country'])->get();

         foreach($results as $key=>$suppliers_val){
         	//$map_results[$key]['coordinates']  = Coordinate::convertToWGS84($suppliers_val->latitude.",".$suppliers_val->longitude);
	        $map_results[$key]['coordinates']  = Coordinate::convertToWGS84($suppliers_val->coordinates);
         	$map_results[$key]['vendor_name']  = preg_replace('/[^A-Za-z0-9\s.\s-]/','',$suppliers_val->vendor_name);
         	$map_results[$key]['auditor_name'] = $suppliers_val->user->getNameAttribute();
         	//$map_results[$key]['auditor_name'] = 'Cristian Petrea';
         	$map_results[$key]['country_name'] = $suppliers_val->country->name;
         	//$map_results[$key]['date']         = $suppliers_val->updated_at->format('Y-m-d');
         	$map_results[$key]['region_name']  = $suppliers_val->region->name;
         	$map_results[$key]['description']  = $suppliers_val->site_name;
         	$map_results[$key]['id']           = $suppliers_val->id;
         }
    	return View::make('statistics.suppliers')
    			   ->with('mapresults',json_encode($map_results));
    			
    }

	/**
     *
     * Get SiteMasters
     *
     **/
	public function getSitemasters(){
		$results = Sitemaster::with(['region','user','country'])
							->where('coordinates','!=','')
							->get();
		foreach($results as $key=>$sitemasters_val){
			if(!empty($sitemasters_val->coordinates)) {
				//$date = (array)$sitemasters_val->created_at;
				$map_results[$key]['coordinates']  = Coordinate::convertToWGS84($sitemasters_val->coordinates);
				$map_results[$key]['site_name']  = preg_replace('/[^A-Za-z0-9\s.\s-]/','',$sitemasters_val->site_name);
				$map_results[$key]['auditor_name'] = $sitemasters_val->user->getNameAttribute();
				$map_results[$key]['country_name'] = $sitemasters_val->country->name;
			//	$map_results[$key]['date']         = date('Y-m-d',strtotime($date['date']));
				$map_results[$key]['region_name']  = $sitemasters_val->region->name;
				$map_results[$key]['description']  = $sitemasters_val->site_name;
				$map_results[$key]['id']           = $sitemasters_val->id;
			}
		}
		return View::make('statistics.sitemasters')
			->with('mapresults',json_encode($map_results));
    			
	}



    /**
     *
     * Excel Download
     *
     **/
    public function getExportXLS(){

    	/*$request = Input::all();
    	$datcl   = Null;
    	$chart_file = tempnam(sys_get_temp_dir(), 'scstool_chart'); 


    	if($request['data_json'] != ''){

    		$json_data = json_decode($request['data_json']);
    	 	$chart_data = explode('base64,',$request['data_chart']) ;

        	foreach($json_data as $Cky=>$column_data){
        		foreach($column_data as $Rky=>$rowdata) {
       				$data[$Cky][$Rky] =  $rowdata;


        		}        		
        	}
			Excel::create('scstool_report', function($excel) use($data,$chart_file) {

				$excel->sheet('WorkSheet', function($sheet) use($data,$chart_file) {

					// Set black background
					$sheet->cells('A1:B1', function($row) {
					    // call cell manipulation methods
					    $row->setBackground('#FFCC99');
					});

	        		// Sheet manipulation
	        		$sheet->fromArray($data);

	        		$sheet->setCellValue('G1',  $chart_file  );

			    });

			})->download('xls');

		} */
		$file_type = 'Excel2007';
        $chart_file = tempnam(sys_get_temp_dir(), 'scstool_chart');
        $xls_file = tempnam(sys_get_temp_dir(), 'scstool_report');
        $request = Input::all();

        if($request['data_json'] != ''){
            $json_data = $request['data_json'];
            $chart_data = explode('base64,',$request['data_chart']) ;

            // Add the data to the XLS sheet
            
            $php_excel = new PHPExcel();
            if (!empty($json_data)) {
                $json_array = json_decode($json_data);
                // Load the workbook

			    
			    $data = [];

			    foreach ($json_array as $Cky=>$column_data) {
			    	foreach($column_data as $Rky=>$row_dat){
			    		$data['header'][$Rky]  = $Rky;
			    	}
			    }

			    $sheet = $php_excel->getActiveSheet();

			    $column_heaing = 'A';
			    foreach($data['header'] as $heading){
			    	$data_row[$column_heaing] = $heading;
			    	$sheet->setCellValue($column_heaing.'1', $heading);
			    	$column_heaing++;
			    }

				$data_row = array_flip($data_row);
                
			   $column_id = $column_heaing;

            	$cul_id = 2;
            	$row_id = 2;
                foreach ($json_array as $Cky=>$column_data) {
            	    foreach ($column_data as $Rky=>$row_data) {
					    if (isset($request['data_type'])) {
            	    		if($request['data_type'] == 'value'){
            	    			if(preg_match('/([0-9\.])/', $row_data)){
            	    			   $row_data = preg_replace('/(\d)(?=(\d\d\d)+(?!\d))/', '$1,', $row_data);
            	    			   $row_data = "$".$row_data;
            	    			 }
            	    		}
						}
                    	   $sheet->setCellValue($data_row[$Rky].$row_id, $row_data);
						   
	                    }
	                    //$sheet->getColumnDimension($column_id)->setAutoSize(true);
	                    $sheet->getStyle('A1:'.$column_heaing.'1')->applyFromArray(array(
	                      'font' => array('bold' => true),
	                      'fill' => array(
	                                'type' => PHPExcel_Style_Fill::FILL_SOLID,
	                                'color' => array('rgb' => 'FFDAB9')
	                            )
	                      )
	                    );
	                    $row_id++;  
	              }

                $column_id++;


            }

            // Add the chart to the XLS sheet
            if (!empty($chart_data[1])) {
                // Create the image

                $image = imagecreatefromstring(base64_decode($chart_data[1]));
                imagepng($image, $chart_file);
                imagedestroy($image);

                // Add an image to the worksheet
                $php_excel_drawing = new PHPExcel_Worksheet_Drawing();
                $php_excel_drawing->setName('Statistics report chart');
                $php_excel_drawing->setPath($chart_file);
                $php_excel_drawing->setCoordinates($column_id. '2');
                $php_excel_drawing->setWorksheet($php_excel->getActiveSheet());
            }

            // Save the workbook
            $php_excelWriter = PHPExcel_IOFactory::createWriter($php_excel, $file_type);
            $php_excelWriter->save($xls_file);

            // Send the file for download
            $response = Response::make(file_get_contents($xls_file));
            $response->header('Content-Disposition', 'attachment; filename=scstool_report.xlsx');
            $response->header('Content-Type', 'application/octet-stream');
            $response->header('Content-Transfer-Encoding', 'binary');
            $response->header('Accept-Ranges', 'bytes');
            $response->header('Cache-Control', 'no-store');
            $response->header('Pragma', 'private');
            $response->header('Content-Length', filesize($xls_file));
           	
            // Delete the file after download
            register_shutdown_function('unlink', $xls_file);
            register_shutdown_function('unlink', $chart_file);

           	return $response;
        } 
        else 
        {
            $response = Response::make("Nothing to export.");
            $response->header('Content-Type', 'text/plain');

            return $response;
        }

		

    }


}