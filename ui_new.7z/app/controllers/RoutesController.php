<?php
use MSLST\Helpers\Certifications;
use MSLST\Helpers\Coordinate;
use MSLST\Helpers\Lists;
use MSLST\Helpers\Audits;
use MSLST\Helpers\Routes;
use MSLST\Helpers\Common;
use MSLST\Helpers\Emails;
use MSLST\Constants\Site;

class RoutesController extends \BaseController {

	/**
	 * Show the form for creating a new resource.
	 * GET /routes/create
	 *
	 * @return Response
	 */
	public function create($step = 0)
	{
		if (!Auth::User()->isAdmin() && ! Auth::User()->access_audits) App::abort(403);

		switch(intval($step))
		{
			case 0:
				$data = Routes::getRouteStepData('basic_details');
				return self::basic_details_form($data);
			case 1:
				$data = Routes::getRouteStepData('needed_certification');
				return self::needed_certification_form($data);
			case 2:
				$data = Routes::getRouteStepData('actual_certification');
				return self::actual_certification_form($data);
			case 3:
				$data = Routes::getRouteStepData('questions');
				return self::questions_form($data);
			case 4:
				$data = Routes::getRouteStepData('comments');
				return self::comments_form($data);
			case 5:
				$data = Session::get('routes');
				$data['start_country_name'] = Lists::getCountriesname($data['basic_details']->start_country);
				$data['end_country_name']   = Lists::getCountriesname($data['basic_details']->end_country);
				return self::summary_list($data);
		}
	}

	/**
	 * Show route details form.
	 *
	 * @return Response
	 */
	public static function basic_details_form($data, $edit = false)
	{
		$countries = ['' => ''] + Lists::getCountriesList();
		return View::make('audits.route.basic_details')
				->with('countries', $countries)
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show route needed information form.
	 *
	 * @return Response
	 */
	public static function needed_certification_form($data, $edit = false)
	{
		return View::make('audits.route.needed_certification')
				->with('tapa_tsr_1', Site::TAPA_TSR_1)
				->with('tapa_tsr_2', Site::TAPA_TSR_2)
				->with('tapa_tsr_3', Site::TAPA_TSR_3)
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show route actual certification form.
	 *
	 * @return Response
	 */
	public static function actual_certification_form($data, $edit = false)
	{
		return View::make('audits.route.actual_certification')
				->with('tapa_tsr_1', Site::TAPA_TSR_1)
				->with('tapa_tsr_2', Site::TAPA_TSR_2)
				->with('tapa_tsr_3', Site::TAPA_TSR_3)
				->with('c_tpat', Site::C_TPAT)
				->with('aeo_s', Site::AEO_S)
				->with('aeo_f', Site::AEO_F)
				->with('aeo_c', Site::AEO_C)
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show route questions form.
	 *
	 * @return Response
	 */
	public static function questions_form($data, $edit = false)
	{
		if ($edit)
		{
			$tapa_needed = $data->tapa_needed;
			$actual_certification = $data->actual_certification;
		}
		else
		{
			$tapa_needed = Session::get('routes.needed_certification')->tapa_needed;
			$actual_certification = (array) Session::get('routes.actual_certification');
		}

		$questions = Routes::getQuestionsList($tapa_needed, $actual_certification);

		$answers = ['' => ''] + Lists::getAnswersList();

		return View::make('audits.route.questions')
				->with('tapa_display', 0)
				->with('c_tpat_display', 0)
				->with('aeo_display', 0)
				->with('questions', $questions)
				->with('answers', $answers)
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show route comments form.
	 *
	 * @return Response
	 */
	public static function comments_form($data, $edit = false)
	{
		return View::make('audits.route.comments')
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show Current Create Summary Route
	 *
	 *@return Response
	 */
	public static function summary_list($data)
	{
		$certification = [Site::TAPA_FSR_A => 'TAPA_FSR_A',
						  Site::TAPA_FSR_B => 'TAPA_FSR_B',
						  Site::TAPA_FSR_C => 'TAPA_FSR_C',
						  Site::TAPA_TSR_1 => 'TAPA_TSR_1',
						  Site::TAPA_TSR_2 => 'TAPA_TSR_2',
						  Site::TAPA_TSR_3 => 'TAPA_TSR_3',
						  Site::C_TPAT => 'C_TPAT',
						  Site::AEO_S => 'AEO_S',
						  Site::AEO_F => 'AEO_F',
						  Site::AEO_C => 'AEO_C'
						  ];

		return View::make('audits.route.summary')
					->with('certification',$certification)
					->with('data',$data);
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /routes
	 *
	 * @return Response
	 */
	public function store()
	{
		if (!Auth::User()->isAdmin() && ! Auth::User()->access_audits) App::abort(403);

			
		switch(intval(Input::get('step')))
		{
			case 0:
				$validator = Validator::make(Input::all(), \Routes::$basic_details_rules);
				$step = 'basic_details';
				$next = 'routes/create/1';
				break;
			case 1:
				$rules = \Routes::$needed_certification_rules;
				$rules['tapa_needed'] .= Site::TAPA_TSR_1 . ','. Site::TAPA_TSR_2 .','. Site::TAPA_TSR_3;
				$validator = Validator::make(Input::all(), $rules);
				$step = 'needed_certification';
				$next = 'routes/create/2';
				break;
			case 2:
				$rules = \Routes::$actual_certification_rules;
				$rules['tapa'] .= '0,'. Site::TAPA_TSR_1 .','. Site::TAPA_TSR_2 .','. Site::TAPA_TSR_3;
				$rules['ctpat'] .= '0,"na",'. Site::C_TPAT;
				$rules['aeo'] .= '0,"na",'. Site::AEO_S .','. Site::AEO_F .','. Site::AEO_C;
				$validator = Validator::make(Input::all(), $rules);

				$validator->sometimes('svi_num', 'required', function($input){
					return (intval($input->ctpat) && $input->ctpat != 'na');
				});

				$validator->sometimes('aeo_num', 'required', function($input){
					return (intval($input->aeo) && $input->aeo != 'na');
				});

				$validator->sometimes('tapa_certificate', 'required', function($input){
					return intval($input->tapa);
				});

				$validator->sometimes('ctpat_certificate', 'required', function($input){
					return (intval($input->ctpat) && $input->ctpat != 'na');
				});

				$validator->sometimes('aeo_certificate', 'required', function($input){
					return (intval($input->aeo) && $input->aeo != 'na');
				});
				$step = 'actual_certification';
				$next = 'routes/create/3';
				break;
			case 3:
				$answers = array_keys(Lists::getAnswersList());
				$validator = Validator::make(Input::all(), \Routes::$questions_rules);

				$validator->sometimes('question', 'required', function($input) use ($answers) {
					if (isset($input->display))
					{
						foreach($input->display as $key => $value)
						{
							if (!in_array(intval($input->question[$key]), $answers))
							{
								return false;
							}
						}
					}

					return true;
				});

				$step = 'questions';
				$next = 'routes/create/4';
				break;
			case 4:
				$validator = Validator::make(Input::all(), \Routes::$comments_rules);

				$step = 'comments';
				$next = 'routes/create/5';
				break;
			case 5:
				Routes::saveRouteData();

				return Redirect::to('audits?type=routes')
								->with('success', "Route audit created successfully.");

		}

		if ($validator->passes())
		{
			$data = Routes::setRouteStepData($step, Input::all());
			return Redirect::to($next);
		}
		else
		{
			return Redirect::back()
					->withInput()
					->withErrors($validator->messages());

		}
	}

	/**
	 * Display the specified resource.
	 * GET /routes/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		if (! Common::canAccess($id, 'route')) App::abort(403);

		$route = \Routes::with('user', 'start_country', 'end_country', 'lsp', 'question', 'certification', 'disabled_certification', 'route_log')->findOrFail($id);
		$audits = Certifications::getRouteAuditQuestions($route);
		$start_coordinates = Coordinate::convertToWGS84($route->start_coordinates);
		$end_coordinates = Coordinate::convertToWGS84($route->end_coordinates);
		$current_certifications = Certifications::getCurrentCertifications($route);
		$legend = Certifications::getAnswersLegend();
		$users = ['' => ''] + Lists::getLspUsersList($route->lsp->id, $route->user->id);
		$owners = RouteOwner::where('route_id', $route->id)->lists('user_id');
		$route['audit_age'] = Common::CalculateAge($route['created_at']);

		return View::make('audits.route.show')
				->with('route', $route)
				->with('start_coordinates', $start_coordinates)
				->with('end_coordinates', $end_coordinates)
				->with('current_certifications', $current_certifications)
				->with('legend', $legend)
				->with('audits', $audits)
				->with('users', $users)
				->with('owners', $owners);
	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /routes/{id}/edit
	 *
	 * @param int  $id
	 * @param int $step
	 * @return Response
	 */
	public function edit($id, $step = 0)
	{
		if (! Common::canAccess($id, 'route')) App::abort(403);

		switch(intval($step))
		{
			case 0:
				$data = Routes::getRouteEditData($id, 'basic_details');
				return self::basic_details_form($data, true);
			case 2:
				$data = Routes::getRouteEditData($id, 'actual_certification');
				return self::actual_certification_form($data, true);
			case 3:
				$data = Routes::getRouteEditData($id, 'questions');
				return self::questions_form($data, true);
			case 4:
				$data = Routes::getRouteEditData($id, 'comments');
				return self::comments_form($data, true);
			default:
				App::abort(404);
		}
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /routes/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		if (! Common::canAccess($id, 'route')) App::abort(403);

		$aeo_chk = ['aeo' => 'na' , 'aeo_num'=>'','aeo_certificate'=>''];
		$ctpat_chk = ['ctpat' => 'na' , 'svi_num'=>'','ctpat_certificate'=>''];

		if(!array_key_exists('aeo',Input::all()) ){
			Input::merge($aeo_chk);
		}else if(!array_key_exists('ctpat',Input::all()) ){
			Input::merge($ctpat_chk);
		}

	

		switch(intval(Input::get('step')))
		{
			case 0:
				$validator = Validator::make(Input::all(), \Routes::$basic_details_rules);

				$step = 'basic_details';
				break;
			case 2:
				$rules = \Routes::$actual_certification_rules;
				$rules['tapa'] = 'in:0,'. Site::TAPA_TSR_1 .','. Site::TAPA_TSR_2 .','. Site::TAPA_TSR_3;
				$rules['ctpat'] = 'in:0,"na",' . Site::C_TPAT;
				$rules['aeo'] = 'in:0,"na",' . Site::AEO_S .','. Site::AEO_F .','. Site::AEO_C;

				$validator = Validator::make(Input::all(), $rules);

				$certs = Routes::getCurrentCertifications($id);

				$validator->sometimes('svi_num', 'required', function($input){
					return (isset($input->ctpat) && intval($input->ctpat));
				});

				$validator->sometimes('aeo_num', 'required', function($input){
					return (isset($input->aeo) && intval($input->aeo));
				});

				// Require file only if the certificate has changed.
				$validator->sometimes('tapa_certificate', 'required', function($input) use ($certs) {
					return ($certs->tapa != $input->tapa);
				});

				$validator->sometimes('ctpat_certificate', 'required', function($input) use ($certs) {
					return ($certs->ctpat != 'na' && $certs->ctpat != $input->ctpat);
				});

				$validator->sometimes('aeo_certificate', 'required', function($input) use ($certs) {
					return ($certs->ctpat != 'na' && $certs->aeo != $input->aeo);
				});

				$step = 'actual_certification';
				break;
			case 3:
				$answers = array_keys(Lists::getAnswersList());
				$validator = Validator::make(Input::all(), \Routes::$questions_rules);

				$validator->sometimes('question', 'required', function($input) use ($answers) {
					if (isset($input->display))
					{
						foreach($input->display as $key => $value)
						{
							if (!in_array(intval($input->question[$key]), $answers))
							{
								return false;
							}
						}
					}

					return true;
				});

				$step = 'questions';
				break;
			case 4:
				$validator = Validator::make(Input::all(), \Routes::$comments_rules);

				$step = 'comments';
				break;
			default:
				App::abort(404);
		}

		if ($validator->passes())
		{
			$data = Routes::setRouteEditData($id, $step, Input::all());
			return Redirect::route('routes.show', $id)
					->with('success', 'Route audit updated successfully.');
		}
		else
		{
			return Redirect::back()
					->withInput()
					->withErrors($validator->messages());

		}
	}

	/**
	 * Toggle review status of the specified resource.
	 * PATCH /routes/review/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function review($id,$option)
	{
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager()) App::abort(403);

		$route = \Routes::findOrFail($id);
		$routelogArray = array('route_id'=>$route->id,'user_id'=>\Auth::User()->id);

		if($option == 'clear')
		{
			$route->review = 0;
			$routelogArray['cleared_at'] = date('Y-m-d h:i:s');

			Emails::sendRouteCleared($route);
			$msg = 'Review request has been cleared.';
		}
		else
		{
			$route->review = 1;
			$routelogArray['requested_at'] = date('Y-m-d h:i:s');

			Emails::sendRouteReview($route, Input::get('review_message'));
			$msg = 'Review has been requested.';			
	    }

		\RouteLog::insert($routelogArray); // Route log insert whether it is cleared/requested review

		$route->save();

		return Redirect::route('routes.show', [$id])
				->with('success', $msg);
	}

	/**
	 * Toggle review status of the specified resource.
	 * PATCH /routes/status/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 **/

	public function status($id,$option='inactive')
	{
		//echo $id."$$".$option; exit;

		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager() && !Auth::User()->isUser() && !Auth::User()->isSupervisor()) App::abort(403);

		$route = \Routes::findOrFail($id);

		$route->status = $option;

		$route->save();

		 return Redirect::route('routes.show', [$id])
				->with('success', 'Route audit changed to <b>'.$option.'</b> status.');

	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /routes/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		if (! Common::canAccess($id, 'route')) App::abort(403);

		$route = \Routes::findOrFail($id);
		$route->delete();

		return Redirect::route('audits.index')
				->with('success', 'Route audit deleted successfully.');
	}


	/**
	 * Create Session Incomplete Audit
	 *
	 * @param int $id
	 * @return Response
	 **/
	public function incomplete($id)
	{

		$route =  \Routes::find($id);

		$basic =  \Routes::$basic_details_rules;

		foreach($basic as $ky=>$val)
		{
		   if($ky != 'start_country' && $ky != 'end_country') Session::put('routes.basic_details.'.$ky,$route['original'][$ky]);
		   else if($ky == 'start_country') Session::put('routes.basic_details.'.$ky,$route['original']['start_country_id']);
		   else if($ky == 'end_country') Session::put('routes.basic_details.'.$ky,$route['original']['end_country_id']);
		}

		Session::put('routes.id',$id);

		return Redirect::route('routes.create');
	}

	/**
	* Update owners for the route.
	* POST /routes/update-owners
	*
	* @return Response
	*/
	public function updateOwners()
	{
		if (! \Auth::User()->isAdmin()
				&& ! \Auth::User()->isSupervisor()
				&& ! \Auth::User()->isManager()) App::abort(403);

		$data = Input::get('owners');
		$route_id = intval(Input::get('id'));

		//@TODO: Check if the users belongs to same lsp

		if ($route_id)
		{
			$affected = RouteOwner::where('route_id', $route_id)
							->delete();
			if ($data)
			{
				foreach($data as $user_id)
				{
					RouteOwner::create([
							'route_id' => $route_id,
							'user_id' => $user_id,
						]);
				}
			}
		}
	}
}
