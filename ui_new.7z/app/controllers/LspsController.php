<?php

class LspsController extends \BaseController {

    /**
     * Instantiate a new LspsController instance.
     */
	public function __construct()
	{
		$this->beforeFilter(function ($route){
			if (!Auth::user()->isAdmin())
			{
				App::abort(404);
			}
		});
	}

	/**
	 * Display a listing of the resource.
	 * GET /lsps
	 *
	 * @return Response
	 */
	public function index()
	{
		$lsps = Lsp::all();

		return View::make('lsps.index')
				->with('lsps', $lsps);
	}

	/**
	 * Show the form for creating a new resource.
	 * GET /lsps/create
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('lsps.create');
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /lsps
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make(Input::all(), Lsp::$rules);

		if ($validator->passes())
		{
		    $region = Lsp::create([
				'name' => Input::get('name'),
		    ]);

			return Redirect::route('lsps.index')
					->with('success', 'LSP created successfully.');
		}
		else
		{
			return Redirect::back()
				    ->withInput()
				    ->withErrors($validator->messages());
		}
	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /lsps/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$lsp = Lsp::findOrFail($id);

		return View::make('lsps.edit')
				->with('lsp', $lsp);
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /lsps/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$rules = Lsp::$rules;
		$rules['name'] .= ','. $id;
		$validator = Validator::make(Input::all(), $rules);

		if ($validator->passes())
		{
			$lsp = Lsp::findOrFail($id);
			$lsp->name = Input::get('name');
			$lsp->save();

			return Redirect::route('lsps.index')
					->with('success', 'LSP updated successfully.');
		}
		else
		{
			return Redirect::back()
				    ->withInput()
				    ->withErrors($validator->messages());
		}
	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /lsps/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$lsp = Lsp::findOrFail($id);
		$lsp->delete();

		return Redirect::route('lsps.index')
				->with('success', 'LSP deleted successfully.');
	}

}