<?php
use MSLST\Helpers\Certifications;
use MSLST\Helpers\Coordinate;
use MSLST\Helpers\Lists;
use MSLST\Helpers\Audits;
use MSLST\Helpers\Locations;
use MSLST\Helpers\Common;
use MSLST\Helpers\Emails;
use MSLST\Constants\Site;

class LocationsController extends \BaseController {

	/**
	 * Show the form for creating a new resource.
	 * GET /locations/create
	 *
	 * @return Response
	 */
	public function create($step = 0)
	{
		if (!Auth::User()->isAdmin() && !Auth::User()->access_audits) App::abort(403);

		switch(intval($step))
		{
			case 0:
				$data = Locations::getLocationStepData('basic_details');
				return self::basic_details_form($data);
			case 1:
				$data = Locations::getLocationStepData('needed_certification');
				return self::needed_certification_form($data);
			case 2:
				$data = Locations::getLocationStepData('actual_certification');
				return self::actual_certification_form($data);
			case 3:
				$data = Locations::getLocationStepData('questions');
				return self::questions_form($data);
			case 4:
				$data = Locations::getLocationStepData('comments');
				return self::comments_form($data);
			case 5:
				$data = Session::get('locations');
				return self::summary_list($data);
		}
	}

	/**
	 * Show location details form.
	 *
	 * @return Response
	 */
	public static function basic_details_form($data, $edit = false)
	{
		$countries = ['' => ''] + Lists::getCountriesList();
		return View::make('audits.location.basic_details')
				->with('countries', $countries)
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show location needed information form.
	 *
	 * @return Response
	 */
	public static function needed_certification_form($data, $edit = false)
	{

		return View::make('audits.location.needed_certification')
				->with('tapa_fsr_a', Site::TAPA_FSR_A)
				->with('tapa_fsr_c', Site::TAPA_FSR_C)
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show location actual certification form.
	 *
	 * @return Response
	 */
	public static function actual_certification_form($data, $edit = false)
	{
		return View::make('audits.location.actual_certification')
				->with('tapa_fsr_a', Site::TAPA_FSR_A)
				->with('tapa_fsr_b', Site::TAPA_FSR_B)
				->with('tapa_fsr_c', Site::TAPA_FSR_C)
				->with('c_tpat', Site::C_TPAT)
				->with('aeo_s', Site::AEO_S)
				->with('aeo_f', Site::AEO_F)
				->with('aeo_c', Site::AEO_C)
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show location questions form.
	 *
	 * @return Response
	 */
	public static function questions_form($data, $edit = false)
	{
		if ($edit)
		{
			$tapa_needed = $data->tapa_needed;
			$actual_certification = $data->actual_certification;
		}
		else
		{
			$tapa_needed = Session::get('locations.needed_certification')->tapa_needed;
			$actual_certification = (array) Session::get('locations.actual_certification');
		}

		$questions = Locations::getQuestionsList($tapa_needed, $actual_certification);

		$answers = ['' => ''] + Lists::getAnswersList();

		return View::make('audits.location.questions')
				->with('tapa_display', 0)
				->with('c_tpat_display', 0)
				->with('aeo_display', 0)
				->with('questions', $questions)
				->with('answers', $answers)
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show location comments form.
	 *
	 * @return Response
	 */
	public static function comments_form($data, $edit = false)
	{
		return View::make('audits.location.comments')
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show Current Create Summary Location
	 *
	 *@return Response
	 */
	public static function summary_list($data)
	{

		$certification = [Site::TAPA_FSR_A => 'TAPA_FSR_A',
						  Site::TAPA_FSR_B => 'TAPA_FSR_B',
						  Site::TAPA_FSR_C => 'TAPA_FSR_C',
						  Site::TAPA_TSR_1 => 'TAPA_TSR_1',
						  Site::TAPA_TSR_2 => 'TAPA_TSR_2',
						  Site::TAPA_TSR_3 => 'TAPA_TSR_2',
						  Site::C_TPAT => 'C_TPAT',
						  Site::AEO_S => 'AEO_S',
						  Site::AEO_F => 'AEO_F',
						  Site::AEO_C => 'AEO_C'
						  ];


		return View::make('audits.location.summary')
					->with('certification', $certification)
					->with('data',$data);
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /locations
	 *
	 * @return Response
	 */
	public function store()
	{
		if (!Auth::User()->isAdmin() && ! Auth::User()->access_audits) App::abort(403);

		switch(intval(Input::get('step')))
		{
			case 0:
				$validator = Validator::make(Input::all(), Location::$basic_details_rules);
				$step = 'basic_details';
				$next = 'locations/create/1';
				break;
			case 1:
				$rules = Location::$needed_certification_rules;
				$rules['tapa_needed'] .= ','. Site::TAPA_FSR_A .','. Site::TAPA_FSR_C;
				$validator = Validator::make(Input::all(), $rules);
				$step = 'needed_certification';
				$next = 'locations/create/2';
				break;
			case 2:
				$rules = Location::$actual_certification_rules;
				
				$rules['tapa'] .= '0,'. Site::TAPA_FSR_A .','. Site::TAPA_FSR_B .','. Site::TAPA_FSR_C;
				$rules['ctpat'] .= '0,"na",'. Site::C_TPAT;
				$rules['aeo'] .= '0,"na",'. Site::AEO_S .','. Site::AEO_F .','. Site::AEO_C;
				$validator = Validator::make(Input::all(), $rules);

				$validator->sometimes('svi_num', 'required', function($input){
					return (intval($input->ctpat) && $input->ctpat != 'na');
				});

				$validator->sometimes('aeo_num', 'required', function($input){
					return (intval($input->aeo) && $input->aeo != 'na');
				});

				$validator->sometimes('tapa_certificate', 'required', function($input){
					return intval($input->tapa);
				});

				$validator->sometimes('ctpat_certificate', 'required', function($input){
					return (intval($input->ctpat) && $input->ctpat != 'na');
				});

				$validator->sometimes('aeo_certificate', 'required', function($input){
					return (intval($input->aeo) && $input->aeo != 'na');
				});
				$step = 'actual_certification';
				$next = 'locations/create/3';
				break;
			case 3:
				$answers = array_keys(Lists::getAnswersList());
				$validator = Validator::make(Input::all(), Location::$questions_rules);

				$validator->sometimes('question', 'required', function($input) use ($answers) {
					if (isset($input->display))
					{
						foreach($input->display as $key => $value)
						{
							if (!in_array(intval($input->question[$key]), $answers))
							{
								return false;
							}
						}
					}

					return true;
				});

				$step = 'questions';
				$next = 'locations/create/4';
				break;
			case 4:
				$validator = Validator::make(Input::all(), Location::$comments_rules);

				$step = 'comments';
				$next = 'locations/create/5';
				break;
			case 5:
					Locations::saveLocationData();
					return Redirect::to('audits')
								->with('success', "Location audit created successfully.");
		}

		if ($validator->passes())
		{
			$data = Locations::setLocationStepData($step, Input::all());
			return Redirect::to($next);
		}
		else
		{
			return Redirect::back()
					->withInput()
					->withErrors($validator->messages());

		}
	}

	/**
	 * Display the specified resource.
	 * GET /locations/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		if (! Common::canAccess($id, 'location')) App::abort(403);

		$location = Location::with('user', 'country', 'lsp', 'question', 'certification', 'disabled_certification', 'location_log')->findOrFail($id);
		$audits = Certifications::getLocationAuditQuestions($location);
		$coordinates = Coordinate::convertToWGS84($location->coordinates);
		$current_certifications = Certifications::getCurrentCertifications($location);
		$legend = Certifications::getAnswersLegend();
		$users = ['' => ''] + Lists::getLspUsersList($location->lsp->id, $location->user->id);
		$owners = LocationOwner::where('location_id', $location->id)->lists('user_id');
		$location['audit_age'] = Common::CalculateAge($location['created_at']);
			
		return View::make('audits.location.show')
				->with('location', $location)
				->with('coordinates', $coordinates)
				->with('current_certifications', $current_certifications)
				->with('legend', $legend)
				->with('audits', $audits)
				->with('users', $users)
				->with('owners', $owners);
	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /locations/{id}/edit
	 *
	 * @param  int  $id
	 * @param  int  $step
	 * @return Response
	 */
	public function edit($id, $step = 0)
	{
		if (! Common::canAccess($id, 'location')) App::abort(403);

		switch(intval($step))
		{
			case 0:
				$data = Locations::getLocationEditData($id, 'basic_details');
				return self::basic_details_form($data, true);
			case 2:
				$data = Locations::getLocationEditData($id, 'actual_certification');
				return self::actual_certification_form($data, true);
			case 3:
				$data = Locations::getLocationEditData($id, 'questions');
				return self::questions_form($data, true);
			case 4:
				$data = Locations::getLocationEditData($id, 'comments');
				return self::comments_form($data, true);
			default:
				App::abort(404);
		}
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /locations/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		if (! Common::canAccess($id, 'location')) App::abort(403);

		$aeo_chk = ['aeo' => 'na' , 'aeo_num'=>'','aeo_certificate'=>''];
		$ctpat_chk = ['ctpat' => 'na' , 'svi_num'=>'','ctpat_certificate'=>''];

	   if(!array_key_exists('aeo',Input::all()) ){
	   		Input::merge($aeo_chk);
		}else if(!array_key_exists('ctpat',Input::all()) ){
			Input::merge($ctpat_chk);
		} 

		
		switch(intval(Input::get('step')))
		{
			case 0:
				$validator = Validator::make(Input::all(), Location::$basic_details_rules);

				$step = 'basic_details';
				break;
			case 2:
				$rules = Location::$actual_certification_rules;
				$rules['tapa'] = 'in:0,'. Site::TAPA_FSR_A .','. Site::TAPA_FSR_B .','. Site::TAPA_FSR_C;
				$rules['ctpat'] = 'in:0,"na",' . Site::C_TPAT;
				$rules['aeo'] = 'in:0,"na",' . Site::AEO_S .','. Site::AEO_F .','. Site::AEO_C;
				$validator = Validator::make(Input::all(), $rules);

				$validator->sometimes('svi_num', 'required', function($input){
					return (isset($input->ctpat) && intval($input->ctpat));
				});

				$validator->sometimes('aeo_num', 'required', function($input){
					return (isset($input->aeo) && intval($input->aeo));
				});

				$certs = Locations::getCurrentCertifications($id);

				// Require file only if the certificate has changed.
				$validator->sometimes('tapa_certificate', 'required', function($input) use ($certs) {
					return ($certs->tapa != $input->tapa);
				});

				$validator->sometimes('ctpat_certificate', 'required', function($input) use ($certs) {
					return ($certs->ctpat != 'na' && $certs->ctpat != $input->ctpat);
				});

				$validator->sometimes('aeo_certificate', 'required', function($input) use ($certs) {
					return ($certs->ctpat != 'na' && $certs->aeo != $input->aeo);
				});

				$step = 'actual_certification';
				break;
			case 3:
				$answers = array_keys(Lists::getAnswersList());
				$validator = Validator::make(Input::all(), Location::$questions_rules);

				$validator->sometimes('question', 'required', function($input) use ($answers) {
					if (isset($input->display))
					{
						foreach($input->display as $key => $value)
						{
							if (!in_array(intval($input->question[$key]), $answers))
							{
								return false;
							}
						}
					}

					return true;
				});

				$step = 'questions';
				break;
			case 4:
				$validator = Validator::make(Input::all(), Location::$comments_rules);

				$step = 'comments';
				break;
			default:
				App::abort(404);
		}

		if ($validator->passes())
		{
			$data = Locations::setLocationEditData($id, $step, Input::all());
			return Redirect::route('locations.show', $id)
					->with('success', 'Location audit updated successfully.');
		}
		else
		{
			return Redirect::back()
					->withInput()
					->withErrors($validator->messages());

		}
	}

	/**
	 * Toggle review status of the specified resource.
	 * PATCH /locations/review/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function review($id ,$option ='request')
	{
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager()) App::abort(403);

		$location = Location::findOrFail($id);

        $locationlogArray = array('location_id'=>$location->id,'user_id'=>\Auth::User()->id);

		if($option == 'clear')
		{
			$location->review = 0;
			$locationlogArray['cleared_at'] = date('Y-m-d h:i:s');
			
			Emails::sendLocationCleared($location);
			$msg = 'Review request has been cleared.';
		}
		else{
			$location->review = 1;
			$locationlogArray['requested_at'] = date('Y-m-d h:i:s');

			Emails::sendLocationReview($location, Input::get('review_message'));
			$msg = 'Review has been requested.';
		}

		$location->save();

		$locationlog = LocationLog::insert($locationlogArray); // Location log insert whether it is cleared/requested review

		return Redirect::route('locations.show', [$id])
				->with('success', $msg);
	}


	/**
	 * Toggle review status of the specified resource.
	 * PATCH /locations/status/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 **/
	public function status($id,$option='inactive')
	{
		//echo $id."$$".$option; 
	
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager() && !Auth::User()->isUser() && !Auth::User()->isSupervisor()) App::abort(403);
	
		$location = Location::findOrFail($id);

		$location->status = $option;

		$location->save();

		 return Redirect::route('locations.show', [$id])
				->with('success', 'Location audit changed to <b>'.ucfirst($option).'</b> status.');

	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /locations/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		if (! Common::canAccess($id, 'location')) App::abort(403);

		$location = Location::findOrFail($id);
		$location->delete();

		return Redirect::route('audits.index')
				->with('success', 'Location audit deleted successfully.');
	}

	/**
	 * Create Session Incomplete Audit
	 *
	 * @param int $id
	 * @return Response
	 **/
	public function incomplete($id)
	{

		$Location =  Location::find($id);
		$basic 	  =  Location::$basic_details_rules;

		foreach($basic as $ky=>$val)
		{
		   if($ky != 'country')	Session::put('locations.basic_details.'.$ky,$Location['original'][$ky]);
		   else Session::put('locations.basic_details.'.$ky,$Location['original']['country_id']);
		}

		Session::put('locations.id', $id);

		return Redirect::route('locations.create');
	}

	/**
	 * Update owners for the location.
	 * POST /locations/update-owners
	 *
	 * @return Response
	 */
	public function updateOwners()
	{
		if (! \Auth::User()->isAdmin()
				&& ! \Auth::User()->isSupervisor()
				&& ! \Auth::User()->isManager()) App::abort(403);

		$data = Input::get('owners');
		$location_id = intval(Input::get('id'));

		//@TODO: Check if the users belongs to same lsp

		if ($location_id)
		{
			$affected = LocationOwner::where('location_id', $location_id)
							->delete();
			if ($data)
			{
				foreach($data as $user_id)
				{
					LocationOwner::create([
							'location_id' => $location_id,
							'user_id' => $user_id,
						]);
				}
			}
		}
	}

}
