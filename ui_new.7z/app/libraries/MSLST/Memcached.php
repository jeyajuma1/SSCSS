<?php namespace MSLST;

/**
 * Creates a Memecache Object and simulates Memcached
 * Only for Windows
 */
class Memcached {
   const OPT_LIBKETAMA_COMPATIBLE = true;
   const OPT_COMPRESSION = true;
   const OPT_NO_BLOCK = true;
   const RES_SUCCESS = 0;
   // Define other constants here
   // Refer: http://www.php.net/manual/en/memcached.constants.php

   public $_instance;

   public function __construct() {
      $this->_instance = new \Memcache;
   }

   public function __call($name, $args) {
      if ($name == 'getResultCode')
      {
        return self::RES_SUCCESS;
      } 
      return call_user_func_array(array($this->_instance, $name), $args);
   }

   public function setOption() {}
}