<?php namespace MSLST\Helpers;

class Common {

    /**
     * @var string
     */
    const PASSWORD_NOT_COMPLEX = 'The password does not meet the requirements.';

    /**
     * Set the link active if its current.
     *
     * @param string path
     * @return boolean
     */
    public static function activeURI($path, $more = [])
    {
        $any = false;
        $more[] = $path;

        foreach ($more as $item)
        {
            if (\Request::is($item))
            {
                $any = true;
                break;
            }
        }

    	return ($any ? 'class="active"' : '');
	}

    /**
     * Set the link active if its the options URI.
     *
     * @return boolean
     */
    public static function optionsURI()
    {
    	$isOptions = false;

    	if (\Request::is('regions*')
    		|| \Request::is('countries*')
    		|| \Request::is('lsps*')
    		|| \Request::is('certifications*')
    		|| \Request::is('questions*')
    		|| \Request::is('settings*'))
    	{
    		$isOptions = true;
    	}

    	return ($isOptions ? 'class="active"' : '');
	}

    /**
     * Generate CSS classes from URI.
     *
     * @return string
     */
    public static function pageClasses()
    {
        $pageId = preg_replace('/[^a-zA-Z\-]/', '', \Request::path());
        if ($pageId == '/')
        {
            $pageId = 'login-page';
        }

        $classes = $pageId;

        if (! \Auth::check())
        {
            $classes .= ' no-auth';
        }

        return $classes;
    }

    /**
     * Get all names from the certifications
     *
     * @param array $certifications
     * @return string
     */
    public static function getCertificationNames($certifications)
    {
        $list = array_map(function ($item) {
            return $item->name;
        }, $certifications);

        return implode(' / ', $list);
    }

    /**
     * Format all settings in object array form
     *
     * @param array $settings
     * @return object
     */
    public static function getFormattedSettings($settings)
    {
        $settings_object = new \stdClass;

        // Create a settings object to ease the use in template
        foreach($settings as $item)
        {
            $settings_object->{$item->name} = $item->value;
        }

        return $settings_object;
    }

    /**
     * Check if the provided string is json or not
     *
     * @param string $string
     * @return boolean
     */
    public static function isJson($string)
    {
        return preg_match('/^(\{|\[)/', $string);
    }

    /**
     * Get date status code
     *
     * @param $item string
     * @param $true string
     * @param $false string
     * @return array
     */
    public static function getDateStatus($item, $true, $false)
    {
        $status = [];

        if (!$item || $item->format('U') < 0)
        {
            $status = [
                'code' => false,
                'label' => $false
            ];
        }
        else
        {
            $status = [
                'code' => true,
                'label' => $true
            ];
        }

        return $status;
    }

    /**
     * Check the access privileges for a resource
     *
     * @param $id number
     * @param $type string
     * @param $user object
     * @param $resource object
     * @return boolean
     */
   public static function canAccess($id, $type, $user = null, $resource = null,$leakid= null)
    {

       
        // If there is to explicit user, use the current user
        if (!$user)
        {
            $user = \Auth::User();
        }

        

        // Admin and manager can can access everything
        if ($user->isAdmin() || $user->isManager())
        {
            return true;
        }

          // If it is an incident file
        if ($type == 'attachment' || $type == 'imei' || $type == 'incident' || $type == 'sn' )
        {
            $incident = $resource ? $resource : \Incident::findOrFail($id);

            // Check for additional ownerships
            $owner = \IncidentOwner::where('incident_id', $incident->id)
                            ->where('user_id', $user->id)
                            ->lists('id');
            if ($owner)
            {
                return true;
            }

            if ($user->isUser())
            {
                if ($incident->user->id == $user->id) return true;
            }
            elseif ($user->isSupervisor())
            {
                if ($incident->user->id == $user->id) return true;

                if ($incident->user->lsp->id == $user->lsp->id) return true;
            }
        }
        // If it is an audit
        elseif ($type == 'location' || $type == 'route')
        {
            if ($type == 'location')
            {
                $audit = $resource ? $resource : \Location::findOrFail($id);

                $owner = \LocationOwner::where('location_id', $audit->id)
                                ->where('user_id', $user->id)
                                ->lists('id');
            }
            else
            {
                $audit = $resource ? $resource : \Routes::findOrFail($id);

                $owner = \RouteOwner::where('route_id', $audit->id)
                                ->where('user_id', $user->id)
                                ->lists('id');
            }

            // Check for additional ownerships
            if ($owner)
            {
                return true;
            }

            if ($user->isUser())
            {
                if ($audit->user->id == $user->id) return true;
            }
            elseif ($user->isSupervisor())
            {
                if ($audit->user->id == $user->id) return true;

                if ($audit->lsp->id == $user->lsp->id) return true;
            }
        }elseif ($type == 'factoryincident') {

            $incident = $resource ? $resource : \FactoryIncident::findOrFail($id);

                if ($user->isUser())
                {
                    if ($incident->user->id == $user->id) return true;
                }
                elseif ($user->isSupervisor())
                {
                    if ($incident->user->id == $user->id) return true;

                    if ($incident->user->lsp->id == $user->lsp->id) return true;
                }
        }elseif ($type == 'supplier') {

            $supplier = $resource ? $resource : \Supplier::findOrFail($id);

                if ($user->isUser())
                {
                    if ($supplier->user->id == $user->id) return true;
                }
                elseif ($user->isSupervisor())
                {
                    if ($supplier->user->id == $user->id) return true;

                    if ($supplier->user->lsp->id == $user->lsp->id) return true;
                }
        }elseif($type == 'sitemaster') {

             $sitemaster = $resource ? $resource : \Sitemaster::findOrFail($id);

             if ($user->isUser())
                {
                    if ($sitemaster->user->id == $user->id) return true;
                }
                elseif ($user->isSupervisor())
                {
                    if ($sitemaster->user->id == $user->id) return true;

                    if ($sitemaster->user->lsp->id == $user->lsp->id) return true;
                }

        }elseif ($type == 'leak_prevention' || $type == 'site_leak_prevention' ) {
           /* $leak_prevention = \LeakPreventionAssessment::findOrFail($leakid);
           
                if ($user->isUser())
                {
                    if ($supplier->user->id == $user->id) return true;
                }
                elseif ($user->isSupervisor())
                {
                    if ($supplier->user->id == $user->id) return true;

                    if ($supplier->user->lsp->id == $user->lsp->id) return true;
                }*/
                return true;
        }elseif($type == 'p_r'){

            if ($user->isUser())
            {
                    if ($supplier->user->id == $user->id) return true;
            }
            return;
        }

        return false;
    }

/**
   * check the access privileges for Request Closure
   *
   **/

    public static function canRequestAccess($type,$user = null,$resource=null){

        // If there is to explicit user, use the current user
        if (!$user)
        {
            $user = \Auth::User();
        }


         if ($type == 'incident')
        {

            $incident = $resource ? $resource : \Incident::findOrFail($id);

            // Check for additional ownerships
            $owner = \IncidentOwner::where('incident_id', $incident->id)
                            ->where('user_id', $user->id)
                            ->lists('id');


            if ($owner)
            {
                return true;
            }


            if ($user->isUser() || $user->isAdmin())
            {
                if ($incident->user->id == $user->id) return true;
            }
            elseif ($user->isSupervisor() || $user->isManager())
            {
                if ($incident->user->id == $user->id) return true;

                if ($incident->user->lsp->id == $user->lsp->id) return true;
            }

        }


        return false;


    }

/**
   * check the access privileges for a leak prevention resource
   *
   **/

    public static function canAccessLeak($type,$user=null,$resource = null)
    {
        // If there is to explicit user, use the current user
        if (! $user)
        {
            $user = \Auth::User();
        }

         // Admin and manager can can access everything
        /*if ($user->isAdmin())
        {
            return true;
        }*/


        if($type == 'sitemaster') {

             $sitemaster = $resource ? $resource : \Sitemaster::findOrFail($id);
 
             if ($sitemaster->user->id == $user->id) return true;
             
        }

         
    }


    /**
   * check the access privileges for a leak prevention resource
   *
   **/

    public static function canAccessPR($user=null,$resource = null)
    {
            $sitemaster = $resource ? $resource : \Sitemaster::findOrFail($id);
            
            // Checking Site
            if($user->isAdmin()){
                return 'admin';
            }else if (($user->isUser() && $user->access_p_r == 1) || ($user->isSupervisor()  && $user->access_p_r == 1) || ($user->isManager()  && $user->access_p_r == 1)  )
            {
 
                    if ($sitemaster->user->id == $user->id && $user->site_user_level == 'csm') return 'csm_plus_user';
                    if ($sitemaster->user->id != $user->id && $user->site_user_level == 'csm') return 'csm_user';


                    /* Checking VAM is associcated with this site */
                   
                   if(!empty($user->user_vam_site_id) && in_array($sitemaster->id,json_decode($user->user_vam_site_id)) ) {
                        if ($sitemaster->user->id == $user->id && $user->site_user_level == 'vam') return 'vam_plus_user';
                        if ($sitemaster->user->id != $user->id && $user->site_user_level == 'vam') return 'vam_user';
                    }/*else{
                        return 'no_vam_user';
                    }*/

                    if ($sitemaster->user->id == $user->id)  return 'supplier_user';
            }else{
                return false;
            } 

         
    }



    /**
   * check the access privileges for a leak prevention resource
   *
   **/

    public static function canAccessLP($user=null,$resource = null)
    {
            $sitemaster = $resource ? $resource : \Sitemaster::findOrFail($id);
            
            // Checking Site
            if($user->isAdmin()){
                return 'admin';
            }else if (($user->isUser() && $user->access_leak_prevention == 1) || ($user->isSupervisor()  && $user->access_leak_prevention == 1) || ($user->isManager()  && $user->access_leak_prevention == 1)  )
            {
 
                    if ($sitemaster->user->id == $user->id && $user->site_user_level == 'protection_pm') return 'pm_plus_user';


                    if ($sitemaster->user->id != $user->id && $user->site_user_level == 'protection_pm') {
                     return 'pm_user';
                    }else{
                          if ($sitemaster->user->id == $user->id)  return 'supplier_user';

                          return 'no_pm_user';
                    }

                  
            }else{
                return false;
            } 

         
    }


 /**
     * Check the access privileges for a resource
     *
     * @param $id number
     * @param $type string
     * @param $user object
     * @param $resource object
     * @return boolean
     */
    public static function canAccessEdit($id, $type,$user = null, $resource = null)
    {
        // If there is to explicit user, use the current user
        if (! $user)
        {
            $user = \Auth::User();
        }

        // Admin and manager can can access everything
        if ($user->isAdmin())
        {
            return true;
        }

        // If it is an incident file
        if ($type == 'attachment' || $type == 'imei' || $type == 'incident')
        {
            $incident = $resource ? $resource : \Incident::findOrFail($id);

            // Check for additional ownerships
            $owner = \IncidentOwner::where('incident_id', $incident->id)
                            ->where('user_id', $user->id)
                            ->lists('id');
            if ($owner)
            {
                return true;
            }

            if ($user->isUser())
            {
                if ($incident->user->id == $user->id) return true;
            }
            elseif ($user->isSupervisor())
            {
                if ($incident->user->id == $user->id) return true;

                if ($incident->user->lsp->id == $user->lsp->id) return true;
            }
        }
        // If it is an audit
        elseif ($type == 'location' || $type == 'route')
        {
            if ($type == 'location')
            {
                $audit = $resource ? $resource : \Location::findOrFail($id);

                $owner = \LocationOwner::where('location_id', $audit->id)
                                ->where('user_id', $user->id)
                                ->lists('id');
            }
            else
            {
                $audit = $resource ? $resource : \Routes::findOrFail($id);

                $owner = \RouteOwner::where('route_id', $audit->id)
                                ->where('user_id', $user->id)
                                ->lists('id');
            }

            // Check for additional ownerships
            if ($owner)
            {
                return true;
            }

            if ($user->isUser())
            {
                if ($audit->user->id == $user->id) return true;
            }
            elseif ($user->isSupervisor())
            {
                if ($audit->user->id == $user->id) return true;

                if ($audit->lsp->id == $user->lsp->id) return true;
            }
        }elseif ($type == 'factoryincident') {

            $incident = $resource ? $resource : \FactoryIncident::findOrFail($id);

                if ($user->isUser())
                {
                    if ($incident->user->id == $user->id) return true;
                }
                elseif ($user->isSupervisor())
                {
                    if ($incident->user->id == $user->id) return true;

                    if ($incident->user->lsp->id == $user->lsp->id) return true;
                }
        }elseif($type == 'supplier') {

             $supplier = $resource ? $resource : \Supplier::findOrFail($id);

             if ($user->isUser())
                {
                    if ($supplier->user->id == $user->id) return true;
                }
                elseif ($user->isSupervisor())
                {
                    if ($supplier->user->id == $user->id) return true;

                    if ($supplier->user->lsp->id == $user->lsp->id) return true;
                }

        }elseif($type == 'sitemaster') {

             $sitemaster = $resource ? $resource : \Sitemaster::findOrFail($id);

             if ($user->isUser())
                {
                    if ($sitemaster->user->id == $user->id) return true;
                }
                elseif ($user->isSupervisor())
                {
                    if ($sitemaster->user->id == $user->id) return true;

                    if ($sitemaster->user->lsp->id == $user->lsp->id) return true;
                }

        }elseif($type == 'p_r'){

             $sitemaster = $resource ? $resource : \Sitemaster::findOrFail($id);
            
             $access_p_r = $user->getOriginal('access_p_r');

                

            if ($user->isUser() &&  $access_p_r == 1)
            {
                    if ($sitemaster->user->id == $user->id) return true;
            }

            if($user->site_user_level == 'vam' &&  $access_p_r == 1){
                 return true;
            }

            if($user->site_user_level == 'csm' &&  $access_p_r == 1){
                 return true;
            }

             if($access_p_r == 1){
                 return true;
            }


            //print "<pre>"; print_r($user); exit;

            return;
        }

        return false;
    }
    /**
     * Download the file
     *
     * @param $fid number
     * @param $id number
     * @param $type string
     * @param $user object
     */
    public static function downloadFile($fid, $id, $type, $user = null)
    {
        
       if (self::canAccess($id, $type, $user,'',$fid))
        {
            if ($type == 'attachment' || $type == 'imei' || $type == 'sn')
            {
                $file = \Attachment::findOrFail($fid);
                $filepath = $file->file_name;
                $filename = $file->file_description;
                $filetype = $file->file_type;

                if (! file_exists($filepath)) \App::abort(404);

                $filesize = filesize($filepath);
            }
            elseif ($type == 'location')
            {
                $file = \LocationCertification::findOrFail($fid);

                if ($file->filename)
                {
                    $filepath = $file->certificate_file;
                    $filename = $file->filename;
                }
                else
                {
                    $filepath = storage_path() .
                                DIRECTORY_SEPARATOR .
                                'files' .
                                DIRECTORY_SEPARATOR .
                                'locations' .
                                DIRECTORY_SEPARATOR .
                                $file->certificate_file;

                    if (! file_exists($filepath)) \App::abort(404);

                    $filename = $file->certificate_file;
                }

                $filetype = 'application/octet-stream';
                $filesize = filesize($filepath);
            }
            elseif ($type == 'route')
            {
                $file = \RouteCertification::findOrFail($fid);

                if ($file->filename)
                {
                    $filepath = $file->certificate_file;
                    $filename = $file->filename;
                }
                else
                {
                    $filepath = storage_path() .
                                DIRECTORY_SEPARATOR .
                                'files' .
                                DIRECTORY_SEPARATOR .
                                'routes' .
                                DIRECTORY_SEPARATOR .
                                $file->certificate_file;

                    $filename = $file->certificate_file;
                }

                $filetype = 'application/octet-stream';

                if (! file_exists($filepath)) \App::abort(404);

                $filesize = filesize($filepath);
            }else if($type == 'factoryincident'){

                $file = \FactoryAttachments::findOrFail($fid);

                $filepath = $file->file_name;  

                 $filename = $file->file_description;
                 

                $filetype = 'application/octet-stream';
                $filesize = filesize($filepath);

            }else if($type == 'leak_prevention'){
            
                $file = \LeakPreventionAssessment::findOrFail($fid);

                $filepath = $file->file_name;  

                 $filename = $file->file_description;
                 

                $filetype = 'application/octet-stream';
                $filesize = filesize($filepath);

            }else if($type == 'site_leak_prevention'){
            
                $file = \SiteLeakPreventionAssessment::findOrFail($fid);

                $filepath = $file->file_name;  

                 $filename = $file->file_description;
                 

                $filetype = 'application/octet-stream';
                $filesize = filesize($filepath);

            }

            // Send the file for download
            $response = \Response::make(file_get_contents($filepath))
                            ->header('Content-Disposition', 'attachment; filename='. urlencode($filename))
                            ->header('Content-Type', $filetype)
                            ->header('Content-Transfer-Encoding', 'binary')
                            ->header('Accept-Ranges', 'bytes')
                            ->header('Cache-control', 'private')
                            ->header('Pragma', 'private')
                            ->header('Content-Length', $filesize);

            return $response;
        }
        else
        {
            \App::abort(403);
        }
    }

    /**
     * Check the codeword policy
     *
     * @param string
     * @return boolean
     */
    public static function checkPasswordPolicy($password)
    {
        $password = trim($password);
        $messages = null;

        if (! preg_match('/^(?=.*\d)(?=.*[A-Za-z])(?=.*(_|\W))[0-9A-Za-z_\W]{8,50}$/', $password))
        {
            $messages = self::PASSWORD_NOT_COMPLEX;
        }

        return $messages;
    }

    /**
     * Check if the user has codeword
     *
     * @param $token string
     * @return boolean
     */
    public static function hasPassword($token)
    {
        $password_reminder = \PasswordReminder::where('token', $token)->first();

        if ($password_reminder)
        {
            $user = \User::where('email', $password_reminder->email)->first();

            if ($user)
            {
                if ($user->password_updated_at)
                {
                    return true;
                }
            }
        }

        return false;
    }

/**
 * Calculate Age
 *
 **/    
  public static function CalculateAge($created_at)
  {

            $startdate = new \DateTime($created_at);
            $endDate   = new \DateTime('now');
            $interval  = $endDate->diff($startdate);
            
            $time_ago = '';
             if (($t = $interval->format("%y")) > 0)
             {
                if(($t = $interval->format("%y"))==1)
                $time_ago = $t . ' year, ';
                else
                $time_ago = $t . ' years, ';
            }   
            if (($t = $interval->format("%m")) > 0){
                if(($t = $interval->format("%m"))==1)
                $time_ago =$time_ago. $t . ' month, ';
                else
                $time_ago = $time_ago.$t . ' months, ';
                }
             if(($t = $interval->format("%d"))>0)
            {
                if(($t = $interval->format("%d"))==1)
                $time_ago = $time_ago.$t . ' day.';
                else
                $time_ago = $time_ago.$t . ' days.';
            }
            if(($t = $interval->format("%d"))==0 && ($t = $interval->format("%m"))==0 && ($t = $interval->format("%y"))==0)
            {
                if(($t = $interval->format("%H"))==1)
                $time_ago = $time_ago.$t . ' hour.';
                else
                $time_ago = $time_ago.$t . ' hours.';
            }

         return $time_ago;
  }

    /**
   *  Statistics Month Range
   **/

  public static function HelperMonthRange(){

        $year = range(2012,date('Y'));
        $month = range(01,12);
        $option = Null;
        $options = ['' => 'All'];
        $current_year  = date('Y');
        $current_month = date('m');
        $monthval = ['01'=>'January','02'=>'February','03'=>'March','04'=>'April','05'=>'May','06'=>'June','07'=>'July','08'=>'August','09'=>'September','10'=>'October','11'=>'November','12'=>'December'] ;
        foreach($year as $yky=>$yval){
                foreach($month as $mky=>$mval){
                    if(strlen($mval) == 1) $mval = '0'.$mval;

                        $option.='<option value="'.$yval.$mval.'">'.$monthval[$mval].' '.$yval."</option>";
                        $options[$yval.$mval] =  $monthval[$mval].' '.$yval;

                    if($current_year == $yval && $current_month == $mval) break;
                }
       }

       return  $options;
  }




  

}
