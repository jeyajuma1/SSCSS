<?php
namespace MSLST\Helpers;


use Carbon\Carbon;
	class Sitemasters {
		public static $basic_information_fields = [
			'site_name', 'status', 'supplier_type','region', 'country', 'city', 'country_state','postal_code', 'address', 'coordinates',
		];
			
		public static $site_information_fields = [
			'lob', 'process', 'parent_site', 'primary_stakeholder', 'sec_stakeholder', 'channel_manager', 'vam', 'last_inspection_date', 'corrective_actions', 'comments','supplier_handle'
		];
		public static $contact_information_fields = [
			'contact_name', 'contact_email', 'other_contact_info',
		];
		public static $questions_fields = [
        'question'
    	];
    	public static $questions_answers_fields = [
       'self_answer_id','self_comment','onsite_answer_id','onsite_comment','supplier_id','question_id','ms_id','self_file_name','self_file_description','self_file_type','activity_id'
    	];

    	public static $inspection_answers_fields = [
       'answer_id','comment','sitemaster_id','question_id'
    	];

    	public static $CAselect = ['id','sitemaster_id','question_id','p_r_reference', 'p_r_version', 'p_r_text','inspector_comments', 'inspector_user_id', 'intial_due_date' ,'supplier_comments_evidence', 'supplier_user_id', 'due_date_extension','days_past_due', 'vam_approval', 'vam_user_id','vam_comments','supplier_request_closure'];
                            	   //


		public static function getSitemasterStepData($name) {
	
			$data = new \stdClass;
			$fields = [];
			$fields = self::${$name .'_fields'};

			if (\Session::has('sitemasters.'. $name))	{
			$data = (object) \Session::get('sitemasters.'. $name);
			}
			else{
				foreach ($fields as $field){
				$data->{$field} = '';
				}
			}
			return $data;
		}

		public static function setSitemasterStepData($name, $step_data) {
			$data = new \stdClass;
			$fields = self::${$name .'_fields'};
				foreach ($fields as $field)  {
					$data->{$field} = $step_data[$field];       
				}
			\Session::set('sitemasters.'. $name, $data);
		}

		public static function getSitemasterEditData($id, $name)  {
			$data = new \stdClass;
			$sitemaster = \Sitemaster::find($id);
			$data->id = $id;
			$fields =self::${$name .'_fields'};		
			foreach ($fields as $field)
			{
				if (isset($sitemaster->{$field}))
				{
					$data->{$field} = $sitemaster->{$field};
				}
			}

			// There is no region_id field, it is region
			$data->region = $sitemaster->region->id;

			// There is no country_id field, it is country
			$data->country = $sitemaster->country->id;
		 return $data;			
		}
		/**
		 * Save the sitemaster edit data
		 *
		 * @param $id number
		 * @param $step string
		 * @param $data array
		*/
		public static function setSitemasterEditData($id, $step, $data)  {
			$sitemaster = \Sitemaster::findOrFail($id);
			
			if ($step == 'basic_information')
			{
				$sitemaster->site_name = $data['site_name'];
				$sitemaster->status = $data['status'];
				$sitemaster->supplier_type = $data['supplier_type'];
				$sitemaster->address = $data['address'];
				$sitemaster->country_id = $data['country'];
				$sitemaster->region_id = $data['region'];
				$sitemaster->city = $data['city'];
				$sitemaster->postal_code = $data['postal_code'];
				$sitemaster->coordinates = $data['coordinates'];
				$sitemaster->country_state = $data['country_state'];
				$sitemaster->save();
			}
			elseif ($step == 'site_information')
			{	$sitemaster->lob = $data['lob'];
				$sitemaster->process = $data['process'];
				$sitemaster->parent_site = $data['parent_site'];
				$sitemaster->primary_stakeholder = $data['primary_stakeholder'];
				$sitemaster->sec_stakeholder = $data['sec_stakeholder'];
				$sitemaster->channel_manager = $data['channel_manager'];
				$sitemaster->vam = $data['vam'];
				$sitemaster->last_inspection_date = !empty($data['last_inspection_date'])?$data['last_inspection_date'] : NULL;	
				$sitemaster->corrective_actions = $data['corrective_actions'];
				$sitemaster->comments = $data['comments'];
				$sitemaster->supplier_handle = $data['supplier_handle'];
				$sitemaster->save();
			}
			elseif ($step == 'contact_information') 
			{
				$sitemaster->contact_name = $data['contact_name'];
				$sitemaster->contact_email = $data['contact_email'];
				$sitemaster->other_contact_info = $data['other_contact_info'];
				$sitemaster->save();
			}
			// Send incident update notification
			//Emails::sendIncidentCreateUpdate($incident, 'updated');
			$sitemasterlogArray = ['sitemaster_id' => $sitemaster->id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SitemasterLog::insert($sitemasterlogArray);
		}

		public static function saveSitemasterData() {
			$sitemaster_data = \Session::get('sitemasters');
			// Get the data from each steps
			$basic_information = (array) $sitemaster_data['basic_information'];
			$site_information = (array) $sitemaster_data['site_information'];
			$contact_information = (array) $sitemaster_data['contact_information'];
			
			// First create the incident
			$sitemaster = \Sitemaster::create([
				'site_name'=> $basic_information['site_name'],
				'status'=> $basic_information['status'],
				'supplier_type'=> $basic_information['supplier_type'],
				'country_id'=> $basic_information['country'],
				'region_id'=> $basic_information['region'],
				'city'=> $basic_information['city'],
				'country_state'=> $basic_information['country_state'],
				'postal_code'=> $basic_information['postal_code'],
				'address'=> $basic_information['address'],
				'coordinates'=> $basic_information['coordinates'],
				'lob'=> $site_information['lob'],
				'process'=> $site_information['process'],
				'parent_site'=> $site_information['parent_site'],
				'primary_stakeholder'=> $site_information['primary_stakeholder'],
				'sec_stakeholder'=> $site_information['sec_stakeholder'],
				'channel_manager'=> $site_information['channel_manager'],	
				'vam'=> $site_information['vam'],	
				'last_inspection_date'=> !empty($site_information['last_inspection_date'])?$site_information['last_inspection_date'] : NULL,	
				'corrective_actions'=> $site_information['corrective_actions'],	
				'comments'=> $site_information['comments'],	
				'contact_name'=> $contact_information['contact_name'],
				'contact_email'=> $contact_information['contact_email'],
				'other_contact_info'=> $contact_information['other_contact_info'],
				'supplier_handle' => $site_information['supplier_handle'],
				'user_id' => \Auth::User()->id
			]);
			// Send incident create notification
			//Emails::sendIncidentCreateUpdate($supplier, 'created');
			\SitemasterLog::create([
	            'sitemaster_id' => $sitemaster->id,
	            'user_id' => \Auth::User()->id,
	            'created_at'=>  Carbon::parse('now')
	        ]);

			// Destroy the session data
			\Session::forget('sitemasters');
		}
		 /**
     * Get all sitemasters by filters
     *
     * @param $filters array
     * @return array
     */
    public static function getFilteredSitemasters($filters)
    {		//echo '<pre>';print_r($filters);exit;
		$sitemasters = \Sitemaster::with('user', 'country', 'region');

		/*if (isset($filters['daterange']) && !empty($filters['daterange']))
		{
			list($start, $end) = explode(' - ', $filters['daterange']);

			$start = new \DateTime($start);
			$end = new \DateTime($end);

			$sitemasters->where(\DB::raw("date_format(incident_date,'%Y-%m-%d')"), '>=', $start->format('Y-m-d'))
					  ->where(\DB::raw("date_format(incident_date,'%Y-%m-%d')"), '<=', $end->format('Y-m-d'));
		}*/

		if (isset($filters['user']) && !empty($filters['user']))
		{
			$sitemasters->whereIn('user_id', $filters['user']);
		}
		
		if (isset($filters['supplier_type']) && !empty($filters['supplier_type']))
		{
			// print_r($filters['supplier_type']);exit;
			$sitemasters->whereIn('supplier_type', $filters['supplier_type']);
		}
		
		if (isset($filters['channel_manager']) && !empty($filters['channel_manager']))
		{
			$sitemasters->whereIn('channel_manager', $filters['channel_manager']);
		}
		/*if (isset($filters['customer']) && !empty($filters['customer']))
		{
			foreach ($filters['customer'] as $key=>$customer)
			{
				$filters['customer'][$key] = strtolower($customer);
            }
            $sitemasters->whereIn('customer' , $filters['customer']);

		}

		if (isset($filters['category']) && !empty($filters['category']))
		{
			$sitemasters->whereIn('category', $filters['category']);
		}*/

		if (isset($filters['status']) && !empty($filters['status']))
		{
			if (count($filters['status']) == 1)
			{
				if ($filters['status'][0] == 'inactive')
				{	$sitemasters->whereIn('status', $filters['status']);
					//$sitemasters->whereRaw('(closed_at is not null AND closed_at <> "0000-00-00 00:00:00")');
				}
				else
				{$sitemasters->whereIn('status', $filters['status']);
					//$sitemasters->whereRaw('(closed_at is null OR closed_at = "0000-00-00 00:00:00")');
				}
			}
		}

		/*if (isset($filters['lsp']) && !empty($filters['lsp']))
		{
            $sitemasters->whereHas('user', function($q) use (&$filters) {
                $q->whereIn('lsp_id', $filters['lsp']);
                $q->withTrashed();
            });
		}*/

		if (isset($filters['region']) && !empty($filters['region']))
		{
			$sitemasters->whereIn('region_id', $filters['region']);
		}

		if (isset($filters['country']) && !empty($filters['country']))
		{
			$sitemasters->whereIn('country_id', $filters['country']);
		}

		if (isset($filters['sitemaster_id']) && !empty($filters['sitemaster_id']))
		{
            $sitemaster_id = $filters['sitemaster_id'];

            $sitemasters->where('id', intval($sitemaster_id));
		}

        if (\Auth::User()->isUser())
        {
            $sitemasters->where(function ($q) {
                
				$q->where('sitemasters.user_id', \Auth::User()->id);
				
			});
        }

        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
          /* $incidents->whereHas('user', function($q) {
                $q->where('lsp_id', '=', \Auth::User()->lsp->id);
            });*/

           $regionChk = \UserRegion::select('region_id')
                                   ->where('user_id',\Auth::User()->id)
                                   ->lists('region_id');

           $sitemasters->whereIn('region_id', $regionChk);

           /*$lspChk    = \User::select('id')
                             ->where('lsp_id',\Auth::User()->lsp->id)
                             ->lists('id');
           $sitemasters->whereIn('user_id', $lspChk);*/
           
        }

		$sitemasters = $sitemasters
					->orderBy('created_at', 'DESC')
					->get()
					->all();

		//dd(\DB::getQueryLog());

		return $sitemasters;
    }


     /**
     *
     *
     **/
    public static function SaveActionPlan($data,$option=null){
    	
    	$action = Lists::getBusinessAction('leak_risk_plan','SiteBusinessAction');


    	$leak_create = [];
    	$leak_create['sitemaster_id'] = $data['sitemaster_id'];

    	foreach($data['asset_id'] as $kar=>$kav){

	    	/*Get Risk Id*/
	    	$risk = \SiteBusinessRisk::select('id','name');
	    	foreach ($kav as $key => $value) {
	    		if($key == 0)
	    		    $risk->where('asset_ids','like','%"'.$value.'"%');
	    		else
	    		    $risk->orwhere('asset_ids','like','%"'.$value.'"%');
	    	}
	    	$risk = $risk->lists('name','id');

       
	    	if($option == 'exist'){
		    	/* Selecting Leak prevention id for existing */
		    	$select_preven_arry = \SiteLeakPreventionAssessment::select('risk_id')
		    							->where('sitemaster_id',$data['sitemaster_id'])
		    							->where('leak_id',$data['LeakRiskAnalysis_id'][$kar])
		    							->lists('risk_id');
		        /*Deleting unselected Leak prevention from existing*/
		        $delete_id = array_diff($select_preven_arry,array_flip($risk));
		        if(!empty($delete_id)){
			       \SiteLeakPreventionAssessment::where('sitemaster_id',$data['sitemaster_id'])
			    							->where('leak_id',$data['LeakRiskAnalysis_id'][$kar])
			    							->whereIn('risk_id',$delete_id)
			    							->delete();
			    }

		    	//$risk = array_flip(array_diff(array_flip($risk), $select_preven_arry)); // Removed after asking to delete duplicate action entries
		    }	

 
	    	/*Insert in Leak Prevention Plan*/
	     	if(!empty($risk)){ 
		    	
		     	foreach($risk as $kay=>$val){

			     	foreach ($action[$kay] as $key => $action_value) {
			     	
			     		$chk_cnt = \SiteLeakPreventionAssessment::where('action_name','like','%'.$action_value['action_name'].'%')->where('sitemaster_id',$data['sitemaster_id'])->count();
			    		
			     		if($chk_cnt == 0){

				     		switch($option){
				    			case 'new':
				    				$leak_create['risk'] = $val;
									$leak_create['risk_id']   = $kay;
									$leak_create['action_id']   = $action_value['action_id'];
									$leak_create['action_name']   = $action_value['action_name'];
									$leak_create['action_description']  = $action_value['action_description'];
									$leak_create['leak_id']   = $data['LeakRiskAnalysis_id'][$kar];
						    		$leak_create['status']  = 'Not Started';
						    		\SiteLeakPreventionAssessment::create($leak_create);
					    		break;
					    		case 'exist':
					    			$leak_update['risk'] = $val;
									$leak_update['risk_id']   = $kay;
									$leak_update['action_id']   = $action_value['action_id'];
									$leak_update['action_name']   = $action_value['action_name'];
									$leak_update['action_description']  = $action_value['action_description'];
									$leak_update['sitemaster_id']   = $data['sitemaster_id'];
									$leak_update['leak_id']   = $data['LeakRiskAnalysis_id'][$kar];
						    		$leak_update['status']  = 'Not Started';
	 
					    			\SiteLeakPreventionAssessment::create($leak_update);
					    		break;
				    	   }
				    	}

			     	}

		    		

		    	}
		    }

	    }
	    

    }
    /*
         * Storing Self-Assessment Data
         *
         */
		public static function setselfassessment($id,$data) {
			
			$activities=Lists::getActivitiesList('SiteBusinessActivity');
			$sitemasters = [];
			$activitykey=0;
				
				if(isset($data[$activitykey.'question']))
				{	
					$questions = $data[$activitykey.'question'];
					$self_comments = isset($data[$activitykey.'selfcomment']) ? $data[$activitykey.'selfcomment'] : [];
					$assessment_data = Sitemasters::get_assessment_data($id,$activitykey);
					// Delete current SA anseres
		            $self = \SiteBusinessAnswer::where(['sitemaster_id'=>$id,'activity_id'=>$activitykey])
		                                        ->forceDelete();
		            // Save the self-assessment ansewrs 
		            foreach ($questions as $qid => $aid)
			            {
			                $self = new \stdClass;
			                $self->self_answer_id = intval($aid);
			                
			                \SiteBusinessAnswer::create([
			                    'sitemaster_id' => $id,
			                    'question_id' => $qid,
			                    'self_answer_id' => $self->self_answer_id,
			                    'self_comment' => isset($self_comments[$qid]) ? $self_comments[$qid] :' ',
			                    'onsite_answer_id'=>isset($assessment_data->onsite_answer_id[$qid])?$assessment_data->onsite_answer_id[$qid]:' ',
			                    'onsite_comment' =>isset($assessment_data->onsite_comment[$qid]) ? $assessment_data->onsite_comment[$qid] :' ',
			                    'ms_id'=>isset($assessment_data->ms_id[$qid])?$assessment_data->ms_id[$qid]:'',
			                    'activity_id' =>$activitykey

			                ]);

			                $sitemasters[] = $self;
			            }
	        	}
        	
        	
       		//Updating Supplier_log
			$logArray = ['sitemaster_id' => $id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SiteMasterLog::insert($logArray);
            
            // Calculate the SA score             
            $sitemaster_tb = \Sitemaster::findOrFail($id);
            $sitemaster_tb->self_assessment_score = self::calculateScore($id, $sitemasters,'self_assessment');
            $sitemaster_tb->save();
        }
	     /*
	     * Storing Onsite-Assessment Data
	     *
	     */
        public static function setonsiteassessment($id,$data,$ms_id) {
			$activities=Lists::getActivitiesList('SiteBusinessActivity');
			$sitemasters = [];
			$activitykey=0;
				if(isset($data[$activitykey.'question']))
				{	
					$questions = $data[$activitykey.'question'];
					$onsite_comments = isset($data[$activitykey.'onsitecomment']) ? $data[$activitykey.'onsitecomment'] : [];
					$assessment_data = Sitemasters::get_assessment_data($id,$activitykey);
					
					// Delete current OSA answers
		            $self = \SiteBusinessAnswer::where(['sitemaster_id'=>$id,'activity_id'=>$activitykey])
		                                        ->forceDelete();
	                foreach ($questions as $qid => $aid)
			        {
		                $self = new \stdClass;
		                $self->onsite_answer_id = intval($aid);
		                
		                \SiteBusinessAnswer::create([
		                	'sitemaster_id' => $id,
		                    'question_id' => $qid,
		                    'onsite_answer_id' => $self->onsite_answer_id,
		                    'onsite_comment' => isset($onsite_comments[$qid]) ? $onsite_comments[$qid] : '',
		                    'self_answer_id'=>isset($assessment_data->self_answer_id[$qid])?$assessment_data->self_answer_id[$qid]:0,
		                    'self_comment' =>isset($assessment_data->self_comment[$qid]) ? $assessment_data->self_comment[$qid] : '',
		                    'ms_id' => $ms_id,
		                    'self_file_name'=>isset($assessment_data->self_file_name[$qid]) ? $assessment_data->self_file_name[$qid] : '',
		                    'self_file_description'=>isset($assessment_data->self_file_description[$qid]) ? $assessment_data->self_file_description[$qid] : '',
		                    'self_file_type'=>isset($assessment_data->self_file_type[$qid]) ? $assessment_data->self_file_type[$qid] : '',
		                    'activity_id' =>$activitykey
		                   ]);

	                	$sitemasters[] = $self;
	            	}
	        	}    
	    	
        
            //Updating Supplier_log
			$logArray = ['sitemaster_id' => $id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SiteMasterLog::insert($logArray);
            // Calculate the OSA score 
            $sitemaster_tb = \Sitemaster::findOrFail($id);
            $sitemaster_tb->onsite_assessment_score = self::calculateScore($id, $sitemasters,'onsite_assessment');
            $sitemaster_tb->save();
        }
        public static function get_assessment_data($id,$activitykey)
		{
			
			$data = new \stdClass;
        	$sitemasters = \SiteBusinessAnswer::where(['sitemaster_id'=>$id,'activity_id'=>$activitykey])
	        							->get();
			$fields = self::$questions_answers_fields;
        	foreach ($sitemasters as $sitemaster) 
        	{	
        		$data->id = $id;
	        	foreach ($fields as $field)
		        {
		            $data->{$field}[$sitemaster->question_id] = $sitemaster->{$field};
		           
		        }
		    }
	    
			return $data;
		}

		public static function get_inspection_data($id)
		{
			
			$data = new \stdClass;
        	$sitemasters = \SiteInspectionAnswer::select('id','question_id','answer_id','comment','sitemaster_id','user_id')
        										->where(['sitemaster_id'=>$id,'user_id'=>\Auth::User()->id])
	        									->get();



			$fields = self::$inspection_answers_fields;
        	foreach ($sitemasters as $sitemaster) 
        	{	
        		$data->id = $id;
	        	foreach ($fields as $field)
		        {
		            $data->{$field}[$sitemaster->question_id] = $sitemaster->{$field};
		           
		        }
		    }

			return $data;
		}


		 public static function setsiteinspection($id,$data,$type=Null) {
			$sitemasters = [];
			//echo Carbon::parse('7 days');
				//print "<pre>";print_r($data);exit;
				if(isset($data['question']))
				{	
					$questions = $data['question'];
					$comments = isset($data['comment']) ? $data['comment'] : [];
					$assessment_data = Sitemasters::get_inspection_data($id);
					
					// Delete current OSA answers
		            $self = \SiteInspectionAnswer::where(['sitemaster_id'=>$id,'user_id'=>\Auth::User()->id])
		                                        ->forceDelete();
	                foreach ($questions as $qid => $aid)
			        {
		                $self = new \stdClass;
		                $self->answer_id = intval($aid);
		                
		                \SiteInspectionAnswer::create([
		                	'sitemaster_id' => $id,
		                    'question_id' => $qid,
		                    'answer_id'=>isset($self->answer_id)?$self->answer_id:0,
		                    'comment' =>$comments[$qid],
		                    'user_id' =>\Auth::User()->id
		                   ]);

		               if($self->answer_id == 2){
		               		$due_date = 'now';
		               		if($data['severity'][$qid] == 1) $due_date = '7 days'; // Urgent
		               		if($data['severity'][$qid] == 2) $due_date = '15 days'; // High
		               		if($data['severity'][$qid] == 3) $due_date = '30 days'; // Medium
		               		if($data['severity'][$qid] == 4) $due_date = '60 days'; // Low

			               	$corective_actions[] = [
			               		'sitemaster_id' =>  $id,
								'question_id' => $qid
								,'p_r_reference' => $data['reference'][$qid]
								,'p_r_version' => $data['version'][$qid]
								,'p_r_text'   =>  $data['p_rtext'][$qid]
								,'inspector_comments' => $data['comment'][$qid]
								,'inspector_user_id' => \Auth::User()->id
								,'intial_due_date' => Carbon::parse($due_date)
							];
		               }


	                	$sitemasters[] = $self;
	            	}

	            	$corrective_actions_olddata=\SiteCorrectiveAction::where('sitemaster_id',$id)->get();
	            	//print "<pre>";print_r([$corrective_actions_olddata,$corective_actions]);exit;
	            	if(!empty($corective_actions)){\SiteCorrectiveAction::insert($corective_actions);}
	        	}    
	    	
        
            //Updating Supplier_log
			$logArray = ['sitemaster_id' => $id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SiteMasterLog::insert($logArray);

			$prlogArray = ['sitemaster_id' => $id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now'),'type'=>$type];
			\SitePrLog::insert($prlogArray);

            
        }

		public static function calculateScore($sitemaster_id, $sitemasters = null,$data)
	    {
	        if (!$sitemasters)
	        {
	            $sitemasters = \SiteBusinessAnswer::where('sitemaster_id', $sitemaster_id)->get()->all();
	        }

	        $score = $count = $final_score = 0;
	        if($data=='self_assessment')
		    {    
		        if ($sitemasters)
		        {
		            foreach ($sitemasters as $sitemaster)
		            {
		                if($sitemaster->self_answer_id == '1')
		                    $score += 1;
		                if($sitemaster->self_answer_id == '2')
		                    $score += 0.5;
		                if($sitemaster->self_answer_id == '3')
		                    $score += 0;
		                if($sitemaster->self_answer_id != '4')
		                    $count++;
		            }
		        }
		    }
		    else
		    {
		    	if ($sitemasters)
		        {
		            foreach ($sitemasters as $sitemaster)
		            {
		                if($sitemaster->onsite_answer_id == '1')
		                    $score += 1;
		                if($sitemaster->onsite_answer_id == '2')
		                    $score += 0.5;
		                if($sitemaster->onsite_answer_id == '3')
		                    $score += 0;
		                if($sitemaster->onsite_answer_id != '4')
		                    $count++;
		            }
		        }
		    }
		    $final_score = ($score / $count)*100;
		        

	        return $final_score;
	    }


	    public static function inspectionExportXLS($id) {
	    	$questions=\Question::select('id','text')->where('availability',4)->get();
	    	//print "<pre>";print_r($questions);exit;

	    	\Excel::create('P&R Inspection', function($excel) use($questions){

			    $excel->sheet('Inspection', function($sheet) use($questions){
			    	$sheet->getColumnDimension('A')->setWidth(20);
        			$sheet->getColumnDimension('B')->setWidth(2000);
			        $sheet->fromArray($questions);
			        

			    });

			})->export('xls');

	    }

	    /**
	     *  Site Corrective Action
	     *
	     * @return Object
	     **/

	    public static function SiteCA($id,$filters){

	    	$caobj = \SiteCorrectiveAction::with('question')
	    								  ->select(Sitemasters::$CAselect)->where('sitemaster_id',$id);
	    	 							  
			if(!empty($filters)){
	    		$caobj->where('inspector_user_id',$filters);
	    	}
	    		$results = $caobj->get();

	    	return $results;    	

	    }

	   /**
	     *  List Insepector
	     *
	     * @return Object
	     **/

	    public static function ListInsepector($id){

	    	//$caobj = \SiteCorrectiveAction::with('user')->select(\DB::raw('distinct inspector_user_id'))->where('sitemaster_id',$id)
	    	 							   
  			$caobj = \SiteCorrectiveAction::select(\DB::raw('distinct inspector_user_id,concat(\'Inspection \',inspector_user_id) as s'))->where('sitemaster_id',$id)
	    	 							  ->lists('s','inspector_user_id');
	   		 
  			return $caobj;    	

	    }


 }

?>