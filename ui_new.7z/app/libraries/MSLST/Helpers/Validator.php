<?php namespace MSLST\Helpers;

use MSLST\Helpers\Coordinate;

class Validator extends \Illuminate\Validation\Validator {
	
	/**
	 * Extend the validator to include current codeword check.
	 *
	 * @param mixed $attribute
	 * @param string $value
	 * @param array $parameters
	 * @return boolean
	 */
	public function validatePasscheck($attribute, $value, $parameters)
	{
		return \Hash::check($value, \Auth::user()->password);
	}

	/**
	 * Extend the validator to include alphabets and spaces check.
	 *
	 * @param mixed $attribute
	 * @param string $value
	 * @param array $parameters
	 * @return boolean
	 */
	public function validateAlphaSpaces($attribute, $value, $parameters)
	{
		return preg_match('/^[\pL\s]+$/u', $value);
	}

	/**
	 * Extend the validator to include alphabets and spaces check.
	 *
	 * @param mixed $attribute
	 * @param string $value
	 * @param array $parameters
	 * @return boolean
	 */
	public function validateCoordinates($attribute, $value, $parameters)
	{
		return Coordinate::isValidGPS($value);
	}
}
