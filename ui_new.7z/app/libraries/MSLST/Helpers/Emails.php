<?php namespace MSLST\Helpers;

use MSLST\Constants\Site;

class Emails {

    /**
     * Send the location create/edit notification email
     *
     * @param $location object
     * @param $action string
     */
    public static function sendLocationCreateUpdate($location, $action = 'created')
    {

    	if ($action == 'created')
    	{
			$subject = \Setting::where('name', 'audit_email_subject_location_create')->first()->value;
			$timestamp = $location->created_at->format('F j,Y');

			/*$users = \User::where('notification_audit_create', 1)
							->get()
							->lists('name', 'email');*/
			$users = self::SendMailUserlist('notification_audit_create',$location);

    	}
    	elseif ($action == 'updated')
    	{
			$subject = \Setting::where('name', 'audit_email_subject_location_edit')->first()->value;
			$timestamp = $location->updated_at->format('F j,Y');

            $users = self::SendMailUserlist('notification_audit_edit',$location);
    	}
		
		$tokens = [
			'%name%' => $location->user->name,
			'%action%' => $action,
			'%site_name%' => $location->site,
			'%country%' => $location->country->name,
			'%address%' => $location->address,
			'%lsp_name%' => $location->lsp->name,
			'%timestamp%' => $timestamp,
		];

		$body = \Setting::where('name', 'audit_email_body_location')->first()->value;
		$body = str_replace(array_keys($tokens), array_values($tokens), $body);

		$params = [
			'to' => $users,
			'subject' => $subject,
		];

		self::sendNotification($body, $params);
    }

    /**
     * Send the route create/edit notification email
     *
     * @param $route object
     * @param $action string
     */
    public static function sendRouteCreateUpdate($route, $action = 'created')
    {
    	if ($action == 'created')
    	{
			$subject = \Setting::where('name', 'audit_email_subject_route_create')->first()->value;
			$timestamp = $route->created_at->format('F j,Y');

			/*$users = \User::where('notification_audit_create', 1)
							->get()
							->lists('name', 'email');*/

			$users = self::SendMailUserlist('notification_audit_create',$route);
    	}
    	elseif ($action == 'updated')
    	{
			$subject = \Setting::where('name', 'audit_email_subject_route_edit')->first()->value;
			$timestamp = $route->updated_at->format('F j,Y');
			$users = self::SendMailUserlist('notification_audit_edit',$route);
			/*$users = \User::where('notification_audit_edit', 1)
							->get()
							->lists('name', 'email');*/
    	}
		
		$tokens = [
			'%name%' => $route->user->name,
			'%action%' => $action,
			'%site_name_start%' => $route->start_site,
			'%site_name_end%' => $route->end_site,
			'%country_start%' => $route->start_country->name,
			'%country_end%' => $route->end_country->name,
			'%address_start%' => $route->start_address,
			'%address_end%' => $route->end_address,
			'%lsp_name%' => $route->lsp->name,
			'%timestamp%' => $timestamp,
		];

		$body = \Setting::where('name', 'audit_email_body_route')->first()->value;
		$body = str_replace(array_keys($tokens), array_values($tokens), $body);

		$params = [
			'to' => $users,
			'subject' => $subject,
		];

		self::sendNotification($body, $params);
    }

    /**
     * Send the incident create notification email
     *
     * @param $incident object
     * @param $action string
     */
    public static function sendIncidentCreateUpdate($incident, $action)
    {
    	if ($action == 'created')
    	{
			$subject = \Setting::where('name', 'incident_email_subject_create')->first()->value;
			$body = \Setting::where('name', 'incident_email_body_create')->first()->value;


			$users = self::SendIncidentMailUserlist('notification_'. $incident->category,$incident);
			/*$users = \User::where('notification_'. $incident->category, 1)
							->get()
							->lists('name', 'email');*/

		}
    	elseif ($action == 'updated')
    	{
			$subject = \Setting::where('name', 'incident_email_subject_edit')->first()->value;
			$body = \Setting::where('name', 'incident_email_body_edit')->first()->value;

			$users = self::SendIncidentMailUserlist('notification_edit',$incident);

			/*$users = \User::where('notification_edit', 1)
							->get()
							->lists('name', 'email');*/
    	}
			 
		$tokens = [
			'%creatorname%' => $incident->user->name,
			'%creatorcompany%' => $incident->user->lsp->name,
			'%category%' => $incident->category,
			'%description%' => $incident->short_description,
			'%incidentdate%' => $incident->incident_date->format('F j,Y'),
			'%city%' => $incident->location_city,
			'%country%' => $incident->country->name,
			'%address%' => $incident->location_address,
			'%facility%' => $incident->facility,
			'%customer%' => $incident->customer,
			'%productquantity%' => array_sum(explode('+',preg_replace('/([^0-9]+)/', '+', $incident->product->number_of_units_missing))),
			'%pltscrtsmissing%' => $incident->product->number_of_plts_missing,
			'%totalvalue%' => $incident->product->total_value_of_lost_units,
			'%firstfindings%' => $incident->first_findings,
			'%status%' => $incident->closed_at ? 'closed' : 'open',
			'%incidentid%' => $incident->name,
			'%incid%' => $incident->id,
		];


		$body = str_replace(array_keys($tokens), array_values($tokens), $body);

		$subject = str_replace(array_keys($tokens), array_values($tokens), $subject);

		$params = [
			'to' => $users,
			'subject' => $subject,
		];

	
		self::sendNotification($body, $params);
    }

    /**
     * Send the incident status change notification email
     *
     * @param $incident object
     * @param $status string
     */
    public static function sendIncidentStatus($incident, $status)
    {
		$subject = \Setting::where('name', 'incident_email_subject_status_change')->first()->value;
		$body = \Setting::where('name', 'incident_email_body_status_change')->first()->value;

		/*$users = \User::where('notification_status', 1)
						->get()
						->lists('name', 'email');*/

		$users = self::SendIncidentMailUserlist('notification_status',$incident);
		
		$tokens = [
			'%creatorname%' => $incident->user->name,
			'%creatorcompany%' => $incident->user->lsp->name,
			'%category%' => $incident->category,
			'%description%' => $incident->short_description,
			'%incidentdate%' => $incident->incident_date->format('F j,Y'),
			'%city%' => $incident->location_city,
			'%country%' => $incident->country->name,
			'%address%' => $incident->location_address,
			'%facility%' => $incident->facility,
			'%customer%' => $incident->customer,
			'%productquantity%' =>  array_sum(explode('+',preg_replace('/([^0-9]+)/', '+',$incident->product->number_of_units_missing))),
			'%pltscrtsmissing%' => $incident->product->number_of_plts_missing,
			'%totalvalue%' => $incident->product->total_value_of_lost_units,
			'%firstfindings%' => $incident->first_findings,
			'%status%' => $status,
			'%incidentid%' => $incident->name,
		];

		$body = str_replace(array_keys($tokens), array_values($tokens), $body);

		$params = [
			'to' => $users,
			'subject' => $subject,
		];

		self::sendNotification($body, $params);
    }

    /**
     * Send the incident update reminder notification email
     *
     * @param $incident object
     * @param $message string
     */
    public static function sendIncidentUpdateNotification($incident)
    {
		$subject = \Setting::where('name', 'incident_email_subject_reminder')->first()->value;
		$body = \Setting::where('name', 'incident_email_body_reminder')->first()->value;
		
		$tokens = [
			'%name%' => $incident->user->name,
			'%incident-url%' => URL::to('incidents.show', [$incident->id]),
			'%incidentid%' => $incident->name,
		];

		$body = str_replace(array_keys($tokens), array_values($tokens), $body);

		$params = [
			'to' => [$route->user->email => $route->user->name],
			'subject' => $subject,
		];

		self::sendNotification($body, $params);
    }

    /**
     * Send the location review email
     *
     * @param $location object
     * @param $message string
     */
    public static function sendLocationReview($location, $message)
	{
		if ($location && $message)
		{
			// Get the subject
			$subject = \Setting::where('name', 'audit_email_subject_review_request')->first()->value;
			$body = \Setting::where('name', 'audit_email_body_review_request')->first()->value;

			$tokens = [
				'%name%' => $location->user->name,
				'%audit-id%' => $location->name,
				'%audit-url%' => \URL::to('locations.show', [$location->id]),
				'%reviewcomment%' => $message,
			];

			$body = str_replace(array_keys($tokens), array_values($tokens), $body);

			$params = [
				'to' => [$location->user->email => $location->user->name],
				'subject' => $subject,
			];

			self::sendNotification($body, $params);
		}
	}

    /**
     * Send the location review cleared email
     *
     * @param $location object
     */
    public static function sendLocationCleared($location)
	{
		if ($location)
		{
			// Get the subject
			$subject = \Setting::where('name', 'audit_email_subject_review_cleared')->first()->value;
			$body = \Setting::where('name', 'audit_email_body_review_cleared')->first()->value;

			$tokens = [
				'%name%' => $location->user->name,
				'%audit-id%' => $location->name,
				'%audit-url%' => \URL::to('locations.show', [$location->id]),
			];

			$body = str_replace(array_keys($tokens), array_values($tokens), $body);

			$params = [
				'to' => [$location->user->email => $location->user->name],
				'subject' => $subject,
			];

			self::sendNotification($body, $params);
		}
	}

    /**
     * Send the route review email
     *
     * @param $route object
     * @param $message string
     */
    public static function sendRouteReview($route, $message)
	{
		if ($route && $message)
		{
			// Get the subject
			$subject = \Setting::where('name', 'audit_email_subject_review_request')->first()->value;
			$body = \Setting::where('name', 'audit_email_body_review_request')->first()->value;

			$tokens = [
				'%name%' => $route->user->name,
				'%audit-id%' => $route->name,
				'%audit-url%' => \URL::to('routes.show', [$route->id]),
				'%reviewcomment%' => $message,
			];

			$body = str_replace(array_keys($tokens), array_values($tokens), $body);

			$params = [
				'to' => [$route->user->email => $route->user->name],
				'subject' => $subject,
			];

			self::sendNotification($body, $params);
		}
	}

    /**
     * Send the route review cleared email
     *
     * @param $route object
     */
    public static function sendRouteCleared($route)
	{
		if ($route)
		{
			// Get the subject
			$subject = \Setting::where('name', 'audit_email_subject_review_cleared')->first()->value;
			$body = \Setting::where('name', 'audit_email_body_review_cleared')->first()->value;

			$tokens = [
				'%name%' => $route->user->name,
				'%audit-id%' => $route->name,
				'%audit-url%' => \URL::to('routes.show', [$route->id]),
			];

			$body = str_replace(array_keys($tokens), array_values($tokens), $body);

			$params = [
				'to' => [$route->user->email => $route->user->name],
				'subject' => $subject,
			];

			self::sendNotification($body, $params);
		}
	}

    /**
     * Send the incident review email
     *
     * @param $incident object
     * @param $message string
     */
    public static function sendIncidentReview($incident, $message)
	{
		if ($incident && $message)
		{
			// Get the subject
			$subject = \Setting::where('name', 'incident_email_subject_review_request')->first()->value;
			$body = \Setting::where('name', 'incident_email_body_review_request')->first()->value;

			$tokens = [
				'%name%' => $incident->user->name,
				'%incident-id%' => $incident->name,
				'%incident-url%' => \URL::to('incidents.show', [$incident->id]),
				'%reviewcomment%' => $message,
			];

			$body = str_replace(array_keys($tokens), array_values($tokens), $body);

			$params = [
				'to' => [$incident->user->email => $incident->user->name],
				'subject' => $subject,
			];

			self::sendNotification($body, $params);
		}
	}

    /**
     * Send the incident review cleared email
     *
     * @param $incident object
     */
    public static function sendIncidentCleared($incident)
	{
		if ($incident)
		{
			// Get the subject
			$subject = \Setting::where('name', 'incident_email_subject_review_cleared')->first()->value;
			$body = \Setting::where('name', 'incident_email_body_review_cleared')->first()->value;

			$tokens = [
				'%name%' => $incident->user->name,
				'%incident-id%' => $incident->name,
				'%incident-url%' => \URL::to('incidents.show', [$incident->id]),
			];

			$body = str_replace(array_keys($tokens), array_values($tokens), $body);

			$params = [
				'to' => [$incident->user->email => $incident->user->name],
				'subject' => $subject,
			];

			self::sendNotification($body, $params);
		}
	}

    /**
     * Send the location review email
     *
     * @param $body string
     * @param $params array
     */
    public static function sendNotification($body, $params,$type=null)
    {

    	$from_address = \Setting::where('name', 'site_email')->first()->value ?: \Config::get('mail.from.address');
    	$from_name = \Setting::where('name', 'site_email_sender')->first()->value ?: \Config::get('mail.from.name');

	 		   	
		if(count($params['to']) <= 30 ){

			\Mail::queue('emails.layout', compact('body'), function ($m) use ($params, $from_address, $from_name) {
						$m->from($from_address, $from_name);
						foreach ($params['to'] as $to_address => $to_name){
						  $m->bcc($to_address,$to_name);
						 }
						  $m->subject($params['subject']);
					   }
				   );
		}else{
			$first_trigger = array_slice($params['to'],0,30);
			 
			\Mail::queue('emails.layout', compact('body'), function ($m) use ($first_trigger, $params, $from_address, $from_name) {
						$m->from($from_address, $from_name);
						foreach ($first_trigger as $to_address => $to_name){
						  $m->bcc($to_address,$to_name);
						 }
						  $m->subject($params['subject']);
					   }
				   );
	 		
			$second_trigger = array_slice($params['to'],30);
	 		
	 		if(!empty($second_trigger)){
	 			
	 			$params['to']  = $second_trigger;
	 			$params['body'] = $body;
				if($type=='csm')
	 			{$path =  storage_path().'/camailtrigger/csm/'.date('YmdHis').'.txt';}
	 			elseif($type=='vam')
	 			{$path =  storage_path().'/camailtrigger/vam/'.date('YmdHis').'.txt';}
	 			elseif($type=='csm_weekly')
	 			{$path =  storage_path().'/camailtrigger/csm_weekly/'.date('YmdHis').'.txt';}
	 			elseif($type=='vam_weekly')
	 			{$path =  storage_path().'/camailtrigger/vam_weekly/'.date('YmdHis').'.txt';}
	 			else	
				{$path =  storage_path().'/mail_trigger/'.date('YmdHis').'.txt';}
				$content = json_encode($params);
				\File::put($path,$content);
	 		}
	 		//print_r($params['to']); exit;

	   }
		 
    }


    /**
     * Send Notication Mail To User  
     *
     * @param $noticificationOption
     * @param array
     **/
    public static function SendMailUserlist($noticificationOption ,$audit){

    		$normaluser = [];

    		$supervisorusers = \User::where($noticificationOption, 1)
							        ->where('lsp_id',\Auth::user()->lsp_id)
									->where('role','supervisor')
									->get()
									->lists('name', 'email');

			$msusers 		= \User::where($noticificationOption, 1)
									->where('lsp_id',Site::HIGHEST_LEVEL_COMPANY)
									->where('role','supervisor')
									->get()
									->lists('name', 'email');

			$adminusers 	= \User::where($noticificationOption, 1)
									->where('role','admin')
									->get()
									->lists('name', 'email');
			
			$users = $supervisorusers + $msusers + $adminusers;

			if(\Auth::user()->$noticificationOption == 1 && \Auth::user()->id == $audit->auditor_id){
				$users += [\Auth::user()->email => \Auth::user()->email ];
			}else{ 
			    $normaluser = \User::where($noticificationOption, 1)
			    				->where('id',$audit->auditor_id)
			    				->get()
								->lists('name', 'email');
				$users = $users + $normaluser;
			}

			 
			return $users;
    }



    /**
     * Incident Send Notication Mail To User  
     *
     * @param $noticificationOption
     * @param array
     * @Return all combine userlist in $users 
     **/
    public static function SendIncidentMailUserlist($noticificationOption,$incident){

    		$spid = []; $supervisorusers = [];

		    /* Fetch User Region */
    	   /* $regionChk = \UserRegion::select('region_id')
                                   	->where('user_id',\Auth::User()->id)
                                   	->lists('region_id');*/


            /* Fetch LSP Supervisor  */
            $supervisorid = \User::where($noticificationOption, 1)
							        ->where('lsp_id',\Auth::user()->lsp_id)
									->where('role','supervisor')
									->get()
									->lists('id','id');
			 

			/* Fetch Microsoft Supervisor  */
			$msusersid		= \User::where($noticificationOption, 1)
									->where('lsp_id',Site::HIGHEST_LEVEL_COMPANY)
									->where('role','supervisor')
									->get()
									->lists('id','id');

			$commonSupervisorId =  $supervisorid + $msusersid;

			/* Fetch LSP + Region Supervisor  */
			if(!empty($commonSupervisorId)){
				$spid = \UserRegion::select('user_id')
	                                   	->where('region_id',$incident->region_id)
	                                   	->whereIn('user_id', $commonSupervisorId)
	                                   	->lists('user_id');
	        }
	        
	        if(!empty($spid)){
	    		$supervisorusers = \User::where($noticificationOption, 1)
								        ->whereIn('id',array_unique($spid))
										->where('role','supervisor')
										->get()
										->lists('name', 'email');
			}

			/* Fetch Microsoft Supervisor  */
			/*$msusers 		= \User::where($noticificationOption, 1)
									->where('lsp_id',Site::HIGHEST_LEVEL_COMPANY)
									->where('role','supervisor')
									->get()
									->lists('name', 'email');*/

			/* Fetch Admin user  */
			$adminusers 	= \User::where($noticificationOption, 1)
									->where('role','admin')
									->get()
									->lists('name', 'email');
			
			$users = $supervisorusers +  $adminusers;

			/* Fetch Respective user  */
			if(\Auth::user()->$noticificationOption == 1 && \Auth::user()->id == $incident->user_id){
				$users += [\Auth::user()->email => \Auth::user()->email ];
			}else{
				 $normaluser = \User::where($noticificationOption, 1)
			    				->where('id', $incident->user_id)
			    				->get()
								->lists('name', 'email');
				 $users = $users + $normaluser;
			}

			return $users;
    }



    /**
     * Send the incident create notification email
     *
     * @param $incident object
     * @param $action string
     */
    public static function sendFactoryIncidentCreateUpdate($incident, $action)
    {
    	//echo $incident->incident_event_date->format('F j,Y');
    	//print "<pre>"; print_r($incident); exit;
    	if ($action == 'created')
    	{
			$subject = \Setting::where('name', 'factory_incident_email_subject_create')->first()->value;
			$body = \Setting::where('name', 'factory_incident_email_body_create')->first()->value;


			$users = self::SendIncidentMailUserlist('notification_factory_create',$incident);
			/*$users = \User::where('notification_'. $incident->category, 1)
							->get()
							->lists('name', 'email');*/

		}
    	elseif ($action == 'updated')
    	{
			$subject = \Setting::where('name', 'factory_incident_email_subject_create')->first()->value;
			$body = \Setting::where('name', 'factory_incident_email_body_create')->first()->value;

			$users = self::SendIncidentMailUserlist('notification_factory_edit',$incident);

			/*$users = \User::where('notification_edit', 1)
							->get()
							->lists('name', 'email');*/
    	}
			 
		$tokens = [
			'%creatorname%' => $incident->user->name,
			'%creatorcompany%' => $incident->user->lsp->name,
			'%description%' => $incident->short_description,
			'%incidentdate%' => $incident->incident_event_date->format('F j,Y'),
			'%city%' => $incident->location_city,
			'%country%' => $incident->country->name,
			'%address%' => $incident->location_address,
			'%facility%' => $incident->facility,
			'%customer%' => $incident->customer,
			'%productquantity%' => array_sum(explode('+',preg_replace('/([^0-9]+)/', '+', $incident->product->number_of_units_missing))),
			'%pltscrtsmissing%' => $incident->product->number_of_plts_missing,
			'%totalvalue%' => $incident->product->total_value_of_lost_units,
			'%status%' => $incident->closed_at ? 'closed' : 'open',
			'%incidentid%' => $incident->name,
			'%incid%' => $incident->id,
		];


		$body = str_replace(array_keys($tokens), array_values($tokens), $body);

		$subject = str_replace(array_keys($tokens), array_values($tokens), $subject);

		$params = [
			'to' => $users,
			'subject' => $subject,
		];


		//print "<pre>"; print_r($params); exit;
	
		self::sendNotification($body, $params);
    }



    /**
      *   Send Mail to  CSM for Requesting Due Date Extension
      *
      *
      **/

    public static function sendDueDateExtensionRequest($site, $action){

    	$caob = \SiteCorrectiveAction::with('user')->where('id',$site['id'])->get();
    	$caobj  = $caob[0];
 
    	if ($action != 'inprogress')
    	{

    		$subject = \Setting::where('name', 'site_inspection_vam_subject_create')->first()->value;
			$body = \Setting::where('name', 'site_inspection_vam_body_create')->first()->value;


			$users = \User::where('site_user_level', 'vam')
							->where('user_vam_site_id','like','%'.$site['sitemaster_id'].'%')
					 				->get()
									->lists('name', 'email');
			 
		 

    	}else{
    		$subject = \Setting::where('name', 'site_inspection_csm_subject_create')->first()->value;
			$body = \Setting::where('name', 'site_inspection_csm_body_create')->first()->value;


			$users = \User::where(['site_user_level' => 'csm','id' => $caobj->inspector_user_id])
									->get()
									->lists('name', 'email'); 
			 

    	}

    	 

    	$params = [
			'to' => $users,
			'subject' => $subject,
		];

    	$tokens = [
			'%site_id%' => $caobj->sitemaster_id,
			'%ca_id%' => $caobj->id,
			'%inspector_name%' => $caobj->user->name,
			'%inspector_comments%' => $caobj->inspector_comments?:'Not Specified',
			'%pr_reference%' => $caobj->p_r_reference,
			'%pr_version%' => $caobj->p_r_version,
			'%pr_text%' => $caobj->p_r_text,
			'%severity%' => $caobj->p_r_severity,
			'%initial_due_date%' => $caobj->intial_due_date,
			'%supplier_request_closer%' => $caobj->supplier_request_closure,
			'%supplier_comments%' => $caobj->supplier_comments_evidence,
			'%ins_id%' => $caobj->inspection_num,
			'%inspector_id%' => $caobj->user->id
		];


    	 $body = str_replace(array_keys($tokens), array_values($tokens), $body);

    	
   
    	 /*File is creating for  Log Purpose*/
	  	 if($action != 'inprogress')
			    	 {
			    	 $params['body']=$body;
		  		 	 $path =  storage_path().'/camailtrigger/vam/'.date('YmdHis').'site_id'.$caobj->sitemaster_id.'CAID'.$caobj->id.'.txt';
					 $content = json_encode($params);
					 \File::put($path,$content);
					}
					else
					{
						 $params['body']=$body;
		  		 	 $path =  storage_path().'/camailtrigger/csm/'.date('YmdHis').'site_id'.$caobj->sitemaster_id.'CAID'.$caobj->id.'.txt';
					 $content = json_encode($params);
					 \File::put($path,$content);
					}


    	 self::sendNotification($body, $params);

    }


     /**
     * CA Send Notication Mail To User  
     *
     * @param $noticificationOption
     * @param array
     * @Return all combine userlist in $users 
     **/
    public static function SendMailUserLevelList($userlevel){

    		$users 	= \User::where('site_user_level',$userlevel)
									->get()
									->lists('name', 'email');

		   return $users;

    }

     /**
     * Send the location review email
     *
     * @param $body string
     * @param $params array
     */
    public static function createNotification()
    {
    	
    		$vam_subject = \Setting::where('name', 'site_inspection_vam_subject_open_ca_weekly_remainder')->first()->value;
			$vam_body = \Setting::where('name', 'site_inspection_vam_body_open_ca_weekly_remainder')->first()->value;
			$vam_users = \User::where(['site_user_level'=>'vam','access_p_r'=>1])
									->get();
									
    		
    		$csm_subject = \Setting::where('name', 'site_inspection_vam_subject_create')->first()->value;
			$csm_body = \Setting::where('name', 'site_inspection_vam_body_create')->first()->value;
			$csm_users = self::SendMailUserLevelList('csm');



			$caob_csm = \SiteCorrectiveAction::with('user')->where(['due_date_extension'=>null,'supplier_request_closure'=>'inprogress'])->get();
			//print "<pre>";print_r($caob_csm);exit;
			if(count($caob_csm))
			{	
				$params = [
					'to' => $csm_users,
					'subject' => $vam_subject,
					];

	    		$tokens=[];
				foreach($caob_csm as $caobj)
				{	
			    	$tokens[$caobj->sitemaster_id][]= [
						'%site_id%' => $caobj->sitemaster_id,
						'%ca_id%' => $caobj->id,
						'%inspector_name%' => $caobj->user->name,
						'%pr_reference%' => $caobj->p_r_reference,
						'%pr_version%' => $caobj->p_r_version,
						'%severity%' => $caobj->p_r_severity,
						'%initial_due_date%' => $caobj->intial_due_date,
						'%supplier_request_closer%' => $caobj->supplier_request_closure?$caobj->supplier_request_closure:'NA',
					];
				}
				$body=explode('<table', $vam_body);
				$body1=explode("</table>", $body[1]);
				$i=1; $main_table='';
			
				foreach ($tokens as $site_key=>$token) {

					$table1=explode("<tr>", $body1[0]);
					$td=explode("</tr>", $table1[1]);$smalltable='';
					$main_table .='<table class="table" border="1" style="width: 1310px;"><thead><b><u>'."Site Id: ".$site_key.'</u></b></thead><tbody>
					<tr style="background:skyblue">
					<td style="line-height: 1.42857;"><span style="font-weight: bold;">SITE MASTER ID</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">CA ID</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">INSPECTOR NAME</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">P+R Reference</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">P+R VERSION</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">Severity</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">Initial Due Date</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">Supplier Request Closer</span></td>
					</tr>';
					
						foreach ($token as $token_key) { 
							$main_table .="<tr>". str_replace(array_keys($token_key), array_values($token_key),$td[0])."</tr>";
						}

				    $main_table .="</tbody></table></br></br>";
				   	$i++;
				}

				 $body=$body[0].$main_table.$body1[1];
				 //print "<pre>";print_r($body);exit;
		    	 $params['body']=$body;
		    	 $path =  storage_path().'/camailtrigger/csm_weekly/'.date('YmdHis').'site_id'.$caobj->sitemaster_id.'Csm-Due date Extension'.'.txt';
				 $content = json_encode($params);
				 \File::put($path,$content); // Create New File for every each Site Inspections
			}	
			
			/*  Generating File for VAM approval with repestive assocaited site*/		 
		    if(!empty($vam_users))
	    	{
	    		foreach ($vam_users as $vam) { 
	    			
	    			$vam_site = array_unique(json_decode($vam->user_vam_site_id));
					
					foreach ($vam_site as $vmst_val) { 
		    		    /* Geting All Corrective with repect to approval*/		 
		    			$caob_vam=\SiteCorrectiveAction::with('user')->whereIn('supplier_request_closure',['completed','declined','mitigated'])->where('sitemaster_id',$vmst_val)->get();
		    			if(count($caob_vam))
		    			{	$vam_to=[$vam->email => $vam->first_name.' '.$vam->last_name];
		    				$params = [
								'to' => $vam_to,
								'subject' => $vam_subject,
								];

				    		$tokens=[];
							foreach($caob_vam as $caobj)
							{
						    	$tokens[$caobj->inspection_num][]= [
									'%site_id%' => $caobj->sitemaster_id,
									'%ca_id%' => $caobj->id,
									'%inspector_name%' => $caobj->user->name,
									'%pr_reference%' => $caobj->p_r_reference,
									'%pr_version%' => $caobj->p_r_version,
									'%severity%' => $caobj->p_r_severity,
									'%initial_due_date%' => $caobj->intial_due_date,
									'%supplier_request_closer%' => $caobj->supplier_request_closure?$caobj->supplier_request_closure:'NA',
								];
							}

							$body=explode('<table', $vam_body);
							$body1=explode("</table>", $body[1]);
							$i=1; $main_table='';
						
							foreach ($tokens as $token) {

								$table1=explode("<tr>", $body1[0]);
								$td=explode("</tr>", $table1[1]);$smalltable='';
								$main_table .='<table class="table" border="1" style="width: 1310px;"><thead><b><u>'."Inspection".$i.'</u></b></thead><tbody>
								<tr style="background:skyblue">
								<td style="line-height: 1.42857;"><span style="font-weight: bold;">SITE MASTER ID</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">CA ID</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">INSPECTOR NAME</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">P+R Reference</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">P+R VERSION</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">Severity</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">Initial Due Date</span></td>
         <td style="line-height: 1.42857;"><span style="font-weight: bold;">Supplier Request Closer</span></td>
								</tr>';
								
									foreach ($token as $token_key) { 
										$main_table .="<tr>". str_replace(array_keys($token_key), array_values($token_key),$td[0])."</tr>";
									}

							    $main_table .="</tbody></table></br></br>";
							   	$i++;
							}

							 $body=$body[0].$main_table.$body1[1];
							 //print "<pre>";print_r($body);exit;
					    	 $params['body']=$body;
					    	 $path =  storage_path().'/camailtrigger/vam_weekly/'.date('YmdHis').'site_id'.$caobj->sitemaster_id.'Vam_id'.$vam->id.'.txt';
							 $content = json_encode($params);
							 \File::put($path,$content); // Create New File for every each Site Inspections
						}	 
					}
			    }
			}
  	}

    


public static function createIncidentNotification()
    {  
    	$incidents=\Incident::where('closure_state','open')->get();
    	$subject = \Setting::where('name', 'incident_email_subject_reminder')->first()->value;
		$body = \Setting::where('name', 'incident_email_body_reminder')->first()->value;
		foreach ($incidents as $incident) 
		{	
			$new_subject=$subject;
			$new_body=$body;
			$dt = \Carbon\Carbon::parse($incident->created_at);
		 	$cdt =\Carbon\Carbon::parse('now');
			$daysdiff=$dt->diff($cdt);
			$owner=\IncidentOwner::select('user_id')->where('incident_id',$incident->id)->get()->toarray();
			$users_id=[];
			foreach ($owner as $value) {
				$users_id[]=$value['user_id'];
			}
			$users_id[]=$incident->user_id;
			if($daysdiff->days>=90)
			{
				$tokens = [
					"%incident-id%" => $incident->id,
				];
				$normaluser = \User::whereIn('id',$users_id)
			    				->get();
			    $lsp_ids=[];
			    foreach ($normaluser as $value) {

			    	$lsp_ids[]=$value->lsp_id;
			    }
			    if(count($normaluser))
			    {
				    
				    $supervisors = \User::whereIn('lsp_id',$lsp_ids)
										->where('role','supervisor')
										->get()
										->lists('name', 'email');
				 

					$normaluser=$normaluser->lists('name', 'email');
					$users = $normaluser+$supervisors;
					$new_body = str_replace(array_keys($tokens), array_values($tokens), $new_body);
					$new_subject = str_replace(array_keys($tokens), array_values($tokens), $new_subject);
					$params = [
						'to' => $users,
						'subject' => $new_subject,
						
					];
					$params['body']=$new_body;
					$path =  storage_path().'/camailtrigger/incident/'.date('YmdHis').'incident_id'.$incident->id.'.txt';
					$content = json_encode($params);
					\File::put($path,$content);
				}
			}
		}
	}

    /**
     * Creation Mail report for previous month Incident creations 
     *
     * @param $body string
     * @param $params array
     */
    public static function incident_monthly_report_create()
    {
    	 
    	$incident_report_subject = \Setting::where('name', 'monthly_incident_report_email_subject')->first()->value;
    	$incident_report_body = \Setting::where('name', 'monthly_incident_report_email_body')->first()->value;
    	$users = \User::where(['role'=>'supervisor','lsp_id'=>8])
    				 ->get()
    				 ->lists('name', 'email');
    	
    	$ldt=date('Y-m-d H:i:s', strtotime('first day of last month'));
		$cdt= date('Y-m-d H:i:s', strtotime('last day of last month'));
		$incident_list = \Incident::with('product','country','region','user')->whereBetween('created_at',array($ldt,$cdt))->withTrashed()->get();
    	
    	if(count($incident_list))
    	{	
    		$params = [
    				'to' => $users,
    				'subject' => $incident_report_subject,
    		];
    
    		$tokens=[];$tatal_value_month=0;
    		foreach($incident_list as $incident)
    		{  	
    			if(empty($incident['deleted_at']))
    			{	
    				$tokens['Created'][]= [ 
	    						'%incident_id%'=> $incident['id'],
	    						'%created_at%'=>$incident['created_at']->format('Y-m-d'), 
	    						'%category%'=>$incident['category'], 
	    						'%lsp_name%'=>$incident['user']['lsp']->name, 
	    						'%loss_value%'=>$incident['product']['total_value_of_lost_units'], 
	    						'%country_name%'=>$incident['country']['name'], 
	    						'%region_name%'=>$incident['region']['name'], 
	    						'%status%'=>$incident['closure_state'], 
	    						'%created_by%'=>$incident['user']['first_name'].$incident['user']['last_name'], 
	    				
	    					
	    			];
	    			$tatal_value_month +=$incident['product']['total_value_of_lost_units'];
    			}
    			else
    			{

    				$tokens['Created & Deleted'][]= [ 
	    						'%incident_id%'=> $incident['id'],
	    						'%created_at%'=>$incident['created_at']->format('Y-m-d'), 
	    						'%category%'=>$incident['category'], 
	    						'%lsp_name%'=>$incident['user']['lsp']->name, 
	    						'%loss_value%'=>$incident['product']['total_value_of_lost_units'], 
	    						'%country_name%'=>$incident['country']['name'], 
	    						'%region_name%'=>$incident['region']['name'], 
	    						'%status%'=>$incident['closure_state'], 
	    						'%created_by%'=>$incident['user']['first_name'].$incident['user']['last_name'], 
	    				
	    					
	    			];
	    			//$tatal_value_month +=$incident['product']['total_value_of_lost_units'];
    			}	
    		}
    		
    		$body=explode('<table', $incident_report_body);
    		$body1=explode("</table>", $body[1]);
    		$i=1; $main_table='';
    			
    		foreach ($tokens as $site_key=>$token) {
    
    			$table1=explode("<tr>", $body1[0]);
    			$td=explode("</tr>", $table1[1]);$smalltable='';//print "<pre>";print_r($td);exit;
    			$main_table .='<table class="table" border="1" style="width: 1100px;"><thead><b><u>'."Status: ".$site_key.'</u></b></thead><tbody>
    				<tr style="background:rgb(0, 128, 255);">
					<td style="line-height: 1.42857;color: rgb(239, 239, 239);"><b>Incident ID</b></td>
    				<td style="line-height: 1.42857;color: rgb(239, 239, 239);"><b> Created Date</b></td>
					<td style="line-height: 1.42857;color: rgb(239, 239, 239);"><b>Category</b></td>
    				<td style="line-height: 1.42857;color: rgb(239, 239, 239);"><b>LSP</b></td>
					<td style="line-height: 1.42857;color: rgb(239, 239, 239);"><b>Loss Value ($)</b></td>
					<td style="line-height: 1.42857;color: rgb(239, 239, 239);"><b>Country</b></td>
					<td style="line-height: 1.42857;color: rgb(239, 239, 239);"><b>Region</b></td>
					<td style="line-height: 1.42857;color: rgb(239, 239, 239);"><b>Status</b></td>
					<td style="line-height: 1.42857;color: rgb(239, 239, 239);"><b>Added By</b></td>
					</tr>';
    			//print "<pre>";print_r($token);exit;
    			foreach ($token as $token_key) {
    				$main_table .="<tr>". str_replace(array_keys($token_key), array_values($token_key),$td[0])."</tr>";
    			}
    			//$main_table.="</br></br>";
    			$i++;
    		}
    		$main_table .="</tbody></table></br></br><b>Total ".date('M', strtotime(date('Y-m')." -1 month"))." month Open Incidents Loss Value : $".round($tatal_value_month,2).'.00';
    		$body=$body[0].$main_table.$body1[1];
    		//print "<pre>";print_r($body);exit;
    		$params['body']=$body;
    		$path =  storage_path().'/camailtrigger/incident_monthly/'.'Incident('.date("M'y", strtotime(date('Y-m-d')." -1 month")).') report.txt';
    		$content = json_encode($params);
    		\File::put($path,$content); // Create New File for every each Site Inspections
    	}
    		
    	
    }
}