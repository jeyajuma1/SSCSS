<?php namespace MSLST\Helpers;

use MSLST\Constants\Site;

class Audits {

    /**
     * Get all locations by filters
     *
     * @param $filters array
     * @return array
     */
    public static function getFilteredLocations($filters)
    {
		$locations = \Location::with('user', 'lsp','country');

		if (isset($filters['daterange']) && !empty($filters['daterange']))
		{
			list($start, $end) = explode(' - ', $filters['daterange']);

			$start = new \DateTime($start);
			$end = new \DateTime($end);

			$locations->where(\DB::raw("FORMAT(created_at,'yyyy-MM-dd')"), '>=', $start->format('Y-m-d'))
				   ->where(\DB::raw("FORMAT(created_at,'yyyy-MM-dd')"), '<=', $end->format('Y-m-d'));
		}

		if (isset($filters['auditor']) && !empty($filters['auditor']))
		{
			$locations->whereIn('auditor_id', $filters['auditor']);
		}

		if (isset($filters['lsp']) && !empty($filters['lsp']))
		{
			$locations->whereIn('lsp_id', $filters['lsp']);
		}

		if (isset($filters['region']) && !empty($filters['region']))
		{
			$locations->whereHas('country', function ($q) use ($filters) {
				$q->whereIn('region_id', $filters['region']);
			});
		}

		if (isset($filters['country']) && !empty($filters['country']))
		{
			$locations->whereIn('country_id', $filters['country']);
		}

		if (isset($filters['score']) && !empty($filters['score']))
		{
			if (in_array('g', $filters['score']))
			{
				$locations->where('score', '>=', 80);
			}
			if (in_array('y', $filters['score']))
			{
				$locations->where('score', '>=', 60);
				$locations->where('score', '<', 80);
			}
			if (in_array('r', $filters['score']))
			{
				$locations->where('score', '<', 60);
			}
		}

		if (isset($filters['review']) && !empty($filters['review']))
		{
			$locations->whereIn('review', $filters['review']);
		}

		if(isset($filters['status']) && !empty($filters['status']))
		{
			$locations->whereIn('status',$filters['status']);
		}

		if (isset($filters['aid']) && !empty($filters['aid']))
		{
			$aid = $filters['aid'];

			if (preg_match('/^'.Site::LOCATION_PREFIX.'/', $aid))
			{
				$aid = ltrim($aid, Site::LOCATION_PREFIX);
			}

			$locations->where('id', '=', intval($aid));
		}

        if (\Auth::User()->isUser())
        {
            $locations->where(function ($q) {
			    $owners = \LocationOwner::select('location_id')->where('user_id', \Auth::User()->id)->lists('location_id');
                $q->where('locations.auditor_id', \Auth::User()->id);
                
				if (! empty($owners))
				{
					$q->OrWhereIn('locations.id', $owners);
				}
            });
        }

        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $locations->where('lsp_id', \Auth::User()->lsp->id);
        }

		$locations = $locations
					->orderBy('created_at', 'DESC')
					->get()
					->all();
	
	//echo "<pre>";  dd(\DB::getQueryLog());
				//	print "<pre>"; print_r(count($locations)); exit;

		return $locations;
    }

    /**
     * Get all routes by filters
     *
     * @param $filters array
     * @return array
     */
    public static function getFilteredRoutes($filters)
    {
		$routes = \Routes::with('user', 'lsp','start_country','end_country');

		if (isset($filters['daterange']) && !empty($filters['daterange']))
		{
			list($start, $end) = explode(' - ', $filters['daterange']);

			$start = new \DateTime($start);
			$end = new \DateTime($end);

			$routes->where(\DB::raw("FORMAT(created_at,'yyyy-MM-dd')"), '>=', $start->format('Y-m-d'))
				   ->where(\DB::raw("FORMAT(created_at,'yyyy-MM-dd')"), '<=', $end->format('Y-m-d'));
		}

		if (isset($filters['auditor']) && !empty($filters['auditor']))
		{
			$routes->whereIn('auditor_id', $filters['auditor']);
		}

		if (isset($filters['lsp']) && !empty($filters['lsp']))
		{
			$routes->whereIn('lsp_id', $filters['lsp']);
		}

		if (isset($filters['region']) && !empty($filters['region']))
		{
			$routes->where(function ($q) use ($filters) {
				$q->orWhereHas('start_country', function($q1) use ($filters) {
					$q1->whereIn('region_id',  $filters['region']);
				});
				$q->orWhereHas('end_country', function($q2) use ($filters) {
					$q2->whereIn('region_id', $filters['region']);
				});
			});
		}

		if (isset($filters['country']) && !empty($filters['country']))
		{
			$routes->where(function ($q) use ($filters) {
				$q->orWhereIn('start_country_id',  $filters['country'])
				  ->orWhereIn('end_country_id', $filters['country']);
			});
		}

		if (isset($filters['score']) && !empty($filters['score']))
		{
			if (in_array('g', $filters['score']))
			{
				$routes->where('score', '>=', 80);
			}
			if (in_array('y', $filters['score']))
			{
				$routes->where('score', '>=', 60);
				$routes->where('score', '<', 80);
			}
			if (in_array('r', $filters['score']))
			{
				$routes->where('score', '<', 60);
			}
		}

		if (isset($filters['review']) && !empty($filters['review']))
		{
			$routes->whereIn('review', $filters['review']);
		}

		if(isset($filters['status']) && !empty($filters['status']))
		{
			$routes->whereIn('status',$filters['status']);
		}

		if (isset($filters['aid']) && !empty($filters['aid']))
		{
			$aid = $filters['aid'];

			if (preg_match('/^'.Site::ROUTE_PREFIX.'/', $aid))
			{
				$aid = ltrim($aid, Site::ROUTE_PREFIX);
			}

			$routes->where('id', '=', intval($aid));
		}

        if (\Auth::User()->isUser())
        {
            $routes->where(function ($q) {
				$owners = \RouteOwner::select('route_id')->where('user_id', \Auth::User()->id)->lists('route_id');
                $q->where('routes.auditor_id', \Auth::User()->id);
				
				if (! empty($owners))
				{
					$q->OrWhereIn('routes.id', $owners);
				}
			});
        }

        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $routes->where('lsp_id', \Auth::User()->lsp->id);
        }

		$routes = $routes
				->orderBy('created_at', 'DESC')
				->get()
				->all();

		//dd(\DB::getQueryLog());

		return $routes;
    }


	/**
	  * Get Statistics Chart Filter
	  *
	  *@params $filter array
	  *return array
	 **/
	public static function findStatisticsGroupedByLocation($filterSet = NULL, $x_axis = NULL, $z_axis = NULL) {

		$select_fields = array();
		$select_minfld = array();
		$total_audit = 'totalaudit';
		$gupby = false;
		$grpbymin = '';
		$x_axis_min = Null;
		$z_axis_min = Null;
		$groupbymin = true;

	    if(count($filterSet['filters']) == 1 && in_array('daterange',$filterSet['filters']) &&  !empty($filterSet['daterange'])){
	      $groupbymin = false;
	    } 


		if(!empty($filterSet['daterange']) ){
			$filt_dat = explode(" - ",$filterSet['daterange']);
			$filterSet['start_date'] = $filt_dat[0];
			$filterSet['end_date']   = $filt_dat[1];
		}

		if ($x_axis == $total_audit || $z_axis == $total_audit) {
	   		$select_minfld[] = '(CASE WHEN 1 >= 1 THEN \'Total Audits\' END) as totalaudit';
		}

		if ($x_axis == 'daterange' || $z_axis == 'daterange') {
			$select_fields[] = 'FORMAT(locations.created_at, \'yyyy\') as daterange';

			if (empty($filterSet['end_date']) && empty($filterSet['start_date'])) {
    	    	  $select_minfld[] = 't.daterange as daterange';
     	    }else{

    		  if(!empty($filterSet['start_date']))  $filt_start_date = date('d M Y',strtotime($filterSet['start_date']));
    		  else $filt_start_date = date('d M Y',strtotime('01-01-2012'));

    		  if(!empty($filterSet['end_date']))  $filt_end_date = date('d M Y',strtotime($filterSet['end_date']));
              else $filt_end_date = date('d M Y',strtotime(date('d-M-Y')));

			  $select_minfld[] = "(CASE WHEN 1 >= 1 THEN '".$filt_start_date." - ".$filt_end_date."' END) as daterange";
    		  $gupby = true;
     	    }

     	    if($x_axis == 'daterange') { $x_axis = 'FORMAT(locations.created_at, \'yyyy\')'; $x_axis_min = 'daterange'; }
            if($z_axis == 'daterange') { $z_axis = 'FORMAT(locations.created_at, \'yyyy\')'; $z_axis_min = 'daterange'; }
        }


        if ($x_axis == 'monthrange' || $z_axis == 'monthrange') {
         /*	$select_fields[] = 'FORMAT(locations.created_at, \'MMM yyyy\') as monthrange, locations.created_at as sort_month';
		    $select_minfld[] ='t.monthrange as monthrange,t.sort_month as sort_month'; */
		    $select_fields[] = 'FORMAT(locations.created_at, \'MMM yyyy\') as monthrange';
		    $select_minfld[] ='t.monthrange as monthrange'; 

		    if($x_axis == 'monthrange') { $x_axis = 'FORMAT(locations.created_at, \'MMM yyyy\')'; $x_axis_min = 't.monthrange'; }
            if($z_axis == 'monthrange') { $z_axis = 'FORMAT(locations.created_at, \'MMM yyyy\')'; $z_axis_min = 't.monthrange'; }
        }
 

        if ($x_axis == 'score' || $z_axis == 'score') {
            $select_fields[] = '(CASE WHEN locations.score >= 80 THEN \'green\' WHEN locations.score >= 60 THEN \'yellow\' ELSE \'red\' END) as score';
            $select_minfld[] ='t.score as score';

            if($x_axis == 'score') { $x_axis = 'score'; $x_axis_min = 't.score'; }
            if($z_axis == 'score') { $z_axis = 'score'; $z_axis_min = 't.score'; }
        }

        if ($x_axis == 'review' || $z_axis == 'review') {
            $select_fields[] = 'IIF(locations.review = 1, \'requested\', \'not requested\') as review';
            $select_minfld[] ='t.review as review';
           if($x_axis == 'review') { $x_axis = 'IIF(locations.review = 1, \'requested\', \'not requested\')'; $x_axis_min = 't.review'; }
           if($z_axis == 'review') { $z_axis = 'IIF(locations.review = 1, \'requested\', \'not requested\')'; $z_axis_min = 't.review'; }
         } 

        if ($x_axis == 'lsp' || $z_axis == 'lsp') {
            $select_fields[] = 'c.name as lsp';
            $select_minfld[] ='t.lsp as lsp';

            if($x_axis == 'lsp') { $x_axis = 'c.name'; $x_axis_min = 't.lsp'; }
            if($z_axis == 'lsp') { $z_axis = 'c.name'; $z_axis_min = 't.lsp'; }
        }
        if ($x_axis == 'region' || $z_axis == 'region') {
            $select_fields[] = "r.name as region";
            $select_minfld[] ='t.region as region';

            if($x_axis == 'region') { $x_axis_min = $x_axis; $x_axis = 'r.name'; }
            if($z_axis == 'region') { $z_axis_min = $z_axis; $z_axis = 'r.name'; }
        }
        if ($x_axis == 'country' || $z_axis == 'country') {
            $select_fields[] = "e.name as country";
            $select_minfld[] ='t.country as country';
            
            if($x_axis == 'country') { $x_axis_min = $x_axis; $x_axis = 'e.name'; }
            if($z_axis == 'country') { $z_axis_min = $z_axis; $z_axis = 'e.name'; }
        }

		$select_fields[] = 'COUNT(locations.id) as total ';
		$select_minfld[] = 'SUM(t.total) as total';



		$locations = \Location::leftjoin('users as u','locations.auditor_id','=','u.id')
							  ->leftjoin('lsps as c','locations.lsp_id','=','c.id')
							  ->leftjoin('countries as e','locations.country_id','=','e.id')
							  ->leftjoin('regions as r','e.region_id','=','r.id')
							  ->select(\DB::raw(implode(',',$select_fields)));
							  //->where('locations.country_id',$filterSet['country'])
							 // ->get();



		if (!empty($filterSet['start_date'])) {
            $startDateObj = new \DateTime($filterSet['start_date']);
            $startDate = $startDateObj->format('Y-m-d');
          	$locations->where(\DB::raw("Format(locations.created_at,'yyyy-MM-dd')"),'>=',$startDate);
        }
        if (!empty($filterSet['end_date'])) {
            $endDateObj = new \DateTime($filterSet['end_date']);
            //$endDateObj->modify('+1 day');
            $endDate = $endDateObj->format('Y-m-d');
         	$locations->where(\DB::raw("Format(locations.created_at,'yyyy-MM-dd')"),'<=',$endDate);
        }

		if(!empty($filterSet['start_month'])){
	       $locations->where(\DB::raw('FORMAT(locations.created_at, \'yyyyMM\')'),'>=',$filterSet['start_month']);
   	    }
        if(!empty($filterSet['end_month'])){
        	$locations->where(\DB::raw('FORMAT(locations.created_at, \'yyyyMM\')'),'<=',$filterSet['end_month']);
        }


        if (!empty($filterSet['score'])) {
            if ($filterSet['score'] == 'green') {
                $locations->where('locations.score','>=',80);
            } elseif ($filterSet['score'] == 'yellow') {
                $locations->where('locations.score','>=',60);
				$locations->where('locations.score','<',80);
            } else {
                $locations->where('locations.score','<',60);
            }
        }
        if (isset($filterSet['review']) && ($filterSet['review'] === '0' || $filterSet['review'] === '1')) {
           	$locations->where('locations.review',$filterSet['review']);
        }
        if (!empty($filterSet['lsp'])) {
            $locations->where('c.id',$filterSet['lsp']);
        }
        if (!empty($filterSet['region'])) {
           $locations->where('r.id',$filterSet['region']);
        }
        if (!empty($filterSet['country'])) {
            $locations->where('e.id',$filterSet['country']);
        }

		/* Create Group By Filter */

		if($z_axis != $total_audit){
			$locations->groupby(\DB::raw($x_axis),\DB::raw($z_axis));
            $sel_minfld_GrpBy = $x_axis_min.','. $z_axis_min; 
			if($gupby == true)  $sel_minfld_GrpBy =  $z_axis_min;
        }else{
        	$locations->groupby(\DB::raw($x_axis));
            $sel_minfld_GrpBy = $x_axis_min;
			//if($gupby == true)  $sel_minfld_GrpBy = 'daterange';
			if($gupby == true) $sel_minfld_GrpBy = $z_axis_min;
		}

		 // Always order by the x and z axis parameters in ascending order
		// Set the sort fields
        $x_sort = $x_axis;
        $z_sort = $z_axis;

        $x_sort_min = $x_axis_min;
        $z_sort_min = $z_axis_min;

        if ($x_sort == 'monthrange') {
            $x_sort = 'sort_month';
            $x_sort_min = 'sort_month';
        }

        if ($z_sort == 'monthrange') {
            $z_sort = 'sort_month';
            $z_sort_min = 'sort_month';
        }

	 	if($z_axis !=  $total_audit){
          	//$locations->orderBy($x_sort,'ASC');
          	//$locations->orderBy($z_sort,'ASC');
          	$sel_minfld_OrdBy = true;
        }else{
			//$locations->orderBy($x_sort,'ASC');
			$sel_minfld_OrdBy = false;
	 	}

		//$results = $locations->get();

	 	if(strstr($sel_minfld_GrpBy,',')){
	 		$grpbymin =  explode(',', $sel_minfld_GrpBy);
	 	}

		 if(!empty($select_minfld)){

		 	$loc_res =	 \DB::table(\DB::raw("({$locations->toSql()}) as t"))
		 					->mergeBindings($locations->getQuery())
		 					->select(\DB::raw(implode(',',$select_minfld)));
		if($groupbymin == true) {
		 	if(!empty($grpbymin)){
		 	  $loc_res->groupby($grpbymin[0],$grpbymin[1]);
		 	}else{
		 	  $loc_res->groupby($sel_minfld_GrpBy);
		 	}
		}
		
		 	if($sel_minfld_OrdBy == true){
		 	  $loc_res->orderBy($x_sort_min,'ASC');
		 	  $loc_res->orderBy($z_sort_min,'ASC');
		 	}else{
		 	  $loc_res->orderBy($x_sort_min,'ASC');
		 	}
	


		 	  $results = $loc_res->get();

		 }
		//echo "<pre>";  dd(\DB::getQueryLog());

		//echo "<pre>"; print_r($results); exit;

		return $results;

	}


/**
	  * Get Statistics Chart Filter  Routes
	  *
	  *@params $filter array
	  *return array
	 **/
	public static function findStatisticsGroupedByRoute($filterSet = NULL, $x_axis = NULL, $z_axis = NULL, $start_location = TRUE) {

		$select_fields = array();
		$select_minfld = array();
		$total_audit = 'totalaudit';
		$gupby = false;
		$grpbymin = Null;
		$x_axis_min = Null;
		$z_axis_min = Null;
	
		$groupbymin = true;

	    if(count($filterSet['filters']) == 1 && in_array('daterange',$filterSet['filters']) &&  !empty($filterSet['daterange'])){
	      $groupbymin = false;
	    } 


		if(!empty($filterSet['daterange']) ){
			$filt_dat = explode(" - ",$filterSet['daterange']);
			$filterSet['start_date'] = $filt_dat[0];
			$filterSet['end_date']   = $filt_dat[1];
		}

		if ($x_axis == $total_audit || $z_axis == $total_audit) {
	   		$select_minfld[] = "(CASE WHEN 1 >= 1 THEN 'Total Audits' END) as totalaudit";
		}

		if ($x_axis == 'daterange' || $z_axis == 'daterange') {
			$select_fields[] = 'FORMAT(routes.created_at, \'yyyy\') as daterange';

			if (empty($filterSet['end_date']) && empty($filterSet['start_date'])) {
    	    	  $select_minfld[] = 't.daterange as daterange';
     	    }else{

    		  if(!empty($filterSet['start_date']))  $filt_start_date = date('d M Y',strtotime($filterSet['start_date']));
    		  else $filt_start_date = date('d M Y',strtotime('01-01-2012'));

    		  

    		  if(!empty($filterSet['end_date']))  $filt_end_date = date('d M Y',strtotime($filterSet['end_date']));
              else $filt_end_date = date('d M Y',strtotime(date('d-M-Y')));

			  $select_minfld[] = "(CASE WHEN 1 >= 1 THEN '".$filt_start_date." - ".$filt_end_date."' END) as daterange";
    		  $gupby = true;
     	    }

     	    if($x_axis == 'daterange') { $x_axis = 'FORMAT(routes.created_at, \'yyyy\')'; $x_axis_min = 'daterange'; }
            if($z_axis == 'daterange') { $z_axis = 'FORMAT(routes.created_at, \'yyyy\')'; $z_axis_min = 'daterange'; }
        }

        if ($x_axis == 'monthrange' || $z_axis == 'monthrange') {
         	$select_fields[] = 'FORMAT(routes.created_at, \'MMM yyyy\') as monthrange';
		    $select_minfld[] ='t.monthrange as monthrange';

		    if($x_axis == 'monthrange') { $x_axis = 'FORMAT(routes.created_at, \'MMM yyyy\')'; $x_axis_min = 't.monthrange'; }
            if($z_axis == 'monthrange') { $z_axis = 'FORMAT(routes.created_at, \'MMM yyyy\')'; $z_axis_min = 't.monthrange'; }
        }


        if ($x_axis == 'score' || $z_axis == 'score') {
            $select_fields[] = "(CASE WHEN routes.score >= 80 THEN 'green' WHEN routes.score >= 60 THEN 'yellow' ELSE 'red' END) as score";
            $select_minfld[] ='t.score as score';

            if($x_axis == 'score') { $x_axis = "(CASE WHEN routes.score >= 80 THEN 'green' WHEN routes.score >= 60 THEN 'yellow' ELSE 'red' END)"; $x_axis_min = 't.score'; }
            if($z_axis == 'score') { $z_axis = "(CASE WHEN routes.score >= 80 THEN 'green' WHEN routes.score >= 60 THEN 'yellow' ELSE 'red' END)"; $z_axis_min = 't.score'; }
        }

        if ($x_axis == 'review' || $z_axis == 'review') {
            $select_fields[] = 'IIF(routes.review = 1, \'requested\', \'not requested\') as review';
            $select_minfld[] ='t.review as review';

            if($x_axis == 'review') { $x_axis = "IIF(routes.review = 1, 'requested', 'not requested')"; $x_axis_min = 't.review'; }
            if($z_axis == 'review')  {  $z_axis = "IIF(routes.review = 1, 'requested', 'not requested')"; $z_axis_min = 't.review'; }
        }

        if ($x_axis == 'lsp' || $z_axis == 'lsp') {
            $select_fields[] = 'c.name as lsp';
            $select_minfld[] ='t.lsp as lsp';

            if($x_axis == 'lsp') { $x_axis = "c.name"; $x_axis_min = 't.lsp'; }
            if($z_axis == 'lsp')  {  $z_axis = "c.name"; $z_axis_min = 't.lsp'; }
        }

        if ($x_axis == 'region' || $z_axis == 'region') {
        	$sel_reg_axis = Null;
        	if($start_location){
            	$select_fields[] = "sr.name as region";
            	$sel_reg_axis = "sr.name";
            }else {
                $select_fields[] = 'er.name as region';
                $sel_reg_axis = "er.name";
            }

            $select_minfld[] ='t.region as region';

            if($x_axis == 'region') { $x_axis = $sel_reg_axis; $x_axis_min = 't.region'; }
            if($z_axis == 'region')  { $z_axis = $sel_reg_axis; $z_axis_min = 't.region'; }
        }

        if ($x_axis == 'country' || $z_axis == 'country') {
			$sel_count_axis = Null;
        	if ($start_location) {
                $select_fields[] = 'se.name as country';
                $sel_count_axis = 'se.name';
            } else {
                $select_fields[] = 'ee.name as country';
                $sel_count_axis  = 'ee.name';
            }

            $select_minfld[] ='t.country as country';

            if($x_axis == 'country') { $x_axis_min = $x_axis; $x_axis = $sel_count_axis; }
            if($z_axis == 'country') {  $z_axis_min = $z_axis; $z_axis = $sel_count_axis; }
        }

		$select_fields[] = 'COUNT(routes.id) as total ';
		$select_minfld[] = 'SUM(t.total) as total';

		$routes = \Routes::leftjoin('lsps as c','routes.lsp_id','=','c.id')
							  ->leftjoin('countries as se','routes.start_country_id','=','se.id')
							  ->leftjoin('regions as sr','se.region_id','=','sr.id')
							  ->leftjoin('countries as ee','routes.end_country_id','=','ee.id')
							  ->leftjoin('regions as er','ee.region_id','=','er.id')
							  ->select(\DB::raw(implode(',',$select_fields)));
							  //->where('routes.country_id',$filterSet['country'])
							 // ->get();



		if (!empty($filterSet['start_date'])) {
            $startDateObj = new \DateTime($filterSet['start_date']);
            $startDate = $startDateObj->format('Y-m-d H:i:s');
          	$routes->where('routes.created_at','>=',$startDate);
        }
        if (!empty($filterSet['end_date'])) {
            $endDateObj = new \DateTime($filterSet['end_date']);
           // $endDateObj->modify('+1 day');
            $endDate = $endDateObj->format('Y-m-d H:i:s');
         	$routes->where('routes.created_at','<=',$endDate);
        }

		if(!empty($filterSet['start_month'])){
	       $routes->where(\DB::raw('FORMAT(routes.created_at, \'yyyyMM\')'),'>=',$filterSet['start_month']);
   	    }
        if(!empty($filterSet['end_month'])){
        	$routes->where(\DB::raw('FORMAT(routes.created_at, \'yyyyMM\')'),'<=',$filterSet['end_month']);
        }


        if (!empty($filterSet['score'])) {

            if ($filterSet['score'] == 'green') {
                $routes->where('routes.score','>=',80);
            } elseif ($filterSet['score'] == 'yellow') {
                $routes->where('routes.score','>=',60);
				$routes->where('routes.score','<',80);
            } else {
                $routes->where('routes.score','<',60);
            }

        }

        if (isset($filterSet['review']) && ($filterSet['review'] === '0' || $filterSet['review'] === '1')) {
           	$routes->where('routes.review',$filterSet['review']);
        }

        if (!empty($filterSet['lsp'])) {
            $routes->where('c.id',$filterSet['lsp']);
        }

        if (!empty($filterSet['region'])) {

        	/*if ($start_location) {
                $routes->where('sr.id',$filterSet['region']);
            } else {
                $routes->where('er.id',$filterSet['region']);
            }*/
  
  			$routes->where(function ($q) use ($filterSet) {
				$q->orWhere('sr.id', '=', $filterSet['region'])
				  ->orWhere('er.id', '=', $filterSet['region']);
			});

        }

        if (!empty($filterSet['country'])) {

          /* if ($start_location) {
            	$routes->where('se.id',$filterSet['country']);
            } else {
            	$routes->where('ee.id',$filterSet['country']);
            } */

            $routes->where(function ($q) use ($filterSet) {
				$q->orWhere('se.id', '=', $filterSet['country'])
				  ->orWhere('ee.id', '=', $filterSet['country']);
			});

        }

     	/* Create Group By Filter */
		if($z_axis != $total_audit){
        	$routes->groupby(\DB::raw($x_axis),\DB::raw($z_axis));
        	$sel_minfld_GrpBy = $x_axis_min.','. $z_axis_min;
			if($gupby == true)  $sel_minfld_GrpBy =  $z_axis_min;

        }else{

        	$routes->groupby(\DB::raw($x_axis));
        	$sel_minfld_GrpBy = $x_axis_min;
			//if($gupby == true)  $sel_minfld_GrpBy = 'daterange';
			if($gupby == true)  $sel_minfld_GrpBy = $z_axis_min;
		}

		 // Always order by the x and z axis parameters in ascending order
		// Set the sort fields
        $x_sort = $x_axis;
        $z_sort = $z_axis;


        $x_sort_min = $x_axis_min;
        $z_sort_min = $z_axis_min;

        if ($x_sort == 'monthrange') {
            $x_sort = 'sort_month';
            $x_sort_min = 'sort_month';
        }
        if ($z_sort == 'monthrange') {
            $z_sort = 'sort_month';
            $z_sort_min = 'sort_month';
        }

	 	if($z_axis !=  $total_audit){
        //  	$routes->orderBy($x_sort,'ASC'); // MSSQL   ORDER BY clause is invalid for in subqueries
        //  	$routes->orderBy($z_sort,'ASC');  // MSSQL   ORDER BY clause is invalid for in subqueries
          	$sel_minfld_OrdBy = true;
        }else{
		//	$routes->orderBy($x_sort,'ASC'); // MSSQL   ORDER BY clause is invalid for in subqueries
			$sel_minfld_OrdBy = false;
	 	}

		//$results = $locations->get();

	 	if(strstr($sel_minfld_GrpBy,',')){
	 		$grpbymin =  explode(',', $sel_minfld_GrpBy);
	 	}

		 if(!empty($select_minfld)){

		 	$rout_res =	 \DB::table(\DB::raw("({$routes->toSql()}) as t"))
		 					->mergeBindings($routes->getQuery())
		 					->select(\DB::raw(implode(',',$select_minfld)));

		 if($groupbymin  == true ){
			 	if(!empty($grpbymin)){
			 	  $rout_res->groupby($grpbymin[0],$grpbymin[1]);
			 	}else{
			 	  $rout_res->groupby($sel_minfld_GrpBy);
			 	}
		  }

		 	if($sel_minfld_OrdBy == true){
		 	  $rout_res->orderBy($x_sort_min,'ASC');
		 	  $rout_res->orderBy($z_sort_min,'ASC');
		 	}else{
		 	  $rout_res->orderBy($x_sort_min,'ASC');
		 	}


		 	  $results = $rout_res->get();

		 }
		 //print "<pre>"; dd(\DB::getQueryLog());
		return $results;

	}

	/**
	 *
	 * Find route list according to the filters to map
	 * @params $filter array
	 * return array
	 *
	 **/

	public static function findStatisticsMapRoutes($filters= Null){

		$filterSet = $filters;

		$results = array();

		$select_fields[] = "routes.id";

		$select_fields[] = " routes.start_site as start_name";
		//$select_fields[] = " routes.start_city as start_city";
		$select_fields[] = " routes.start_coordinates as start_coordinates";
		$select_fields[] = " se.name as start_country_name";
		$select_fields[] = " sr.name as start_region_name";
		$select_fields[] = " sr.id as start_rid";

		$select_fields[] = " routes.end_site as end_name";
		//$select_fields[] = " routes.end_city as end_city";
		$select_fields[] = " routes.end_coordinates as end_coordinates";
		$select_fields[] = " ee.name as end_country_name";
		$select_fields[] = " er.name as end_region_name";
		$select_fields[] = " er.id as end_rid";

		$select_fields[] = " c.name as company_name";
		$select_fields[] = " FORMAT(routes.created_at,'yyyy-MM-dd') as date";
		$select_fields[] = " routes.score";
		$select_fields[] = " routes.tapa_needed";
		$select_fields[] = " (CASE WHEN routes.score >= 80 THEN 'green' WHEN routes.score >= 60 THEN 'yellow' ELSE 'red' END) as category";
		$select_fields[] = " CONCAT(u.first_name,' ', u.last_name) as auditor_name";
		$select_fields[] = " c.id as cid";
		$select_fields[] = " u.id as userid";


		$routes = \Routes::leftjoin('users as u','routes.auditor_id','=','u.id')
						 ->leftjoin('lsps as c','routes.lsp_id','=','c.id')
						 ->leftjoin('countries as se','routes.start_country_id','=','se.id')
						 ->leftjoin('regions as sr','se.region_id','=','sr.id' )
						 ->leftjoin('countries as ee','routes.end_country_id','=','ee.id')
						 ->leftjoin('regions as er','ee.region_id','=','er.id')
						 ->select(\DB::raw(implode(',', $select_fields)));


		if(!empty($filterSet['daterange']) ){
			$filt_dat = explode(" - ",$filterSet['daterange']);
			$filterSet['start_date'] = $filt_dat[0];
			$filterSet['end_date']   = $filt_dat[1];
		}

		if (!empty($filterSet['start_date'])) {
            $startDateObj = new \DateTime($filterSet['start_date']);
            $startDate = $startDateObj->format('Y-m-d');
            $routes->where(\DB::raw("FORMAT(routes.created_at, 'yyyy-MM-dd')"),'>=',$startDate);

        }

        if (!empty($filterSet['end_date'])) {

            $endDateObj = new \DateTime($filterSet['end_date']);
            $endDateObj->modify('+1 day');
            $endDate = $endDateObj->format('Y-m-d H:i:s');
            $routes->where(\DB::raw("FORMAT(routes.created_at, 'yyyy-MM-dd')"),'<=',$endDate);

        }

	    if(!empty($filterSet['start_month'])){
            $routes->where(\DB::raw("FORMAT(routes.created_at, 'yyyyMM')"),'>=',$filterSet['start_month']);
        }

        if(!empty($filterSet['end_month'])){
            $routes->where(\DB::raw("FORMAT(routes.created_at, 'yyyyMM')"),'<=',$filterSet['end_month']);
        }

        if (!empty($filterSet['score'])) {

            if ($filterSet['score'] == 'green') {
                $routes->where("routes.score",'>=',80);
            } elseif ($filterSet['score'] == 'yellow') {
            	$routes->where("routes.score",'>=',60);
            	$routes->where("routes.score",'<',80);
            } else {
                $routes->where("routes.score",'<',60);
            }

        }

        if (isset($filterSet['review']) && ($filterSet['review'] === '0' || $filterSet['review'] === '1')) {
            $routes->where("routes.review",$filterSet['review']);
        }

        if (!empty($filterSet['lsp'])) {
            $routes->where("c.id",$filterSet['lsp']);
        }

        if (!empty($filterSet['region'])) {
        	$filterregion = $filterSet['region'];

            $routes->where( function($q) use($filterregion) {
             	$q->where("sr.id",$filterregion)
             	  ->orWhere("er.id",$filterregion);
             });
             	

        }

        if (!empty($filterSet['country'])) {

            $filtercountry = $filterSet['country'];
               $routes->where( function($q) use($filtercountry) {
             	$q->where("se.id",$filtercountry)
             	  ->orWhere("ee.id",$filtercountry);
             });
        }

        if( !empty($filterSet['month']) && $filterSet['month'] != 'all'){
             $routes->orWhere(\DB::raw("FORMAT(routes.created_at, 'MMM')"),$filterSet['month']);
        }

        $routes->where('routes.tapa_needed','!=',0);
        
        $routes->orderBy('routes.created_at','ASC');

		$results = $routes->get();;
	
		//print "<pre>"; print_r(count($results)); exit;

		return $results;

	}


	/**
	 * Find location list according to the filters to map
	 *
	 *
	 **/
	public static function findStatisticsMapLocations($filterSet = NULL){

		$select_fields[] = 'locations.id';
		$select_fields[] = 'locations.site as name';
		$select_fields[] = 'locations.address';
		$select_fields[] = 'locations.coordinates as coordinates';
		$select_fields[] = 'FORMAT(locations.created_at, \'yyyy-MM-dd\') as date';
		$select_fields[] = 'locations.score';
		$select_fields[] = 'locations.tapa_needed';
		$select_fields[] = "(CASE WHEN locations.score >= 80 THEN 'green' WHEN locations.score >= 60 THEN 'yellow' ELSE 'red' END) as category";
		$select_fields[] = "CONCAT(u.first_name,' ',u.last_name) as auditor_name";
		$select_fields[] = 'u.id as userid';
		$select_fields[] = 'c.id as cid';
		$select_fields[] = 'r.id as rid';
		$select_fields[] = 'c.name as company_name';
		$select_fields[] = 'e.name as country_name';
		$select_fields[] = 'r.name as region_name';

		$locations = \Location::leftjoin('users as u','locations.auditor_id','=','u.id')
							  ->leftjoin('lsps as c','locations.lsp_id','=','c.id')
							  ->leftjoin('countries as e','locations.country_id','=','e.id')
							  ->leftjoin('regions as r','e.region_id','=','r.id')
							  ->select(\DB::raw(implode(',',$select_fields)));

		if(!empty($filterSet['daterange']) ){
			$filt_dat = explode(" - ",$filterSet['daterange']);
			$filterSet['start_date'] = $filt_dat[0];
			$filterSet['end_date']   = $filt_dat[1];
		}

		if (!empty($filterSet['start_date'])) {
            $startDateObj = new \DateTime($filterSet['start_date']);
            $startDate = $startDateObj->format('Y-m-d H:i:s');
            $locations->where('locations.created_at','>=',$startDate);
        }
        if (!empty($filterSet['end_date'])) {
            $endDateObj = new \DateTime($filterSet['end_date']);
            $endDateObj->modify('+1 day');
            $endDate = $endDateObj->format('Y-m-d H:i:s');
            $locations->where('locations.created_at','<=',$endDate);
        }
	 if(!empty($filterSet['start_month'])){
            $locations->where(\DB::raw('FORMAT(locations.created_at, \'yyyyMM\')'),'>=',$filterSet['start_month']);
        }
        if(!empty($filterSet['end_month'])){
            $locations->where(\DB::raw('FORMAT(locations.created_at, \'yyyyMM\')'),'<=',$filterSet['end_month']);
        }


         if(!empty($filterSet['month'])  && $filterSet['month'] != 'all'){
            $locations->where(\DB::raw('FORMAT(locations.created_at, \'yyyyMM\')'),'=',$filterSet['month']);
        }
        if (!empty($filterSet['score'])) {
            if ($filterSet['score'] == 'green') {
                $locations->where('locations.score','>=',80);
            } elseif ($filterSet['score'] == 'yellow') {
                $locations->where('locations.score','>=',60);
                $locations->where('locations.score','<',80);
            } else {
                $locations->where('locations.score','<',60);
            }
        }
        if (isset($filterSet['review']) && ($filterSet['review'] === '0' || $filterSet['review'] === '1')) {
            $locations->where('locations.review','=',$filterSet['review']);
        }
        if (!empty($filterSet['lsp'])) {
            $locations->where('c.id','=',$filterSet['lsp']);
        }
        if (!empty($filterSet['region'])) {
            $locations->where('r.id','=',$filterSet['region']);
        }
        if (!empty($filterSet['country'])) {
            $locations->where('e.id','=',$filterSet['country']);
        }

        $locations->where('locations.tapa_needed','!=',0);

        $locations->orderBy('locations.created_at','ASC');




        $results = $locations->get()->all();

        //print "<pre>"; print_r(count($results)); exit;
        
        return $results;
	}

}
