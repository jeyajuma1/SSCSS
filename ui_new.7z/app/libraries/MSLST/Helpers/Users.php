<?php
namespace MSLST\Helpers;
use Carbon\Carbon;
	class Users {
	
		public static function getFilteredUsers($filters) {
		
			$users = \User::withTrashed()->with('lsp');
			if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
			{
				$users =  $users->where('lsp_id', \Auth::User()->lsp->id);
			}
		
			if (isset($filters['username']) && !empty($filters['username']))
			{
				$users->whereIn('id', $filters['username']);
			}
			
			if (isset($filters['role']) && !empty($filters['role']))
			{
				$users->whereIn('role', $filters['role']);
			}
			
			if (isset($filters['user_access']) && !empty($filters['user_access']))
			{
			foreach ($filters['user_access'] as $selection) {
						$users->Where($selection,'=','1');
				}
			}
			
			if (isset($filters['lspname']) && !empty($filters['lspname']))
			{
				$users->whereIn('lsp_id', $filters['lspname'])
					->withTrashed();
				
			}
					
			$users = $users
						->orderBy('created_at', 'DESC')
						->get()
						->all();
			
			return $users;
		}
	}
?>