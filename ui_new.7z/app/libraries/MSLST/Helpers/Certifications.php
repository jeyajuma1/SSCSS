<?php namespace MSLST\Helpers;

class Certifications {

    /**
     * Get all locations by filters
     *
     * @param $filters array
     * @return array
     */
    public static function getLocationAuditQuestions($location)
    {
    	$legend = self::getAnswersLegend();
        $tapa_needed = $location->tapa_needed;
        $location_certifications = $location->certification->all();
        $audits = $location->question->all();
        $audit_questions = [];

        // Find certifications for the current location
        $location_certs = [];
        foreach ($location_certifications as $certification) {
            $location_certs[$certification->id] = $certification->name;
        }
        $location_cert_ids = array_keys($location_certs);

        // Find all disabled certifications for this location
        $disabled_cert_items = $location->disabled_certification()->lists('certification_group_id');
        $disabled_certs = [];
        foreach ($disabled_cert_items as $item) {
            if ($item == \MSLST_Site::TAPA_GROUP) {
                $disabled_certs = array_merge($disabled_certs, 
                	[\MSLST_Site::TAPA_FSR_A, \MSLST_Site::TAPA_FSR_B, \MSLST_Site::TAPA_FSR_C]
                );
            } elseif ($item == \MSLST_Site::C_TPAT_GROUP) {
                $disabled_certs = array_merge($disabled_certs, 
                	[\MSLST_Site::C_TPAT]
                );
            } elseif ($item == \MSLST_Site::AEO_GROUP) {
                $disabled_certs = array_merge($disabled_certs, 
                	[\MSLST_Site::AEO_S, \MSLST_Site::AEO_F, \MSLST_Site::AEO_C]
                );
            }
        }

        // Loop through all the current location audits
        foreach ($audits as $audit) {

            // Skip the question if its disabled
            //if ($audit->is_archived || $audit->pivot->is_archived) continue;
			if ($audit->pivot->is_archived) continue;
			//@TODO fix the above check

            // Get the current question id, its answer id
            $answer_id = $audit->pivot->answer_id;
            $question_id = $audit->id;

            // Setup the audit questions and its hidden status for the view audit page
            $audit_questions[$question_id]['text'] = $audit->text;
            $audit_questions[$question_id]['hidden'] = $audit->is_archived;

            // Find certifications for the current audit question
            $question_cert_ids = $audit->certifications->lists('id');

            $tapa_cert_ids = [\MSLST_Site::TAPA_FSR_A, \MSLST_Site::TAPA_FSR_B, \MSLST_Site::TAPA_FSR_C];
            $tapa_matches = array_intersect($question_cert_ids, $tapa_cert_ids);
            if (! empty($tapa_matches)) $audit_questions[$question_id]['certification'] = 'TAPA';

            $c_tpat_cert_ids = [\MSLST_Site::C_TPAT];
            $c_tpat_matches = array_intersect($question_cert_ids, $c_tpat_cert_ids);
            if (! empty($c_tpat_matches)) $audit_questions[$question_id]['certification'] = 'C-TPAT';

            $aeo_cert_ids = [\MSLST_Site::AEO_S, \MSLST_Site::AEO_F, \MSLST_Site::AEO_C];
            $aeo_matches = array_intersect($question_cert_ids, $aeo_cert_ids);
            if (! empty($aeo_matches)) $audit_questions[$question_id]['certification'] = 'AEO';

            // If the question is answered by the creator, get the answer and comment, if any
            if ($audit->pivot->answer_id != 0) {
                $audit_questions[$question_id]['class'] = 'answer'. $answer_id;
                $audit_questions[$question_id]['content'] = $legend['answer'. $answer_id];
                $audit_questions[$question_id]['comment'] = $audit->pivot->comment;
            } else {

                // Skip the question if it belongs to a disabled category
                $question_disabled_cert_groups = array_intersect($question_cert_ids, $disabled_certs);
                if (count($question_disabled_cert_groups) > 0) continue;

                // Mark the Questions that is already certified by TAPA or not needed
                if (in_array(\MSLST_Site::TAPA_FSR_A, $question_cert_ids)
                     || in_array(\MSLST_Site::TAPA_FSR_B, $question_cert_ids)
                     || in_array(\MSLST_Site::TAPA_FSR_C, $question_cert_ids)) {

                    // If certificate selected on first step (required certificate) is TAPA FSR A
                    if ($tapa_needed == \MSLST_Site::TAPA_FSR_A) {
                        if (in_array(\MSLST_Site::TAPA_FSR_A, $location_cert_ids)) {
                            if (in_array(\MSLST_Site::TAPA_FSR_A, $question_cert_ids)) {
                                array_push($question_cert_ids, \MSLST_Site::TAPA_FSR_A);
                            }
                            //--> @HACK
                            if (in_array(\MSLST_Site::TAPA_FSR_B, $question_cert_ids) || in_array(\MSLST_Site::TAPA_FSR_C, $question_cert_ids)) {
                                array_push($question_cert_ids, \MSLST_Site::TAPA_FSR_A);
                            }
                            //--> Experimental - need to verify
                        }
                        if (in_array(\MSLST_Site::TAPA_FSR_B, $location_cert_ids)) {
                            if(in_array(\MSLST_Site::TAPA_FSR_C, $question_cert_ids)
                                && !in_array(\MSLST_Site::TAPA_FSR_B, $question_cert_ids)){
                                array_push($question_cert_ids, \MSLST_Site::TAPA_FSR_B);
                            }
                        }
                        if (empty($location_cert_ids)) { // when none is selected
                            $audit_questions[$question_id]['content'] = "Not Needed";
                            $audit_questions[$question_id]['class'] = 'answernone';
                        }
                    }

                    // If certificate selected on first step (required certificate) is TAPA FSR C
                    if ($tapa_needed == \MSLST_Site::TAPA_FSR_C) {
                        if (in_array(\MSLST_Site::TAPA_FSR_A, $location_cert_ids)) {
                            if (!in_array(\MSLST_Site::TAPA_FSR_A, $question_cert_ids)) {
                                array_push($question_cert_ids, \MSLST_Site::TAPA_FSR_A);
                            }
                        }
                        if (in_array(\MSLST_Site::TAPA_FSR_B, $location_cert_ids)) {
                            if (!in_array(\MSLST_Site::TAPA_FSR_B, $question_cert_ids)) {
                                array_push($question_cert_ids, \MSLST_Site::TAPA_FSR_B);
                            }
                        }
                        if (empty($location_cert_ids)) { // when none is selected
                            $audit_questions[$question_id]['content'] = "Not Needed";
                            $audit_questions[$question_id]['class'] = 'answernone';
                        }
                    }

                    // Mark the already certified questions
                    foreach ($location_cert_ids as $id) {
                        if (in_array($id, $question_cert_ids)) {
                            $audit_questions[$question_id]['content'] = "Certified with ". $location_certs[$id];
                            $audit_questions[$question_id]['class'] = 'answer'. $answer_id;

                            break 1;
                        } else {
                            $audit_questions[$question_id]['content'] = "Not Needed";
                            $audit_questions[$question_id]['class'] = 'answernone';
                        }
                    }

                }
                // If not a TAPA certified location
                else {
                    foreach ($location_cert_ids as $id) {
                        if (in_array($id, $question_cert_ids)) {
                            $audit_questions[$question_id]['content'] = "Certified with ". $location_certs[$id];
                            $audit_questions[$question_id]['class'] = 'answer'. $answer_id;
                            break 1;
                        }
                    }
                }
            }
        }

        // Remove the invalid audits (for which either certificate is disabled or hidden)
        $temp_audit_questions = [];
        foreach ($audit_questions as $key => $question) {
            if (!isset ($question['content'])) {
                unset($audit_questions[$key]);
            } 
            else {
                if (isset($question['certification']) && isset($question['content']))
                {
                    $temp_audit_questions[$question['certification']][$question['content']][$key] = $question;
                }
            }
        }
        $audit_questions = $temp_audit_questions;

        return $audit_questions;
    }

    /**
     * Get all locations by filters
     *
     * @param $filters array
     * @return array
     */
    public static function getRouteAuditQuestions($route)
    {
    	$legend = self::getAnswersLegend();
        $tapa_needed = $route->tapa_needed;
        $route_certifications = $route->certification->all();
        $audits = $route->question->all();
        $audit_questions = [];

        // Find certifications for the current route
        $route_certs = [];
        foreach ($route_certifications as $certification) {
            $route_certs[$certification->id] = $certification->name;
        }
        $route_cert_ids = array_keys($route_certs);

        // Find all disabled certifications for this route
        $disabled_cert_items = $route->disabled_certification()->lists('certification_group_id');
        $disabled_certs = [];
        foreach ($disabled_cert_items as $item) {
            if ($item == \MSLST_Site::TAPA_GROUP) {
                $disabled_certs = array_merge($disabled_certs, 
                	[\MSLST_Site::TAPA_TSR_1, \MSLST_Site::TAPA_TSR_2, \MSLST_Site::TAPA_TSR_3]
                );
            } elseif ($item == \MSLST_Site::C_TPAT_GROUP) {
                $disabled_certs = array_merge($disabled_certs, 
                	[\MSLST_Site::C_TPAT]
                );
            } elseif ($item == \MSLST_Site::AEO_GROUP) {
                $disabled_certs = array_merge($disabled_certs, 
                	[\MSLST_Site::AEO_S, \MSLST_Site::AEO_F, \MSLST_Site::AEO_C]
                );
            }
        }

        // Loop through all the current route audits
        foreach ($audits as $audit) {

            // Skip the question if its disabled
            //if ($audit->is_archived || $audit->pivot->is_archived) continue;
			if ($audit->pivot->is_archived) continue;
			//@TODO fix the above check

            // Get the current question id, its answer id
            $answer_id = $audit->pivot->answer_id;
            $question_id = $audit->id;

            // Setup the audit questions and its hidden status for the view audit page
            $audit_questions[$question_id]['text'] = $audit->text;
            $audit_questions[$question_id]['hidden'] = $audit->is_archived;

            // Find certifications for the current audit question
		    $question_cert_ids = $audit->certifications->lists('id');

            $tapa_cert_ids = [\MSLST_Site::TAPA_TSR_1, \MSLST_Site::TAPA_TSR_2, \MSLST_Site::TAPA_TSR_3];
            $tapa_matches = array_intersect($question_cert_ids, $tapa_cert_ids);
            if (! empty($tapa_matches)) $audit_questions[$question_id]['certification'] = 'TAPA';

            $c_tpat_cert_ids = [\MSLST_Site::C_TPAT];
            $c_tpat_matches = array_intersect($question_cert_ids, $c_tpat_cert_ids);
            if (! empty($c_tpat_matches)) $audit_questions[$question_id]['certification'] = 'C-TPAT';

            $aeo_cert_ids = [\MSLST_Site::AEO_S, \MSLST_Site::AEO_F, \MSLST_Site::AEO_C];
            $aeo_matches = array_intersect($question_cert_ids, $aeo_cert_ids);
            if (! empty($aeo_matches)) $audit_questions[$question_id]['certification'] = 'AEO';

            // If the question is answered by the creator, get the answer and comment, if any
            if ($audit->pivot->answer_id != 0) {
                $audit_questions[$question_id]['class'] = 'answer'. $answer_id;
                $audit_questions[$question_id]['content'] = $legend['answer'. $answer_id];
                $audit_questions[$question_id]['comment'] = $audit->pivot->comment;
            } else {

                // Skip the question if it belongs to a disabled category
                $question_disabled_cert_groups = array_intersect($question_cert_ids, $disabled_certs);
                if (count($question_disabled_cert_groups) > 0) continue;

                // Check if the question is already cetified; Check TAPA
                $is_question_certified = FALSE;
                if (in_array(\MSLST_Site::TAPA_TSR_1, $question_cert_ids)
                        || in_array(\MSLST_Site::TAPA_TSR_2, $question_cert_ids)
                        || in_array(\MSLST_Site::TAPA_TSR_3, $question_cert_ids)) {

                    // If the needed certification is TAPA TSR 1
                    if ($tapa_needed == \MSLST_Site::TAPA_TSR_1) {

                        // The selected certification is TAPA TSR 1
                        if (in_array(\MSLST_Site::TAPA_TSR_1, $route_cert_ids)) {
                            // The question has TAPA TSR 1, TAPA TSR 2 OR TAPA TSR 3
                            if (in_array(\MSLST_Site::TAPA_TSR_1, $question_cert_ids)
                                    || in_array(\MSLST_Site::TAPA_TSR_2, $question_cert_ids)
                                    || in_array(\MSLST_Site::TAPA_TSR_3, $question_cert_ids)) {
                              $is_question_certified = TRUE;
                            }
                        }
                        // The selected certification is TAPA TSR 2
                        elseif (in_array(\MSLST_Site::TAPA_TSR_2, $route_cert_ids)) {
                            // The question has TAPA TSR 2 OR TAPA TSR 3
                            if (in_array(\MSLST_Site::TAPA_TSR_2, $question_cert_ids)
                                    || in_array(\MSLST_Site::TAPA_TSR_3, $question_cert_ids)) {
                              $is_question_certified = TRUE;
                            }
                        }
                        // The selected certification is TAPA TSR 3
                        elseif (in_array(\MSLST_Site::TAPA_TSR_3, $route_cert_ids)) {
                            // The question has TAPA TSR 3
                            if (in_array(\MSLST_Site::TAPA_TSR_3, $question_cert_ids)) {
                              $is_question_certified = TRUE;
                            }
                        }
                    }
                }

                // Check if the question is already cetified; Check AEO
                if (in_array(\MSLST_Site::AEO_S, $question_cert_ids)) {
                    if (in_array(\MSLST_Site::AEO_S, $route_cert_ids)) {
                        $is_question_certified = TRUE;
                    }
                }
                if (in_array(\MSLST_Site::AEO_F, $question_cert_ids)) {
                    if (in_array(\MSLST_Site::AEO_F, $route_cert_ids)) {
                        $is_question_certified = TRUE;
                    }
                }
                if (in_array(\MSLST_Site::AEO_C, $question_cert_ids)) {
                    if (in_array(\MSLST_Site::AEO_C, $route_cert_ids)) {
                        $is_question_certified = TRUE;
                    }
                }

                // only these questions will be displayed in the route view
                if ($answer_id != 0 && !$is_question_certified) {
                    $audit_questions[$question_id]['content'] = $legend['answer'. $answer_id];
                    if ($audit->getComment()) {
                        $audit_questions[$question_id]['comment'] = $audit->pivot->comment;
                    }
                    $audit_questions[$question_id]['class'] = 'answer'. $answer_id;
                } else {
                    if(in_array(\MSLST_Site::TAPA_TSR_1, $question_cert_ids)
                          || in_array(\MSLST_Site::TAPA_TSR_2, $question_cert_ids)
                          || in_array(\MSLST_Site::TAPA_TSR_3, $question_cert_ids)) {

                        // If the needed certification is TAPA TSR 1
                        if ($tapa_needed == \MSLST_Site::TAPA_TSR_1) {

                            // The selected certification is TAPA TSR 1
                            if (in_array(\MSLST_Site::TAPA_TSR_1, $route_cert_ids)) {

                                // The current question will be certified by TAPA TSR 1
                                array_push($question_cert_ids, \MSLST_Site::TAPA_TSR_1);
                            }
                            // The selected certification is TAPA TSR 2
                            elseif (in_array(\MSLST_Site::TAPA_TSR_2, $route_cert_ids)) {
                                if (count($question_cert_ids) == 1 && $question_cert_ids[0] == \MSLST_Site::TAPA_TSR_3) {
                                    // The current question certified only by TAPA TSR 3; Make it not needed
                                }
                                // If the current question is not certified by TAPA TSR 2; Make it certified by TAPA TSR 2
                                elseif (!in_array(\MSLST_Site::TAPA_TSR_2, $question_cert_ids)) {
                                    array_push($question_cert_ids, \MSLST_Site::TAPA_TSR_2);
                                }
                            }
                            // The selected certification is TAPA TSR 3
                            elseif (in_array(\MSLST_Site::TAPA_TSR_3, $route_cert_ids)) {
                                if (count($question_cert_ids) == 1 && $question_cert_ids[0] == \MSLST_Site::TAPA_TSR_2) {
                                    // The current question certified only by TAPA TSR 2; Make it not needed
                                }
                                // If the current question is not certified by TAPA TSR 3; Make it certified by TAPA TSR 3
                                elseif (!in_array(\MSLST_Site::TAPA_TSR_3, $question_cert_ids)) {
                                    array_push($question_cert_ids, \MSLST_Site::TAPA_TSR_3);
                                }
                            } else {
                                if (in_array(\MSLST_Site::TAPA_TSR_2, $route_cert_ids) || in_array(\MSLST_Site::TAPA_TSR_3, $route_cert_ids)) {
                                    if (!in_array(\MSLST_Site::TAPA_TSR_1, $question_cert_ids)) {
                                        $question_cert_ids = array();
                                    }
                                }
                            }
                        }
                        // If the needed certification is TAPA TSR 2
                        if ($tapa_needed == \MSLST_Site::TAPA_TSR_2) {
                            // If the selected certification is TAPA TSR 1
                            if (in_array(\MSLST_Site::TAPA_TSR_1, $route_cert_ids)) {

                                // The current question will be certified by TAPA TSR 1
                                array_push($question_cert_ids, \MSLST_Site::TAPA_TSR_1);
                            }
                            // If the selected certification is TAPA TSR 2
                            if (in_array(\MSLST_Site::TAPA_TSR_2, $route_cert_ids)) {
                                if (count($question_cert_ids) == 1) {
                                    if ($question_cert_ids[0] == \MSLST_Site::TAPA_TSR_2 && $question_cert_ids[0] == \MSLST_Site::TAPA_TSR_3) {
                                        // The current question certified only by TAPA TSR 2 OR TAPA TSR 3; Make it not needed
                                    }
                                }
                                // Make it certified by TAPA TSR 2
                                else {
                                    array_push($question_cert_ids, \MSLST_Site::TAPA_TSR_2);
                                }
                            }
                            // Case 'TAPA TSR 3' & 'None' are need not be considered becuase the answer assignment logic below
                            // will automatically take care of those 2 cases, ie 'not needed' and 'certified with TSR 3'
                        }
                        if ($tapa_needed == \MSLST_Site::TAPA_TSR_3) {
                            if (in_array(\MSLST_Site::TAPA_TSR_1, $route_cert_ids)) {
                                array_push($question_cert_ids, \MSLST_Site::TAPA_TSR_1);
                            }
                            if (in_array(\MSLST_Site::TAPA_TSR_2, $route_cert_ids)) {
                                array_push($question_cert_ids, \MSLST_Site::TAPA_TSR_2);
                            }
                            if (in_array(\MSLST_Site::TAPA_TSR_3, $route_cert_ids)) {
                                array_push($question_cert_ids, \MSLST_Site::TAPA_TSR_3);
                            }
                        }
                        if (!empty($route_cert_ids)) {  // no certifications mapped to this question
                            foreach ($route_cert_ids as $id) {
                                if (in_array($id, $question_cert_ids)) {
                                    $audit_questions[$question_id]['content'] = "Certified with ". $route_certs[$id];
                                    $audit_questions[$question_id]['class'] = 'answer0';
                                    break 1;
                                } else {
                                    $audit_questions[$question_id]['content'] = "Not Needed";
                                    $audit_questions[$question_id]['class'] = 'answernone';
                                }
                            }
                        } else {
                            $audit_questions[$question_id]['content'] = "Not Needed";
                            $audit_questions[$question_id]['class'] = 'answernone';
                        }
                    } else {
                        foreach ($route_cert_ids as $id) {
                            if (in_array($id, $question_cert_ids)) {
                                $audit_questions[$question_id]['content'] = "Certified with ". $route_certs[$id];
                                $audit_questions[$question_id]['class'] = 'answer0';
                                break 1;
                            }
                        }
                    }
                }
            }
        }

        // Remove the invalid audits (for which either certificate is disabled or hidden)
        $temp_audit_questions = array();
        foreach ($audit_questions as $key => $question) {
            if (!isset ($question['content'])) {
                unset($audit_questions[$key]);
            } 
            else {
                if (isset($question['certification']) && isset($question['content']))
                {
                    $temp_audit_questions[$question['certification']][$question['content']][$key] = $question;
                }
            }
        }
        $audit_questions = $temp_audit_questions;

        return $audit_questions;
    }

    /**
     * Get the legend for answers list
     * 
     * @return array
     */
    public static function getAnswersLegend()
    {
        $legend = [
            'answer0'=>'This question has been certified',
            'answernone'=>'Not Needed'
        ];

        $answers = \Answer::all();
        foreach ($answers as $answer) {
            $legend['answer'.$answer->id] = $answer->content;
        }

        return $legend;
    }

    /**
     * Get current certifications
     * 
     * @param array $audit
     * @return array
     */
    public static function getCurrentCertifications($audit)
    {
    	$tapa_needed = \MSLST_Site::$TAPA_CERTIFICATIONS[$audit->tapa_needed];
    	$tapa_actual = 'None';
    	$c_tpat = 'None';
    	$aeo = 'None';

    	$certifications = $audit->certification->lists('id');

    	foreach ($certifications as $key)
    	{
    		if (isset(\MSLST_Site::$TAPA_CERTIFICATIONS[$key]))
    		{
    			$tapa_actual = \MSLST_Site::$TAPA_CERTIFICATIONS[$key];
    		}
    		if (isset(\MSLST_Site::$C_TPAT_CERTIFICATIONS[$key]))
    		{
    			$c_tpat = \MSLST_Site::$C_TPAT_CERTIFICATIONS[$key];
    		}
    		if (isset(\MSLST_Site::$AEO_CERTIFICATIONS[$key]))
    		{
    			$aeo = \MSLST_Site::$AEO_CERTIFICATIONS[$key];
    		}
    	}

    	$disabled = $audit->disabled_certification->lists('certification_group_id');

    	if (in_array(\MSLST_Site::TAPA_GROUP, $disabled))
    	{
    		$tapa_actual = 'Not Applicable';
    	}
    	if (in_array(\MSLST_Site::C_TPAT_GROUP, $disabled))
    	{
    		$c_tpat = 'Not Applicable';
    	}
    	if (in_array(\MSLST_Site::AEO_GROUP, $disabled))
    	{
    		$aeo = 'Not Applicable';
    	}

    	return [
    		'tapa_needed' => $tapa_needed,
    		'tapa_actual' => $tapa_actual,
    		'c_tpat' => $c_tpat,
    		'aeo' => $aeo,
    	];
    }

    /**
     * Check if the certification assigned to some questions
     *
     * @param $cid int
     * @return boolean
     */
    public static function isCertificationAssigned($cid)
    {
        return \QuestionCertification::withTrashed()->where('certification_id', $cid)->count();
    }
}