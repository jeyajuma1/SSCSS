@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">
             Users

            @if(Auth::User()->isAdmin())
            <div class="btn-group pull-right incident-btns">
                {{ Form::button('<i class="fa fa-plus "></i> Add New User', ['type' => 'button', 'class' => 'btn btn-primary', 'href' => route('users.create')]) }}
            </div>
            @endif
            </h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>

    @if(Session::has('success'))
    <div id="form-success" class="alert alert-success" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div>
    <!-- end form-success -->
    @endif

    <div class="row">
        <div class="col-lg-12">
              <div class="ibox float-e-margins animated flipInX">
                                <div class="ibox-title">
                                    <h5>
                                        <i class="fa fa-filter" aria-hidden="true"></i> Filters
                                    </h5>
                                    <div class="ibox-tools">
                                        <a class="collapse-link"> <i class="fa fa-chevron-up"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="ibox-content">
                                    <div class="row">
                                         <div class="panel panel-default sitemasters-panel">
                                            <div class="panel-heading">
                                                {{ Form::open(['route' => 'users.index', 'method' => 'get', 'id' => 'users-list-form', 'class' => 'form-inline', 'role[]' => 'form']) }}
                                                <div class="form-group-row">
                                                    <div class="form-group">
                                                            <div class="input-group">
                                                                <span class="input-group-addon">User Access</span>
                                                                <!--{{ Form::select('user_access[]', ['access_audits' => 'Access Audits', 'access_incidents' => 'Access Incidents', 'access_sitemasters' => 'Access Site Master', 'access_suppliers' => 'Access Suppliers','access_factory_incidents' => 'Access Factory Incidents'], Input::get('user_access'), [ 'multiple' => 'multiple','class' => 'form-control']) }}-->
                                                               {{ Form::select('user_access[]', ['access_audits' => 'Access Audits', 'access_incidents' => 'Access Incidents', 'access_sitemasters' => 'Access Site Master','access_factory_incidents' => 'Access Factory Incidents'], Input::get('user_access'), [ 'multiple' => 'multiple','class' => 'form-control']) }}
                                                            </div>
                                                    </div>
                                                    <div class="form-group">
                                                            <div class="input-group">
                                                                 <span class="input-group-addon">Role</span>
                                                                {{ Form::select('role[]',['admin'=>'Admin','supervisor'=>'Supervisor','user'=>'User'] ,Input::get('role'), ['multiple' => 'multiple','class' => 'form-control']) }}
                                                            </div>
                                                    </div>
                                                    @if(Auth::user()->isAdmin() || Auth::User()->isManager())
                                                    <div class="form-group">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">LSP</span>
                                                            {{ Form::select('lspname[]', $lspname, Input::get('lspname'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                        </div>                               
                                                    </div>
                                                     @endif
                                                        
                                                </div>
                                                {{ Form::close() }}
                                            </div>
                                         </div>
                                    </div>
                                </div>
              </div>

 
              <div class="ibox float-e-margins animated flipInX">
                                <div class="ibox-title">
                                    <h5>
                                        <i class="fa fa-table" aria-hidden="true"></i> Users
                                    </h5>
                                    <div class="ibox-tools">
                                         
                                    </div>
                                </div>
                                <div class="ibox-content">
                                    <div class="row">
                                         <div class="col-lg-12">
                                             <div class="panel panel-default sitemasters-panel">
                                                <div class="panel-body">
                                                    <table class="table table-hover table-bordered" id="users-list">
                                                            <thead>
                                                                <th>Name</th>
                                                                <th>Role</th>
                                                                <th>Email</th>
                                                                <th>Title</th>
                                                                <th>LSP</th>
                                                                <th>Last Login</th>
                                                                <th></th>
                                                            </thead>
                                                            <tbody>
                                                                @foreach($users as $user)
                                                                <tr>
                                                                    <td>{{ $user->name }}</td>
                                                                    <td>{{ ucfirst($user->role) }}</td>
                                                                    <td>{{ $user->email }}</td>
                                                                    <td>{{ $user->title }}</td>
                                                                    
                                                                    @if(isset($user->lsp))
                                                                        <td>{{ $user->lsp->name }}</td>
                                                                    @else
                                                                        <td>&nbsp;</td>
                                                                    @endif

                                                                    @if(!$user->password_updated_at== '0000-00-00 00:00:00' && $user->last_login_at = '0000-00-00 00:00:00')
                                                                        <td>Activation Pending</td>
                                                                    @elseif(!$user->last_login_at == '0000-00-00 00:00:00')
                                                                        <td>Not Logged In</td>
                                                                    @else
                                                                        <td>{{ $user->last_login_at }}</td>
                                                                    @endif

                                                                    @if(\Auth::User()->isAdmin())
                                                                    <td class="action-buttons"  nowrap>
                                                                    {{ Form::open(['route' => ['users.edit', $user->id], 'method' => 'get']) }}
                                                                        {{ Form::button('Edit', ['type' => 'submit', 'class' => 'btn btn-primary btn-xs']) }}
                                                                    {{ Form::close() }}
                                                                    {{ Form::open(['route' => ['users.destroy', $user->id], 'method' => 'delete']) }}
                                                                        @if (!$user->deleted_at)
                                                                            {{ Form::button('Disable', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs user-delete-button']) }}
                                                                        @else
                                                                            {{ Form::button('Enable', ['type' => 'submit', 'class' => 'btn btn-success btn-xs user-delete-button']) }}
                                                                        @endif
                                                                    {{ Form::close() }}
                                                                    </td>
                                                                    @else
                                                                    <td></td>
                                                                    @endif
                                                                </tr>
                                                                @endforeach
                                                            </tbody>
                                                    </table>
                                                </div>
                                             </div>
                                         </div>
                                    </div>
                                </div>
              </div>
        </div>
    </div>

</div>

 
<!-- /#page-wrapper -->
@stop