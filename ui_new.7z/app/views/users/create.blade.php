@extends('layouts.master')

@section('content')
<div id="page-wrapper">
     <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Add new user</h2>
        </div><!-- /.col-lg-12 -->        
    </div>

    <div class="row">
         <div class="col-lg-12">
              <div class="ibox">
                  <div class="ibox-title">
                    <h5>Add new user</h5>
                    <div class="ibox-tools">
                      <a class="collapse-link"> <i class="fa fa-chevron-up"></i>
                      </a> <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        
                      </a>
                    
                    </div>
                  </div>
                  <div class="ibox-content">
                        {{ Form::open(['route' => 'users.store', 'class' => 'form-horizontal', 'role' => 'form', 'id' => 'user-add']) }}
                        <div class="panel-body">
                             
                            @if($errors->all())
                            <div id="form-errors" class="alert alert-danger" role="alert">
                              <ul>
                                @foreach($errors->all() as $error)
                                  <li>{{ $error }}</li>
                                @endforeach
                              </ul>
                            </div>
                            @endif

                            <div class="row bodycontent">
                                 <div class="pull-right mandatoryfld">
                                    (*) Mandatory Field
                                 </div>
                                <div class="col-lg-12">

                                      <div class="form-group">
                                        {{ Form::label('role', 'Role*', ['class' => 'col-lg-2 control-label required']) }}
                                        <div class="col-lg-6">
                                          {{ Form::select('role', $user_roles, ['class' => 'form-control', 'id' => 'role']) }}
                                        </div>
                                      </div>
                                      <div class="form-group users-regions-group">
                                        {{ Form::label('region', 'Region(s)*', ['class' => 'col-lg-2 control-label required']) }}
                                        <div class="col-lg-6">
                                            <?php $i = 0; ?>
                                            @foreach($regions as $key => $region)
                                              <label class="control-label">
                                                  {{ Form::checkbox('region['. $i .']', $key) }} {{ $region }}
                                              </label><br />
                                              <?php $i++; ?>
                                            @endforeach
                                        </div>
                                      </div>
                                      <div class="form-group users-lsp-group">
                                        {{ Form::label('lsp', 'Company Name*', ['class' => 'col-lg-2 control-label required']) }}
                                        <div class="col-lg-6">
                                          {{ Form::select('lsp', $lsps, ['class' => 'form-control', 'id' => 'lsp']) }}
                                        </div>
                                      </div>

                                      <div class="form-group users-userlevel-group">
                                        {{ Form::label('user_level', 'User Level*', ['class' => 'col-lg-2 control-label required']) }}
                                        <div class="col-lg-6">
                                          {{ Form::select('user_level', ['none'=>'None','vam'=>'VAM','csm'=>'CSM','protection_pm'=>'Protection PM'], ['class' => 'form-control', 'id' => 'user_level']) }}
                                        </div>
                                      </div>
                                       
                                      <div class="form-group users-sm_id-group">
                                       {{ Form::label('site_master_id', 'Site Association*', ['class' => 'col-lg-2 control-label required']) }}
                                          <div class="col-lg-8 user_site_master">
                                               {{Form::select('site_master_id[]',$sm_id , [], ['class' => 'form-control', 'id' => 'sm_id','multiple'])}}
                                          </div>
                                      </div>
     
                                      <div class="form-group">
                                        {{ Form::label('first_name', 'First Name*', ['class' => 'col-lg-2 control-label required']) }}
                                        <div class="col-lg-6">
                                          {{ Form::text('first_name', '', ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('last_name', 'Last Name*', ['class' => 'col-lg-2 control-label required']) }}
                                        <div class="col-lg-6">
                                          {{ Form::text('last_name', '', ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('email', 'Email*', ['class' => 'col-lg-2 control-label required']) }}
                                        <div class="col-lg-6">
                                          {{ Form::text('email', '', ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('title', 'Title*', ['class' => 'col-lg-2 control-label required']) }}
                                        <div class="col-lg-6">
                                          {{ Form::text('title', '', ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        <h4 class="col-lg-10 col-md-offset-2">Access Privileges</h4>
                                      </div>
                                      <!--
                                      <div class="form-group">
                                        {{ Form::label('access_lanes', 'Access Lanes', ['class' => 'col-lg-2 control-label']) }}
                                        <div class="col-lg-6">
                                          {{ Form::checkbox('access_lanes', '1', false, ['class' => 'form-control']) }}
                                        </div>
                                      </div>-->
                                      <div class="form-group">
                                        {{ Form::label('access_audits', 'Access Audits', ['class' => 'col-lg-2 control-label']) }}
                                        <div class="col-lg-6">
                                          {{ Form::checkbox('access_audits', '1', false, ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('access_incidents', 'Access Incidents', ['class' => 'col-lg-2 control-label']) }}
                                        <div class="col-lg-6">
                                          {{ Form::checkbox('access_incidents', '1', false, ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('access_factory_incidents', 'Access Factory Incidents', ['class' => 'col-lg-2 control-label']) }}
                                        <div class="col-lg-6">
                                          {{ Form::checkbox('access_factory_incidents', '1', false, ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                       
                                      <div class="form-group">
                                        {{ Form::label('access_sitemasters', 'Access Site Master', ['class' => 'col-lg-2 control-label']) }}
                                        <div class="col-lg-6">
                                          {{ Form::checkbox('access_sitemasters', '1', false, ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('access_leak_prevention', 'Access Leak Prevention', ['class' => 'col-lg-2 control-label']) }}
                                        <div class="col-lg-6">
                                          {{ Form::checkbox('access_leak_prevention', '1', false, ['class' => 'form-control']) }}
                                         </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('access_p_r', 'Access P+R', ['class' => 'col-lg-2 control-label']) }}
                                        <div class="col-lg-6">
                                          {{ Form::checkbox('access_p_r', '1', false, ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        <h4 class="col-lg-10 col-md-offset-2">Email Notification Settings</h4>
                                      </div>
                                      <div class="form-group">
                                        <div class="col-lg-6 col-md-offset-2">
                                            <label class="control-label">
                                                {{ Form::checkbox('notification_audit_create', '1') }} When a new audit is created
                                            </label><br />
                                            <label class="control-label">
                                                {{ Form::checkbox('notification_audit_edit', '1') }} When an audit is edited
                                            </label><br />
                                            <label class="control-label">
                                                {{ Form::checkbox('notification_major', '1') }} When a new major incident is created
                                            </label><br />
                                            <label class="control-label">
                                                {{ Form::checkbox('notification_medium', '1') }} When a new medium incident is created
                                            </label><br />
                                            <label class="control-label">
                                                {{ Form::checkbox('notification_minor', '1') }} When a new minor incident is created
                                            </label><br />
                                            <label class="control-label">
                                                {{ Form::checkbox('notification_status', '1') }} When status of incident changes
                                            </label><br />
                                            <label class="control-label">
                                                {{ Form::checkbox('notification_edit', '1') }} When incident is edited
                                            </label><br />
                                             <label class="control-label">
                                                {{ Form::checkbox('notification_factory_create', '1') }} When New Factory incident is created
                                            </label><br />
                                             <label class="control-label">
                                                {{ Form::checkbox('notification_factory_edit', '1') }} When Factory incident is edited
                                            </label><br />
                                            <label class="control-label">
                                                {{ Form::checkbox('incident_monthly_report', '1') }} Monthly Incident Report
                                            </label><br />
                                        </div>
                                      </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'href' => '/users']) }}
                        </div>
                    {{ Form::close() }}
                  </div>
            </div>
         </div>
    </div>

</div>
@stop