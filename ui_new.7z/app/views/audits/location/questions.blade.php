@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Location</h1>
                @else
                  <h1 class="page-header">Create Location</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Questions</div>
                    {{ Form::open(['route' => ($edit ? ['locations.update', $data->id] : 'locations.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'audit-form', 'role' => 'form', 'id' => 'location-form-questions']) }}
                        {{ Form::hidden('step', 3) }}   
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard">
                                    <a>
                                      <span>Location Details</span>
                                    </a>
                                    <a>
                                      <span>Needed Certification</span>
                                    </a>
                                    <a>
                                      <span>Actual Certification</span>
                                    </a>
                                    <a class="current">
                                      <span>Questions</span>
                                    </a>
                                    <a>
                                      <span>Comments</span>
                                    </a>
                                  </div>

                                <!-- Nav tabs -->
                                <ul class="nav nav-tabs">
                                  @if (isset($questions['tapa']))
                                    <li id="tapa-tab" class="active"><a href="#tapa" data-toggle="tab">TAPA FSR</a></li>
                                  @endif
                                  @if (isset($questions['c_tpat']))
                                    <li id="ctpat-tab"><a href="#ctpat" data-toggle="tab">C-TPAT</a></li>
                                  @endif
                                  @if (isset($questions['aeo']))
                                    <li id="aeo-tab"><a href="#aeo" data-toggle="tab">AEO</a></li>
                                  @endif
                                </ul>

                                <div class="bs-callout bs-callout-info" id="error_questions" style="display:none;" >
                                    <h4>  </h4>
                                </div>

                                <!-- Tab panes -->
                                <div class="tab-content audit-form-tabs">
                                    @if (isset($questions['tapa']))
                                    <div class="tab-pane active" id="tapa">
                                                                            @foreach($questions['tapa'] as  $question) 
                                            <?php $id = $question['id']; ?>
                                            @if (! $question['display']) 
                                                {{ Form::hidden("question[$id]", 0) }}
                                            @else 
                                                                                           {{ Form::hidden("display[$id]", 1) }}
                                                <?php $tapa_display = 1; ?>
                                                <div class="question-block">
                                                    <div class="form-group">
                                                        {{ Form::label("question$id", $question['text'], ['class' => 'control-label']) }}
                                                        {{ Form::select("question[$id]", $answers, ((isset($data->answer) && isset($data->answer[$id])) ? $data->answer[$id] : null), ['class' => 'form-control bigdrop', 'id' => "question$id"]) }}
                                                        <p class="help-block">{{ $question['certifications'] }}</p>
                                                    </div>                               
                                                    <div class="form-group">
                                                        <?php $form_control = (isset($data->comment) && isset($data->comment[$id])) ? 'form-control' : 'hidden' ?>
                                                        <a onClick="document.getElementById('comment{{ $id }}').className='form-control';" href="javascript:void(0);" class="comment-link">Add Comment</a>
                                                        {{ Form::textarea("comment[$id]", ((isset($data->comment) && isset($data->comment[$id])) ? $data->comment[$id] : ''), ['class' => $form_control, 'rows' => 3, 'id' => "comment$id"]) }}
                                                    </div>
                                                </div>
                                            @endif
                                        @endforeach
                                    </div>
                                    @endif

                                    @if (isset($questions['c_tpat']))
                                    <div class="tab-pane" id="ctpat">
                                        @foreach($questions['c_tpat'] as $question)
                                            <?php $id = $question['id']; ?>
                                            @if (! $question['display']) 
                                                {{ Form::hidden("question[$id]", 0) }}
                                            @else
                                                {{ Form::hidden("display[$id]", 1) }}
                                                <?php $c_tpat_display = 1; ?>
                                                <div class="question-block">
                                                    <div class="form-group">
                                                        {{ Form::label("question$id", $question['text'], ['class' => 'control-label']) }}
                                                        {{ Form::select("question[$id]", $answers, ((isset($data->answer) && isset($data->answer[$id])) ? $data->answer[$id] : null), ['class' => 'form-control bigdrop', 'id' => "question$id"]) }}
                                                        <p class="help-block">{{ $question['certifications'] }}</p>
                                                    </div>                               
                                                    <div class="form-group">
                                                        <?php $form_control = (isset($data->comment) && isset($data->comment[$id])) ? 'form-control' : 'hidden' ?>
                                                        <a onClick="document.getElementById('comment{{ $id }}').className='form-control';" href="javascript:void(0);" class="comment-link">Add Comment</a>
                                                        {{ Form::textarea("comment[$id]", ((isset($data->comment) && isset($data->comment[$id])) ? $data->comment[$id] : ''), ['class' => $form_control, 'rows' => 3, 'id' => "comment$id"]) }}
                                                    </div>
                                                </div>
                                            @endif
                                        @endforeach
                                    </div>
                                    @endif

                                    @if (isset($questions['aeo']))
                                    <div class="tab-pane" id="aeo">
                                        
                                        @foreach($questions['aeo'] as $question)
                                            <?php $id = $question['id']; ?>
                                            @if (! $question['display']) 
                                                {{ Form::hidden("question[$id]", 0) }}
                                            @else
                                                
                                                {{ Form::hidden("display[$id]", 1) }}
                                                <?php $aeo_display = 1; ?>
                                                <div class="question-block">
                                                    <div class="form-group">
                                                        {{ Form::label("question$id", $question['text'], ['class' => 'control-label']) }}
                                                        {{ Form::select("question[$id]", $answers, ((isset($data->answer) && isset($data->answer[$id])) ? $data->answer[$id] : null), ['class' => 'form-control bigdrop', 'id' => "question$id"]) }}
                                                        <p class="help-block">{{ $question['certifications'] }}</p>
                                                    </div>                               
                                                    <div class="form-group">
                                                        <?php $form_control = (isset($data->comment) && isset($data->comment[$id])) ? 'form-control' : 'hidden' ?>
                                                        <a onClick="document.getElementById('comment{{ $id }}').className='form-control';" href="javascript:void(0);" class="comment-link">Add Comment</a>
                                                        {{ Form::textarea("comment[$id]", ((isset($data->comment) && isset($data->comment[$id])) ? $data->comment[$id] : ''), ['class' => $form_control, 'rows' => 3, 'id' => "comment$id"]) }}
                                                    </div>
                                                </div>
                                            @endif
                                        @endforeach
                                    </div>
                                    @endif
                                </div>

                                <div id="no-questions">
                                    <div class="bs-callout bs-callout-warning">
                                        <p>No questions available to be answered based on certification selection you have made.</p>
                                    </div>
                                </div>

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('locations.show', $data->id),'id'=>"audit_cancel" ]) }}
                        @else
                          <div class="clearfix">
                            <div class="pull-left">
                             <!-- {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }} -->
                              <a href="{{($edit ? ['locations.update', $data->id] : '2')}}" class ='btn btn-default' alt='Back'>Back</a>
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('audits.index'),'id'=>"audit_cancel" ]) }}
                            </div>
                          </div>
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>

@if (!$tapa_display)
    <style type="text/css">#tapa, #tapa-tab { display: none; }</style>
@endif

@if (!$c_tpat_display)
    <style type="text/css">#ctpat, #ctpat-tab { display: none; }</style>
@endif

@if (!$aeo_display)
    <style type="text/css">#aeo, #aeo-tab { display: none; }</style>
@endif

@if (!$tapa_display && !$c_tpat_display && !$aeo_display)
    <style type="text/css">#no-questions { display: block; } .audit-form-tabs, .nav-tabs { display: none; } </style>
@else
    <style type="text/css">#no-questions { display: none; } </style>
@endif

@stop