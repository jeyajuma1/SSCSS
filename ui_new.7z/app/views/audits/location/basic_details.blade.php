@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Location</h1>
                @else
                  <h1 class="page-header">Create Location</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Location Details</div>
                    {{ Form::open(['route' => ($edit ? ['locations.update', $data->id] : 'locations.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal audit-form', 'role' => 'form', 'id' => 'location-form-details']) }}
                        {{ Form::hidden('step', 0) }}
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard">
                                    <a class="current">
                                      <span>Location Details</span>
                                    </a>
                                    <a>
                                      <span>Needed Certification</span>
                                    </a>
                                    <a>
                                      <span>Actual Certification</span>
                                    </a>
                                    <a>
                                      <span>Questions</span>
                                    </a>
                                    <a>
                                      <span>Comments</span>
                                    </a>
                                  </div>

                                  @if($errors->all())
                                  <div id="form-errors" class="alert alert-danger" role="alert">
                                    <ul>
                                      @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                      @endforeach
                                    </ul>
                                  </div>
                                  @endif

                                  <div class="form-group">
                                    {{ Form::label('country', 'Country', ['class' => 'col-sm-2 control-label required']) }}
                                    <div class="col-sm-6">
                                      {{ Form::select('country', $countries, $data->country, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('site', 'Site Name', ['class' => 'col-sm-2 control-label required']) }}
                                    <div class="col-sm-6">
                                      {{ Form::text('site', $data->site, ['class' => 'form-control', 'placeholder' => 'Site, building, warehouse, hub names']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('address', 'Address', ['class' => 'col-sm-2 control-label required']) }}
                                    <div class="col-sm-6">
                                      {{ Form::text('address', $data->address, ['class' => 'form-control', 'placeholder' => 'Site Address']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('value', 'Storage Value', ['class' => 'col-sm-2 control-label']) }}
                                    <div class="col-sm-6">
                                      {{ Form::text('value', $data->value, ['class' => 'form-control', 'placeholder' => 'The warehouse value (In USD)']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('coordinates', 'Coordinates', ['class' => 'col-sm-2 control-label required']) }}
                                    <div class="col-sm-4">
                                      {{ Form::text('coordinates', $data->coordinates, ['class' => 'form-control', 'placeholder' => 'Coordinate format: latitude, longitude', 'id' => 'coordinates']) }}
                                    </div>
                                    <div class="col-sm-2">
                                    <input type="hidden" id="myField" value="" />
                                      {{ Form::button('Validate', ['type' => 'button', 'class' => 'form-control btn btn-primary', 'id' => 'location-coordinate-check']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    <div class="col-sm-6 col-sm-offset-2" id="location-coordinate-pick"></div>
                                  </div>
                                  <div class="form-group">
                                    <div class="col-sm-6 col-sm-offset-2 description">
                                    (Example: 42.374335,-71.116991 (Decimal Degrees) or N30 17.477,W97 44.315 (GPS) or N42 21 30,W71 06 14 (Degrees, Minutes &amp; Seconds) or 19N 326727 4691707 (UTM))
                                    </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('locations.show', $data->id) ,'id'=>"audit_cancel" ]) }}
                        @else
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('audits.index') ,'id'=>"audit_cancel"]) }}
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>

<!--script type="text/javascript" charset="UTF-8" src="https://js.api.here.com/ee/2.5.4/jsl.js?with=all"></script-->
<script type="text/javascript" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
  var Locations = {'coordinates': null, 'mapElement': null};
</script>

@stop
