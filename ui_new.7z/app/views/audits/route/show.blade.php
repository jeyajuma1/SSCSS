@extends('layouts.master')

@section('content')



<div class="row border-bottom white-bg page-heading">
     <div class="row">
          <div class="col-lg-12">
                    <h2 class="show_page_header">
                       View Route @if($route->review == 1)
                                    <span class="glyphicon glyphicon-exclamation-sign icon-red"></span>
                       @endif
                      <div class="pull-right">
                           <div class="btn-group audit-btns">
                                {{ Form::open(['route' => 'audits.index', 'method' => 'get']) }}
                                    {{ Form::hidden('type', 'routes') }}
                                    {{ Form::button('<i class="fa fa-arrow-left"></i> Go Back', ['type' => 'submit', 'class' => 'btn btn-outline btn-default']) }}
                                {{ Form::close() }}

                                @if (\Auth::User()->isAdmin())
                                    @if($route->review == 0)
                                        {{ Form::open(['route' => ['routes.review', $route->id,'request'], 'method' => 'patch']) }}
                                            {{ Form::button('Request Review', ['type' => 'submit', 'class' => 'btn btn-outline btn-default route-review-button']) }}
                                            {{ Form::hidden('review_message', '') }}
                                        {{ Form::close() }}
                                    @else
                                        {{ Form::open(['route' => ['routes.review', $route->id,'clear'], 'method' => 'patch']) }}
                                            {{ Form::button('Clear Review', ['type' => 'submit', 'class' => 'btn btn-outline btn-default']) }}
                                        {{ Form::close() }}

                                    @endif

                                    {{ Form::open(['route' => ['routes.destroy', $route->id], 'method' => 'delete']) }}
                                        {{ Form::button('Remove', ['type' => 'submit', 'class' => 'btn btn-outline btn-default route-delete-button']) }}
                                    {{ Form::close() }}
                                @endif

                                {{ Form::open(['route' => ['routes.show', $route->id]]) }}
                                    {{ Form::button('Print', ['type' => 'button', 'class' => 'btn btn-outline btn-default', 'onclick' => 'javascript:window.print()']) }}
                                {{ Form::close() }}


                               @if (\Auth::User()->isAdmin() || \Auth::User()->isSupervisor() || \Auth::User()->isManager())
                                 @if($route->status == 'active')
                                    {{ Form::open(['route' => ['routes.status', $route->id,'inactive'] , 'method'=>'patch']) }}
                                        {{ Form::button('Make Inactive',['type' => 'submit' , 'class' =>'btn btn-outline btn-default location-inactive-button' ]) }}
                                    {{ Form::close() }}
                                 @elseif($route->status == 'inactive')
                                    {{ Form::open(['route' => ['routes.status', $route->id,'active'] , 'method'=>'patch']) }}
                                        {{ Form::button('Make Active',['type' => 'submit' , 'class' =>'btn btn-outline btn-default location-active-button' ]) }}
                                    {{ Form::close() }}
                                 @endif
                               @endif
                            </div>
                      </div>
              </div><!-- /.col-lg-12 -->
     </div><!-- /.row -->
</div> <!-- /.page-head -->

@if(Session::has('success'))
<div id="form-success" class="alert alert-success" role="alert">
    <span>
        {{ trans(Session::get('success')) }}
    </span>
</div><!-- end form-success -->
@endif



<div class="wrapper-content animated fadeIn">
     <div class="panel-body">
         <div class="col-lg-8">
             <div class="ibox float-e-margins">
                   <div class="ibox-title">
                        <h5><i class="fa fa-briefcase"></i>Route Information</h5>
                        <div class="ibox-tools">                           
                            @if (\MSLST\Helpers\Common::canAccessEdit(null, 'route', null, $route))
                                    <div class="pull-right">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-default btn-xs" href="{{ route('routes.edit', [$route->id]) }}">
                                                Edit
                                            </button>
                                        </div><a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>
                                    </div>
                             @endif
                         </div>
                    </div>  <!-- /.ibox-title -->
                     
                   <div class="ibox-content">
                       <div class="table-responsive">
                              <table class="incidents-basic-table">
                                    <tbody>
                                         <tr class="font-darkblue-first">
                                                <td>
                                                    Origin
                                                </td>
                                                <td>
                                                    Destination
                                                </td>
                                         </tr>
                                         <tr>
                                            <td>
                                               
                                                    {{ $route->start_site }}<br />
                                                    {{ $route->start_address }}<br />
                                                    {{ $route->start_country->name }}
                                                
                                            </td>
                                            <td>
                                                
                                                    {{ $route->end_site }}<br />
                                                    {{ $route->end_address }}<br />
                                                    {{ $route->end_country->name }}
                                                
                                            </td>
                                         </tr>
                                         <tr class="font-darkblue">
                                            <td>
                                                Start Coordinates
                                            </td>
                                            <td>
                                                End Coordinates
                                            </td>
                                         </tr>
                                         <tr>
                                            <td>
                                               
                                                {{ $route->start_coordinates }}
                                            </td>
                                            <td>
                                              
                                                {{ $route->end_coordinates }}
                                            </td>
                                         </tr>
                                         <tr>
                                            <td colspan="2">
                                                <div id="route_map" class="detail-view-map span12  col-sm-12">
                                                </div>
                                            </td>
                                         </tr>
                                    </tbody>
                               </table>
                       </div>
                   </div>  <!-- /.ibox-content -->
             </div>  <!-- /.ibox float-e-margins -->

             <div class="ibox float-e-margins">
                   <div class="ibox-title">
                        <h5><i class="fa fa-briefcase"></i>Current Certifications</h5>
                        <div class="ibox-tools">                           
                            @if (\MSLST\Helpers\Common::canAccessEdit(null, 'route', null, $route))
                                    <div class="pull-right">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-default btn-xs" href="{{ route('routes.edit', [$route->id, 2]) }}">
                                                Edit
                                            </button>
                                        </div><a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>
                                    </div>
                             @endif
                         </div>
                    </div>  <!-- /.ibox-title -->
                     
                   <div class="ibox-content">
                       <div class="table-responsive">
                            <table class="incidents-basic-table">
                                    <thead>
                                         <tr class="font-darkblue-first">
                                            <td>TAPA</td>
                                            <td>C-TPAT</td>
                                            <td>AEO</td>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>
                                                Needed Certification: {{ $current_certifications['tapa_needed'] }}<br />
                                                Actual Certification: {{ $current_certifications['tapa_actual'] }}
                                            </td>
                                            <td>
                                                {{ $current_certifications['c_tpat'] }}
                                            </td>
                                            <td>
                                                {{ $current_certifications['aeo'] }}
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                &nbsp;
                                            </td>
                                            <td>
                                                @if($route->ctpat_number != "")
                                                    SVI Number: {{ $route->ctpat_number }}
                                                @else
                                                    SVI Number: NA
                                                @endif
                                            </td>
                                            <td>
                                                @if($route->aeo_number)
                                                    AEO Number: {{ $route->aeo_number }}
                                                @else
                                                    AEO Number: NA
                                                @endif
                                            </td>
                                        </tr>
                                    </tbody>
                             </table>
                       </div>
                   </div>  <!-- /.ibox-content -->
             </div>  <!-- /.ibox float-e-margins -->

              <div class="ibox float-e-margins">
                   <div class="ibox-title">
                        <h5><i class="fa fa-briefcase"></i> Questions &amp; Answers</h5>
                        <div class="ibox-tools">                           
                            @if (\MSLST\Helpers\Common::canAccessEdit(null, 'route', null, $route))
                                    <div class="pull-right">
                                        <div class="btn-group">
                                           <button type="button" class="btn btn-default btn-xs" href="{{ route('routes.edit', [$route->id, 3]) }}">
                                                Edit
                                            </button>
                                        </div><a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>
                                    </div>
                             @endif
                         </div>
                    </div>  <!-- /.ibox-title -->
                     
                   <div class="ibox-content">
                       <div class="panel-body">
                            @if(!empty($audits))
                            <div class="panel-group" id="accordion">
                                @foreach($audits as $category => $list)
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-toggle="collapse" data-parent="#accordion" href="#{{ md5($category) }}">
                                                    {{ $category }}
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="{{ md5($category) }}" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                <div class="panel-group" id="accordion_{{ md5($category) }}">
                                                    @foreach($list as $question_category => $questions)
                                                        <div class="panel panel-default">
                                                            <div class="panel-heading">
                                                                <h4 class="panel-title">
                                                                    <a data-toggle="collapse" data-parent="#accordion_{{ md5($category) }}" href="#{{ md5($category.$question_category) }}">
                                                                        {{ $question_category }}
                                                                    </a>
                                                                </h4>
                                                            </div>
                                                            <div id="{{ md5($category.$question_category) }}" class="panel-collapse collapse">
                                                                <div class="panel-body">
                                                                    {{--*/ $i=1; /*--}}
                                                                    @foreach($questions as $question)
                                                                        <div class="question-wrapper">
                                                                            <div class="question-circle {{ $question['class'] }}" title="{{ $legend[$question['class']] }}" data-toggle="tooltip" data-placement="bottom">
                                                                                &nbsp;
                                                                            </div>
                                                                            <div class="answer-wrapper">
                                                                                <h5>
                                                                                    <span class="{{ $question['class'] }}">
                                                                                        {{ $i++ }}
                                                                                    </span>. {{ $question['text'] }}
                                                                                </h5>
                                                                                <div class="answer">
                                                                                    @if (isset($question['comment']) && $question['comment'] != '')
                                                                                        <div class="comment">
                                                                                            <p>{{ $question['comment'] }}</p>
                                                                                        </div>
                                                                                    @else
                                                                                        <p>&nbsp;</p>
                                                                                    @endif
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    @endforeach
                                                                </div>
                                                            </div>
                                                        </div>
                                                    @endforeach
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div>
                            @else
                                <p>There are no questions & answers.</p>
                            @endif
                       </div>
                   </div>  <!-- /.ibox-content -->
             </div>  <!-- /.ibox float-e-margins -->

              <div class="ibox float-e-margins">
                   <div class="ibox-title">
                        <h5><i class="fa fa-briefcase"></i> Comments</h5>
                        <div class="ibox-tools">
                           @if (\MSLST\Helpers\Common::canAccessEdit(null, 'route', null, $route))
                                <div class="pull-right">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-default btn-xs" href="{{ route('routes.edit', [$route->id, 4]) }}">
                                            Edit
                                        </button>
                                    </div>
                                      <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>
                                </div>
                             @endif

                         </div>
                    </div>  <!-- /.ibox-title -->
                     
                   <div class="ibox-content">
                       <div class="table-responsive">
                            <table class="incidents-basic-table">
                                <tbody>
                                    <tr>
                                        <td>
                                            {{ $route->comment }}
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                     </div>
                   </div>  <!-- /.ibox-content -->
             </div>  <!-- /.ibox float-e-margins -->
        </div><!-- /.col-lg-8 -->
        
       <div class="col-lg-4">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="table-responsive">
                          <table class="incidents-basic-table">
                             <tbody>
                                    <tr class="font-darkblue-first">
                                        <td>
                                            Created by
                                        </td>
                                    </tr>
                                    <tr> 
                                        <td class="incidentviewtd"><span>{{ $route->user->name }}</span>
                                        </td>
                                    </tr>
                                    <tr class="font-darkblue">
                                        <td>
                                            Created On
                                        </td>
                                    </tr>
                                    <tr> 
                                        <td class="incidentviewtd"><span>{{ $route->created_at->format('M d, Y h:i A') }}</span>
                                        </td>
                                    </tr>
                                    <tr class="font-darkblue">
                                        <td>
                                            Audit Age
                                        </td>
                                    </tr>
                                     <tr> 
                                        <td class="incidentviewtd"><span>{{ $route->audit_age}}</span> </td>
                                    </tr>

                                    <tr class="font-darkblue">
                                        <td>
                                            LSP
                                        </td>
                                    </tr>
                                     <tr> 
                                        <td class="incidentviewtd"><span>{{ $route->lsp->name }}</span>
                                        </td>
                                    </tr>
                                    <tr class="font-darkblue">
                                        <td>
                                            Audit ID
                                        </td>
                                    </tr>
                                    <tr> 
                                        <td class="incidentviewtd"><span>{{ $route->name }}</span> </td>
                                    </tr>
                                    
                                    <tr class="font-darkblue">
                                        <td>
                                           Status
                                        </td>
                                    </tr>
                                    <tr> 
                                        <td class="incidentviewtd">
                                            <span class="label @if($route->status == 'active') label-success @else label-danger @endif">
                                                    {{ucfirst($route->status)}}
                                            </span>
                                        </td>
                                    </tr>
                                    <tr class="font-darkblue">
                                        <td>
                                            Score
                                        </td>
                                    </tr>
                                    <tr> 
                                        <td class="incidentviewtd">
                                            @if($route->score >= 80)
                                                 <span class="label label-success">
                                            @elseif($route->score >= 60)
                                                 <span class="label label-warning">
                                            @else
                                                <span class="label label-danger">
                                            @endif
                                            @if(!$route->tapa_needed)
                                              Audit Pending
                                            @else
                                                 {{ round($route->score, 2) }}
                                            @endif
                                            </span> 
                                        </td>
                                    </tr>
                                    <tr class="font-darkblue">
                                        <td>
                                            Last Edit Date
                                        </td>
                                    </tr>
                                    <tr> 
                                        <td class="incidentviewtd"><span>{{ $route->updated_at->format('M d, Y h:i A') }}</span>
                                        </td>
                                    </tr>
                                    @if (\Auth::User()->isAdmin())
                                    <tr class="font-darkblue">
                                        <td>
                                            Additional Owners
                                        </td>
                                    </tr>
                                     <tr> 
                                        <td class="incidentviewtd"><span>{{ Form::select('owners', $users, $owners,['multiple' => true]) }}</span>
                                        </td>
                                    </tr>
                                    @endif
                             </tbody>
                          </table>
                    </div>
                </div>
                <!-- /.panel-body -->
            </div>

             <div class="ibox float-e-margins">
                   <div class="ibox-title">
                        <h5><i class="fa fa-briefcase"></i> Attachments</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>
                         </div>
                    </div>  <!-- /.ibox-title -->
                     
                   <div class="ibox-content">
                       <div class="table-responsive">
                            <table class="incidents-basic-table">
                                <tbody>
                                    @if($route->certification->count() > 0)
                                        @foreach($route->certification as $attachment)
                                            <tr>
                                                <td>
                                                    <a href="{{ route('audits.download', [$attachment->pivot->id, $route->id, 'route']) }}">{{ str_limit($attachment->pivot->filename?:$attachment->pivot->certificate_file, 40) }}</a><br />
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr>
                                            <td>No attachments.</td>
                                        </tr>
                                    @endif
                                </tbody>
                            </table>
                     </div>
                   </div>  <!-- /.ibox-content -->
             </div>  <!-- /.ibox float-e-margins -->

              <div class="ibox float-e-margins">
                   <div class="ibox-title">
                        <h5><i class="fa fa-briefcase"></i> History Log</h5>
                        <div class="ibox-tools">
                            <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>
                         </div>
                    </div>  <!-- /.ibox-title -->
                     
                   <div class="ibox-content">
                       <div class="table-responsive">
                            <table class="tbody-small">
                                <tbody class="font-black-small">
                                    @foreach($route->route_log as $log)
                                    <tr>
                                        <td>
                                            @if($log->created_at != NULL)
                                                {{ $log->created_at->format('M d, Y h:i A') }} - Created by {{ $log->user->name }}
                                            @elseif($log->updated_at != NULL)
                                                {{ $log->updated_at->format('M d, Y h:i A') }} - Edited by {{ $log->user->name }}
                                            @elseif($log->requested_at != NULL)
                                                {{  date('M d, Y h:i A',strtotime($log->requested_at))  }} - Review requested by {{ $log->user->name }}
                                            @elseif($log->cleared_at != NULL)
                                                {{  date('M d, Y h:i A',strtotime($log->cleared_at))  }} - Review cleared by {{ $log->user->name }}
                                            @endif
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                          </table>
                     </div>
                   </div>  <!-- /.ibox-content -->
             </div>  <!-- /.ibox float-e-margins -->
             
                    
       </div><!-- /.col-lg-4 -->        
     </div>  <!-- /.panel-body -->
</div> <!-- /#wrapper-content -->
 
<!--<script type="text/javascript" charset="UTF-8" src="//js.api.here.com/ee/2.5.4/jsl.js?with=all"></script>-->
 <script type="text/javascript" charset="UTF-8"  src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
	var Routes = {
		mapElement: 'route_map',
		startCoordinates: '{{ $start_coordinates }}',
		endCoordinates: '{{ $end_coordinates }}'
	};
</script>

@stop
