@extends('layouts.master')

@section('content')
<div id="page-wrapper">
      <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
                Summary
            </h1>
        </div>
      </div>

    <!-- /.row -->
    <div class="row">
      <!-- /.col-lg-12 -->
      <div class="col-lg-12">
           <div class="panel panel-default">
                    <div class="panel-heading"><h4>Data not yet saved. Please review the information and confirm once done.</h4></div>
            </div>
             {{ Form::open(['route' => 'routes.store', 'method' => 'post', 'class' => 'audit-form', 'role' => 'form', 'id' => 'form-summary']) }}
             {{ Form::hidden('step', 5) }}
            <div class="panel-body">
                   <!-- /.row -->
                   <div class="row audit-show">
                        <!-- /.col-lg-8 -->
                        <div class="col-lg-8">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <i class="fa fa-bar-chart-o fa-fw"></i> Route Information
                                    <div class="pull-right">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-default btn-xs" href="{{ route('routes.create', 0) }}">
                                                Edit
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                          <table class="table">
                                              <tbody>
                                                  <tr>
                                                      <td>
                                                          <b>Origin</b><br />
                                                          <p>
                                                            {{ $data['basic_details']->start_site }}<br />
                                                            {{ $data['basic_details']->start_address }}<br />
                                                            {{  $data['start_country_name'][$data['basic_details']->start_country] }}
                                                          </p>
                                                      </td>
                                                      <td>
                                                          <b>Destination</b><br />
                                                          <p>
                                                            {{ $data['basic_details']->end_site }}<br />
                                                            {{ $data['basic_details']->end_address }}<br />
                                                            {{ $data['end_country_name'][$data['basic_details']->end_country] }}
                                                          </p>
                                                      </td>
                                                  </tr>
                                                  <tr>
                                                      <td>
                                                          <b>Start Coordinates</b><br />
                                                          <p>{{$data['basic_details']->start_coordinates }}</p>
                                                      </td>
                                                      <td>
                                                          <b>End Coordinates</b><br />
                                                          <p>{{ $data['basic_details']->end_coordinates }}</p>
                                                      </td>
                                                  </tr>
                                                  <tr>
                                                      <td colspan="2">
                                                          <div id="route_map" class="detail-view-map span12 col-sm-12">
                                                          </div>
                                                      </td>
                                                  </tr>
                                              </tbody>
                                          </table>
                                    </div>
                                </div>
                            </div>
                              <!-- /.panel -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <i class="fa fa-bar-chart-o fa-fw"></i> Current Certifications
                                    <div class="pull-right">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-default btn-xs" href="{{ route('routes.create', 2) }}">
                                                Edit
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                          <thead>
                                            <tr>
                                              <td><b>TAPA</b></td>
                                              <td><b>C-TPAT</b></td>
                                              <td><b>AEO</b></td>
                                            </tr>
                                          </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                      Needed Certification: {{ (is_numeric($data['needed_certification']->tapa_needed)) ? $certification[$data['needed_certification']->tapa_needed] : $data['needed_certification']->tapa_needed}}<br />
                                                      Actual Certification: {{ (!empty($data['actual_certification']->tapa) && is_numeric($data['actual_certification']->tapa)) ? $certification[$data['actual_certification']->tapa] : 'None' }}
                                                    </td>
                                                    <td>
                                                        {{ (!empty($data['actual_certification']->ctpat) && is_numeric($data['actual_certification']->ctpat)) ? $certification[$data['actual_certification']->ctpat] : 'Not Applicable' }}
                                                    </td>
                                                    <td>
                                                       {{ (!empty($data['actual_certification']->aeo) && is_numeric($data['actual_certification']->aeo)) ? $certification[$data['actual_certification']->aeo] : 'Not Applicable' }}
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        &nbsp;
                                                    </td>
                                                    <td>
                                                          SVI Number : {{  $data['actual_certification']->svi_num ?  $data['actual_certification']->svi_num : 'NA' }}
                                                    </td>
                                                    <td>
                                                           AEO Number: {{ $data['actual_certification']->aeo_num ? $data['actual_certification']->aeo_num : 'NA'  }}
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                     </div>
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                            <!-- /.panel -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <i class="fa fa-bar-chart-o fa-fw"></i> Comments
                                    <div class="pull-right">
                                        <div class="btn-group">
                                            <button type="button" class="btn btn-default btn-xs" href="{{ route('routes.create', 4) }}">
                                                Edit
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <tbody>
                                                <tr>
                                                  <td>
                                                    {{ $data['comments']->comments }}
                                                  </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                     </div>
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-8 -->
                        <!-- /.col-lg-4 -->
                        <div class="col-lg-4">
                                 <!-- /.panel -->
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <i class="fa fa-bar-chart-o fa-fw"></i> Attachments
                                </div>
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table">
                                            <tbody>
                                              @if((isset($data['actual_certification']->tapa_certificate)) || (isset($data['actual_certification']->ctpat_certificate))  || (isset($data['actual_certification']->aeo_certificate)))
                                                <?php
                                                      $certificate = ['tapa'=>$data['actual_certification']->tapa_certificate,'ctpat'=>$data['actual_certification']->ctpat_certificate,'aeo'=>$data['actual_certification']->aeo_certificate];
                                                      $certificate = array_filter($certificate);
                                                ?>
                                                  @foreach($certificate as $attachment)
                                                    <tr>
                                                        <td>
                                                            {{ str_limit($attachment['filename'], 40) }}<br/>
                                                        </td>
                                                    </tr>
                                                  @endforeach
                                              @else
                                                <tr>
                                                  <td>No attachments.</td>
                                                </tr>
                                                @endif
                                            </tbody>
                                        </table>
                                     </div>
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-4 -->
                  </div>
                  <!-- /.row -->
            </div>
            <!-- /.panel-body -->

            <div class="panel-footer summary_footer">

                          <div class="clearfix">
                            <div class="pull-left">
                              {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }}
                            </div>
                            <div class="pull-right">
                              {{ Form::button('Confirm', ['type' => 'submit', 'class' => 'btn btn-primary','id'=>'summaryform']) }}
                              {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('audits.index'),'id'=>"audit_cancel" ]) }}
                            </div>
                          </div>
            </div>
      </div>
       <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
</div>
    <!-- /#page-wrapper -->
<!--<script type="text/javascript" charset="UTF-8" src="//js.api.here.com/ee/2.5.4/jsl.js?with=all"></script>-->
<script type="text/javascript" charset="UTF-8"  src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
  var Routes = {
    mapElement: 'route_map',
    startCoordinates: '{{$data["basic_details"]->start_coordinates }}',
    endCoordinates: '{{$data["basic_details"]->end_coordinates }}'
  };
</script>

@stop
