@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Route</h1>
                @else
                  <h1 class="page-header">Create Route</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Route Details</div>
                    {{ Form::open(['route' => ($edit ? ['routes.update', $data->id] : 'routes.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'audit-form', 'role' => 'form', 'id' => 'route-form-details']) }}
                        {{ Form::hidden('step', 0) }}
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard">
                                    <a class="current">
                                      <span>Route Details</span>
                                    </a>
                                    <a>
                                      <span>Needed Certification</span>
                                    </a>
                                    <a>
                                      <span>Actual Certification</span>
                                    </a>
                                    <a>
                                      <span>Questions</span>
                                    </a>
                                    <a>
                                      <span>Comments</span>
                                    </a>
                                  </div>

                                  @if($errors->all())
                                  <div id="form-errors" class="alert alert-danger" role="alert">
                                    <ul>
                                      @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                      @endforeach
                                    </ul>
                                  </div>
                                  @endif

                                  <div class="row">
                                      <div class="col-lg-5">
                                          <div class="form-group">
                                            <h4>Origin</h4>
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('start_country', 'Country', ['class' => 'control-label required']) }}
                                            <div>
                                              {{ Form::select('start_country', $countries, $data->start_country, ['class' => 'form-control']) }}
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('start_site', 'Site Name', ['class' => 'control-label required']) }}
                                            <div>
                                              {{ Form::text('start_site', $data->start_site, ['class' => 'form-control', 'placeholder' => 'Site, building, warehouse, hub names']) }}
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            <div class="form-group">
                                              {{ Form::label('start_address', 'Address', ['class' => 'control-label required']) }}
                                              <div>
                                                {{ Form::text('start_address', $data->start_address, ['class' => 'form-control', 'placeholder' => 'Site Address']) }}
                                              </div>
                                            </div>
                                          </div>
                                          <!--
                                          <div class="form-group">
                                              {{ Form::label('start_carrier', 'Carrier', ['class' => 'control-label required']) }}
                                              <div>
                                                {{ Form::text('start_carrier', @$data->start_carrier, ['class' => 'form-control', 'placeholder' => 'Carrier Information']) }}
                                              </div>
                                          </div>
                                          -->
                                          <div class="form-group">
                                            {{ Form::label('start_coordinates', 'Coordinates', ['class' => 'control-label required']) }}
                                            <div>
                                              {{ Form::text('start_coordinates', $data->start_coordinates, ['class' => 'form-control', 'placeholder' => 'Coordinate format: latitude, longitude', 'id' => 'start_coordinates']) }}
                                            </div>
                                            <div>
                                              {{ Form::button('Validate', ['type' => 'button', 'class' => 'form-control btn btn-primary', 'id' => 'route-start-coordinate-check']) }}
                                            </div>
                                          </div>
                                          <div class="form-group row">
                                            <div id="start-coordinate-pick" class="col-md-12"></div>
                                          </div>
                                          <div class="form-group row">
                                            <div class="description col-md-12">
                                            (Example: 42.374335,-71.116991 (Decimal Degrees) or N30 17.477,W97 44.315 (GPS) or N42 21 30,W71 06 14 (Degrees, Minutes &amp; Seconds) or 19N 326727 4691707 (UTM))
                                            </div>
                                          </div>
                                      </div>
                                      <div class="col-lg-2">
                                        <div class="form-group route-center-arrow-wrap">
                                            <span class="route-center-arrow">
                                                <i class="fa fa-arrow-right fa-4x fa-fw"></i>
                                            </span>
                                        </div>
                                      </div>
                                      <div class="col-lg-5 pull-right">
                                          <div class="form-group">
                                            <h4>Destination</h4>
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('end_country', 'Country', ['class' => 'control-label required']) }}
                                            <div>
                                              {{ Form::select('end_country', $countries, $data->end_country, ['class' => 'form-control']) }}
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('end_site', 'Site Name', ['class' => 'control-label required']) }}
                                            <div>
                                              {{ Form::text('end_site', $data->end_site, ['class' => 'form-control', 'placeholder' => 'Site, building, warehouse, hub names']) }}
                                            </div>
                                          </div>
                                          <div class="form-group">
                                              {{ Form::label('end_address', 'Address', ['class' => 'control-label required']) }}
                                              <div>
                                                {{ Form::text('end_address', $data->end_address, ['class' => 'form-control', 'placeholder' => 'Site Address']) }}
                                              </div>
                                          </div>
                                          <!--
                                          <div class="form-group">
                                              {{ Form::label('end_carrier', 'Carrier', ['class' => 'control-label required']) }}
                                              <div>
                                                {{ Form::text('end_carrier', @$data->end_carrier, ['class' => 'form-control', 'placeholder' => 'Carrier Information']) }}
                                              </div>
                                          </div>
                                          -->
                                          <div class="form-group">
                                            {{ Form::label('end_coordinates', 'Coordinates', ['class' => 'control-label required']) }}
                                            <div>
                                              {{ Form::text('end_coordinates', $data->end_coordinates, ['class' => 'form-control', 'placeholder' => 'Coordinate format: latitude, longitude', 'id' => 'end_coordinates']) }}
                                            </div>
                                            <div><input type="hidden" id="myField" value="" />
                                              {{ Form::button('Validate', ['type' => 'button', 'class' => 'form-control btn btn-primary', 'id' => 'route-end-coordinate-check']) }}
                                            </div>
                                          </div>
                                          <div class="form-group row">
                                            <div id="end-coordinate-pick" class="col-md-12"></div>
                                          </div>
                                          <div class="form-group row">
                                            <div class="description col-md-12">
                                            (Example: 42.374335,-71.116991 (Decimal Degrees) or N30 17.477,W97 44.315 (GPS) or N42 21 30,W71 06 14 (Degrees, Minutes &amp; Seconds) or 19N 326727 4691707 (UTM))
                                            </div>
                                          </div>
                                      </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('routes.show', $data->id),'id'=>"audit_cancel" ]) }}
                        @else
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('audits.index'),'id'=>"audit_cancel" ]) }}
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>

<!--script type="text/javascript" charset="UTF-8" src="https://js.api.here.com/ee/2.5.4/jsl.js?with=all"></script-->
<script type="text/javascript" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
  var Routes = {'startCoordinates': null, 'endCoordinates': null, 'mapElement': null};
</script>

@stop
