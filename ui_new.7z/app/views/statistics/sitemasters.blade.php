@extends('layouts.master')
@section('content')
<div id="page-wrapper">
  

    @if(Session::has('message'))
          <div class="bs-callout bs-callout-info">
              <h4> {{ Session::get('message') }}</h4>
          </div>
    @endif

    <div class="row">
        <div class="col-lg-12">

          @if(Input::get('type') == 'map')
            <div class="panel panel-default statistics-panel">
                 <div id="map-wrapper">
                                <div id="map_canvas" style="position: fixed; right: 0;height: 100%; width: 100%; background-color: grey; border: solid 0px #B3B3B3; margin-bottom: 10px;"></div>
                                    <div id="map-controls" class="col-md-3">
                                       <div class="panel panel-default">
                                       <div class="panel-heading">
                                        Sites
                                       </div>
                                       <div class="panel-body">
                                            <?php $Any = array(''=>'Any'); ?>
                                            <!--<form class="form-inline" role="form" id="statistics_search"> -->
                                            {{Form::open(['action'=>'StatisticsController@getSitemasters','method'=>'get' ,'id'=>'statistics_search','class'=>'form-inline','role'=>'form'])}}
                                            <div class="form-group-row">
                                                {{ Form::select('statistics-switch', array('incidents'=>'Incidents','audits'=>'Audits','suppliers' =>'Suppliers','sitemaster' =>'Sites'), 'sitemaster', ['class' => 'form-control', 'id' => 'statistics-switch']) }}
                                                {{ Form::hidden('type', Input::get('type'), ['class' => 'form-control', 'id' => 'type']) }}
                                            </div>
                                            <div class="form-group-row">
                                                @if(Input::get('type') != 'map')
                                                <div class="form-group">
                                                    {{ Form::select('report', array('incidents'=>'Number of incidents','value'=>'Incident value'), Input::get('report'), ['class' => 'form-control']) }}
                                                </div>
                                                @endif
                                            </div>
                                            {{Form::close()}}
                                       </div>
                                       </div>
                                    </div>
                  </div>
        
            </div>
          @endif

        </div>
    </div>

</div>

<!-- /#page-wrapper -->
 <script type="text/javascript" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
{{ HTML::script('https://code.jquery.com/jquery-1.11.1.min.js') }}
<script type="text/javascript">
    var Statistics = {};
</script>
@if(Input::get('type') == 'map')
{{ HTML::script('js/maps/bing_cluster.js') }}
<script type="text/javascript">
  var coordinates = {{$mapresults}};
  Statistics.plottype      = 'map';
  showSitemastersMapByAddress(coordinates,'map_canvas');
</script>
@endif

@if(Input::get('type') == 'map')
<style type="text/css">
    
	 #page-wrapper {
        padding : 0px 15px !important;
        min-height :100% !important;
        height: auto !important;
    }
    #wrapper {
       min-height :100% !important;
       height: auto !important;
    }
    #map_canvas{
       /*height: 830px !important;*/
    }
    footer{
        background :none repeat scroll 0 0 rgba(0, 0, 0, 0.4) !important;
        position:relative;
        padding: 0 15px 5px !important;
    }
    .footer-wrap {
        position: absolute;
        bottom: 0px;
    }
    .container p {
        margin: 0px !important;
    }
    .container .footer-links {
        padding-bottom: 0px !important;
    }
    .footer-links a {
        color :#001b51 !important;
    }
</style>
@endif

@stop
