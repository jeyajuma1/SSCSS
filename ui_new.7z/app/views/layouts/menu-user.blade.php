<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav" id="side-menu">
		   <li class="pull-right" style='margin-right:15px;'>
			<!-- {{ HTML::decode(HTML::link('/UserManual/UserManual_User.pdf', 'User Manual', [ 'target' => '_blank'] )) }} -->
              <a  data-toggle="modal" data-target="#myModal">User Manual</a>
			</li>
            <li {{ MSLST_Common::activeURI('dashboard*') }}>
                <a href="/dashboard">Dashboard</a>
            </li>
          
            @if(Auth::User()->access_incidents)
            <li {{ MSLST_Common::activeURI('incidents*') }}>
                <a href="/incidents">Incidents</a>
            </li>
            @endif
            @if(Auth::User()->access_audits)
            <li {{ MSLST_Common::activeURI('audits*', ['locations*', 'routes*']) }}>
                <a href="/audits">Audits</a>
            </li>
            @endif

            @if(Auth::User()->access_lanes)
           <!-- <li {{ MSLST_Common::activeURI('lanes*') }}>
                <a href="/lanes">Lanes</a>
            </li>-->
            @endif

			@if(Auth::User()->access_suppliers == 1 )			
            <!--<li {{ MSLST_Common::activeURI('suppliers*', ['suppliers*']) }}>
                <a href="/suppliers">Suppliers</a>
            </li>-->
			@endif
			@if(Auth::User()->access_sitemasters == 1)
			 <li {{ MSLST_Common::activeURI('sitemaster*', ['sitemaster*']) }}>
                @if(Auth::User()->access_p_r && Auth::User()->site_user_level == 'csm')
                    <a href="#" class="dropdown-toggle sitemaster-menu-item" data-toggle="dropdown" id="sitemaster-menu">Site Master <span class="fa fa-angle-down"></span></a>
                    <ul class="dropdown-menu" role="menu" aria-labelledby="sitemaster-menu" id="sitemaster-drop">
                        <li>
                            <a   href="/sitemaster">Site</a>
                        </li>
                        <li>
                            <a  data-toggle="modal" data-target="#inspect_model">Documents</a>
                        </li> 
                    </ul>
                @else
                     <a href="/sitemaster">Site Master</a>
                @endif
            </li>
			@endif
           
        </ul>
        <!-- /#side-menu -->
    </div>
    <!-- /.sidebar-collapse -->
</nav>
<!-- /.navbar-static-side -->


<div class="modal inmodal" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content animated bounceInRight">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <i class="fa fa-file-o modal-icon"></i>
            <h4 class="modal-title">User Manual Document</h4>
         </div>
         <div class="modal-body">
            <div id="nestable2" class="dd">
               <ol class="dd-list">
                  <li data-id="4" class="dd-item dd-collapsed">
                     <div class="dd-handle">
                        <span class="label label-danger"><i class="fa fa-file-pdf-o"></i></span>  {{ HTML::decode(HTML::link('/UserManual/UserManual_User.pdf', ' UserManual For User', [ 'target' => '_blank'] )) }}
                     </div>
                  </li>
                  @if(Auth::User()->site_user_level == 'csm')
                  <li data-id="5" class="dd-item dd-collapsed">
                     <div class="dd-handle">
                        <span class="label label-success"><i class="fa fa-file-excel-o"></i></span> {{ HTML::decode(HTML::link('/UserManual/SCS Inspection Guide FY17.xlsx', ' Inspection Guide', [ 'target' => '_blank'] )) }} 
                     </div>
                  </li>
                  @endif
               </ol>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
         </div>
      </div>
   </div>
</div>




<div class="modal inmodal" id="inspect_model" tabindex="-1" role="dialog" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content animated bounceInRight">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <i class="fa fa-file-o modal-icon"></i>
            <h4 class="modal-title">SCS Inspection Document</h4>
         </div>
         <div class="modal-body">
            <div id="nestable2" class="dd">
               <ol class="dd-list">
                  <li data-id="5" class="dd-item dd-collapsed">
                     <div class="dd-handle">
                        <span class="label label-success"><i class="fa fa-file-excel-o"></i></span> {{ HTML::decode(HTML::link('/UserManual/SCS Inspection Guide FY17.xlsx', ' Inspection Guide', [ 'target' => '_blank'] )) }} 
                     </div>
                  </li>
               </ol>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
         </div>
      </div>
   </div>
</div>
