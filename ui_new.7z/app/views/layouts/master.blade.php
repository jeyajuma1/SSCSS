<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv='Content-Type' content='text/html; charset=utf-8'/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Microsoft Supply Chain Security Solutions</title>
	{{ HTML::style('css/style.min.css') }}
   
    <script type='text/javascript' src="/js/ie/modernizr.min.js"></script>
    <script type='text/javascript' src="/js/ie/css3-mediaqueries.js"></script> 

    <!-- For IE8 -->
    <!--[if lt IE 10]>
      <script src="/js/ie/html5shiv.min.js"></script>
      <script src="/js/ie/respond.min.js"></script>
    <![endif]-->
</head>
<body class="{{ MSLST_Common::pageClasses() }} top-navigation"   @if(!Auth::check()) id="loginBody" @endif>
       
    <div id="wrapper">
       @if(Auth::check())
        <div id="page-wrapper" class="gray-bg">
        @endif
        @include('layouts.header')

        @if(Auth::check() && Route::getCurrentRoute()->getUri() != 'terms')

            @if(Auth::user()->isAdmin())

                @include('layouts.menu-admin')

            @elseif(Auth::user()->isSupervisor())

                @include('layouts.menu-supervisor')

            @else

                @include('layouts.menu-user')
                
            @endif
        
        @endif

       @if(Session::get('settings_site_alert_option') == 1)
            <nav class='marquebar alert alert-info'> <marquee>{{Session::get('settings_site_alert_message')}} </marquee></nav>
       @endif

        @yield('content')

        @if(Auth::check()) </div> @endif
    </div>
    <!-- /#wrapper -->

    @include('layouts.footer')

    
    {{ HTML::script('js/scripts.min.js') }}

 
   

</body>
</html>