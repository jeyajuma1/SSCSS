<div class="row border-bottom white-bg">
            <nav class="navbar navbar-static-top" role="navigation">
                <div class="navbar-header">
                    {{ HTML::decode(HTML::link('/', '<img class="mslogo" src="/images/brandmark.png" />', ['class'=>'navbar-brand'])) }}

                </div>
               
                    <ul class="nav navbar-nav">
                        <li><h4 style="font-size: 20px; padding: 7px 10px;">Supply
                                Chain Security Solutions</h4></li>
                    </ul>
                @if(Auth::check() && Route::getCurrentRoute()->getUri() != 'terms')
                    <ul class="nav navbar-top-links navbar-right">
                            <li>
                                    <span class="m-r-sm text-muted welcome-message">Welcome {{Auth::user()->name}} ({{Auth::user()->lsp->name}}, {{ucfirst(Auth::user()->role)}})</span>
                            </li>
                            <li>
                                {{ HTML::decode(link_to_route('profile.edit', '<i class="fa fa-user"></i> My Profile', [Auth::user()->id])) }}
                             </li>
                            <li>
                                {{ HTML::decode(HTML::link('logout', '<i class="fa fa-sign-out"></i> Logout')) }}
                            </li>
                    </ul>
                @endif
            </nav>
</div>
 




<!--
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
     
    

    @if(Auth::check() && Route::getCurrentRoute()->getUri() != 'terms')
    <ul class="nav navbar-top-links navbar-right pull-right">
         
        <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <i class="fa fa-user fa-fw"></i> Welcome {{Auth::user()->name}} ({{Auth::user()->lsp->name}}, {{ucfirst(Auth::user()->role)}}) &nbsp; <i class="fa fa-caret-down"></i>
            </a>
            <ul class="dropdown-menu dropdown-user">

                <li>
                    {{ HTML::decode(link_to_route('profile.edit', '<i class="fa fa-user fa-fw"></i> My Profile', [Auth::user()->id])) }}
                </li>
                <li class="divider"></li>
                <li>
                    {{ HTML::decode(HTML::link('logout', '<i class="fa fa-sign-out fa-fw"></i> Logout')) }}
                </li>
            </ul>
          
        </li> 
    </ul> 
    @endif

</nav>  -->