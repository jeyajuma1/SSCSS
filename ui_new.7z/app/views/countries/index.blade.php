@extends('layouts.master') @section('content')
<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
			<h2 class="page-header">
				Countries @if(Auth::User()->isAdmin())
				<div class="btn-group pull-right incident-btns">
					{{ Form::button('<i class="fa fa-plus "></i> Add New Country',
					['type' => 'button', 'class' => 'btn btn-primary', 'href' =>
					route('countries.create')]) }}
				</div>
				@endif
			</h2>
		</div>
		<!-- /.col-lg-12 -->
	</div>

	<!-- /.row -->

	@if(Session::has('success'))
	<div id="form-success" class="alert alert-success" role="alert">
		<span> {{ trans(Session::get('success')) }} </span>
	</div>
	<!-- end form-success -->
	@endif






	<div class="ibox float-e-margins animated flipInX">
		<div class="ibox-title">
			<h5>
				<i class="fa fa-table" aria-hidden="true"></i> Countries
			</h5>
			<div class="ibox-tools"></div>
		</div>
		<div class="ibox-content">
			<div class="row">
				<div class="col-lg-12">
					<div class="panel panel-default sitemasters-panel">
						<div class="panel-body">
							<table class="table table-hover table-striped"
								id="countries-list">
								<thead>
									<th>Name</th>
									<th>Region</th>
									<th></th>
								</thead>
								<tbody>
									@foreach($countries as $country)
									<tr>
										<td>{{ $country->name }}</td>
										<td>@if(isset($country->region->name)){{
											$country->region->name }} @else &nbsp; @endif</td>
										<td class="action-buttons" nowrap>{{ Form::open(['route' =>
											['countries.edit', $country->id], 'method' => 'get']) }} {{
											Form::button('Edit', ['type' => 'submit', 'class' => 'btn
											btn-primary btn-xs']) }} {{ Form::close() }} {{
											Form::open(['route' => ['countries.destroy', $country->id],
											'method' => 'delete']) }} {{ Form::button('Remove', ['type'
											=> 'submit', 'class' => 'btn btn-danger btn-xs
											country-delete-button']) }} {{ Form::close() }}</td>
									</tr>
									@endforeach
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>



</div>

<!-- /#page-wrapper -->
@stop
