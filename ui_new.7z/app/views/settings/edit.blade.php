@extends('layouts.master')

@section('content')
<div id="page-wrapper">
   <div class="row">
		<div class="col-lg-12">
			<h2 class="page-header">Settings</h2>
		</div>
		<!-- /.col-lg-12 -->
	</div>
    <!-- /.row -->    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                
                {{ Form::open(['action' => 'SettingsController@putSettings', 'method' => 'put', 'autocomplete' => 'off', 'class' => 'form-horizontal', 'role' => 'form', 'id' => 'settings-form']) }}
                    <div class="panel-body">

                        @if(Session::has('success'))
                        <div id="form-success" class="alert alert-success" role="alert">
                          <span>
                            {{ Session::get('success') }}
                          </span>
                        </div>
                        <!-- end form-success -->
                        @endif

                        @if($errors->all())
                        <div id="form-errors" class="alert alert-danger" role="alert">
                          <ul>
                            @foreach($errors->all() as $error)
                              <li>{{ $error }}</li>
                            @endforeach
                          </ul>
                        </div>
                        <!-- end form-errors -->
                        @endif

                        <ul class="nav nav-tabs">
                          <li class="active"><a href="#site" data-toggle="tab">Site Settings</a></li>
                          <li><a href="#account" data-toggle="tab">Account Email Settings</a></li>
                          <li><a href="#audit" data-toggle="tab">Audit Email Settings</a></li>
                          <li><a href="#incident" data-toggle="tab">Incident Email Settings</a></li>
                          <li><a href="#factoryincident" data-toggle="tab">Factory Incident Email Settings</a></li>
                          <li><a href="#site_inspection" data-toggle="tab">Site Inspection Email Settings</a></li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane active" id="site">                                
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::SITE_EMAIL, 'Site Email', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    {{ Form::email(MSLST_Email::SITE_EMAIL, $settings->site_email, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::SITE_EMAIL_SENDER, 'Site Email Sender', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    {{ Form::text(MSLST_Email::SITE_EMAIL_SENDER, $settings->site_email_sender, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::SITE_ASK_AGREE_TNC, 'Ask Agree to TOS', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        <label class="control-label">
                                    		{{ Form::checkbox(MSLST_Email::SITE_ASK_AGREE_TNC, 1, $settings->site_ask_agree_tnc) }}
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::SITE_ALERT_OPTION, 'Site Alert Option', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        <label class="control-label">
                                            {{ Form::checkbox(MSLST_Email::SITE_ALERT_OPTION,1,$settings->site_alert_option) }}
                                        </label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::SITE_ALERT_MESSAGE, 'Site Alert Message', ['class' => 'col-sm-3 control-label required']) }}
                                     <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::SITE_ALERT_MESSAGE, $settings->site_alert_message, ['class' => 'fosite_alert_optionrm-control']) }}
                                        <div class="description">&nbsp;</code></div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="account">
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::ACCOUNT_EMAIL_SUBJECT_USER_CREATE, 'New Account Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::text(MSLST_Email::ACCOUNT_EMAIL_SUBJECT_USER_CREATE, $settings->account_email_subject_user_create, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::ACCOUNT_EMAIL_BODY_USER_CREATE, 'New Account Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::textarea(MSLST_Email::ACCOUNT_EMAIL_BODY_USER_CREATE, $settings->account_email_body_user_create, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%reset-url%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::ACCOUNT_EMAIL_SUBJECT_PASSWORD_RESET, 'Password Reset Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::text(MSLST_Email::ACCOUNT_EMAIL_SUBJECT_PASSWORD_RESET, $settings->account_email_subject_password_reset, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::ACCOUNT_EMAIL_BODY_PASSWORD_RESET, 'Password Reset Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::textarea(MSLST_Email::ACCOUNT_EMAIL_BODY_PASSWORD_RESET, $settings->account_email_body_password_reset, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%reset-url%, %expiration%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::NEW_USER_ACCESS_REQUEST_EMAIL_SUBJECT, 'New User Access Request Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::text(MSLST_Email::NEW_USER_ACCESS_REQUEST_EMAIL_SUBJECT, $settings->new_user_access_request_email_subject, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::NEW_USER_ACCESS_REQUEST_EMAIL_SUBJECT_BODY, 'New User Access Request Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::NEW_USER_ACCESS_REQUEST_EMAIL_SUBJECT_BODY, $settings->new_user_access_request_email_body, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%username%, %company_name%, %address%, %country%, %city%, %email%, %microsoft_contact%, %microsoft_contact_email%, %supplier_type%</code></div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="audit">
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::AUDIT_EMAIL_SUBJECT_LOCATION_CREATE, 'Location Create Notification Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::text(MSLST_Email::AUDIT_EMAIL_SUBJECT_LOCATION_CREATE, $settings->audit_email_subject_location_create, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::AUDIT_EMAIL_SUBJECT_LOCATION_EDIT, 'Location Edit Notification Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::text(MSLST_Email::AUDIT_EMAIL_SUBJECT_LOCATION_EDIT, $settings->audit_email_subject_location_edit, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::AUDIT_EMAIL_BODY_LOCATION, 'Location Notification Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                     <div class="col-sm-6">
                                    	{{ Form::textarea(MSLST_Email::AUDIT_EMAIL_BODY_LOCATION, $settings->audit_email_body_location, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%name%, %action%, %site_name%, %country%, %address%, %lsp_name%, %timestamp%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::AUDIT_EMAIL_SUBJECT_ROUTE_CREATE, 'Route Create Notification Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::text(MSLST_Email::AUDIT_EMAIL_SUBJECT_ROUTE_CREATE, $settings->audit_email_subject_route_create, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::AUDIT_EMAIL_SUBJECT_ROUTE_EDIT, 'Route Edit Notification Email Subject', ['class' => 'col-sm-3 control-label required']) }}                                    
                                    <div class="col-sm-6">
                                    	{{ Form::text(MSLST_Email::AUDIT_EMAIL_SUBJECT_ROUTE_EDIT, $settings->audit_email_subject_route_edit, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::AUDIT_EMAIL_BODY_ROUTE, 'Route Notification Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::textarea(MSLST_Email::AUDIT_EMAIL_BODY_ROUTE, $settings->audit_email_body_route, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%name%, %action%, %site_name_start%, %country_start%, %address_start%, %site_name_end%, %country_end%, %address_end%, %lsp_name%, %timestamp%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::AUDIT_EMAIL_SUBJECT_LANE_CREATE, 'Lane Create Notification Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::text(MSLST_Email::AUDIT_EMAIL_SUBJECT_LANE_CREATE, $settings->audit_email_subject_lane_create, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::AUDIT_EMAIL_SUBJECT_LANE_EDIT, 'Lane Edit Notification Email Subject', ['class' => 'col-sm-3 control-label required']) }}                                    
                                    <div class="col-sm-6">
                                    	{{ Form::text(MSLST_Email::AUDIT_EMAIL_SUBJECT_LANE_EDIT, $settings->audit_email_subject_lane_edit, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::AUDIT_EMAIL_BODY_LANE, 'Lane Notification Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::textarea(MSLST_Email::AUDIT_EMAIL_BODY_LANE, $settings->audit_email_body_lane, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%name%, %action%, %site_name_start%, %country_start%, %address_start%, %site_name_end%, %country_end%, %address_end%, %lsp_name%, %timestamp%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::AUDIT_EMAIL_SUBJECT_REVIEW_REQUEST, 'Audit Review Request Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::text(MSLST_Email::AUDIT_EMAIL_SUBJECT_REVIEW_REQUEST, $settings->audit_email_subject_review_request, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::AUDIT_EMAIL_BODY_REVIEW_REQUEST, 'Audit Review Request Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::AUDIT_EMAIL_BODY_REVIEW_REQUEST, $settings->audit_email_body_review_request, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%name%, %audit-id%, %audit-url%, %reviewcomment%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::AUDIT_EMAIL_SUBJECT_REVIEW_CLEARED, 'Audit Review Cleared Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::text(MSLST_Email::AUDIT_EMAIL_SUBJECT_REVIEW_CLEARED, $settings->audit_email_subject_review_cleared, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::AUDIT_EMAIL_BODY_REVIEW_CLEARED, 'Audit Review Cleared Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::AUDIT_EMAIL_BODY_REVIEW_CLEARED, $settings->audit_email_body_review_cleared, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%name%, %audit-id%, %audit-url%</code></div>
                                    </div>
                                </div>
							</div>
                            <div class="tab-pane fade" id="incident">
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::INCIDENT_EMAIL_SUBJECT_CREATE, 'New Incident Notification Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::text(MSLST_Email::INCIDENT_EMAIL_SUBJECT_CREATE, $settings->incident_email_subject_create, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                	{{ Form::label(MSLST_Email::INCIDENT_EMAIL_BODY_CREATE, 'New Incident Notification Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::INCIDENT_EMAIL_BODY_CREATE, $settings->incident_email_body_create, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code> %creatorname%, %creatorcompany%, %category%, %description%, %incidentdate%, %city%, %country%, %address%, %facility%, %customer%, %productquantity%, %pltscrtsmissing%, %totalvalue%, %firstfindings%, %status%, %incidentid%,%incid%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::INCIDENT_EMAIL_SUBJECT_STATUS_CHANGE, 'Incident Status Change Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::text(MSLST_Email::INCIDENT_EMAIL_SUBJECT_STATUS_CHANGE, $settings->incident_email_subject_status_change, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::INCIDENT_EMAIL_BODY_STATUS_CHANGE, 'Incident Status Change Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::INCIDENT_EMAIL_BODY_STATUS_CHANGE, $settings->incident_email_body_status_change, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code> %creatorname%, %creatorcompany%, %category%, %description%, %incidentdate%, %city%, %country%, %address%, %facility%, %customer%, %productquantity%, %pltscrtsmissing%, %totalvalue%, %firstfindings%, %status%, %incidentid%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::INCIDENT_EMAIL_SUBJECT_EDIT, 'Incident Edit Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::text(MSLST_Email::INCIDENT_EMAIL_SUBJECT_EDIT, $settings->incident_email_subject_edit, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::INCIDENT_EMAIL_BODY_EDIT, 'Incident Edit Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::INCIDENT_EMAIL_BODY_EDIT, $settings->incident_email_body_edit, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code> %creatorname%, %creatorcompany%, %category%, %description%, %incidentdate%, %city%, %country%, %address%, %facility%, %customer%, %productquantity%, %pltscrtsmissing%, %totalvalue%, %firstfindings%, %status%, %incidentid%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::INCIDENT_EMAIL_SUBJECT_REVIEW_REQUEST, 'Incident Review Request Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::text(MSLST_Email::INCIDENT_EMAIL_SUBJECT_REVIEW_REQUEST, $settings->incident_email_subject_review_request, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::INCIDENT_EMAIL_BODY_REVIEW_REQUEST, 'Incident Review Request Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::INCIDENT_EMAIL_BODY_REVIEW_REQUEST, $settings->incident_email_body_review_request, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%name%, %incident-id%, %incident-url%, %reviewcomment%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::INCIDENT_EMAIL_SUBJECT_REVIEW_CLEARED, 'Incident Review Cleared Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::text(MSLST_Email::INCIDENT_EMAIL_SUBJECT_REVIEW_CLEARED, $settings->incident_email_subject_review_cleared, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::INCIDENT_EMAIL_BODY_REVIEW_CLEARED, 'Incident Review Cleared Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::INCIDENT_EMAIL_BODY_REVIEW_CLEARED, $settings->incident_email_body_review_cleared, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%name%, %incident-id%, %incident-url%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::INCIDENT_EMAIL_SUBJECT_REMINDER, 'Incident Reminder Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::text(MSLST_Email::INCIDENT_EMAIL_SUBJECT_REMINDER, $settings->incident_email_subject_reminder, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::INCIDENT_EMAIL_BODY_REMINDER, 'Incident Reminder Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::INCIDENT_EMAIL_BODY_REMINDER, $settings->incident_email_body_reminder, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%name%, %incident-url%, %incident-id%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::MONTHLY_INCIDENT_REPORT_EMAIL_SUBJECT, 'Monthly Incident Report Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::text(MSLST_Email::MONTHLY_INCIDENT_REPORT_EMAIL_SUBJECT, $settings->monthly_incident_report_email_subject, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::MONTHLY_INCIDENT_REPORT_EMAIL_BODY, 'Monthly Incident Report Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::MONTHLY_INCIDENT_REPORT_EMAIL_BODY, $settings->monthly_incident_report_email_body, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code>%name%, %incident-url%, %incident-id%, %month%, %created_at%, %category%, %lsp_name%, %loss_value%, %country_name%, %region_name%, %status%, %created_by% </code></div>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="factoryincident">
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::FACTORY_INCIDENT_EMAIL_SUBJECT_CREATE, 'New Factory Incident Notification Email Subject', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::text(MSLST_Email::FACTORY_INCIDENT_EMAIL_SUBJECT_CREATE, $settings->factory_incident_email_subject_create, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::FACTORY_INCIDENT_EMAIL_BODY_CREATE, 'New FACTORY Incident Notification Email Body', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::FACTORY_INCIDENT_EMAIL_BODY_CREATE, $settings->factory_incident_email_body_create, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code> %creatorname%, %creatorcompany%, %category%, %description%, %incidentdate%, %city%, %country%, %address%, %facility%, %customer%, %productquantity%, %pltscrtsmissing%, %totalvalue%, %firstfindings%, %status%, %incidentid%,%incid%</code></div>
                                    </div>
                                </div>
                            </div>
                             <div class="tab-pane fade" id="site_inspection">
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::SITE_INSPECTION_VAM_EMAIL_SUBJECT_CREATE, 'Inspection VAM Email Subject Create', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::text(MSLST_Email::SITE_INSPECTION_VAM_EMAIL_SUBJECT_CREATE, $settings->site_inspection_vam_subject_create, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::SITE_INSPECTION_VAM_EMAIL_BODY_CREATE, 'Inspection VAM Email Body Create', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::SITE_INSPECTION_VAM_EMAIL_BODY_CREATE, $settings->site_inspection_vam_body_create, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code> %site_id%,, %ca_id%, %inspector_name%, %inspector_comments%, %pr_reference%, %pr_version%, %pr_text%, %severity%, %initial_due_date%, %supplier_request_closer%, %supplier_comments%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::SITE_INSPECTION_CSM_EMAIL_SUBJECT_CREATE, 'Inspection CSM Email Subject Create', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::text(MSLST_Email::SITE_INSPECTION_CSM_EMAIL_SUBJECT_CREATE, $settings->site_inspection_csm_subject_create, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::SITE_INSPECTION_CSM_EMAIL_BODY_CREATE, 'Inspection CSM Email Body Create', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::SITE_INSPECTION_CSM_EMAIL_BODY_CREATE, $settings->site_inspection_csm_body_create, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code> %site_id%,, %ca_id%, %inspector_name%, %inspector_comments%, %pr_reference%, %pr_version%, %pr_text%, %severity%, %initial_due_date%, %supplier_request_closer%, %supplier_comments%</code></div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::SITE_INSPECTION_VAM_EMAIL_SUBJECT_OPEN_CA_WEEKLY_REMAINDER, 'Email Subject for Open CA Weekly Remainder', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::text(MSLST_Email::SITE_INSPECTION_VAM_EMAIL_SUBJECT_OPEN_CA_WEEKLY_REMAINDER, $settings->site_inspection_vam_subject_open_ca_weekly_remainder, ['class' => 'form-control']) }}
                                    </div>
                                </div>
                                <div class="form-group">
                                    {{ Form::label(MSLST_Email::SITE_INSPECTION_VAM_EMAIL_BODY_OPEN_CA_WEEKLY_REMAINDER, 'Email Body for Open CA Weekly Remainder', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                        {{ Form::textarea(MSLST_Email::SITE_INSPECTION_VAM_EMAIL_BODY_OPEN_CA_WEEKLY_REMAINDER, $settings->site_inspection_vam_body_open_ca_weekly_remainder, ['class' => 'form-control']) }}
                                        <div class="description">Available tokens: <code> %site_id%,, %ca_id%, %inspector_name%, %inspector_comments%, %pr_reference%, %pr_version%, %pr_text%, %severity%, %initial_due_date%, %supplier_request_closer%, %supplier_comments%</code></div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="panel-footer">
                        {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default','id' => 'setting_cancel']) }}
                    </div>
                {{ Form::close() }}
            </div>
            <!-- /.col-lg-12 -->
        </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->
@stop