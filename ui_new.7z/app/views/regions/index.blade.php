@extends('layouts.master')

@section('content')
 
<div class="wrapper wrapper-content animated fadeInRight">
    <div class="row">
                        <div class="col-lg-12">
                            <div class="ibox float-e-margins">
                                <div class="ibox-title">
                                    <h5>
                                        <i class="fa fa-map-marker" aria-hidden="true"></i> Regions
                                    </h5>
                                    <div class="ibox-tools">
                                        <a class="collapse-link"> <i class="fa fa-chevron-up"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="ibox-content">
                                    <table class="table">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th colspan="3"></th>
                                            </tr>
                                        </thead>
                                        <tbody> 
                                            @foreach($regions as $region)
                                                <tr>
                                                    <td>{{ $region->name }}</td>
                                                    <td class="action-buttons" nowrap>
                                                    {{ Form::open(['route' => ['regions.edit', $region->id], 'method' => 'get']) }}
                                                        {{ Form::button('Edit', ['type' => 'submit', 'class' => 'btn btn-primary btn-xs']) }}
                                                    {{ Form::close() }}
                                                    </td>
                                                    <td>
                                                    {{ Form::open(['route' => ['regions.destroy', $region->id], 'method' => 'delete']) }}
                                                        {{ Form::button('Remove', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs region-delete-button']) }}
                                                    {{ Form::close() }}
                                                    </td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
    </div>
</div>
<!-- /#page-wrapper -->
@stop