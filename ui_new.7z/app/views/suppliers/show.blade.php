@extends('layouts.master')
@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
            View Supplier
            <div class="pull-right">
                <div class="btn-group incident-btns">
                    {{ Form::open(['route' => 'suppliers.index', 'method' => 'get']) }}
                        {{ Form::button('Go Back', ['type' => 'submit', 'class' => 'btn btn-primary', 'onclick' => 'javascript:history.back()']) }}
                    {{ Form::close() }}
                    {{form::hidden('supplier_user_id',$supplier->user_id)}}
                     {{form::hidden('supplier_user_name',$supplier->user->name)}}
                    {{form::hidden('login_user_id',\Auth::user()->id)}}
                    {{form::hidden('supplier_id',$supplier->id)}}

                    @if(\Auth::user()->access_leak_prevention)
                        @if($supplier->user_id == Auth::User()->id && count($leak_risk_analysis)>0)
                            {{ Form::open(['route' => ['suppliers.self',$supplier->id], 'method' => 'get']) }}
                                {{ Form::button('Self-Assessment', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::close() }}
                        @endif

                        @if(Auth::user()->isManager() && count($leak_risk_analysis)>0)
                            {{ Form::open(['route' => ['suppliers.onsite',$supplier->id], 'method' => 'get']) }}
                                {{ Form::button('Onsite-Assessment', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::close() }}
                        @endif
                    @endif
                    
                    @if (\Auth::User()->isAdmin() || \Auth::User()->isSupervisor() || \Auth::User()->isManager())
                       @if($supplier->status == 'active')
                        {{ Form::open(['route' => ['suppliers.status', $supplier->id,'inactive'] , 'method'=>'patch']) }}
                            {{ Form::button('Set Inactive',['type' => 'submit' , 'class' =>'btn btn-primary location-inactive-button' ]) }}
                        {{ Form::close() }}
                       @elseif($supplier->status == 'inactive')
                        {{ Form::open(['route' => ['suppliers.status', $supplier->id,'active'] , 'method'=>'patch']) }}
                            {{ Form::button('Set Active',['type' => 'submit' , 'class' =>'btn btn-primary location-active-button' ]) }}
                        {{ Form::close() }}
                       @endif
                    @endif
                </div>
            </div>
			     </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
  	@if(Session::has('success'))
      <div id="form-success" class="alert alert-success" role="alert">
          <span>
              {{ trans(Session::get('success')) }}
          </span>
      </div>
      <!-- end form-success -->
    @endif
   <div class="panel-body">
      <ul class="nav nav-tabs" style="margin-left: 15px;margin-right: 15px;">
        <li class="active"><a href="#a" data-toggle="tab">Basic</a></li>
          @if(\Auth::user()->access_leak_prevention)
            <li><a href="#b" data-toggle="tab">Leak Prevention</a></li>
            @if(count($leak_prevention)>0)
             @if($supplier->supplier_handle)
            <li><a class="fa fa-question-circle" href="#c" data-toggle="tab"> Question & Answers</a></li>
             @endif
            @endif
          @endif

      </ul>

     <div class="tab-content suppliers-form-tabs">
        <div class="tab-pane active" id="a">
          <div class="col-lg-7">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-info-circle"></i> Basic Information 
                  @if (\MSLST\Helpers\Common::canAccessEdit($supplier->id, 'supplier', null, $supplier))
                    <div class="pull-right">
                        <div class="btn-group">
                            <button type="button" class="btn btn-default btn-xs" href="{{ route('suppliers.edit', [$supplier->id]) }}">
                                Edit
                            </button>
                        </div>
                    </div>
                  @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="supplier-basic-table">
                            <tbody>
              
                               <tr data-id="{{ $supplier->id }}" style="vertical-align: top;">
                  <td>  
                    <b>Vendor Number</b><br/>
                    <p> @if(!empty($supplier->vendor_number)) <a  title="{{$supplier->vendor_number}}" data-toggle="tooltip"> {{str_limit($supplier->vendor_number,20) }}</a> @else  Not Specified @endif </p>
                  </td>
                  <td>  
                    <b>Region</b><br/>
                    <p> @if(!empty($supplier->region->name)) {{ $supplier->region->name }} @else  Not Specified @endif</p>
                  </td>
                  <td>
                    <b>Postal Address</b><br/>
                    <p>@if(!empty($supplier->address))<a  title="{{$supplier->address}}" data-toggle="tooltip"> {{str_limit($supplier->address,30)}}</a> @else  Not Specified @endif</p>
                  </td>
                                </tr>
                
                <tr data-id="{{ $supplier->id }}">
                  <td>
                                        <b>Supplier Name</b><br/>
                                        <p>@if(!empty($supplier->vendor_name)) <a  title="{{$supplier->vendor_name}}" data-toggle="tooltip">{{ str_limit($supplier->vendor_name,20) }}</a> @else  Not Specified @endif</p>
                                    </td>
                  
                                    <td>
                                        <b>Country</b><br/>
                                        <p>@if(!empty($supplier->country->name)){{$supplier->country->name }}@else  Not Specified @endif</p>
                                    </td>
                  <td>  
                    <b>Postal Code</b><br/>
                    <p>@if(!empty($supplier->postal_code))<a title="{{$supplier->postal_code}}" data-toggle="tooltip" >{{str_limit($supplier->postal_code,25)}}</a>@else  Not Specified @endif</p>
                  </td>
                  
                                </tr>
                
                <tr data-id="{{ $supplier->id }}">
                  <td>
                    <b>Site Name</b><br/>
                    <p>
                    @if(!empty($supplier->site_name))
                      <a title="{{$supplier->site_name}}" data-toggle="tooltip">{{str_limit($supplier->site_name,20) }}</a>
                    @else
                      Not Specified
                    @endif
                    </p>
                  </td>
                  <td>
                    <b>City</b><br/>
                    <p>@if(!empty($supplier->city)){{$supplier->city}}@else  Not Specified @endif</p>
                  </td>
                  
                  <td>
                                        <b>GPS Coordinate</b><br/>
                                        <p>@if(!empty($supplier->coordinates)) {{str_replace(',','<br>',$supplier->coordinates) }} @else  Not Specified @endif</p>
                                    </td>
                </tr>
                            </tbody>
                        </table>
                      <div id="supplier_map" class="detail-view-map span12">
                      </div>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-phone-square"></i> Contact Information
                    @if (\MSLST\Helpers\Common::canAccessEdit(null, 'supplier', null, $supplier))
                    <div class="pull-right">
                        <div class="btn-group">
                          <button type="button" class="btn btn-default btn-xs" href="{{ route('suppliers.edit', [$supplier->id, 2]) }}">
                                Edit
                            </button>
                        </div>
                    </div>
                    @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table">
                            <tbody>
                                <tr data-id="{{ $supplier->id }}">
                                      <td>
                                        <b>Telephone Number</b><br/>
                                        @if(!empty($supplier->contact_telephone_number))
                                        <p>{{$supplier->contact_telephone_number}}</p>
                                        @else 
                                          Not Specified
                                        @endif                  
                                      </td>           
                                      
                                      <td>
                                        <b>Email Address</b><br/>
                                        @if(!empty($supplier->contact_email_address))
                                        <p>{{$supplier->contact_email_address}}</p>
                                        @else 
                                          Not Specified
                                        @endif
                                      </td>
                                </tr>             
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
        </div>
        <!-- /.col-lg-6 -->

    <div class="col-lg-5">

            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table">
                            <tbody>
                                <tr>
                                    <td>
                                        <b>Created by</b>
                                        <p> <span>{{ $supplier->user->name }}</span></p>
                                    </td>
                                    <td>
                                        <b>Created On</b>
                                        <p><span>{{ $supplier->created_at->format('M d, Y h:i A') }}</span></p>
                                    </td>
                                    <td>
                                        <b>Supplier ID</b>
                                        <p><span>{{ $supplier->name }}</span></p>
                                    </td>
                                    <td>
                                        <b>Status</b>
                                        <p><span class="label @if($supplier->status == 'active') label-success @else label-danger @endif">
                                                {{ucfirst($supplier->status)}}
                                        </span></p>
                                    </td>
                                </tr>                             
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- /.panel-body -->
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-info-circle"></i> Supplier Information
                   @if (\MSLST\Helpers\Common::canAccessEdit(null, 'supplier', null, $supplier))
                    <div class="pull-right">
                        <div class="btn-group">
                            <button type="button" class="btn btn-default btn-xs" href="{{ route('suppliers.edit', [$supplier->id, 1]) }}">
                                Edit
                            </button>
                        </div>
                    </div>
                    @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table">
                            <tbody>
                                <tr>
                                  <td colspan="3">
                                    Does the supplier handle unannounced components/ products containing device ID (size, look, specifications, etc.)?
                                    <br/>
                                    <p>@if(!empty($supplier->supplier_handle)) 
                                        <span class="label label-success"> Yes </span>
                                       @else
                                        <span class="label label-danger"> No </span>
                                       @endif
                                    </p>
                                  </td>
                                </tr> 
                                <tr data-id="{{ $supplier->id }}">
                                              <td>
                                                  <b>Supplier Type</b><br/>
                                                  <p>@if(!empty($supplier->supplier_type)){{$supplier->supplier_type}}@else  Not Specified @endif</p>
                                              </td>
                                              <td>
                                                  <b>Supplier Role</b><br/>
                                                  <p>@if(!empty($supplier->supplier_role)){{$supplier->supplier_role}}@else  Not Specified @endif</p>
                                              </td>
                                              <td>
                                                  <b>Site Technology</b><br/>
                                                  <p>@if(!empty($supplier->site_technology))
                                                  {{$supplier->site_technology}}
                                                  @else
                                                  Not Specified
                                                  @endif
                                                  </p>
                                              </td>
                                </tr>
                                <tr data-id="{{ $supplier->id }}">
                                      <td>  
                                          <b>Relationship</b><br/>
                                          <p>
                                          @if(!empty($supplier->relationship))
                                          {{$supplier->relationship}}
                                          @else
                                          Not Specified
                                          @endif
                                          </p>
                                      </td>
                                      <td>  
                                          <b>Category</b><br/>
                                          <p>@if(!empty($supplier->category)){{$supplier->category}}@else  Not Specified @endif</p>
                                      </td>
                                      <td>
                                          <b>Tier</b><br/>
                                          <p>@if(!empty($supplier->tier||$supplier->tier==0)){{$supplier->tier}}@else  Not Specified @endif</p>
                                      </td>
                                </tr> 
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
 
            

              <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-history"></i> History Log
                </div>
                <div class="panel-body">
                    <div class="table-responsive" style="min-height:20px;max-height:280px;overflow-y:auto;">
                        <table class="table">
                            <tbody>
                              @if(count($supplier->supplier_log))
                                @foreach($supplier->supplier_log as $log)
                                  <tr>
                                    <td>
                                      @if($log->created_at != Null )
                                          {{ $log->created_at->format('M d, Y h:i A') }} - Created by {{ $log->user->name }}
                                      @elseif($log->updated_at != Null )
                                          {{ $log->updated_at->format('M d, Y h:i A') }} - Edited by {{ $log->user->name }}
                                      @elseif($log->requested_at != Null )
                                          {{  date('M d, Y h:i A',strtotime($log->requested_at))  }} - Review requested by {{ $log->user->name }}
                                      @elseif($log->cleared_at != Null )
                                          {{  date('M d, Y h:i A',strtotime($log->cleared_at))  }} - Review cleared by {{ $log->user->name }}
                                      @endif
                                    </td>
                                  </tr>
                                @endforeach
                              @else
                                <tr>
                                  <td>
                                    {{ $supplier->created_at->format('M d, Y h:i A') }} - Created by {{ $supplier->user->name }}
                                  </td>
                                </tr>
                              @endif
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
              </div>
    </div>
            <!-- /.col-lg-6 -->
        </div>
        <div class="tab-pane" id="b" >
          @if(\Auth::user()->access_leak_prevention)
           <!-- /.col-lg-12 -->
           <div class="col-lg-12">
              <div class="panel panel-default">
                          <div class="panel-heading">
                              <i class="fa fa-bar-chart-o fa-fw"></i>
                                Leak Prevention Activities
                                @if (\MSLST\Helpers\Common::canAccessEdit(null, 'supplier', null, $supplier))
                                  <div class="pull-right">
                                      <div class="btn-group">
                                          <button type="button" class="btn btn-default btn-xs" href="{{ route('suppliers.edit', [$supplier->id, 1]) }}">
                                              Edit
                                          </button>
                                      </div>
                                  </div>
                                @endif
                          </div>
                          <div class="panel-body">
                          <?php $role = Auth::User()->role;?>
                          @if(Auth::User()->isManager())
                            <?php $role = 'PM';?>
                          @endif
                            <input type="hidden" name="role"  value="{{$role}}">
                                @if($supplier->supplier_handle)
                                   <div class="col-lg-12">
                                     @if($supplier->user_id == Auth::User()->id)
                                      <div class="row">
                                           <div class="col-md-12">
                                                <div class="box box-primary">
                                                      <div class="box-header with-border">
                                                        <i class="fa fa-fw fa-list"></i>
                                                        <h3 class="box-title">Leak Risk Analysis</h3>

                                                        <div class="box-tools pull-right">
                                                            &nbsp;
                                                        </div>
                                                      </div>
                                                      <div class="box-body">
                                                            <div class="form-group">
                                                                  <div class="col-xs-12">
                                                                      <div class="row">
                                                                          <div class="col-xs-1 activity-cols">
                                                                            <h5>#</h5>
                                                                         </div>
                                                                         <div class="col-xs-3">
                                                                            <h5>Business Activity (what is done)</h5>
                                                                         </div>
                                                                         <div class="col-xs-2">
                                                                            <h5>Assets (What is handled)</h5>
                                                                         </div> 
                                                                      </div>
                                                                  </div>
                                                                   @if($leak_risk_analysis)
                                                                    <div class="col-xs-12" id="busines_activity">
                                                                     <?php $j=1 ?>
                                                                        @foreach($leak_risk_analysis as $ky=>$lk_pr) 
                                                                          @if(!empty($lk_pr->activity_id))
                                                                              <div class="row activty-row" id="activty-row{{$j}}" data-id="{{$lk_pr->id}}" >
                                                                                    <div class="col-sm-1 activity-cols">
                                                                                      <span class="form-control activty-count">{{$j}}</span>
                                                                                    </div>
                                                                                    <div class="col-lg-3">
                                                                                      <div class="form-group">
                                                                                        <?php $emptyval = ["" =>"Select Business Activity"]; $business_activities = $emptyval+$business_activities;  ?>
                                                                                        {{Form::select('activity'.$j,$business_activities,$lk_pr->activity_id,array('placeholder' => 'Select Business Activity','class'=>'form-control bus_activity_sel'.$lk_pr->id.' selectpicker'))}}
                                                                                      </div>
                                                                                    </div>
                                                                                    <div class="col-lg-3" id="asset_div{{$lk_pr->id}}">
                                                                                      <div class="form-group">
                                                                                          <select name="assets{{$j}}" id="bus_assests_sel{{$j}}" class ='form-control bus_assests_sel{{$lk_pr->id}} selectpicker' multiple="multiple" title=" Select Assets" >
                                                                                              <option data-hidden="true"></option>
                                                                                          </select>
                                                                                      </div>
                                                                                    </div>
                                                                                    <div class="col-lg-1">
                                                                                          <span class="glyphicon glyphicon-remove business_remove" id="business_remove{{$j}}"   alt="{{$j}}" aria-hidden="true"></span>
                                                                                    </div>
                                                                              </div>
                                                                              <?php $j=$j+1; ?>
                                                                          @endif
                                                                        @endforeach
                                                                       </div>
                                                                        <?php $busines_show= '1'; ?>
                                                                   @else
                                                                      <div class="col-xs-12" id="busines_activity">
                                                                           <div class="row activty-row" id="activty-row1">
                                                                                <div class="col-sm-1 activity-cols">
                                                                                  <span class="form-control activty-count">1</span>
                                                                                </div>
                                                                                <div class="col-lg-3">
                                                                                  <div class="form-group">
                                                                                  <?php $emptyval = ["" =>"Select Business Activity"]; $business_activities = $emptyval+$business_activities;  ?>
                                                                                        {{Form::select('activity1',$business_activities,'',array('placeholder' => 'Select Business Activity','class'=>'form-control bus_activity_sel selectpicker'))}}
                                                                                  </div>
                                                                                </div>
                                                                                <div class="col-lg-3">
                                                                                  <div class="form-group">
                                                                                     <select name="assets1" id="bus_assests_sel1" class ='form-control bus_assests_sel selectpicker' multiple="multiple" title=" Select Assets" >
                                                                                          <option data-hidden="true"></option>
                                                                                      </select>
                                                                                  </div>
                                                                                </div> 
                                                                                <div class="col-lg-1">
                                                                                      <span class="glyphicon glyphicon-remove business_remove" id="business_remove1" alt="1" aria-hidden="true"></span>
                                                                                </div>
                                                                           </div>
                                                                      </div>
                                                                       <?php $busines_show= '2'; ?>
                                                                        <div class="col-xs-12 leak_risk_activity_assets">
                                                                            <div class="alert alert-warning">
                                                                                 This supplier does not have business activities and assets
                                                                            </div>
                                                                        </div>
                                                                   @endif

                                                                   <input type="hidden" value="{{$busines_show}}" name="busines_show" >
                                                            </div>
                                                      </div>
                                                      <div class="box-footer clearfix" style="display: block;">
                                                           <button id="addassests" class="btn btn-primary " type="button">Add Activity & Assets</button>
                                                           <button id="save_leak_analysis" class="btn btn-success " type="button">Save</button>
                                                      </div>
                                                 </div>
                                             </div>
                                      </div>        
                                     @endif

                                      <div class="row">
                                           <div class="col-md-12">
                                                <div class="box box-primary">
                                                      <div class="box-header with-border">
                                                       <i class="fa fa-fw fa-table"></i>
                                                       <h3 class="box-title">Leak prevention action plan</h3>

                                                        <div class="box-tools pull-right">
                                                           <span class=""> <i class="fa fa-th-list text-grey"></i> Predefined Risk</span>&nbsp;
                                                            <span class=""> <i class="fa fa-th-list text-light-blue"></i> Manual Risk</span>&nbsp;
                                                            <span class=""> <i class="fa fa-th-list  text-yellow"></i> Incident</span> &nbsp;
                                                        </div>
                                                      </div>
                                                      <div class="box-body">
                                                            <div class="col-lg-12">
                                                              @if(!$leak_prevention->isEmpty())
                                                                  <div class="table-responsive">
                                                                         <table class="table table-hover table-striped" id="leak_risk_analysis_tab">
                                                                              <thead id="suppliers-head">
                                                                                <th>Risk</th>
                                                                                <th>Action</th>
                                                                                <th>Status</th>
                                                                                <th>Date</th>
                                                                                <th>File</th>
                                                                                <th>Verified</th>
                                                                                <th>Date</th>
                                                                                <th>Verified By</th>
                                                                                @if($supplier->user_id == Auth::User()->id || Auth::User()->isManager()) <th>&nbsp;</th> @endif
                                                                              </thead>
                                                                               <tbody>
                                                                                  @foreach($leak_prevention as $lk_pr)
                                                                                  <?php  
                                                                                      $tdclass = "";
                                                                                      if(!empty($lk_pr->leak_id))   $tdclass = "well well-sm";
                                                                                      else if(!empty(($lk_pr->inc_id)))  $tdclass = "alert alert-warning";
                                                                                      else  $tdclass = "alert alert-info";
                                                                                  ?>
                                                                                  <tr class="{{$tdclass}}">
                                                                                      <td class="{{$tdclass}}">
                                                                                          <a data-toggle="tooltip" title="{{$lk_pr->risk}}">{{str_limit(ucfirst($lk_pr->risk),15)}}</a>
                                                                                      </td>
                                                                                      @if(!empty($lk_pr->leak_id))  
                                                                                      <td class="{{$tdclass}}">
                                                                                        <a data-toggle="tooltip" title="{{$lk_pr->action_description}}">{{str_limit(ucfirst(trim($lk_pr->action_name)),15)}}</a>
                                                                                      </td>
                                                                                      @else
                                                                                        <td class="{{$tdclass}}">
                                                                                           <a data-toggle="tooltip" title="{{$lk_pr->action_description}}">{{str_limit(ucfirst(trim($lk_pr->action_name)),15)}}</a>
                                                                                        </td>
                                                                                      @endif 
                                                                                      <td class="alert  @if($lk_pr->status == 'Completed') alert-success @elseif($lk_pr->status == 'Not Started') alert-danger @elseif($lk_pr->status == 'In Progress') alert-warning @endif">
                                                                                          @if(!empty($lk_pr->status)){{$lk_pr->status}}@else - @endif
                                                                                      </td>
                                                                                      <td class="{{$tdclass}}">@if(!empty($lk_pr->status_date)){{$lk_pr->status_date->format('d-m-Y')}}@else - @endif</td>
                                                                                      <td class="{{$tdclass}}">
                                                                                      @if(!empty($lk_pr->file_name))
                                                                                         <a data-toggle="tooltip" title="{{$lk_pr->file_description}}">{{str_limit(ucfirst(trim($lk_pr->file_description)),15)}}</a>
                                                                                      @else - @endif
                                                                                      </td>
                                                                                      <td class="{{$tdclass}}"> 
                                                                                          @if($lk_pr->verified_status == "yes") 
                                                                                           <span class="label label-success">Yes</span>
                                                                                          @elseif($lk_pr->verified_status == 'no') 
                                                                                           <span class="label label-danger">No</span>
                                                                                          @else  
                                                                                            <span class="label label-primary">N/A</span>
                                                                                          @endif 
                                                                                      </td>
                                                                                      <td class="{{$tdclass}}">@if(!empty($lk_pr->verified_date)){{$lk_pr->verified_date->format('d-m-Y')}}@else - @endif</td>
                                                                                      <td class="{{$tdclass}}">@if(!empty($lk_pr->verified_by)){{$lk_pr->user->name}}@else - @endif </td>
                                                                                      @if($supplier->user_id == Auth::User()->id || Auth::User()->isManager())
                                                                                      <td class="{{$tdclass}}" data-id="{{$lk_pr->id}}" data-type="@if(!empty($lk_pr->leak_id) || !empty($lk_pr->inc_id)) auto @else manual @endif" >
                                                                                                          <i class="fa fa-edit risk_mitigation_manual text-navy" aria-hidden="true" title="Edit"></i>
                                                                                                          @if((empty($lk_pr->leak_id) && empty($lk_pr->inc_id)) &&  ($supplier->user_id == Auth::User()->id))
                                                                                                          <i class="fa fa-trash-o text-navy manual_risk_delete" aria-hidden="true" title='Delete'></i>
                                                                                                          @endif
                                                                                      </td>
                                                                                      @endif  
                                                                                  </tr>
                                                                                  @endforeach                                                            
                                                                              </tbody>
                                                                           </table>
                                                                  </div>
                                                              @else
                                                                  <div class="alert alert-warning">
                                                                      This supplier does not have any leak prevention actions.
                                                                  </div>
                                                              @endif
                                                            </div>
                                                             
                                                      </div>

                                                      <div class="box-footer clearfix" style="display: block;">
                                                            @if($supplier->user_id == Auth::User()->id)
                                                                     <button id="addrisk"  class="btn btn-primary pull-left" type="button">Add new risk</button>
                                                            @endif
                                                      </div>
                                                </div>
                                          </div>
                                      </div>

                                      <div class="row">
                                           <div class="col-md-12">
                                                <div class="box box-primary">
                                                     <div class="box-header with-border">
                                                          <i class="fa fa-fw fa-table"></i>
                                                          <h3 class="box-title">Leak incident history</h3>
                                                          <div class="box-tools pull-right">
                                                              &nbsp;
                                                          </div>
                                                     </div>
                                                     <div class="box-body">
                                                          <div class="col-xs-12">
                                                                @if(!$leak_incident_history->isEmpty())
                                                                 <div class="table-responsive">
                                                                          <table  class="table table-hover table-striped" id="leak_incident_history_tab">
                                                                            <thead>
                                                                              <th>Title</th>
                                                                              <th>Date</th>
                                                                              <th>Type</th>
                                                                              <th>Corrective action</th>
                                                                              <th>Overdue</th>
                                                                              @if($supplier->user_id == Auth::User()->id) <th>&nbsp;</th> @else<!--<th>View</th>-->  @endif
                                                                            </thead>
                                                                            <tbody>
                                                                            @foreach($leak_incident_history as $lih)
                                                                            <tr  data-id="{{$lih->id}}">
                                                                              <td>
                                                                                <a data-toggle="tooltip" title="{{$lih->title}}">{{str_limit(ucfirst($lih->title),15)}}</a>
                                                                              </td>
                                                                              <td>{{$lih->incident_date->format('d-m-Y')}}</td>
                                                                              <td>{{ucfirst($lih->incident_type)}}</td>
                                                                              <td>
                                                                                 <a data-toggle="tooltip" title="{{$lih->corrective_action_description}}">{{str_limit(ucfirst($lih->corrective_action_title),15)}}</a>
                                                                              </td>
                                                                              <td> <?php  $days = $lih->incident_date->diffInDays($lih->deadline_date,false);  ?>
                                                                              @if($days > 0)
                                                                                <span class="label label-primary">No</span>
                                                                              @else
                                                                               <span class="label label-danger">Yes</span>
                                                                              @endif</td>
                                                                              @if($supplier->user_id == Auth::User()->id)
                                                                              <td>
                                                                                @if($supplier->user_id == Auth::User()->id)
                                                                                    <i class="fa fa-edit incident_history" aria-hidden="true" title="Edit"></i>
                                                                                    <i class="fa fa-trash-o incident_history_remove" aria-hidden="true" title="Delete"></i>
                                                                                   <!-- <i class="fa fa-file-text-o" aria-hidden="true" title="View"></i>-->
                                                                                @endif
                                                                              </td>
                                                                              @else
                                                                                <!--<td>
                                                                                  <i class="fa fa-file-text-o" aria-hidden="true" title="View"></i>
                                                                              </td>-->
                                                                              @endif
                                                                            </tr>
                                                                          @endforeach
                                                                             
                                                                            </tbody>
                                                                          </table>
                                                                 </div>
                                                                @else
                                                                 <div class="alert alert-warning">
                                                                        This supplier does not have any incident history.
                                                                 </div>
                                                                @endif
                                                          </div>
                                                     </div>
                                                     <div class="box-footer clearfix" style="display: block;">
                                                          @if($supplier->user_id == Auth::User()->id)                                        
                                                            <button id="addnewincident" class="btn btn-primary" type="button">Add new incident</button>
                                                          @endif
                                                     </div>
                                                </div>
                                           </div>
                                      </div>

                                      <div class="row">
                                           <div class="col-md-12">
                                                <div class="box box-success">
                                                     <div class="box-header with-border">
                                                          <i class="fa fa-fw fa-columns"></i>
                                                          <h3 class="box-title">Supplier leak prevention status</h3>

                                                          <div class="box-tools pull-right">
                                                              &nbsp;
                                                          </div>
                                                     </div>
                                                     <div class="box-body">
                                                          <div class="col-lg-9">
                                                                 <div class="row">
                                                                      {{ Form::label('action_plan_status', 'Action plan status', ['class' => 'col-sm-2 control-label']) }}
                                                                      <div class="col-sm-4">
                                                                        {{ Form::text('action_plan_status',$supplier->action_plan_status ? $supplier->action_plan_status ."%" : 0 ."%", ['class' => 'form-control leak_status','readonly' => 'true' ]) }}
                                                                      </div>
                                                                  </div>
                                                                  <div class="row">
                                                                    &nbsp;
                                                                  </div>
                                                                  <div class="row">
                                                                          {{ Form::label('assessment_status', 'Assessment status', ['class' => 'col-sm-2 control-label']) }}
                                                                          <div class="col-sm-4">
                                                                            {{ Form::text('assessment_status',$supplier->assessment_status, ['class' => 'form-control leak_status','readonly' => 'true']) }}
                                                                          </div>
                                                                      </div>
                                                                      <div class="row">
                                                                          {{ Form::label('assessment_score', 'Assessment score', ['class' => 'col-sm-2 control-label']) }}
                                                                          <div class="col-sm-4">
                                                                            {{ Form::text('assessment_score',$supplier->assessment_score, ['class' => 'form-control leak_status','readonly' => 'true']) }}
                                                                          </div>
                                                                      </div>
                                                                  <div class="row">
                                                                    &nbsp;
                                                                  </div>
                                                                   <div class="row">
                                                                      {{ Form::label('summary', 'Summary', ['class' => 'col-sm-2 control-label']) }}
                                                                      <div class="col-sm-4">
                                                                        @if(Auth::user()->access_leak_prevention == 1 && Auth::user()->lsp_id == \MSLST\Constants\Site::HIGHEST_LEVEL_COMPANY )
                                                                        <?php $ary_dis = ['class' => 'form-control leak_summary_desc','size' => '20x5','maxlength' => '300']; ?>
                                                                        @else
                                                                         <?php $ary_dis = ['disabled'=>'disabled','class' => 'form-control','size' => '20x5','maxlength' => '300']; ?>
                                                                        @endif
                                                                        {{ Form::textarea('summary',$supplier->leak_prevention_summary ? : null,  $ary_dis) }}
                                                                        <a href="#" class="small-box-footer btn-success pull-right save-summary-leak-desc">
                                                                             Save summary <i class="fa fa-arrow-circle-right"></i>
                                                                        </a>
                                                                      </div>
                                                                  </div>
                                                                  <div class="row">
                                                                    &nbsp;
                                                                  </div>
                                                                  <div class="row">
                                                                      {{ Form::label('overall_status', 'Overall Status', ['class' => 'col-sm-2 control-label']) }}
                                                                      <div class="col-sm-4">
                                                                        
                                                                        <?php $overall_status = ceil($supplier->overall_status); ?>
                                                                          <select class="selectpicker overall_status bs-select-hidden" name="overall_status" style="width:300px;">
                                                                           @if($overall_status == 0)
                                                                            <option data-content="<span class='label label-default'>Not in scope</span>" value="1" @if($overall_status == 0) selected="selected" @endif>Not in scope</option>
                                                                           @elseif($overall_status >= 85)
                                                                            <option data-content="<span class='label label-success'>Compliant</span>" value="2" @if($overall_status <= 85) selected="selected" @endif>Compliant</option>
                                                                           @elseif($overall_status >= 50 && $overall_status <= 85) 
                                                                            <option data-content="<span class='label label-warning'>Partially compliant</span>" value="3" @if($overall_status > 50 && $overall_status <= 85 ) selected="selected" @endif>Partially compliant</option>
                                                                           @elseif($overall_status <= 50)  
                                                                            <option data-content="<span class='label label-danger'>Non compliant</span>" value="4" @if($overall_status >= 50) selected="selected" @endif>Non compliant</option>
                                                                           @endif
                                                                          </select>
                                                                      </div>
                                                                  </div>
                                                          </div>
                                                     </div>
                                                     <div class="box-footer clearfix" style="display: block;">
                                                     </div>
                                                </div>
                                           </div>
                                      </div>

 
                                   </div>
                                @else
                                <div class="alert alert-warning">
                                       This supplier does not handle any Microsoft components/products.
                                </div>
                                @endif
                          </div>
            </div>
        </div>
           <!-- /.col-lg-12 -->
          @endif
        </div>
        <div class="tab-pane" id="c">
         <div class="col-lg-6"> 
            <div class="panel panel-default">
              <div class="panel-heading">
                  <i class="fa fa-fw fa-list"></i> Self-Assessment
              </div>
              <!-- /.panel-heading -->
              <div class="panel-body">
                  <i ></i> <b>Activities</b>
                  @if(!empty($assessment_data))
                  <div class="panel-group" id="accordion">
                    @foreach($activities as $activitykey => $activity)
                      @if(in_array($activitykey,$questions['activities_id']))
                      <?php $act=md5('self'.$activity);?>
                      <div class="panel panel-default">
                          <div class="panel-heading">
                              <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion" href="#{{ $act }}">
                                    {{ $activity }}
                                </a>
                              </h4>
                          </div>
                          <div id="{{ $act }}" class="panel-collapse collapse">
                              <div class="panel-body">
                                  <i ></i> <b>Categories</b>
                                  <div class="panel-group" id="accordion_{{ $act }}">
                                    @foreach($categories as $category_id=>$category)
                                    <?php $cat=md5('self'.$activity.$category); ?>
                                    <div class="panel panel-default">
                                      <div class="panel-heading">
                                          <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion_{{ $act }}" href="#{{ $cat }}">
                                                {{ $category }}
                                            </a>
                                          </h4>
                                      </div>
                                      <div id="{{ $cat }}" class="panel-collapse collapse">
                                          <div class="panel-body">
                                              <i></i> <b>Answers</b>
                                              <div class="panel-group" id="accordion_{{ $cat }}">
                                                  @foreach($answers as $answer=>$answer_name)
                                                    <?php $ans=md5('self'.$activity.$category.$answer); ?>
                                                      <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="panel-title">
                                                              <a data-toggle="collapse" data-parent="#accordion_{{ $cat }}" href="#{{ $ans }}">
                                                                  {{ $answer_name }}
                                                              </a>
                                                            </h4>
                                                        </div>
                                                        <div id="{{ $ans }}" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                              <div class="panel-group" id="accordion_{{ $ans }}">
                                                              {{--*/ $i=1; /*--}}
                                                              @if(!empty($assessment_data[$activitykey]))
                                                              @foreach($assessment_data[$activitykey] as $assessment)
                                                              @if($assessment['self_answer_id']==$answer && $questions[$assessment['question_id']-1]['category']==$category_id)
                                                                  <div class="question-wrapper">
                                                                      <div class="question-circle answer{{ $answer }}"  data-toggle="tooltip" data-placement="bottom">
                                                                          &nbsp;
                                                                      </div>
                                                                      <div class="answer-wrapper">
                                                                        <h5>
                                                                          <span>
                                                                            {{ $i++ }}
                                                                          </span>. {{ $questions[$assessment['question_id']-1]['name'] }}
                                                                        </h5>
                                                                      </div>
                                                                  </div>
                                                                @endif
                                                              @endforeach
                                                              @endif
                                                            </div>   
                                                            </div>
                                                        </div>
                                                      </div>
                                                  @endforeach
                                              </div>
                                          </div>
                                      </div>
                                    </div>
                                    @endforeach
                                  </div>
                              </div>
                          </div>
                      </div>
                      @endif
                    @endforeach  
                  </div>
                  @else
                      <p>There are no questions & answers.</p>
                  @endif
              </div>
              <!-- /.panel-body -->
            </div>
         </div>  
         <div class="col-lg-6"> 
            <div class="panel panel-default">
              <div class="panel-heading">
                  <i class="fa fa-fw fa-list"></i> Onsite-Assessment
              </div>
              <!-- /.panel-heading -->
              <div class="panel-body">
                  <i></i> <b>Activities</b>
                  @if(!empty($assessment_data))
                  <div class="panel-group" id="accordion1">
                     @foreach($activities as $activitykey => $activity)
                      @if(in_array($activitykey,$questions['activities_id']))
                      <?php $act=md5('onsite'.$activity);?>
                      <div class="panel panel-default">
                          <div class="panel-heading">
                              <h4 class="panel-title">
                                <a data-toggle="collapse" data-parent="#accordion1" href="#{{ $act }}">
                                    {{ $activity }}
                                </a>
                              </h4>
                          </div>
                          <div id="{{ $act }}" class="panel-collapse collapse">
                              <div class="panel-body">
                                  <i></i> <b>Categories</b>
                                  <div class="panel-group" id="accordion_{{ $act }}">
                                    @foreach($categories as $category_id=>$category)
                                    <?php $cat=md5('onsite'.$activity.$category);?>
                                    <div class="panel panel-default">
                                      <div class="panel-heading">
                                          <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion_{{ $act }}" href="#{{ $cat }}">
                                                {{ $category }}
                                            </a>
                                          </h4>
                                      </div>
                                      <div id="{{ $cat }}" class="panel-collapse collapse">
                                          <div class="panel-body">
                                              <i></i> <b>Answers</b>
                                              <div class="panel-group" id="accordion_{{ $cat }}">
                                                  @foreach($answers as $answer=>$answer_name)
                                                    <?php $ans=md5('onsite'.$activity.$category.$answer);?>
                                                      <div class="panel panel-default">
                                                        <div class="panel-heading">
                                                            <h4 class="panel-title">
                                                              <a data-toggle="collapse" data-parent="#accordion_{{ $cat }}" href="#{{ $ans }}">
                                                                  {{ $answer_name }}
                                                              </a>
                                                            </h4>
                                                        </div>
                                                        <div id="{{ $ans }}" class="panel-collapse collapse">
                                                            <div class="panel-body">
                                                              <div class="panel-group" id="accordion_{{ $ans }}">
                                                              {{--*/ $i=1; /*--}}
                                                              @if(!empty($assessment_data[$activitykey]))
                                                              @foreach($assessment_data[$activitykey] as $assessment)
                                                                @if($assessment['onsite_answer_id']==$answer && $questions[$assessment['question_id']-1]['category']==$category_id)
                                                                  <div class="question-wrapper">
                                                                      <div class="question-circle answer{{ $answer }}"  data-toggle="tooltip" data-placement="bottom">
                                                                          &nbsp;
                                                                      </div>
                                                                      <div class="answer-wrapper">
                                                                        <h5>
                                                                          <span>
                                                                            {{ $i++ }}
                                                                          </span>. {{ $questions[$assessment['question_id']-1]['name'] }}
                                                                        </h5>
                                                                      </div>
                                                                  </div>
                                                                @endif
                                                              @endforeach
                                                              @endif
                                                             
                                                            </div>   
                                                            </div>
                                                        </div>
                                                      </div>
                                                  @endforeach
                                              </div>
                                          </div>
                                      </div>
                                    </div>
                                    @endforeach
                                  </div>
                              </div>
                          </div>
                      </div>
                      @endif
                    @endforeach  
                  </div>
                  @else
                      <p>There are no questions & answers.</p>
                  @endif
              </div>
              <!-- /.panel-body -->
            </div>
         </div> 
        </div>
     </div>
   </div>  
    <!--/.panel-body--> 
</div>	
<!-- /#page-wrapper -->
<!-- -->
<script src="//js.api.here.com/ee/2.5.4/jsl.js?with=all" type="text/javascript" charset="utf-8"></script>



<script type="text/javascript">
	var Suppliers = {
		mapElement: 'supplier_map',
		coordinates: '{{$coordinates}} '
	};
  var incident_history_json = {{json_encode($leak_incident_history)}};
  var incident_prevention_json = {{json_encode($leak_prevention)}};
  var business_activity = {{json_encode($business_activities)}};
  var business_assets = {{json_encode($business_assets)}};
  var business_risk = {{json_encode($business_risk)}};
  var business_actions = {{json_encode($business_actions)}};
  var leak_risk_analysis = {{json_encode($leak_risk_analysis)}};
</script>
<style type="text/css">
.panel-title{
  font-size: 14px !important;
  font-family: segoe_ui;
}
</style>
@stop
