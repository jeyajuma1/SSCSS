@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">Self-Assessment</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>

        <!--?php print($data); ?-->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default" style="width:1300px">
                    <div class="panel-heading">Questions</div>
                    <div class="panel-body">
                    <ul class="nav nav-tabs">
                        @foreach($activities as $activity)
                            <li id="tapa-tab" class="active"><a href="#tapa" data-toggle="tab">{{ $activity }}</a></li>
                        @endforeach
                    </ul>   
                    @if(!empty($questions))
                    <div class="panel-group" id="accordion">
                        @foreach($categories as  $category)
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <h4 class="panel-title">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#{{ md5($category) }}">
                                            {{ $category['name'] }}
                                        </a>
                                    </h4>
                                </div>
                                <div id="{{ md5($category) }}" class="panel-collapse collapse">
                                    <div class="panel-body">
                                        <div class="panel-group" id="accordion_{{ md5($category) }}">
                                           @foreach($questions as  $question) 
                                            @if($question['category']==$category['id'])
                                            <?php $id = $question['id']; ?>
                                             {{ Form::hidden("display[$id]", 1) }}
                                                <?php $tapa_display = 1; ?>
                                                <div class="question-block">
                                                    <div class="form-group">
                                                        {{ Form::label("question$id", $question['name'], ['class' => 'control-label']) }}
                                                        {{ Form::select("question[$id]", $answers, ((isset($data->answer) && isset($data->answer[$id])) ? $data->answer[$id] : null), ['class' => 'form-control bigdrop', 'id' => "question$id"]) }}
                                                    </div>                               
                                                    <div class="form-group">
                                                        <?php $form_control = (isset($data->comment) && isset($data->comment[$id])) ? 'form-control' : 'hidden' ?>
                                                        <a onClick="document.getElementById('comment{{ $id }}').className='form-control';" href="javascript:void(0);" class="comment-link">Add Comment</a>
                                                        {{ Form::textarea("comment[$id]", ((isset($data->comment) && isset($data->comment[$id])) ? $data->comment[$id] : ''), ['class' => $form_control, 'rows' => 3, 'id' => "comment$id"]) }}
                                                    </div>
                                                </div>
                                          @endif  
                                        @endforeach 
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                    @else
                        <p>There are no questions & answers.</p>
                    @endif
                </div>
                        
                        <div class="panel-footer">
                        {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default','id'=>'supplier_cancel_edit']) }}
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            </div>
            <!-- /.col-lg-12 -->
        
    </div>
</div>
            <!-- /.col-lg-12 -->
       



@stop