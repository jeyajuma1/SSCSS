@extends('layouts.master')

@section('content')

<div class="body_content">
      <div id="wrapper">
               @if($edit)
                  <h2 class="page-header">Edit Site</h2>
                @else
                  <h2 class="page-header">Create Site</h2>
                @endif
      </div>

      <div class="wrapper-content animated fadeInRight">
        <div class="row">
          <div class="col-lg-12">
             <div class="ibox">
                <div class="ibox-title">
                    <h5>Contact Information</h5>
                    <div class="ibox-tools">
                      <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>  
                    </div>
                </div>
                <div class="ibox-content">
                     <div class="wizard">
                                        <a>
                                          <span>1. Basic Information</span>
                                        </a>
                                        <a >
                                          <span>2. Site Information</span>
                                        </a>
                                        <a  class="current">
                                          <span>3. Contact Information</span>
                                        </a>
                     </div>
                     <div class="panel panel-default wizard_body" > 
 
                    {{ Form::open(['route' => ($edit ? ['sitemaster.update', $data->id] : 'sitemaster.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal sitemaster-form', 'role' => 'form', 'id' => 'sitemaster-form-basic']) }}
                        {{ Form::hidden('step',2) }}
                            <div class="panel-body"  >
                                <!-- end form-errors -->
                                <div class="row">
                                    <div class="col-lg-9">
                                        @if($errors->all())
                                        <div id="form-errors" class="alert alert-danger" role="alert">
                                          <ul>
                                            @foreach($errors->all() as $error)
                                              <li>{{ $error }}</li>
                                            @endforeach
                                          </ul>
                                        </div>
                                        @endif

                                        <div class="form-group" style="margin-top:30px">
                                          {{ Form::label('contact_name', 'Contact Name *', ['class' => 'col-lg-3 control-label required']) }}
                                          <div class="col-lg-5">
                                          {{ Form::text('contact_name', $data->contact_name, ['class' => 'form-control','maxlength'=>150]) }}
                                          </div>
                                      </div>

                                      <div class="form-group"> 
                                          {{ Form::label('contact_email', 'Contact Email *', ['class' => 'col-lg-3 control-label required']) }}
                                          <div class="col-lg-5">
                                          {{ Form::text('contact_email', $data->contact_email, ['class' => 'form-control','maxlength'=>150]) }}
                                          </div>
                                      </div>

                                      <div class="form-group">
                                          {{ Form::label('other_contact_info', 'Other Contact Info', ['class' => 'col-lg-3 control-label ']) }}
                                          <div class="col-lg-5">
                                            {{ Form::text('other_contact_info', $data->other_contact_info, ['class' => 'form-control','maxlength'=>150]) }}
                                          </div>
                                      </div>

                                    </div>

                                    <div class="col-lg-3">
                                         <div class="pull-right text-danger">
                                            (*) Mandatory Field
                                        </div>
                                        <div class="text-center">
                                          <div style="margin-top: 20px">
                                            <i style="font-size: 180px; color: #e5e5e5" class="fa fa-sign-in"></i>
                                          </div>
                                        </div>
                                     </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                                  @if($edit)
                                    {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                    {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.show', $data->id),'id'=>'sitemaster_cancel_edit']) }}
                                  @else
                                    <div class="clearfix">
                                      <div class="pull-left">
                                        {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }}
                                      </div>
                                      <div class="pull-right">
                                      {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                      {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.index'),'id'=>'sitemaster_cancel']) }}
                                      </div>
                                    </div>
                                  @endif
                            </div>
                        {{ Form::close() }}
                     </div> 
                </div>  
              </div>
          </div>
        </div>
      </div>
</div>

<script type="text/javascript">
  var Sitemasters = {'coordinates': null, 'mapElement': null};
 var incident_history_json = null;
  var incident_prevention_json = null;
  var business_activity = null;
  var business_assets = null;
  var business_lob = null;
  var business_risk = null;
  var business_actions= null;
  var leak_risk_analysis = null;
  var corrective_actions = null;
  var lp_corrective_actions = null;
  var accessname = null;
</script>
@stop