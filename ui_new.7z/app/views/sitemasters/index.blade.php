@extends('layouts.master')

@section('content')


<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Site Master
                  <div class="btn-group pull-right incident-btns ">
                    {{ Form::button('<i class="fa fa-plus "></i> Add Site', ['type' => 'button', 'class' => 'btn btn-primary', 'href' => route('sitemaster.create')]) }}
                </div>
            </h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>

    @if(Session::has('success'))
    <div id="form-success" class="alert alert-success" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div> 
    @endif

    <div class="row">
        <div class="col-lg-12">
              <div class="ibox float-e-margins animated flipInX">
                                <div class="ibox-title">
                                    <h5>
                                        <i class="fa fa-filter" aria-hidden="true"></i> Filters
                                    </h5>
                                    <div class="ibox-tools">
                                        <a class="collapse-link"> <i class="fa fa-chevron-up"></i>
                                        </a>
                                    </div>
                                </div>
                                <div class="ibox-content">
                                    <div class="row">
                                         <div class="panel panel-default sitemasters-panel">
                                            <div class="panel-heading">
                                                {{ Form::open(['route' => 'sitemaster.index', 'method' => 'get', 'id' => 'sitemasters-list-form', 'class' => 'form-inline', 'role' => 'form']) }}
                                                <div class="form-group-row">
                                                    @if(Auth::user()->isAdmin() || Auth::User()->isManager() || Auth::user()->isSupervisor())
                                                        <div class="form-group">
                                                            <div class="input-group">
                                                                <span class="input-group-addon">User&nbsp;&nbsp;</span>
                                                                {{ Form::select('user[]', $users, Input::get('user'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                            </div>
                                                        </div>
                                                    @endif
                                                    <div class="form-group">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">Region&nbsp;</span>
                                                            {{ Form::select('region[]', $regions, Input::get('region'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                        </div>                               
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">Country&nbsp;&nbsp;</span>
                                                            {{ Form::select('country[]', $countries, Input::get('country'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                        </div>                              
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">&nbsp;&nbsp;&nbsp;&nbsp;ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                            {{ Form::text('sitemaster_id', Input::get('sitemaster_id'), ['class' => 'form-control sitemaster-id']) }}
                                                        </div>                              
                                                    </div>

                                                    <div class="form-group">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">Status</span>
                                                            {{ Form::select('status[]', ['active' => 'Active', 'inactive' => 'Inactive'], Input::get('status'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">Supplier Type</span>
                                                            {{ Form::select('site_supplier_type[]', $supplier_type, Input::get('site_supplier_type'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="input-group">
                                                            <span class="input-group-addon" >Channel Manager</span>
                                                            {{ Form::select('channel_manager[]', $channel_manager, Input::get('channel_manager'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="input-group">
                                                        <span class="input-group-addon" title="Last Inspection Date"><i class="fa fa-calendar" ></i></span>
                                                        {{ Form::text('daterange', Input::get('daterange'), ['class' => 'form-control','placeholder'=>'Last Inspection Date']) }}
                                                        </div>
                                                    </div>

                                                    <div class="form-group text-left hidden">
                                                        {{ Form::button('Filter', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                                        {{ Form::button('Reset', ['type' => 'reset', 'class' => 'btn btn-primary', 'id' => 'sitemaster-filter-reset' ]) }}
                                                    </div>
                                                </div>
                                                {{ Form::close() }}
                                            </div>
                                         </div>
                                    </div>
                                </div>
              </div>

 
              <div class="ibox float-e-margins animated flipInX">
                                <div class="ibox-title">
                                    <h5>
                                        <i class="fa fa-table" aria-hidden="true"></i> Site Master
                                    </h5>
                                    <div class="ibox-tools">
                                         
                                    </div>
                                </div>
                                <div class="ibox-content">
                                    <div class="row">
                                         <div class="col-lg-12">
                                             <div class="panel panel-default sitemasters-panel">
                                                <div class="panel-body">
                                                       <table class="table table-hover table-bordered" id="sitemasterslist">
                                                                    <thead id="sitemasters-head">
                                                                        <th id="tenplus" style='width:5%'>ID</th>
                                                                        <th id="tenplus" style='width:25%'>Site Name</th>
                                                                        <th id="tenplus">Country</th> 
                                                                        <th id="tenplus">Channel Manager</th> 
                                                                        <th id="tenplus">Line Of Business</th>
                                                                        <th id="tenplus">Supplier Type</th>
                                                                        <th id="tenplus" >Last Inspection Date</th> 
                                                                        <th id="tenplus"> Last Inspection Results</th>
                                                                        <th id="tenplus"> Open/ Closed CAs</th>
                                                                        <th id="tenplus">Overdue CAs</th>
                                                                        
                                                                    </thead>
                                                                    <tbody>
                                                                        @foreach($sitemasters as $sitemaster)
                                                                        <tr class="clickable-row sitemasters-item"  data-id="{{ $sitemaster->id }}">
                                                                            <td>{{ $sitemaster->id }}</td>
                                                                            <td>{{$sitemaster->site_name}}</td>
                                                                            <td>{{ $sitemaster->country->name }}</td> 
                                                                            <td>{{ $sitemaster->channel_manager }}</td>  
                                                                             {{-- */ $lob = $sitemaster->lob?implode(',',json_decode($sitemaster->lob)):'';  /* --}}
                                                                            <td title="{{$lob}}" class="lob">{{str_limit($lob,15) }}</td> 
                                                                              {{-- */ $supp_type =  $sitemaster->supplier_type?implode(',',json_decode($sitemaster->supplier_type)):'';  /* --}}
                                                                            <td title="{{$supp_type}}">{{str_limit($supp_type,15)}}</td>  
                                                                            <td>{{($sitemaster->last_inspection_date)? $sitemaster->last_inspection_date->format('Y-m-d'):'NA' }}</td>
                                                                             <?php $overall_status = ceil($sitemaster->overall_status);    ?>

                                                                                @if($sitemaster->determined_overall_status == 0 && $sitemaster->supplier_handle == 0)
                                                                                   <?php $tdclass= "label  label-default"; $overallstatus = "Not in scope"; ?>
                                                                                @elseif($overall_status >= 85)
                                                                                    <?php $tdclass= "label label-success"; $overallstatus = "Compliant"; ?>
                                                                                @elseif($overall_status >= 50 && $overall_status <= 85) 
                                                                                    <?php $tdclass= "label label-warning"; $overallstatus = "Partially compliant"; ?>
                                                                                @elseif($overall_status <= 50 && $sitemaster->supplier_handle == 1) 
                                                                                    <?php $tdclass= "label  label-danger"; $overallstatus = "Non compliant"; ?>
                                                                                @endif
                                                                                @if($sitemaster->determined_overall_status != 0)
                                                                               
                                                                                  {{-- */ $overallstatus  = \MSLST_Site::$Determined_status[$sitemaster->determined_overall_status]['val']; $tdclass= "label  label-".\MSLST_Site::$Determined_status[$sitemaster->determined_overall_status]['clas'];   /* --}}                                    
                                                                                  @endif
                                                                            <td>  
                                                                                @if(!empty($sitemaster->pr_inspection_main->toArray()))
                                                                                       {{$sitemaster->pr_inspection_main->toArray()[0]['sc_scoring_rules_final_rating']}}      
                                                                                @else
                                                                                    NA
                                                                                @endif
                                                                            </td>
                                                                             <?php $open_ca=0; $closed_ca=0;  $overdue_ca=0; ?>
                                                                            {{-- */ $ca_status = false; /* --}}
                                                                            @if(!empty($sitemaster->insepction_pr->toArray()))
                                                                                @foreach($sitemaster->insepction_pr->toArray() as $ky=>$val)
                                                                                  @if(@$sitemaster->pr_inspection_main->toArray()[0]['id'] == $val['inspection_num'])
                                                                                    <?php
                                                                                        if($val['pr_status'] == 'open') $open_ca= $val['cnt_status'];
                                                                                        if($val['pr_status'] == 'overdue') $overdue_ca= $val['cnt_status'];
                                                                                        if($val['pr_status'] == 'closed') $closed_ca= $val['cnt_status'];
                                                                                    ?>
                                                                                  @endif
                                                                                @endforeach
                                                                                {{-- */ $ca_status = true; /* --}}
                                                                            @endif
                                                                            <td>@if($ca_status == true)<span class="rat_hig_class" title="Open"> {{$open_ca}} </span>/ <span class="rat_low_class" title="Closed">{{$closed_ca}}</span> @else N/A @endif</td>
                                                                            <td>@if($ca_status == true) {{$overdue_ca}} @else N/A @endif </td>
                                                                            
                                                                        </tr>
                                                                        @endforeach
                                                                    </tbody>
                                                       </table>
                                                </div>
                                             </div>
                                         </div>
                                    </div>
                                </div>
              </div>
        </div>
    </div>

</div>

<!--
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
                Site Master
             <div class="btn-group pull-right incident-btns">
                {{ Form::button('Add Site', ['type' => 'button', 'class' => 'btn-gray', 'href' => route('sitemaster.create')]) }}
            </div>   
            </h1>
        </div>
         
    </div> 
	@if(Session::has('success'))
    <div id="form-success" class="alert alert-success" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div> 
    @endif
      <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default sitemasters-panel">
                <div class="panel-heading">
                    {{ Form::open(['route' => 'sitemaster.index', 'method' => 'get', 'id' => 'sitemasters-list-form', 'class' => 'form-inline', 'role' => 'form']) }}
                    <div class="form-group-row">
					@if(Auth::user()->isAdmin() || Auth::User()->isManager() || Auth::user()->isSupervisor())
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">User&nbsp;&nbsp;</span>
                                {{ Form::select('user[]', $users, Input::get('user'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                            </div>
                        </div>
						@endif
						<div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">Region&nbsp;</span>
                                {{ Form::select('region[]', $regions, Input::get('region'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                            </div>                               
                        </div>
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">Country&nbsp;&nbsp;</span>
                                {{ Form::select('country[]', $countries, Input::get('country'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                            </div>                              
                        </div>
						<div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">&nbsp;&nbsp;&nbsp;&nbsp;ID&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                {{ Form::text('sitemaster_id', Input::get('sitemaster_id'), ['class' => 'form-control sitemaster-id']) }}
                            </div>                              
                        </div>
						
						<div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">Status</span>
                                {{ Form::select('status[]', ['active' => 'Active', 'inactive' => 'Inactive'], Input::get('status'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                            </div>
                        </div>
						<div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">Supplier Type</span>
                                {{ Form::select('site_supplier_type[]', $supplier_type, Input::get('site_supplier_type'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                            </div>
                        </div>
						<div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon" >Channel Manager</span>
                                {{ Form::select('channel_manager[]', $channel_manager, Input::get('channel_manager'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                            </div>
						</div>
						<div class="form-group">
                            <div class="input-group">
                               <span class="input-group-addon" title="Last Inspection Date"><i class="fa fa-calendar" ></i></span>
                                {{ Form::text('daterange', Input::get('daterange'), ['class' => 'form-control','placeholder'=>'Last Inspection Date']) }}
                            </div>
                        </div>
						
						<div class="form-group text-left hidden">
                            {{ Form::button('Filter', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Reset', ['type' => 'reset', 'class' => 'btn btn-primary', 'id' => 'sitemaster-filter-reset' ]) }}
                        </div>
                    </div>
                    {{ Form::close() }}
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-striped" id="sitemasterslist">
                        <thead id="sitemasters-head">
                        	<th id="tenplus" style='width:5%'>ID</th>
							<th id="tenplus" style='width:25%'>Site Name</th>
							<th id="tenplus">Country</th> 
							<th id="tenplus">Channel Manager</th> 
							<th id="tenplus">Line Of Business</th>
							<th id="tenplus">Supplier Type</th>
							<th id="tenplus" >Last Inspection Date</th> 
                            <th id="tenplus"> Last Inspection Results</th>
                            <th id="tenplus"> Open/ Closed CAs</th>
                            <th id="tenplus">Overdue CAs</th>
                            
                        </thead>
                        <tbody>
                            @foreach($sitemasters as $sitemaster)
                            <tr class="clickable-row sitemasters-item"  data-id="{{ $sitemaster->id }}">
                                <td>{{ $sitemaster->id }}</td>
                                <td>{{ $sitemaster->site_name }}</td>
								<td>{{ $sitemaster->country->name }}</td> 
								<td>{{ $sitemaster->channel_manager }}</td>	 
                                <td>{{$sitemaster->lob?implode(',',json_decode($sitemaster->lob)):'' }}</td> 
                                <td>{{ $sitemaster->supplier_type?implode(',',json_decode($sitemaster->supplier_type)):''  }}</td>  
                                <td>{{($sitemaster->last_inspection_date)? $sitemaster->last_inspection_date->format('Y-m-d'):'NA' }}</td>
                                 <?php $overall_status = ceil($sitemaster->overall_status);    ?>

                                    @if($sitemaster->determined_overall_status == 0 && $sitemaster->supplier_handle == 0)
                                       <?php $tdclass= "label  label-default"; $overallstatus = "Not in scope"; ?>
                                    @elseif($overall_status >= 85)
                                        <?php $tdclass= "label label-success"; $overallstatus = "Compliant"; ?>
                                    @elseif($overall_status >= 50 && $overall_status <= 85) 
                                        <?php $tdclass= "label label-warning"; $overallstatus = "Partially compliant"; ?>
                                    @elseif($overall_status <= 50 && $sitemaster->supplier_handle == 1) 
                                        <?php $tdclass= "label  label-danger"; $overallstatus = "Non compliant"; ?>
                                    @endif
                                    @if($sitemaster->determined_overall_status != 0)
                                   
                                      {{-- */ $overallstatus  = \MSLST_Site::$Determined_status[$sitemaster->determined_overall_status]['val']; $tdclass= "label  label-".\MSLST_Site::$Determined_status[$sitemaster->determined_overall_status]['clas'];   /* --}}                                    
                                      @endif
                                <td>  
                                    @if(!empty($sitemaster->pr_inspection_main->toArray()))
                                           {{$sitemaster->pr_inspection_main->toArray()[0]['sc_scoring_rules_final_rating']}}      
                                    @else
                                        NA
                                    @endif
                                </td>
                                 <?php $open_ca=0; $closed_ca=0;  $overdue_ca=0; ?>
                                {{-- */ $ca_status = false; /* --}}
                                @if(!empty($sitemaster->insepction_pr->toArray()))
                                    @foreach($sitemaster->insepction_pr->toArray() as $ky=>$val)
                                      @if(@$sitemaster->pr_inspection_main->toArray()[0]['id'] == $val['inspection_num'])
                                        <?php
                                            if($val['pr_status'] == 'open') $open_ca= $val['cnt_status'];
                                            if($val['pr_status'] == 'overdue') $overdue_ca= $val['cnt_status'];
                                            if($val['pr_status'] == 'closed') $closed_ca= $val['cnt_status'];
                                        ?>
                                      @endif
                                    @endforeach
                                    {{-- */ $ca_status = true; /* --}}
                                @endif
                                <td>@if($ca_status == true)<span class="rat_hig_class" title="Open"> {{$open_ca}} </span>/ <span class="rat_low_class" title="Closed">{{$closed_ca}}</span> @else N/A @endif</td>
                                <td>@if($ca_status == true) {{$overdue_ca}} @else N/A @endif </td>
                                
							</tr>
                            @endforeach
                        </tbody>
                       </table>
                    </div>
                </div>
            </div> 
        </div> 
</div>

-->

<!-- /#page-wrapper -->

@stop