@extends('layouts.master')

@section('content')
<div class="body_content">
      <div id="wrapper">
                @if($edit)
                  <h1 class="page-header">Edit Site</h1>
                @else
                  <h1 class="page-header">Create Inspection Main</h1>
                @endif
      </div> <!--/*wrapper -->

      <div class="wrapper-content animated fadeInRight">
        <div class="row">
          <div class="col-lg-12">
             <div class="ibox">
                <div class="ibox-title">
                    <h5>P+R Inspection</h5>
                    <div class="ibox-tools">
                      <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>  
                    </div>
                </div> <!--/*ibox-title -->
                <div class="ibox-content">
                     <div class="wizard">
                                        <a class="current">
                                          <span>1. Inspection Main</span>
                                        </a>
                                        <a>
                                          <span>2. Questions</span>
                                        </a>
                                        <a>
                                          <span>3. Summary</span>
                                        </a>
 
                     </div> <!--/*wizard -->
                     <div class="panel panel-default wizard_body"> 
                         
                           {{ Form::open(['route' => ($edit ? ['sitemaster.inspectionupdate', $data->id,$data->inspection_num,1] : ['sitemaster.inspectionprstore',$data->id,'online']), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal sitemaster-form', 'role' => 'form', 'id' => 'sitemaster-form-basic','name'=>'sitemaster_form_inspection']) }}
                          {{Form::hidden('inspection_num',Input::get('inspection_num'))}}
                          {{ Form::hidden('step', 1) }}
                            <div class="panel-body"  >
                                <!-- end form-errors -->
                                <div class="row">
                                    <div class="col-lg-9">
                                        @if($errors->all())
                                          <div id="form-errors" class="alert alert-danger" role="alert">
                                            <ul>
                                              @foreach($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                              @endforeach
                                            </ul>
                                          </div>
                                          @elseif(Session::has('success'))
                                            <div id="form-success" class="alert alert-success" role="alert">
                                                <span>
                                                    {{ trans(Session::get('success')) }}
                                                </span>
                                            </div>
                                            <!-- end form-success -->
                                        @endif


                                        <div class="form-group">
                                            {{ Form::label('ins_main_date', 'Inspection Date', ['class' => 'col-lg-6 control-label required']) }}
                                            <div class="col-sm-6">
                                              <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                                {{ Form::text('ins_main_date', $data->ins_main_date, ['class' => 'form-control']) }}
                                              </div>
                                            </div>
                                         </div> 

                                        <div class="form-group">
                                          {{ Form::label('ins_main_num_sep_buliding_at_this_site', 'Number of separate buildings at this site', ['class' => 'col-lg-6 control-label required']) }}
                                          <div class="col-lg-6">
                                            {{ Form::text('ins_main_num_sep_buliding_at_this_site', $data->ins_main_num_sep_buliding_at_this_site, ['class' => 'form-control']) }}
                                          </div>
                                        </div> 

                                         <div class="form-group">
                                            {{ Form::label('ins_main_num_buliding_ms_related_functions', '  Number of buildings with Microsoft-related functions', ['class' => 'col-lg-6 control-label required']) }}
                                            <div class="col-lg-6">
                                              {{ Form::text('ins_main_num_buliding_ms_related_functions', $data->ins_main_num_buliding_ms_related_functions, ['class' => 'form-control','type'=>"number"]) }}
                                            </div>
                                          </div> 

                                          <div class="form-group">
                                            {{ Form::label('ins_main_num_full_time_emp_facility', 'Number of full-time employees at this facility', ['class' => 'col-lg-6 control-label required']) }}
                                            <div class="col-lg-6">
                                              {{ Form::text('ins_main_num_full_time_emp_facility', $data->ins_main_num_full_time_emp_facility, ['class' => 'form-control']) }}
                                            </div>
                                          </div> 

                                          <div class="form-group">
                                            {{ Form::label(' ins_main_supp_subcontract_handling_ms_product_ip', 'Supplier Subcontractor(s) Handling Microsoft product or IP', ['class' => 'col-lg-6 control-label ']) }}
                                            <div class="col-lg-6">
                                              {{ Form::text(' ins_main_supp_subcontract_handling_ms_product_ip', $data-> ins_main_supp_subcontract_handling_ms_product_ip, ['class' => 'form-control']) }}
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('ins_main_emp_ms_system_account', 'Employees with Microsoft System Access', ['class' => 'col-lg-6 control-label ']) }}
                                            <div class="col-lg-6">
                                              {{ Form::text('ins_main_emp_ms_system_account', $data->ins_main_emp_ms_system_account, ['class' => 'form-control']) }}
                                            </div>
                                          </div>
                                            <div class="form-group">
                                              <div>
                                                    {{ Form::label('ins_main_name_alias_access', 'Employees with Microsoft System Accounts', ['class' => 'col-lg-6 control-label required']) }}
                                                    {{ Form::label('ins_main_name_alias_access_name', 'Name', ['class' => 'col-name ']) }}
                                                    {{ Form::label('ins_main_name_alias_access_alias', 'Alias', ['class' => 'col-name ']) }}
                                                    {{ Form::label('ins_main_name_alias_access_access', 'Access', ['class' => 'col-name ']) }}
                                                    <button id="namealiasaccess" class="onlinebtn" type="button"><b>+</b></button>
                                              </div>
                                              <?php $i=1;$ins_main_name_alias_access=json_decode($data->ins_main_name_alias_access);?>
                                              @if(isset($data->ins_main_name_alias_access) && count($ins_main_name_alias_access))
                                                @foreach($ins_main_name_alias_access as $key_val => $ins_main_name_alias_access_data)
                                                  @if(!empty(trim($ins_main_name_alias_access_data->name)))
                                                  <div class="row activty-row" id="activty-row<?php echo $i?>" style="margin-bottom: 15px;">
                                                      <div class="col-lg-6">
                                                        
                                                      </div>
                                                      <div class="col-sm-1 activity-cols" style="display:none;">
                                                          <span class="form-control activty-count" style="display:none;">{{$i}}</span>
                                                      </div>
                                                      <div class="col-lg-2" style="width:120px;margin-bottom: 3px;">
                                                         <input type="text" name="ins_main_name_alias_access[<?php echo $i;?>][name]" id="ins_main_name<?php echo $i;?>" value="{{$ins_main_name_alias_access_data->name}}"class="form-control ins_main" style="width: 120px;">        
                                                      </div>
                                                      <div class="col-lg-2" style="width:120px;margin-left:12px;margin-bottom: 3px;">
                                                         <input type="text" name="ins_main_name_alias_access[<?php echo $i;?>][alias]" id="ins_main_alias<?php echo $i;?>"class="form-control ins_main1"  value="{{$ins_main_name_alias_access_data->alias}}"style="width: 120px;">
                                                      </div>
                                                      <div class="col-lg-2" style="width:120px;margin-left:12px;margin-bottom: 3px;">
                                                        <!-- {{ Form::text("ins_main_name_alias_access[$key_val][access]",$ins_main_name_alias_access_data->access, ['class' => 'form-control-ins-main-naa']) }} -->

                                                        <select id="ins_main_access<?php echo $i;?>" name="ins_main_name_alias_access[<?php echo $i;?>][access]" style="width:120px; height:34px;border:1px solid #CCCCCC;" class="ins_main2" >
                                                          <option value="">- Select -</option>
                                                          <option value="MS System Accounts" <?=$ins_main_name_alias_access_data->access == 'MS System Accounts' ? ' selected="selected"' : '';?>>MS System Accounts</option>
                                                          <option value="Team Center" <?=$ins_main_name_alias_access_data->access == 'Team Center' ? ' selected="selected"' : '';?>>Team Center</option>
                                                          <option value="RSM" <?=$ins_main_name_alias_access_data->access == 'RSM' ? ' selected="selected"' : '';?>>RSM</option>
                                                          <option value="Orion" <?=$ins_main_name_alias_access_data->access == 'Orion' ? ' selected="selected"' : '';?>>Orion</option>
                                                          <option value="MOO" <?=$ins_main_name_alias_access_data->access == 'MOO' ? ' selected="selected"' : '';?>>MOO</option>
                                                          <option value="Other" <?=$ins_main_name_alias_access_data->access == 'Other' ? ' selected="selected"' : '';?>>Other</option>
                                                        </select>
                                                      </div>                                          
                                                      <div class="col-lg-1" sty>
                                                        <span class="glyphicon glyphicon-remove name_alias_access_remove"  style="cursor:pointer;margin:10px 0 0 20px;"  id="name_alias_access_remove<?php echo $i; ?>" alt="<?php echo $i; ?>" aria-hidden="true"></span>                                  
                                                      </div>
                                                  </div>  
                                                  <?php $i=$i+1; ?>
                                                 @endif
                                                @endforeach
                                              @else
                                                <div class="row activty-row" id="activty-row1" >
                                                  <div class="col-sm-1 activity-cols" style="display:none;">
                                                    <span class="form-control activty-count" style="display:none;">1</span>
                                                  </div>  

                                                  <div class="col-lg-2" style="width:122px;margin-left: 14px;">
                                                    <div class="form-group"> 
                                                      <input type="text" name="ins_main_name_alias_access[1][name]" id="ins_main_name1" class="form-control ins_main" style="width: 120px;" />        
                                                    </div>
                                                  </div>

                                                  <div class="col-lg-2" style="width:122px;margin-left:12px;">
                                                    <div class="form-group"> 
                                                      <input type="text" name="ins_main_name_alias_access[1][alias]" id="ins_main_alias1"class="form-control ins_main1" style="width: 120px;" />        
                                                    </div>
                                                  </div>

                                                  <div class="col-lg-2" style="width:122px;margin-left:12px;">
                                                    <div class="form-group">
                                                      <select id="ins_main_access1" name="ins_main_name_alias_access[1][access]" class= "ins_main2"style="width:120px; height:34px;">
                                                        <option value="">- Select -</option>
                                                        <option value="MS System Accounts">MS System Accounts</option>
                                                        <option value="Team Center">Team Center</option>
                                                        <option value="RSM">RSM</option>
                                                        <option value="Orion">Orion</option>
                                                        <option value="MOO">MOO</option>          
                                                        <option value="Other">Other</option>  
                                                      </select>
                                                    </div>
                                                  </div>
                                                  <div id="otherType0" style="display:none;width:419px;">
                                                    <input type="text" name="others" id="others0" class="form-control" />
                                                  </div> 

                                                </div>                           
                                                                                                                                                
                                              @endif  
                                               <div id="empwithmsaccnt">       
                                               </div>                                              
                                            </div>

                                            <div class="form-group">
                                              {{ Form::label('ins_main_comments', 'Inspector Comments', ['class' => 'col-lg-6 control-label ']) }}
                                              <div class="col-lg-6">
                                                {{ Form::text('ins_main_comments', $data->ins_main_comments, ['class' => 'form-control']) }}
                                              </div>
                                            </div> 

                                           <div class="form-group">
                                              <div class="row">
                                                {{ Form::label('ins_main_inspectors', 'Inspectors', ['class' => 'col-lg-6 control-label required']) }}
                                                {{ Form::label('ins_main_inspectors_firm', 'Firm', ['class' => 'colsm3']) }}
                                                {{ Form::label('ins_main_inspectors_name','Name', ['class' => 'colsm3']) }}
                                                 <button id="inspectorfirmname" class="onlinebtn" type="button"><b>+</b></button>
                                              </div> 

                                              <?php $j=1;$ins_main_inspectors=json_decode($data->ins_main_inspectors);?>
                                                @if(isset($data->ins_main_inspectors) && count($ins_main_inspectors))
                                                  @foreach($ins_main_inspectors as $ins_key=>$ins_main_inspectors_data)
                                                      @if(!empty(trim($ins_main_inspectors_data->firm)))
                                                         <div class="row">
                                                              <div class="col-lg-6"></div>
                                                                <div style="float: right;margin-top: 2px;margin-right: 26px;">
                                                                  <div class="row activty-rows" id="activty-rows<?php echo $j; ?>" style="margin-left:0px;">
                                                                    <div class="col-sm-1 activity-cols" style="display:none;">
                                                                      <span class="form-control activty-counts" >{{$j}}</span>
                                                                    </div>   
                                                                    <div class="col-lg-3" style="width: 197px;">
                                                                         <div class="form-group">
                                                                                <select id="ins_main_inspectors_firm<?php echo $j; ?>" name="ins_main_inspectors[<?php echo $j; ?>][firm]" style="width: 182px; height: 34px;margin-left: 15px;border:1px solid #CCCCCC;" class="ins_inspec">
                                                                                      <option value="">- Select -</option>
                                                                                      <option value="Microsoft" <?=$ins_main_inspectors_data->firm == 'Microsoft' ? ' selected="selected"' : '';?>>Microsoft</option>

                                                                                      <option value="WGroup" <?=$ins_main_inspectors_data->firm == 'WGroup' ? ' selected="selected"' : '';?>>WGroup</option>

                                                                                      <option value="IPForensics" <?=$ins_main_inspectors_data->firm == 'IPForensics' ? ' selected="selected"' : '';?>>IPForensics</option>

                                                                                      <option value="FreightWatch" <?=$ins_main_inspectors_data->firm == 'FreightWatch' ? ' selected="selected"' : '';?>>FreightWatch</option>

                                                                                      <option value="Cisco" <?=$ins_main_inspectors_data->firm == 'Cisco' ? ' selected="selected"' : '';?>>Cisco</option>                  
                                                                                </select>                             
                                                                         </div>
                                                                    </div>
                                                                    <div class="col-lg-3" style="width: 197px;">
                                                                         <div class="form-group">
                                                                                  <select id="ins_main_inspectors_name<?php echo $j; ?>" name="ins_main_inspectors[<?php echo $j; ?>][name]" style="width: 182px; height: 34px;margin-left: 15px;" class="ins_inspec1">
                                                                                       <option value="{{$ins_main_inspectors_data->firm}}" <?=$ins_main_inspectors_data->name == $ins_main_inspectors_data->name ? ' selected="selected"' : '';?>>{{$ins_main_inspectors_data->name}}</option>    
                                                                                  </select>
                                                                          </div>
                                                                    </div>
                                                                    <div class="col-lg-1">
                                                                       <span class="glyphicon glyphicon-remove ins_main_remove"   id="ins_main_remove<?php echo $j; ?>" alt="<?php echo $j; ?>" aria-hidden="true" style="margin:10px 0 0 15px;cursor: pointer;"></span>
                                                                    </div>
                                                                  </div>
                                                                </div> 
                                                         </div>
                                                          <?php $j=$j+1; ?>
                                                        @endif
                                                  @endforeach 
                                                @else
                                                   <div class="row">
                                                     <div class="col-lg-6"> </div>  
                                                        <div class="row activty-rows" id="activty-rows1" style="float:left;margin-left:15px">
                                                          <div class="col-sm-1 activity-cols" style=" display:none;">
                                                            <span class="form-control activty-counts" >1</span>
                                                          </div>  
                                                          <div class="col-lg-3" style="width: 197px;">
                                                            <div class="form-group">
                                                              <select id="ins_main_inspectors_firm1" name="ins_main_inspectors[1][firm]" style="width: 182px; height: 34px;border:1px solid #CCCCCC;" class="ins_inspec" >
                                                                <option value="">- Select -</option>
                                                                <option value="Microsoft">Microsoft</option>
                                                                <option value="WGroup">WGroup</option>
                                                                <option value="IPForensics">IPForensics</option>
                                                                <option value="FreightWatch">FreightWatch</option>
                                                                <option value="Cisco">Cisco</option>                  
                                                              </select>           
                                                            </div>
                                                          </div> 
                                                          <div class="col-lg-3" style="width: 197px;">
                                                            <div class="form-group">
                                                              <select id="ins_main_inspectors_name1" name="ins_main_inspectors[1][name]" style="width: 182px; height: 34px;border:1px solid #CCCCCC;" class="ins_inspec1">
                                                                <option value="">- Select -</option>
                                                              </select>
                                                            </div>
                                                          </div>
                                                        </div>
                                                      </div>
                                                @endif
                                            </div>
                                            <div class="row">
                                              <div class="col-lg-6"> </div>
                                              <div id="insfirmname" style="float: right;width:420px;margin-top:-15px;">                                            
                                              </div>                      
                                            </div>

                                    </div>

                                    <div class="col-lg-3">
                                         <div class="pull-right text-danger">
                                            (*) Mandatory Field
                                        </div>
                                        <div class="text-center">
                                          <div style="margin-top: 20px">
                                            <i style="font-size: 180px; color: #e5e5e5" class="fa fa-sign-in"></i>
                                          </div>
                                        </div>
                                     </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                                  @if($edit)
                                      {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                      {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.show', $data->id),'id'=>'sitemaster_cancel_edit']) }}
                                  @else
                                      {{form::hidden('inspection_num',Input::get('inspection_num'))}}
                                      {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                      {{ Form::button('Save as Draft', ['type' => 'button', 'class' => 'btn btn-info','alt'=>route('sitemaster.inspectionprstore',[$data->id,'draft']),'id'=>'sitemaster_inspection_save_draft']) }}
                                      {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.index'),'id'=>'sitemaster_cancel']) }}
                                  @endif
                            </div>
                        {{ Form::close() }}
                     </div>  <!--/* .wizard_body -->
                </div>    <!--/* .ibox-content -->
              </div>  <!--/* .ibox -->
          </div> <!--/* .col-lg-12 -->
        </div>  <!--/* .row-->
      </div>  <!--/. animated-->
</div><!-- /.body_content -->                          
@stop
