@extends('layouts.pdf-master') @section('content')
<div class="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
			<h1 class="page-header">{{$sitemaster->site_name}}
				[#{{$sitemaster->id}}]</h1>
		</div>
	</div>

	<div class="tab-content sitemaster-show-pdf">
		<div class="tab-pane active">
			<div class="col-lg-7">
				<div class="panel panel-default">
					<div class="panel-heading">Basic Information</div>
					<!-- /.panel-heading -->
					<div class="panel-body">
						<div class="table-responsive">
							<table class="incidents-basic-table">
								<tbody>
									<tr data-id="{{ $sitemaster->id }}"
										style="vertical-align: top;">
										<td><b>Site Name</b><br />
											<p>@if(!empty($sitemaster->site_name)) {{
												$sitemaster->site_name }} @else Not Specified @endif</p></td>
										<td><b>Region</b><br />
											<p>@if(!empty($sitemaster->region->name)) {{
												$sitemaster->region->name }} @else Not Specified @endif</p>
										</td>
										<td><b>Postal Address</b><br />
											<p>@if(!empty($sitemaster->address)){{$sitemaster->address}}@else
												Not Specified @endif</p></td>
									</tr>

									<tr data-id="{{ $sitemaster->id }}">
										<td><b>Status</b><br />
											<p>@if(!empty($sitemaster->status)){{ ($sitemaster->status)
												}}@else Not Specified @endif</p></td>
										<td><b>Country</b><br />
											<p>@if(!empty($sitemaster->country->name)){{$sitemaster->country->name
												}}@else Not Specified @endif</p></td>
										<td><b>Postal Code</b><br />
											<p>@if(!empty($sitemaster->postal_code)){{$sitemaster->postal_code}}@else
												Not Specified @endif</p></td>
									</tr>

									<tr data-id="{{ $sitemaster->id }}">
										<td><b> Country State</b><br />
											<p>@if(!empty($sitemaster->country_state)){{$sitemaster->country_state}}@else
												Not Specified @endif</p></td>
										<td><b>City</b><br />
											<p>@if(!empty($sitemaster->city)){{$sitemaster->city}}@else
												Not Specified @endif</p></td>
										<td><b>Supplier Type</b><br />
											<p>@if(!empty($sitemaster->supplier_type)){{$sitemaster->supplier_type}}@else
												Not Specified @endif</p></td>
									</tr>
									<tr data-id="{{ $sitemaster->id }}">
										<td><b>GPS Coordinate</b><br />
											<p>@if(!empty($sitemaster->coordinates)){{
												$sitemaster->coordinates }}@else Not Specified @endif</p></td>
									</tr>
								</tbody>
							</table>
							<!--  <div id="sitemaster_map" class="detail-view-map span12">
                              </div>-->
						</div>
					</div>
				</div>
				<!-- /.panel-default -->
				<div class="panel panel-default">
					<div class="panel-heading pdf">Contact Information</div>
					<!-- /.panel-heading -->
					<div class="panel-body">
						<div class="table-responsive contact_info">
							<table class="incidents-basic-table">
								<tbody>
									<tr data-id="{{ $sitemaster->id }}">
										<td><b>Site Contact name</b><br />
											@if(!empty($sitemaster->contact_name))
											<p>{{$sitemaster->contact_name}}</p> @else Not Specified
											@endif</td>
										<td><b> Site contact Email</b><br />
											@if(!empty($sitemaster->contact_email))
											<p>{{$sitemaster->contact_email}}</p> @else Not Specified
											@endif</td>
										<td><b>Otder Contact Information</b><br />
											@if(!empty($sitemaster->otder_contact_info))
											<p>{{$sitemaster->otder_contact_info}}</p> @else Not
											Specified @endif</td>
									</tr>
								
									<tr data-id="{{ $sitemaster->id }}">
										<td><b>Created by</b>
											<p>
												<span>{{ $sitemaster->user->name }}</span>
											</p></td>
										<td><b>Created On</b>
											<p>
												<span>{{ $sitemaster->created_at->format('M d, Y h:i A') }}</span>
											</p></td>
										<td><b>Site Master ID</b>
											<p>
												<span>{{ $sitemaster->name }}</span>
											</p></td>
										<td><b>Status</b>
											<p>
												<span
													class="label @if($sitemaster->status == 'active') label-success @else label-danger @endif">
													{{ucfirst($sitemaster->status)}} </span>
											</p></td>
									</tr>
									<tr>
										<td colspan="3"><b> Site visit schedule </b>
											<p>
												<span> @if(\Auth::User()->site_user_level == 'csm') <span
													class="input-group-addon span_sit_vist"><i
														class="fa fa-calendar"></i></span>
													{{Form::text('sit_vist',$sitemaster->next_site_visit,['class'=>'form-control
													sit_visit_input'])}} @else {{$sitemaster->next_site_visit ?
													$sitemaster->next_site_visit->format('M d, Y') : 'Not
													Specified'}} @endif
												</span>
											</p></td>
								
								</tbody>
							</table>
						</div>
					</div>
					<!-- /.panel-body -->
				</div>
				<!-- /.panel-default -->
				<div class="panel panel-default">
					<div class="panel-heading"><span>Site Information</span></div>
					<!-- /.panel-heading -->
					<div class="panel-body">
						<div class="table-responsive site_info">
							<table class="incidents-basic-table">
								<tbody>
									<tr>
										<td colspan="3">The supplier handles unannounced components/
											products containing device ID (size, look, specifications,
											etc.) <br />
											<p>
												@if(!empty($sitemaster->supplier_handle)) <span
													class="label label-success"> Yes </span> @else <span
													class="label label-danger"> No </span> @endif
											</p>
										</td>
									</tr>
									<tr data-id="{{ $sitemaster->id }}">
										<td><b> Line of Business</b><br />
											<p>@if(!empty($sitemaster->lob)){{$sitemaster->lob}}@else Not
												Specified @endif</p></td>
										<td><b>Process</b><br />
											<p>@if(!empty($sitemaster->process)){{$sitemaster->process}}@else
												Not Specified @endif</p></td>
										<td><b>Parent Site</b><br />
											<p>@if(!empty($sitemaster->parent_site))
												{{$sitemaster->parent_site}} @else Not Specified @endif</p>
										</td>
									</tr>

									<tr data-id="{{ $sitemaster->id }}">
										<td><b>Primary SCS Stakeholder </b><br />
											<p>@if(!empty($sitemaster->primary_stakeholder))
												{{$sitemaster->primary_stakeholder}} @else Not Specified
												@endif</p></td>
										<td><b>Secondary SCS Stakeholder </b><br />
											<p>@if(!empty($sitemaster->sec_stakeholder))
												{{$sitemaster->sec_stakeholder}} @else Not Specified @endif
											</p></td>
										<td><b>Channel Manager</b><br />
											<p>@if(!empty($sitemaster->channel_manager)){{$sitemaster->channel_manager}}@else
												Not Specified @endif</p></td>
									</tr>
									<tr data-id="{{ $sitemaster->id }}">
										<td><b>VAM</b><br />
											<p>@if(!empty($sitemaster->vam)){{$sitemaster->vam}}@else Not
												Specified @endif</p></td>
										<td><b>Last Inspection Date</b><br />
											<p>@if(isset($sitemaster->last_inspection_date))
												{{$sitemaster->last_inspection_date->format('M d, Y')}}
												@else Not Specified @endif</p></td>
										<td><b>C-TPAT SVI Number</b><br />
											<p>
												@if(!empty($sitemaster->c_tpat_svi_number)){{$sitemaster->c_tpat_svi_number}}@else
												Not Specified @endif</p></td>
									</tr>

									<tr data-id="{{ $sitemaster->id }}">
										<td><b>Number of corrective actions</b><br />
											<p>@if(!empty($sitemaster->corrective_actions)){{$sitemaster->corrective_actions}}@else
												Not Specified @endif</p></td>
										<td><b>Comments</b><br />
											<p>@if(!empty($sitemaster->comments)){{$sitemaster->comments}}@else
												Not Specified @endif</p></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>
					<!-- /.panel-body -->
				</div>
				<!-- /.panel-default -->
			</div>
			<!-- /. cols-5 -->
		</div>
		<!--/. tab d -->
		<div class="tab-pane active">
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-heading pdf">
						P+R Inspection
					</div>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="row">
							<div class="col-md-12">

								<div class="box box-primary">
									<div class="box-header witd-border">
										<i class="fa fa-fw fa-table"></i>
										<h3 class="box-title">Corrective Actions</h3>
										<div class="box-tools pull-right">
											@if(!empty(Input::get('uid'))) {{-- */ $user_inspnum =
											explode("_",Input::get('uid')); /* --}} @if(\Auth::user()->id
											== $user_inspnum[0]) {{ Form::open(['route' =>
											['sitemaster.inspection',$sitemaster->id,'online'], 'metdod'
											=> 'post']) }} {{form::hidden('inspection_type','exist' )}}
											{{form::hidden('inspection_num',$user_inspnum[1])}} {{
											Form::button('Edit Inspection', ['type' => 'submit', 'class'
											=> 'btn btn-primary btn-xs']) }} {{ Form::close() }} @endif
											@endif</div>
									</div>
										<div class="col-lg-12">
											@if(isset($CA) && !empty($CA))
											<div class="table-responsive ca-form-tabs_pdf">
												<table class="table table-hover table-striped">
													<tbody>
														<tr id="suppliers-head">
															<td>ID</td>
															<td id="p_r_reference">P+R reference</td>
															<td id="p_r_version">P+R version</td>
															<td>P+R text</td>
															<td>Severity</td>
															<td>Inspector Comments</td>
															<td>Initial due date</td>
															<td>Ext. due date</td>
															<td>VAM Approval</td>
															<td id="overdue">Overdue</td>
														</tr>
														@foreach($CA as $ca)
														<tr data-id="{{$ca->id}}">
															<td>{{$ca->id}}</td>
															<td id="p_r_reference">{{$ca->p_r_reference}}</td>
															<td id="p_r_version">{{$ca->p_r_version}}</td>
															<td>{{$ca->p_r_text}}</td>
															<td>
															{{-- */ $p_r_severity  = ucfirst(strtolower(trim($ca->p_r_severity))); /*--}}
                                                             <span class="label {{$PR_Severity['ClassName'][$p_r_severity]}}">{{$p_r_severity}}</span>
															</td>
															<td>{{$ca->inspector_comments}}</td>
															<td>{{$ca->intial_due_date->format('d-M-Y')}}</td>
															<td>@if(!empty($ca->due_date_extension)){{$ca->due_date_extension->format('d-M-Y')}}@elseif($ca->days_past_due
																== null && $ca->supplier_request_closure=='inprogress')<span
																class="label label-pending"> Pending </span>@else N/A
																@endif
															</td>
															<td><span
																class="label @if($ca->vam_approval == 'accept') label-success @else label-danger @endif">
																	@if($ca->vam_approval == 'accept') Closed @else Open
																	@endif </span></td>
																															<?php
																	$intial_due_date = $ca->intial_due_date->diffInDays ( \Carbon\Carbon::today (), false );
																	if (! empty ( $ca->due_date_extension )) {
																	$due_date_extension = $ca->due_date_extension->diffInDays ( \Carbon\Carbon::today (), false );
																	} else
																	$due_date_extension = 0;
																	?>
															<td><span
															class="label @if(($intial_due_date < 0 && $due_date_extension <= 0
															) || $ca->vam_approval == 'accept') label-success @else label-danger @endif">
															@if(($intial_due_date < 0 && $due_date_extension <= 0
															) || $ca->vam_approval == 'accept') No @else Yes
															@endif </span></td>
														</tr>
														{{-- */ $ca_json[$ca->id] = $ca; /* --}}
														 {{-- */ $ca_json[$ca->id]['severity'] = $ca->p_r_severity; /* --}}  
														  @endforeach
													</tbody>
												</table>
											</div>
											@else
											<div class="alert alert-warning">This site master does not
												have any corrective actions.</div>
											@endif
										</div>

								</div>
							</div>
						</div>
					</div>
				</div>
				@if(count($prlogs))
				<div class="panel panel-default">
					<div class="panel-heading pdf">History Log</div>
					<div class="panel-body">
						
							<table class="incidents-basic-table">
								<tbody>
									@if(count($prlogs)) @foreach($prlogs as $log)
									<tr>
										<td>@if($log->updated_at != Null ) {{
											$log->updated_at->format('M d, Y h:i A') }} -
											{{ucfirst($log->type)}} by {{ $log->user->name }}
											@elseif($log->requested_at != Null ) {{ date('M d, Y h:i
											A',strtotime($log->requested_at)) }} -
											{{ucfirst($log->type)}} inspection review requested by {{
											$log->user->name }} @elseif($log->cleared_at != Null ) {{
											date('M d, Y h:i A',strtotime($log->cleared_at)) }} -
											{{ucfirst($log->type)}} inspection review cleared by {{
											$log->user->name }} @endif</td>
									</tr>
									@endforeach @endif
								</tbody>
							</table>
					</div>
					<!-- /.panel-body -->
				</div>
				@endif
			</div>
		</div>
	</div>




</div>
<!-- page-wrapper 

<script src="https://js.api.here.com/ee/2.5.4/jsl.js?witd=all" type="text/javascript" charset="utf-8"></script>-->
<script type="text/javascript">
  var Sitemasters = {
    mapElement: 'sitemaster_map',
    coordinates: '{{$coordinates}} '
  };
  var incident_history_json = null;
  var incident_prevention_json = null;
  var business_activity = null;
  var business_assets = null;
  var business_lob = null;
  var business_risk = null;
  var business_actions= null;
  var leak_risk_analysis = null;
  var corrective_actions = null;
  var lp_corrective_actions = null;
  var accessname = null;
</script>
@stop
