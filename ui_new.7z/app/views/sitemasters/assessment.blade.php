@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($assessment_type=='onsite')<h1 class="page-header">Onsite-Assessment</h1>
                @elseif($assessment_type=='self')<h1 class="page-header">Self-Assessment</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>

        <!--?php print($data); ?-->
        
              
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default" style="width:1300px">
                    <div class="panel-heading">Questions</div>
                    @if($assessment_type=='onsite')
                        {{ Form::open(['route' => ['sitemaster.onsite_assessment_store',$sitemaster->id], 'method' => 'post', 'class' => 'supplier-assessment-form', 'role' => 'form', 'id' => 'form-summary', 'files' => true]) }}
                    @else
                        {{ Form::open(['route' => ['sitemaster.self_assessment_store',$sitemaster->id], 'method' => 'post', 'class' => 'supplier-assessment-form', 'role' => 'form', 'id' => 'form-summary', 'files' => true]) }}
                    @endif
                    <div class="panel-body">
                    <ul class="nav nav-tabs">
                        <?php $coun=0;$activitykey=0;$activityvalue='Questionnaire';?>
                        
                        <li id="{{$activitykey.'-tab'}}" @if($coun==0) class="active" @endif><a href="#{{$activitykey}}" data-toggle="tab">{{ $activityvalue }}</a></li>
                                
                        
                     </ul>   
                    @if(!empty($questions))
                    <div class="tab-content panel-group">
                        <?php $cnt=0;$activitykey=0;$activityvalue='Questionnaire';?>
                            <div  @if($cnt==0) class="tab-pane active" @else class="tab-pane" @endif id="{{$activitykey}}">
                                <?php $value_show=$activitykey;$activity_key=$activitykey ?>
                                @foreach($categories as  $category_id=>$category)
                                    <?php $categoryenc=md5($activityvalue.$category);$accordion=md5('accordion'.$activityvalue);?>
                                    <div class="panel panel-default">
                                        <div class="panel-heading">
                                            <h4 class="panel-title">
                                                <a data-toggle="collapse" data-parent="#{{$accordion}}" href="#{{ $categoryenc }}">
                                                    {{ $category }}
                                                </a>
                                            </h4>
                                        </div>
                                        <div id="{{  $categoryenc }}" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                <div class="panel-group" id="accordion_{{  $categoryenc }}">
                                                  <div class="row">
                                                    <div class="form-group col-lg-8">
                                                      <b>Question</b>  
                                                    </div>
                                                    <div class="form-group col-lg-2"><b> Self-Assessment</b>   
                                                    </div>
                                                    <div class="form-group col-lg-2"> <b> Onsite-Assessment </b>    
                                                    </div> <!---->
                                                </div>
                                                    <?php $question_val = 0;$total=count($questions); ?>
                                                    @foreach($questions as  $question)
                                                        @if($question_val<$total-1)
                                                            @if($question['category_id']==$category_id)

                                                                <?php $id = $question['id']; ?>
                                                             {{ Form::hidden($value_show."display[$id]", $value_show) }}
                                                                <div class="row">
                                                                    <div class="form-group col-lg-8">
                                                                        {{ Form::label($value_show."question$id", $question['name'], ['class' => 'control-label']) }}
                                                                    </div>
                                                                    @if($assessment_type=='onsite')
                                                                    <div class="form-group col-lg-2">    
                                                                        {{ Form::select($value_show."question[$id]", $answers, ((isset($assessment_data[$activity_key]->self_answer_id) && isset($assessment_data[$activity_key]->self_answer_id[$id])) ? $assessment_data[$activity_key]->self_answer_id[$id] : null), ['class' => 'form-control ','disabled'=>'disabled', 'id' => $value_show."self_question$id"]) }}
                                                                        <?php $form_control = (!empty($assessment_data[$activity_key]->self_comment[$id]) && isset($assessment_data[$activity_key]->self_comment[$id])) ? 'form-control' : 'hidden' ?>
                                                                        <a onClick="document.getElementById('{{$value_show}}selfcomment{{ $id }}').className='form-control';" href="javascript:void(0);" class="comment-link" disabled="disabled">SA Comment</a>
                                                                        {{ Form::textarea($value_show."selfcomment[$id]", ((!empty($assessment_data[$activity_key]->self_comment[$id]) && isset($assessment_data[$activity_key]->self_comment[$id])) ? $assessment_data[$activity_key]->self_comment[$id] : ''),['class' => $form_control,'disabled'=>'disabled', 'rows' => 2, 'id' => $value_show."selfcomment$id",'maxlength' =>100]) }}
                                                                    </div>
                                                                    <div class="form-group col-lg-2">    
                                                                        {{ Form::select($value_show."question[$id]", $answers, ((isset($assessment_data[$activity_key]->onsite_answer_id) && isset($assessment_data[$activity_key]->onsite_answer_id[$id])) ? $assessment_data[$activity_key]->onsite_answer_id[$id] : null), ['class' => 'form-control ', 'id' => $value_show."onsite_question$id"]) }}
                                                                        <?php $form_control = (!empty($assessment_data->onsite_comment[$id]) && isset($assessment_data->onsite_comment[$id])) ? 'form-control' : 'hidden' ?>
                                                                        <a onClick="document.getElementById('{{$value_show}}onsitecomment{{ $id }}').className='form-control';" href="javascript:void(0);" class="comment-link">OSA Comment</a>
                                                                        {{ Form::textarea($value_show."onsitecomment[$id]", ((isset($assessment_data[$activity_key]->onsite_comment) && isset($assessment_data[$activity_key]->onsite_comment[$id])) ? $assessment_data[$activity_key]->onsite_comment[$id] : ''), ['class' => $form_control, 'rows' => 2, 'id' => $value_show."onsitecomment$id" ,'maxlength' =>100]) }}
                                                                    </div>
                                                                    @else
                                                                    <div class="form-group col-lg-2">
                                                                        {{ Form::select($value_show."question[$id]", $answers, ((isset($assessment_data[$activity_key]->self_answer_id) && isset($assessment_data[$activity_key]->self_answer_id[$id])) ? $assessment_data[$activity_key]->self_answer_id[$id] : null), ['class' => 'form-control ', 'id' => $value_show."self_question$id"]) }}
                                                                        <?php $form_control = (!empty($assessment_data[$activity_key]->self_comment[$id]) && isset($assessment_data[$activity_key]->self_comment[$id])) ? 'form-control' : 'hidden' ?>
                                                                        <a onClick="document.getElementById('{{$value_show}}selfcomment{{ $id }}').className='form-control';" href="javascript:void(0);" class="comment-link" >SA Comment</a>
                                                                        {{ Form::textarea($value_show."selfcomment[$id]", ((!empty($assessment_data[$activity_key]->self_comment[$id]) && isset($assessment_data[$activity_key]->self_comment[$id])) ? $assessment_data[$activity_key]->self_comment[$id] : ''),['class' => $form_control, 'rows' => 2, 'id' => $value_show."selfcomment$id",'maxlength' =>100]) }}
                                                                    </div>
                                                                  <div class="form-group col-lg-2">  
                                                                        {{ Form::select("$value_show.question[$id]", $answers, ((isset($assessment_data[$activity_key]->onsite_answer_id) && isset($assessment_data[$activity_key]->onsite_answer_id[$id])) ? $assessment_data[$activity_key]->onsite_answer_id[$id] : null), ['class' => 'form-control','disabled'=>'disabled', 'id' => $value_show."onsite_question$id"]) }}
                                                                        <?php $form_control = (!empty($assessment_data[$activity_key]->onsite_comment[$id]) && isset($assessment_data[$activity_key]->onsite_comment[$id])) ? 'form-control' : 'hidden' ?>
                                                                        <a onClick="document.getElementById('{{$value_show}}onsitecomment{{ $id }}').className='form-control';" href="javascript:void(0);" class="comment-link" disabled="disabled">OSA Comment</a>
                                                                        {{ Form::textarea($value_show."onsitecomment[$id]", ((isset($assessment_data[$activity_key]->onsite_comment) && isset($assessment_data[$activity_key]->onsite_comment[$id])) ? $assessment_data[$activity_key]->onsite_comment[$id] : ''), ['class' => $form_control, 'disabled'=>'disabled','rows' => 2, 'id' => $value_show."onsitecomment$id",'maxlength' =>100]) }}
                                                                    </div>  <!-- -->
                                                                    @endif
                                                                </div>
                                                                <div class="box box-default">
                                                                </div>
                                                            @endif
                                                        @endif    
                                                        <?php $question_val++?>  
                                                    @endforeach 
                                                
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                @endforeach
                            </div> 
                            <?php $cnt++;?>   
                           
                            
                    </div>
                    @else
                        <p>There are no questions & answers.</p>
                    @endif
                </div>
                        
                        <div class="panel-footer">
                        {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default','alt' => route('sitemaster.show', $sitemaster->id),'id'=>'sitemaster_cancel']) }}
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            </div>
            <!-- /.col-lg-12 -->
        
    </div>
</div>
            <!-- /.col-lg-12 -->                          
@stop
