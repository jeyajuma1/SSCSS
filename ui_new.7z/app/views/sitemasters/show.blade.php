@extends('layouts.master')
@section('content')
 {{-- */ $ca_json = []; $lp_ca_json =[]; /* --}}
 {{-- */ $pr_access_name = \MSLST\Helpers\Common::canAccessPR(\Auth::user(), $sitemaster); /* --}}
 {{-- */ $lp_access_name = \MSLST\Helpers\Common::canAccessLP(\Auth::user(), $sitemaster); /* --}}

	<div class="row border-bottom white-bg page-heading">
				<div class="row">
						<div class="col-lg-12">
							<h2 class="show_page_header">{{$sitemaster->site_name}}</h2>
							<div class="pull-right page_header_btn">
							 	 {{ Form::open(['route' => 'sitemaster.index', 'method' => 'get']) }}
                      					{{ Form::button('<i class="fa fa-arrow-left"> Go Back</i>', ['type' => 'submit', 'class' => 'btn btn-outline btn-default', 'onclick' => 'javascript:history.back()']) }}
                   				 {{ Form::close() }}

								 {{form::hidden('supplier_user_id',$sitemaster->user_id)}}
								 {{form::hidden('supplier_user_name',$sitemaster->user->name)}}
								 {{form::hidden('login_user_id',\Auth::user()->id)}}
								 {{form::hidden('supplier_id',$sitemaster->id)}}
								 {{Form::hidden('sit_vist_hidden',$sitemaster->next_site_visit)}}

                  
		                    	 @if (\Auth::User()->isAdmin() || \Auth::User()->isSupervisor() || \Auth::User()->isManager())
		                     
			                       @if($sitemaster->status == 'active')
			                        {{ Form::open(['route' => ['sitemaster.status', $sitemaster->id,'Inactive'] , 'method'=>'patch']) }}
			                            {{ Form::button('Set Inactive',['type' => 'submit' , 'class' =>'btn-blue location-inactive-button' ]) }}
			                        {{ Form::close() }}
			                       @elseif($sitemaster->status == 'inactive')
			                        {{ Form::open(['route' => ['sitemaster.status', $sitemaster->id,'Active'] , 'method'=>'patch']) }}
			                            {{ Form::button('Set Active',['type' => 'submit' , 'class' =>'btn-blue location-active-button' ]) }}
			                        {{ Form::close() }}
			                       @endif

	                   				 {{ Form::open(['route' => ['sitemaster.pdf_report', $sitemaster->id] , 'method'=>'patch']) }}
	                           				 {{ Form::button('<i class="fa fa-file-pdf-o"> PDF Report</i> ',['type' => 'submit' , 'class' =>'btn btn-outline btn-info' ]) }}
	                        		 {{ Form::close() }}
                        		  @endif
							</div>
						</div>
					</div>
	</div>

	<div class="row">
		 <div class="wrapper-content animated fadeIn">
				<div class="row">
					<div class="col-lg-12">
						<div class="tabs-container">
						  <ul class="nav nav-tabs">
								<li class="active"><a href="#a" data-toggle="tab">Basic</a></li>
								@if(\MSLST\Helpers\Common::canAccessEdit(null, 'p_r', null, $sitemaster))
									<li><a href="#b" data-toggle="tab">SCS Inspections</a></li> 
								@endif
								@if(\Auth::user()->access_leak_prevention)
									<li><a href="#c" data-toggle="tab">Leak Prevention</a></li>
								@endif
							</ul>
							<div class="tab-content">
								<div id="a" class="tab-pane active">
									<div class="panel-body">
										<div class="col-lg-7">
											<div class="ibox float-e-margins">
												<div class="ibox-title">
													<h5>
														<i class="fa fa-briefcase"></i> Basic Information
													</h5>
													<div class="ibox-tools">
														@if(\MSLST\Helpers\Common::canAccessEdit(null, 'sitemaster', null, $sitemaster))
				                   							 <button type="button" class="btn btn-white tn-xs" href="{{ route('sitemaster.edit', [$sitemaster->id]) }}">
							                                	Edit
							                            	 </button> 
	                    								@endif
														<a class="collapse-link"> <i class="fa fa-chevron-up"></i>
														</a>
													</div>
												</div>
												<div class="ibox-content">
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Site Name</h3>
															<p>@if(!empty($sitemaster->site_name)) {{ $sitemaster->site_name }} @else  Not Specified @endif </p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Region</h3>
															<p>@if(!empty($sitemaster->region->name)) {{$sitemaster->region->name }} @else  Not Specified @endif</p>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Status</h3>
															<p>@if(!empty($sitemaster->status)){{ ($sitemaster->status) }}@else  Not Specified @endif</p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Supplier Type</h3>
															<p>@if(isset($sitemaster->supplier_type) && !empty($sitemaster->supplier_type))
																{{str_replace('Other (Please describe in Comment field)','',implode(" ,",json_decode($sitemaster->supplier_type)))}}@else  Not Specified @endif
																@if(!empty($sitemaster->supplier_other_type)){{ $sitemaster->supplier_other_type}} @endif</p>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Postal Address</h3>
															<p>
																@if(!empty($sitemaster->address)){{$sitemaster->address}}@else  Not Specified @endif
															</p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Postal Code</h3>
															<p>@if(!empty($sitemaster->postal_code)){{$sitemaster->postal_code}}@else  Not Specified @endif</p>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Country</h3>
															<p>@if(!empty($sitemaster->country->name)){{$sitemaster->country->name }}@else  Not Specified @endif</p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Country State</h3>
															<p>@if(!empty($sitemaster->country_state)){{$sitemaster->country_state}}@else  Not Specified @endif</p>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">City</h3>
															<p>@if(!empty($sitemaster->city)){{$sitemaster->city}}@else  Not Specified @endif</p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">GPS Coordinate</h3>
															<p>@if(!empty($sitemaster->coordinates)){{ $sitemaster->coordinates }}@else  Not Specified @endif</p>
														</div>
													</div>
													<!--<hr style="clear: both;">-->
													<div class="row">
														<div class="col-sm-12">
															<div id="sitemaster_map" class="detail-view-map span12 col-sm-12" ></div>
														</div>
													</div>
													<hr style="clear: both;">
												</div>
											</div>
											<div class="ibox float-e-margins">
												<div class="ibox-title">
													<h5>
														<i class="fa fa-history"></i> History Log
													</h5>
													<div class="ibox-tools">

														<a class="collapse-link"> <i class="fa fa-chevron-up"></i>
														</a>
													</div>

												</div>
												<div class="ibox-content">
													  <div class="table-responsive history_log_site_basic">
									                        <table class="tbody-small">
									                            <tbody >
									                              <tr  class="font-black-small">
									                                  <td>
									                                    {{ $sitemaster->created_at->format('M d, Y h:i A') }} - Created by {{ $sitemaster->user->name }}
									                                  </td>
									                                </tr>
									                              @if(count($sitemaster->sitemaster_log))
									                                @foreach($sitemaster->sitemaster_log as $log)
									                                  <tr  class="font-black-small">
									                                    <td>
									                                      @if($log->updated_at != Null )
									                                          {{ $log->updated_at->format('M d, Y h:i A') }} - Edited by {{ $log->user->name }}
									                                      @elseif($log->requested_at != Null )
									                                          {{  date('M d, Y h:i A',strtotime($log->requested_at))  }} - Review requested by {{ $log->user->name }}
									                                      @elseif($log->cleared_at != Null )
									                                          {{  date('M d, Y h:i A',strtotime($log->cleared_at))  }} - Review cleared by {{ $log->user->name }}
									                                      @endif
									                                    </td>
									                                  </tr>
									                                @endforeach
									                              @endif
									                            </tbody>
									                        </table>
                     								  </div>
												</div>
												<!-- /.panel-body -->
											</div>
										</div>
										<div class="col-lg-5">
											<div class="ibox float-e-margins">
												<div class="ibox-title">
													<h5>
														<i class="fa fa-user"></i> Contact Information
													</h5>
													<div class="ibox-tools">														 
														 @if (\MSLST\Helpers\Common::canAccessEdit(null, 'sitemaster', null, $sitemaster))
									                              <button type="button" class="btn btn-white btn-xs" href="{{ route('sitemaster.edit', [$sitemaster->id, 2]) }}">
									                                  Edit
									                              </button> 
									                      @endif
														<a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>
													</div>
												</div>
												<div class="ibox-content">
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Site Contact name</h3>
															<p> @if(!empty($sitemaster->contact_name))
                    												{{$sitemaster->contact_name}}	
                   												@else 
                      												Not Specified
                    											@endif
                    										</p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Site contact Email</h3>
															<p> @if(!empty($sitemaster->contact_email))
											                     {{$sitemaster->contact_email}} 
											                    @else 
											                      Not Specified
											                    @endif
											                </p>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Other Contact Information</h3>
															<p>@if(!empty($sitemaster->other_contact_info))
												                   {{$sitemaster->other_contact_info}} 
												               @else 
												                   Not Specified
												               @endif
												             </p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Created by</h3>
															<p>{{ $sitemaster->user->name }}</p>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Created On</h3>
															<p>{{ $sitemaster->created_at->format('M d, Y h:i A') }}</p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Site ID</h3>
															<p>{{ $sitemaster->name }}</p>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Status</h3>
															<p>
																<span class="label @if($sitemaster->status == 'Active') label-success @else label-danger @endif">
                                                   					 {{ucfirst($sitemaster->status)}}
                                           						</span>
															</p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Last Inspection Date</h3>
															<p>
																  @if(isset($sitemaster->last_inspection_date))
                                    									{{$sitemaster->last_inspection_date->format('M d, Y')}}
								                                  @else
								                                    Not Specified
								                                  @endif
                                                  			</p>
														</div>
													</div>

													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Site visit schedule</h3>
															<p>
																@if(\Auth::User()->site_user_level == 'csm')
                                                       					<span class="input-group-addon span_sit_vist"><i class="fa fa-calendar"></i></span>
                                                      					{{Form::text('sit_vist',($sitemaster->next_site_visit)?$sitemaster->next_site_visit->format('Y-m-d'): '',['class'=>'form-control sit_visit_input'])}}
                                                  				@else
			                                                    		{{$sitemaster->next_site_visit ? $sitemaster->next_site_visit->format('M d, Y') : 'Not Specified'}}
			                                                    @endif
                                                  			</p>
														</div>
														@if(isset($sitemaster->next_site_visit) && !empty($sitemaster->next_site_visit))
															<div class="col-sm-5">
																<h3 class="m-t-none m-b">Remaining Days</h3>
																<p>
																	<a class="btn btn-xs btn-primary">{{$sitemaster->next_site_visit->diffInDays(\Carbon\Carbon::now()) }} days</a>
																</p>
															</div>
														@endif
													</div>
													<div class="row">
														<div class="col-sm-12">
															 <table class="incidents-basic-table " >
								                                <tbody>
								                                    <tr class= "font-darkblue-first">
								                                        <td>
								                                        	Corrective Actions Summary
								                                        </td>
								                                     </tr>
								                                     <tr>
								                                        <td class="pr_ca_section">
													                        <div class="table-responsive ca-form-tabs" id="pr_ca_detail">
													                        	 <table class="table cascroll table-bordered" id="corrective_actions_summary">
													                        	 	<thead>
													                        	 		<tr>
														                        	 		<th>
														                        	 			Inspection
														                        	 			
														                        	 		</th>
														                        	 		<th>
														                        	 			Status
														                        	 		</th>
														                        	 		<th>
														                        	 			Total CAs
														                        	 		</th>
														                        	 		<th>
														                        	 			Urgent
														                        	 		</th>
														                        	 		<th>
														                        	 			High
														                        	 		</th>
														                        	 		<th>
														                        	 			Medium
														                        	 		</th>
														                        	 		<th>
														                        	 			Low
														                        	 		</th>
														                        	  </tr>
														                        	
													                        	 	</thead>
													                        	 	<tbody>
													                        	 	<?php $i =1;?>
													                        	 		@forelse($basic_ca as $ky=>$pr_ca_val)
													                        	 		<tr>
														                        	 			<td rowspan="2"> Inspection {{$i++}} <br/> {{'@'.$pr_ca_val['date']->format('M/d/Y')}} </td>
														                        	 			<td>
														                        	 				 Open
														                        	 			</td>
														                        	 			<td> {{!empty($pr_ca_val['open']) ?  $pr_ca_val['open']['open_totalcas'] : 0}} </td>
														                        	 			<td><span class="rat_urg_class">
														                        	 				{{ !empty($pr_ca_val['open']) ? (array_key_exists('urgent', $pr_ca_val['open']) ==1) ? $pr_ca_val['open']['urgent']['cnt']: 0 : 0}}</span>
														                        	 			</td>
														                        	 			<td> <span class="rat_hig_class">  
														                        	 				{{ !empty($pr_ca_val['open']) ? (array_key_exists('high', $pr_ca_val['open']) ==1) ? $pr_ca_val['open']['high']['cnt']: 0 : 0}} </span>
														                        	 			</td>
														                        	 			<td> <span class="rat_mid_class">
														                        	 				{{ !empty($pr_ca_val['open']) ? (array_key_exists('medium', $pr_ca_val['open']) ==1) ? $pr_ca_val['open']['medium']['cnt']: 0 : 0}} </span>
														                        	 			</td>
														                        	 			<td> <span class="rat_low_class">
														                        	 			 	{{ !empty($pr_ca_val['open']) ? (array_key_exists('low', $pr_ca_val['open']) ==1) ? $pr_ca_val['open']['low']['cnt']: 0 : 0}} </span>
														                        	 			</td>
														                        	 		</tr> 
														                        	 		<tr> 
														                        	 			<td>
														                        	 				Closed
														                        	 			</td>
														                        	 			<td> {{!empty($pr_ca_val['closed']) ? $pr_ca_val['closed']['closed_totalcas'] : 0}}  </td>
														                        	 			<td> 
														                        	 				<span class="rat_urg_class">{{ !empty($pr_ca_val['closed']) ? (array_key_exists('urgent', $pr_ca_val['closed']) ==1) ? $pr_ca_val['closed']['urgent']['cnt']: 0  : 0}}</span>
														                        	 			</td>
														                        	 			<td> <span class="rat_hig_class">  
														                        	 				{{ !empty($pr_ca_val['closed']) ?  (array_key_exists('high', $pr_ca_val['closed']) ==1) ? $pr_ca_val['closed']['high']['cnt']: 0 : 0}}</span>
														                        	 			</td>
														                        	 			<td> <span class="rat_mid_class"> 
														                        	 				{{ !empty($pr_ca_val['closed']) ?  (array_key_exists('medium',$pr_ca_val['closed']) ==1) ? $pr_ca_val['closed']['medium']['cnt']: 0 : 0}} </span>
														                        	 			</td>
														                        	 			<td> <span class="rat_low_class"> 
														                        	 			 	{{ !empty($pr_ca_val['closed']) ? (array_key_exists('low', $pr_ca_val['closed']) ==1) ? $pr_ca_val['closed']['low']['cnt']: 0 : 0}} </span>
														                        	 			</td>
														                        	 		</tr>
														                        	 	@empty
														                        	 		   <tr>
														                        	 		   		<td colspan="7">
														                        	 		   			<div class="alert alert-warning">This site does not have any corrective actions.</div>
														                        	 		   	    </td>
														                        	 		   </tr>
													                        	 		@endforelse
													                        	 	</tbody>
													                        	 </table>
													                        </div>
													                    </td>
													                </tr>
													            </tbody>
													        </table> 

														</div>
													</div>
												</div>
											</div>
											<div class="ibox float-e-margins">
												<div class="ibox-title">
													<h5>
														<i class="fa fa-bank"></i> Site Information
													</h5>
													<div class="ibox-tools">
														@if (\MSLST\Helpers\Common::canAccessEdit(null, 'sitemaster', null, $sitemaster))
                    								        <button type="button" class="btn btn-white btn-xs" href="{{ route('sitemaster.edit', [$sitemaster->id, 1]) }}">
								                                Edit
								                            </button>
								                         @endif 
														<a class="collapse-link"> <i class="fa fa-chevron-up"></i>
														</a>
													</div>
												</div>
												<div class="ibox-content">
													<div class="row">
														<div class="col-sm-12">
															<p>
																The supplier handles unannounced components/ products
																containing device ID (size, look, specifications, etc.)

																 @if(!empty($sitemaster->supplier_handle)) 
                                      								<span class="label label-success"> Yes </span>
                                       							 @else
                                       								<span class="label label-danger"> No </span>
                                      							 @endif
															</p>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Line of Business</h3>
															<p>
															@if(isset($sitemaster->lob) && !empty($sitemaster->lob) && $sitemaster->lob != 'Null')
                    												{{str_replace('Other (Please describe in Comment field)','',implode(" ,",json_decode($sitemaster->lob)))}}@else  Not Specified @endif
                   											@if(!empty($sitemaster->lob_other_type)){{ $sitemaster->lob_other_type}} @endif
                   										   </p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Process</h3>
															<p>
																@if(isset($sitemaster->process) && !empty($sitemaster->process) && $sitemaster->process != 'Null'  )
											                    	{{str_replace('Other (Please describe in Comment field)','',implode(" ,",json_decode($sitemaster->process)))}}@else  Not Specified @endif
											                    @if(!empty($sitemaster->process_other_type)){{ $sitemaster->process_other_type}} @endif
                    										</p>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Parent Site</h3>
															<p>  @if(!empty($sitemaster->parent_site))
                                        							 {{$sitemaster->parent_site}}
							                                     @else
							                                      Not Specified
							                                     @endif
							                                </p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Primary SCS Stakeholder</h3>
															<p> @if(!empty($sitemaster->primary_stakeholder)) {{$sitemaster->primary_stakeholder}}
								                                @else
								                                    Not Specified
								                                @endif
								                            </p>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">Secondary SCS Stakeholder</h3>
															<p>  @if(!empty($sitemaster->sec_stakeholder)) {{$sitemaster->sec_stakeholder}}
							                                     @else
							                                    	 Not Specified
							                                     @endif
							                                </p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Channel Manager</h3>
															<p>@if(!empty($sitemaster->channel_manager)){{$sitemaster->channel_manager}}@else  Not Specified @endif</p>
														</div>
													</div>
													<div class="row">
														<div class="col-sm-7">
															<h3 class="m-t-none m-b">C-TPAT SVI Number</h3>
															<p>@if(!empty($sitemaster->c_tpat_svi_number)){{$sitemaster->c_tpat_svi_number}}@else  Not Specified @endif</p>
														</div>
														<div class="col-sm-5">
															<h3 class="m-t-none m-b">Associated Users</h3>
															<p  class="associated_users">
																 
								                                    <select class="selectpicker" id="associated_users" data-style="btn-info"  multiple title="Associated Users" >
										                                   @if(isset($user_assoc['optionvam']) && !empty($user_assoc['optionvam']))
															                    <optgroup label="VAM User" disabled >
															                     {{$user_assoc['optionvam']}}
															                    </optgroup>
														                   @endif
														                   @if(isset($user_assoc['optionlsp']) && !empty($user_assoc['optionlsp']))
														                    <optgroup label="Lsp User" disabled >
														                     {{$user_assoc['optionlsp']}}
														                    </optgroup>
														                   @endif
													                </select>
															</p>
														</div>
													</div>
												</div>
											</div>



										</div>
									</div>
								</div>
								<div id="b" class="tab-pane">
									<div class="panel-body pr_scs_inspection">
										   <div class="col-lg-12">
								                <div class="panel panel-default pull-right inspection_button">
							                         <div class="btn-group">
							                             @if(!empty($list_inspector))
							                                        {{ Form::select('status',$list_inspector['select_insepection'],Input::get('uid'),['class' => 'selectpicker','data-style'=>'btn-primary btn-sm' ,'title' => 'Select Inspection' ,'id'=>"selectInspectionID"]) }}
							                             @endif  
							                         </div>
								 
								                     @if(\Auth::user()->site_user_level == 'csm' || \Auth::user()->role == 'admin')
								                            <div class="btn-group">
								                                  {{ Form::button('New Offline Inspection', ['type' => 'submit', 'class' => 'btn btn-primary btn-sm','id'=>'offline_inspection']) }}
								                            </div>
								                            <div class="btn-group">
								                              @if(($pr_access_name == 'csm_user' || $pr_access_name == 'csm_plus_user' || $pr_access_name == 'admin') && (\Auth::User()->id  != $sitemaster->user_id) || 1==1)
								                                   {{ Form::open(['route' => ['sitemaster.prinspection',$sitemaster->id,'online',1], 'method' => 'get']) }} 
								                                    {{ Form::button('New Online Inspection', ['type' => 'submit', 'class' => 'btn btn-primary btn-sm','id'=>'online_inspection']) }}
								                                  {{ Form::close() }}
								                              @endif
								                             </div>
							                              @if(!empty($list_inspector) && !empty(Input::get('uid')))
								                               <div class="btn-group">
								                                {{ Form::button('Delete Inspection', ['type' => 'submit', 'class' => 'btn btn-danger btn-sm','id'=>'delete_inspection']) }}
								                              </div>
							                              @endif    
								                      @endif

								                </div>
             								</div>
		            						<div class="col-lg-12">
		                 						 <div class="panel panel-default">
									                  <div class="panel-body">
									                        <div class="row">
									                             <div class="col-md-12">
														              @if(!empty($CA))
														                     @if(!empty($CA) && !empty($insp_main_data))
													                            <div class="box box-primary panel-default">
													                                   <div class="box-header with-border  panel-heading">
														                                    <i class="fa fa-fw fa-table"></i>
														                                    <h3 class="box-title font-bold">Inspection Details</h3>
													                                        <div class="box-tools pull-right">
													                                            @if(!empty(Input::get('uid')))
													                                                          {{-- */ $user_inspnum = explode("_",Input::get('uid')); /* --}}
													                                                            @if(\Auth::user()->id == $user_inspnum[0])
													                                                              {{ Form::open(['route' => ['sitemaster.inspectionedit',$sitemaster->id,$user_inspnum[1],1], 'method' => 'post']) }}
													                                                                          {{form::hidden('inspection_type','exist' )}}
													                                                                          {{form::hidden('step',1)}}
													                                                                          {{form::hidden('inspection_num',$user_inspnum[1])}}
													                                                                          {{ Form::button('Edit', ['type' => 'submit', 'class' => 'btn btn-primary btn-xs']) }}
													                                                              {{ Form::close() }}
													                                                            @endif
													                                                      @endif
													                                        </div>
													                                   </div>
													                                    <div class="box-body">
														                                     <div class="table-responsive">
														                                         <table class="incidents-basic-table">
															                                            <tbody>
															                                               <tr class="m-t-none m-b font-bold" style="vertical-align: top;" data-id="1382">
															                                                  <td>Inspection Date </td>
															                                                  <td> Number of separate buildings at this site</td>
															                                                  <td> Number of buildings with Microsoft-related functions </td>
															                                               </tr>
															                                               <tr>
															                                                  <td>
															                                                     <p>{{$insp_main_data['ins_main_date']->format('M d, Y h:i A')}}</p>
															                                                  </td>
															                                                  <td>
															                                                     <p>{{$insp_main_data['ins_main_num_sep_buliding_at_this_site']}}</p>
															                                                  </td>
															                                                  <td>
															                                                     <p>{{$insp_main_data['ins_main_num_buliding_ms_related_functions']}}</p>
															                                                  </td>
															                                               </tr>
															                                               <tr class="m-t-none m-b font-bold" data-id="1382">
															                                                  <td> Number of full-time employees at this facility </td>
															                                                  <td> Supplier Subcontractor(s) Handling Microsoft product or IP</td>
															                                                  <td> Employees with Microsoft System Accounts </td>
															                                               </tr>
															                                               <tr>
															                                                  <td>
															                                                     <p>{{$insp_main_data['ins_main_num_full_time_emp_facility']}}</p>
															                                                  </td>
															                                                  <td>
															                                                     <p>{{$insp_main_data['ins_main_supp_subcontract_handling_ms_product_ip']}}</p>
															                                                  </td>
															                                                  <td>
															                                                     <p>{{$insp_main_data['ins_main_emp_ms_system_account']}}</p>
															                                                  </td>
															                                               </tr>
															                                               <tr class="m-t-none m-b font-bold" data-id="1382">
															                                                  <td>Comments:</td>
															                                                  
															                                               </tr>
															                                               <tr>
															                                                  <td>
															                                                     {{$insp_main_data['ins_main_comments']}}
															                                                  </td>
															                                                  
															                                               </tr>
															                                               <tr class="m-t-none m-b font-bold" data-id="1382">
															                                                  <td> Inspectors:</td>
															                                                  <td>Employees with Microsoft System Access:</td>
															                                               </tr>
															                                               <tr>
															                                                  <td>
															                                                    {{-- */ $inspector = json_decode($insp_main_data['ins_main_inspectors']) /* --}}
															                                                     <div class="col-lg-12">
															                                                        <div class="score-content ca-form-tabs">
															                                                           <table class="table">
															                                                              <thead>
															                                                                 <tr>
															                                                                    <th>Firm</th>
															                                                                    <th>Name</th>
															                                                                 </tr>
															                                                              </thead>
															                                                              <tbody>
															                                                              @foreach($inspector as $ky=>$value)
															                                                                 <tr>
															                                                                    <td>{{trim($inspector[$ky]->firm)}}</td>
															                                                                    <td>{{trim($inspector[$ky]->name)}}</td>
															                                                                 </tr>
															                                                              @endforeach
															                                                              </tbody>
															                                                           </table>
															                                                        </div>
															                                                     </div>
															                                                  </td>
															                                                  <td>
															                                                     {{-- */ 
															                                                              $ms_alias_access = json_decode($insp_main_data['ins_main_name_alias_access']);
															                                                              $ms_alias_access = array_filter($ms_alias_access);                                               
															                                                     /* --}}
															                                                     <div class="col-lg-12">
															                                                        <div class="score-content ca-form-tabs">
															                                                           <table class="table">
															                                                              <thead>
															                                                                 <tr>
															                                                                    <th>Name</th>
															                                                                    <th>Alias</th>
															                                                                    <th>Access</th>
															                                                                 </tr>
															                                                              </thead>
															                                                              <tbody>
															                                                              @foreach($ms_alias_access as $ky=>$value)
															                                                                 @if(!empty(trim($ms_alias_access[$ky]->name)))
															                                                                 <tr>
															                                                                    <td>{{trim($ms_alias_access[$ky]->name)}}</td>
															                                                                    <td>{{trim($ms_alias_access[$ky]->alias)}}</td>
															                                                                    <td>{{trim($ms_alias_access[$ky]->access)}}</td>
															                                                                 </tr>
															                                                                 @endif
															                                                              @endforeach
															                                                              </tbody>
															                                                           </table>
															                                                        </div>
															                                                     </div>

															                                                  </td>
															                                               </tr>
															                                            </tbody>
														                                          </table>
														                                      </div>
													                                    </div>
													                            </div>

													                            <div class="box box-primary panel-default">
										                                              <div class="box-header with-border panel-heading">
											                                               <i class="fa fa-fw fa-table"></i>
											                                               <h3 class="box-title">Corrective Actions </h3>
											                                               <div class="box-tools pull-right">
											                                                  @if(!empty(Input::get('uid')))
											                                                        {{-- */ $user_inspnum = explode("_",Input::get('uid')); /* --}}
											                                                          @if(\Auth::user()->id == $user_inspnum[0])
											                                                            {{ Form::open(['route' => ['sitemaster.inspectionedit',$sitemaster->id,$user_inspnum[1],2], 'method' => 'post']) }}
											                                                                        {{form::hidden('inspection_type','exist' )}}
											                                                                        {{form::hidden('step',2)}}
											                                                                        {{form::hidden('inspection_num',$user_inspnum[1])}}
											                                                                        {{ Form::button('Edit', ['type' => 'submit', 'class' => 'btn btn-primary btn-xs']) }}
											                                                            {{ Form::close() }}
											                                                          @endif
											                                                    @endif
											                                               </div> 
										                                              </div>
										                                              <div class="box-body">
										                                                    <div class="col-lg-12">
										                                                       @if(!empty($CA))
										                                                            <div class="table-responsive ca-form-tabs">
										                                                                   <table class="table table-hover table-striped" id="corrective_action_tb">
										                                                                        <thead id="suppliers-head">
										                                                                          <th>&nbsp;</th>
										                                                                          <th>ID</th>
										                                                                          <!--th>Inspector Name</th-->
										                                                                          <th id="p_r_reference" width="5%">P+R reference</th>
										                                                                          <th id="p_r_version" width="2%">P+R version</th>
										                                                                          <th>P+R text</th>
										                                                                          <th>Severity</th>
										                                                                          <th>Inspector Comments</th>
										                                                                          <th>Initial due date</th>
										                                                                          <th>Ext. due date</th>
										                                                                          <th>VAM Approval</th>
										                                                                          <th id="overdue">Overdue</th> 
										                                                                        </thead>
										                                                                         <tbody>

										                                                                            @foreach($CA as $ca)
										                                                                            <tr data-id="{{$ca->id}}">
										                                                                                <td>
										                                                                                  <i class="fa fa-edit correctiv_action_edit" aria-hidden="true" title="Edit"></i>
										                                                                                </td>
										                                                                                <td>{{$ca->id}}</td>
										                                                                                <!--td>{{$ca->user->first_name.' '.$ca->user->last_name}}</td-->
										                                                                                <td id="p_r_reference">{{$ca->p_r_reference}}</td>
										                                                                                <td id="p_r_version">{{$ca->p_r_version}}</td>
										                                                                                <td class="autotip_corrective_action">
										                                                                                  <a data-toggle="tooltip" title="{{$ca->p_r_text}}" data-placement="left">{{str_limit($ca->p_r_text,200)}}</a>
										                                                                                </td>
										                                                                                {{-- */ $p_r_severity  = ucfirst(strtolower(trim($ca->p_r_severity))); /*--}}
										                                                                                <td class="{{$PR_Severity['ClassName'][$p_r_severity]}}">
										                                                                                  <span class="label {{$PR_Severity['ClassName'][$p_r_severity]}}">{{$p_r_severity}}</span>
										                                                                                </td>
										                                                                                <td class="autotip_corrective_action"><a data-toggle="tooltip" title="{{$ca->inspector_comments}}" data-placement="left">{{str_limit($ca->inspector_comments,50)}}</a></td>
										                                                                                <td>{{$ca->intial_due_date->format('d-M-Y')}}</td>
										                                                                                <td>@if(!empty($ca->due_date_extension)){{$ca->due_date_extension->format('d-M-Y')}}@elseif($ca->days_past_due == null && $ca->supplier_request_closure=='inprogress')<span class="label label-pending"> Pending </span>@else N/A @endif</td>
										                                                                                <td class="@if($ca->vam_approval == 'accept') label-success @else label-danger @endif">  
										                                                                                    <span class="label @if($ca->vam_approval == 'accept') label-success @else label-danger @endif">
										                                                                                         @if($ca->vam_approval == 'accept') Closed @else Open @endif
										                                                                                    </span>
										                                                                                </td>
										                                                                                    <?php
										                                                                                      $today = \Carbon\Carbon::today();
										                                                                                      $intial_due_date = $today->diffInDays($ca->intial_due_date,false);
										                                                              
										                                                                                      if(!empty($ca->due_date_extension)){ $due_date_extension = $today->diffInDays($ca->due_date_extension,false); }else$due_date_extension=0;
										                                                                                     ?>
										                                                                                    @if(($intial_due_date > 0 || $due_date_extension > 0 ) && $ca->vam_approval != 'accept')
										                                                                                      {{-- */ $intial_due_className = 'label-primary'; $intial_due_value = 'No'; /*--}}
										                                                                                    @else
										                                                                                      {{-- */ $intial_due_className = 'label-danger'; $intial_due_value = 'Yes'; /*--}}
										                                                                                    @endif
										                                                                                <td class="{{$intial_due_className}}"> 
										                                                                                     <span class="label {{$intial_due_className}}">{{$intial_due_value}}</span>
										                                                                                </td>
										                                                                            </tr>
										                                                                             {{-- */ $ca_json[$ca->id] = $ca; /* --}}
										                                                                              {{-- */ $ca_json[$ca->id]['severity'] = $ca->p_r_severity; /* --}}  
										                                                                            @endforeach                                                            
										                                                                        </tbody>
										                                                                     </table>
										                                                            </div>
										                                                        @else
										                                                            <div class="alert alert-warning">
										                                                                This site master does not have any Inspections.
										                                                            </div>
										                                                        @endif
										                                                    </div>
										                                              </div>
													                            </div>

													                            <div class="box box-primary panel-default">
														                              <div class="box-header with-border panel-heading">
														                                   <i class="fa fa-fw fa-table"></i>
														                                   <h3 class="box-title">Inspection Summary</h3>
														                                   <div class="box-tools pull-right">
														                                      @if(!empty(Input::get('uid')))
											                                                      {{-- */ $user_inspnum = explode("_",Input::get('uid')); /* --}}
											                                                        @if(\Auth::user()->id == $user_inspnum[0])
											                                                          {{ Form::open(['route' => ['sitemaster.inspectionedit',$sitemaster->id,$user_inspnum[1],3], 'method' => 'post']) }}
											                                                                      {{form::hidden('inspection_type','exist' )}}
											                                                                      {{form::hidden('step',3)}}
											                                                                      {{form::hidden('inspection_num',$user_inspnum[1])}}
											                                                                      {{ Form::button('Edit', ['type' => 'submit', 'class' => 'btn btn-primary btn-xs']) }}
											                                                          {{ Form::close() }}
											                                                        @endif
														                                     @endif
														                                   </div>
														                               </div>
													                                  <div class="box-body">
													                                       <div class="table-responsive">
														                                          <table class="incidents-basic-table">
														                                             <tbody>
															                                                <tr>
															                                                   <td>
															                                                      <div class="col-lg-12">
															                                                         <div class="score-content ca-form-tabs">
															                                                            <table class="table">
															                                                               <thead>
															                                                                  <tr>
															                                                                     <th>Scoring</th>
															                                                                     <th>Expected</th>
															                                                                     <th>Required</th>
															                                                                     <th>Accumulate</th>
															                                                                     <th>%</th>
															                                                                     <th>Calculate Score</th>
															                                                                  </tr>
															                                                               </thead>
															                                                               <tbody>
															                                                                  <tr>
															                                                                     <td>P&R Requirement</td>
															                                                                     <td>{{$insp_main_data['sc_pr_req_excepted']}}</td>
															                                                                     <td>{{$insp_main_data['sc_pr_req_required']}}</td>
															                                                                     <td>{{$insp_main_data['sc_pr_req_accumulated']}}</td>
															                                                                     <td>{{round($insp_main_data['sc_pr_req_percent']*100,2)}}%</td>
															                                                                      <?php
															                                                                          $fin_rating = $insp_main_data['sc_scoring_rules_final_rating'];
															                                                                          $classname = 'text-nav';
															                                                                          if($fin_rating == 'Low Risk') $classname = 'text-success'; $ratin_icon = "fa-level-down";
															                                                                          if($fin_rating == 'Medium Risk') $classname = 'text-warning'; $ratin_icon = "fa-level-down";
															                                                                          if($fin_rating == 'High Risk') $classname = 'text-danger'; $ratin_icon = "fa-level-up";
															                                                                          if($fin_rating == 'Eminent Risk' or $fin_rating == 'Urgent Risk') $classname = 'text-info';  $ratin_icon = "fa-level-up";
															                                                                       ?>
															                                                                     <td rowspan="2" class="{{$classname}}"><i class="fa {{$ratin_icon}}"></i>{{round($insp_main_data['sc_calulated_score']*100,2)}}%</td>
															                                                                  </tr>
															                                                                  <tr>
															                                                                     <td>P&R Score</td>
															                                                                     <td>{{$insp_main_data['sc_pr_score_excepted']}}</td>
															                                                                     <td>{{$insp_main_data['sc_pr_score_required']}}</td>
															                                                                     <td>{{$insp_main_data['sc_pr_score_accumulated']}}</td>
															                                                                     <td>{{round($insp_main_data['sc_pr_score_percent']*100,2)}}%</td> 
															                                                                  </tr>
															                                                               </tbody>
															                                                            </table>
															                                                         </div>
															                                                      </div>
															                                                   </td>
															                                                   <td>
															                                                      <div class="col-lg-12">
															                                                         <div class="score-content ca-form-tabs">
															                                                            <table class="table table-bordered">
															                                                               <thead>
															                                                                  <tr>
															                                                                     <th>Scoring Rules</th>
															                                                                     <th>Final Rating</th>
															                                                                  </tr>
															                                                               </thead>
															                                                               <tbody>
															                                                                  <tr>
															                                                                     <td>The Calculated Score is a guideline meant for the consideration of the Inspector. The opinion of the inspector is the one that provides the Final Rating.</td>
															                                                                     <td class="{{$classname}}"> <i class="fa {{$ratin_icon}}"></i> {{$insp_main_data['sc_scoring_rules_final_rating']}}</td>
															                                                                  </tr>
															                                                               </tbody>
															                                                            </table>
															                                                         </div>
															                                                      </div>
															                                                   </td>
															                                                </tr>
														                                             </tbody>
														                                          </table>
													                                       </div>
														                                   <div class="table-responsive">
														                                        <table class="incidents-basic-table">
															                                           <tbody>
															                                              <tr>
															                                                 <td>
															                                                    <div class="col-lg-12">
															                                                       <div class="ibox inspection-summary-wrapper">
															                                                          <div class="ibox-title summary_head list-group-item-heading">
															                                                             <h5> Company Background; Type of product/service provided by supplier to Microsoft; Key customers; Historical information (prior inspections, reported losses, etc.); any other relevant information </h5>
															                                                          </div>
															                                                          <div class="inspection-summary-content">
															                                                             <div class="list-group">
															                                                                <p class=" list-group-item list-group-item-text summary_body_hght"> &nbsp;{{$insp_main_data['summ_company_background']}}</p>
															                                                             </div>
															                                                          </div>
															                                                       </div>
															                                                    </div>
															                                                 </td>
															                                                 <td>
															                                                    <div class="col-lg-12">
															                                                       <div class="ibox inspection-summary-wrapper ">
															                                                          <div class="ibox-title summary_head list-group-item-heading">
															                                                             <h5>Overview of Inspection Work and Recommended controls</h5>
															                                                          </div>
															                                                          <div class="inspection-summary-content">
															                                                             <div class="list-group">
															                                                                 <p class=" list-group-item list-group-item-text summary_body_hght"> &nbsp;{{$insp_main_data['summ_overview_inspection_work']}}</p>
															                                                             </div>
															                                                          </div>
															                                                       </div>
															                                                    </div>
															                                                 </td>
															                                              </tr>
															                                           </tbody>
														                                        </table>
														                                    </div>
														                                    <div class="table-responsive">
														                                        <table class="incidents-basic-table">
														                                           <tbody>
														                                             <tr>
														                                              	 <td>
														                                                    &nbsp;
														                                                 </td>
														                                             </tr>
														                                              <tr>
														                                                 <td>
														                                                    <div class="col-lg-12">
														                                                       <div class="ibox inspection-summary-wrapper ">
														                                                          <div class="ibox-title summary_head_2 list-group-item-heading">
														                                                             <h5>Facility and site description, including security features; any other relevant information</h5>
														                                                          </div>
														                                                          <div class="inspection-summary-content">
														                                                             <div class="list-group">
														                                                                <p class=" list-group-item list-group-item-text summary_body_hght "> &nbsp;{{$insp_main_data['summ_facility_site_desc']}}</p>
														                                                             </div>
														                                                          </div>
														                                                       </div>
														                                                    </div>
														                                                 </td>
														                                                 <td>
														                                                    <div class="col-lg-12">
														                                                       <div class="ibox inspection-summary-wrapper ">
														                                                          <div class="ibox-title summary_head_2 list-group-item-heading">
														                                                             <h5>People Interviewed during Inspection</h5>
														                                                          </div>
														                                                          <div class="inspection-summary-content">
														                                                             <div class="col-lg-12">
														                                                                <div class="score-content ca-form-tabs">
														                                                                   <table class="table table-bordered">
														                                                                      <thead>
														                                                                         <tr>
														                                                                            <th>Name</th>
														                                                                            <th>Title/Role</th>
														                                                                         </tr>
														                                                                      </thead>
														                                                                      <tbody>
														                                                                      {{-- */$int_dur_inspec = json_decode($insp_main_data['summ_people_interview_during_inspec']) /* --}}
														                                                                      @foreach($int_dur_inspec as $ky=>$value)
														                                                                         @if(!empty($int_dur_inspec[$ky]->name))
														                                                                         <tr>
														                                                                            <td>{{$int_dur_inspec[$ky]->name}}</td>
														                                                                            <td>{{$int_dur_inspec[$ky]->title}}</td>
														                                                                         </tr>
														                                                                        @endif
														                                                                      @endforeach
														                                                                      </tbody>
														                                                                   </table>
														                                                                </div>
														                                                             </div>
														                                                          </div>
														                                                       </div>
														                                                    </div>
														                                                 </td>
														                                              </tr>
														                                           </tbody>
														                                        </table>
														                                    </div>													
													                                  </div>
													                            </div>
	             	 	   															@if(count($prlogs))
														                            <div class="box box-primary panel-default">
														                            	 <div class="box-header with-border panel-heading">
														                            	 	  <i class="fa fa-history"></i>
															                                   <h3 class="box-title">History Log</h3>
														                            	 </div>
														                            	 <div class="box-body">
																		                      <div class="table-responsive" style="min-height:20px;max-height:154px;overflow-y:auto;">
																		                              <table class="tbody-small">
																		                                  <tbody>
																		                                    @if(count($prlogs))
																		                                      @foreach($prlogs as $log)
																		                                        <tr class="font-black-small">
																		                                          <td>
																		                                            @if($log->updated_at != Null )
																		                                                {{ $log->updated_at->format('M d, Y h:i A') }} - {{ucfirst($log->type)}} by {{ $log->user->name }}
																		                                            @elseif($log->requested_at != Null )
																		                                                {{  date('M d, Y h:i A',strtotime($log->requested_at))  }} - {{ucfirst($log->type)}} inspection review requested by {{ $log->user->name }}
																		                                            @elseif($log->cleared_at != Null )
																		                                                {{  date('M d, Y h:i A',strtotime($log->cleared_at))  }} - {{ucfirst($log->type)}} inspection review cleared by {{ $log->user->name }}
																		                                            @endif
																		                                          </td>
																		                                        </tr>
																		                                      @endforeach
																		                                    @endif
																		                                  </tbody>
																		                              </table>
																		                      </div>
														                            	 </div>
														                            </div>
														                            @endif
													                        @endif
														                @else
														                      	<div class="box box-primary panel-default">
										                                              <div class="box-header with-border panel-heading">
											                                               <i class="fa fa-fw fa-table"></i>
											                                               <h3 class="box-title">Corrective Actions </h3>
											                                                <div class="box-tools pull-right">
											                                                </div> 
										                                              </div>
										                                              <div class="box-body">
										                                                    <div class="col-lg-12">
											                                                        <div class="alert alert-warning">
											                                                                This site master does not have any Inspections.
											                                                        </div>
										                                                    </div>
										                                              </div>
														                        </div>
														                @endif

									                             </div>
									                        </div>
									                    </div>
									               </div>
		           							</div>
									</div>
								</div>
								<div id="c" class="tab-pane">
									<div class="panel-body">
										  @if(\Auth::user()->access_leak_prevention)
								           <!-- /.col-lg-12 -->
								           <div class="col-lg-12">
									            <div class="panel panel-default">
									                          <div class="panel-heading">
									                              <i class="fa fa-bar-chart-o fa-fw"></i>
									                                <span class="font-bold">IP protection and confidentiality activities</span>
									                                  <div class="pull-right">
									                                      
									                                      @if (\MSLST\Helpers\Common::canAccessEdit(null, 'sitemaster', null, $sitemaster))
									                                      <div class="btn-group">    
									                                          <button type="button" class="btn btn-white btn-xs" href="{{ route('sitemaster.edit', [$sitemaster->id, 1]) }}">
									                                              Edit
									                                          </button>
									                                      </div>
											                              @endif
									                                  </div>
									                          </div>
									                          <div class="panel-body">
									                          <?php $role = Auth::User()->role;?>
									                          @if(Auth::User()->site_user_level == 'protection_pm')
									                            <?php $role = 'PM';?>
									                          @endif
									                            <input type="hidden" name="role"  value="{{$role}}">
									                                @if($sitemaster->supplier_handle)
									                                   <div class="col-lg-12">
									                                    <!-- Leak Risk Analysis -->
									                                      <div class="row">
									                                           <div class="col-md-12">
									                                                <div class="box box-primary">
									                                                      <div class="box-header with-border">
									                                                        <i class="fa fa-fw fa-list"></i>
									                                                        <h3 class="box-title">Supplier profile</h3>
									                                                        <div class="box-tools pull-right">
									                                                            &nbsp;
									                                                        </div>
									                                                      </div>
									                                                      <div class="box-body">
									                                                            <div class="form-group">
									                                                                  <div class="col-xs-12">
									                                                                      <div class="row">
									                                                                          <div class="col-xs-1 activity-cols">
									                                                                            <h5>#</h5>
									                                                                         </div>
									                                                                         <div class="col-xs-3">
									                                                                            <h5>Business activities (process areas)</h5>
									                                                                         </div>
									                                                                         <div class="col-xs-3">
									                                                                            <h5>Assets (what is handled)</h5>
									                                                                         </div> 
									                                                                         <div class="col-xs-3">
									                                                                         	 <h5>Supported lines of business</h5>
									                                                                         </div>
									                                                                      </div>
									                                                                  </div>
									                                                                   @if($leak_risk_analysis)
									                                                                    <div class="col-xs-12" id="busines_activity">
									                                                                     <?php $j=1 ?>
									                                                                        @foreach($leak_risk_analysis as $ky=>$lk_pr) 
									                                                                          @if(!empty($lk_pr->activity_id))
									                                                                              <div class="row activty-row" id="activty-row{{$j}}" data-id="{{$lk_pr->id}}" >
									                                                                                    <div class="col-sm-1 activity-cols">
									                                                                                      <span class="form-control activty-count">{{$j}}</span>
									                                                                                    </div>
									                                                                                    <div class="col-lg-3">
									                                                                                      <div class="form-group">
									                                                                                        <?php $emptyval = ["" =>"Select Business Activity"]; $business_activities = $emptyval+$business_activities;  ?>
									                                                                                        {{Form::select('activity'.$j,$business_activities,$lk_pr->activity_id,array('placeholder' => 'Select Business Activity','class'=>'form-control bus_activity_sel'.$lk_pr->id.' selectpicker'))}}
									                                                                                      </div>
									                                                                                    </div>
									                                                                                    <div class="col-lg-3" id="asset_div{{$lk_pr->id}}">
									                                                                                      <div class="form-group">
									                                                                                          <select name="assets{{$j}}" id="bus_assests_sel{{$j}}" class ='form-control bus_assests_sel{{$lk_pr->id}} selectpicker' multiple="multiple" title=" Select Assets" >
									                                                                                              <option data-hidden="true"></option>
									                                                                                          </select>
									                                                                                      </div>
									                                                                                    </div>
									                                                                                    <div class="col-lg-3">
									                                                                                    	 <div class="form-group">
									                                                                                    	     {{ Form::select('supp_lob'.$j,$business_lob,"",['class' =>'form-control selectpicker bus_supp_lob'.$j,'id'=>'bus_supp_lob'.$j,'title'=>'Select Supported lines of business','multiple' => 'Multiple']) }}
									                                                                                    	 </div>
									                                                                                    </div>

									                                                                                    @if(\MSLST\Helpers\Common::canAccessLeak('sitemaster',null, $sitemaster))
									                                                                                    <div class="col-lg-1">
									                                                                                          <span class="glyphicon glyphicon-remove business_remove" id="business_remove{{$j}}"   alt="{{$j}}" aria-hidden="true"></span>
									                                                                                    </div>
									                                                                                    @endif
									                                                                              </div>
									                                                                              <?php $j=$j+1; ?>
									                                                                          @endif
									                                                                        @endforeach
									                                                                       </div>
									                                                                        <?php $busines_show= '1'; ?>
									                                                                   @else
									                                                                      <div class="col-xs-12" id="busines_activity">
									                                                                           <div class="row activty-row" id="activty-row1">
									                                                                                <div class="col-sm-1 activity-cols">
									                                                                                  <span class="form-control activty-count">1</span>
									                                                                                </div>
									                                                                                <div class="col-lg-3">
									                                                                                  <div class="form-group">
									                                                                                  <?php $emptyval = ["" =>"Select Business Activity"]; $business_activities = $emptyval+$business_activities;  ?>
									                                                                                        {{Form::select('activity1',$business_activities,'',array('placeholder' => 'Select Business Activity','class'=>'form-control bus_activity_sel selectpicker'))}}
									                                                                                  </div>
									                                                                                </div>
									                                                                                <div class="col-lg-3">
									                                                                                  <div class="form-group">
									                                                                                     <select name="assets1" id="bus_assests_sel1" class ='form-control bus_assests_sel selectpicker' multiple="multiple" title=" Select Assets " >
									                                                                                          <option data-hidden="true"></option>
									                                                                                      </select>
									                                                                                  </div>
									                                                                                </div>
									                                                                                <div class="col-lg-3">
									                                                                                  <div class="form-group">
									                                                                                     <select name="supp_lob1" id="business_supp_lob1" class ='form-control business_supp_lob1 selectpicker' multiple="multiple" title=" Select Supported lines of business " >
									                                                                                          <option data-hidden="true"></option>
									                                                                                      </select>
									                                                                                  </div>
									                                                                                </div>
									                                                                               @if(\MSLST\Helpers\Common::canAccessLeak('sitemaster',null, $sitemaster))
									                                                                                <div class="col-lg-1">
									                                                                                      <span class="glyphicon glyphicon-remove business_remove" id="business_remove1" alt="1" aria-hidden="true"></span>
									                                                                                </div>
									                                                                                @endif
									                                                                           </div>
									                                                                      </div>
									                                                                       <?php $busines_show= '2'; ?>
									                                                                        <div class="col-xs-12 leak_risk_activity_assets">
									                                                                            <div class="alert alert-warning">
									                                                                                 This supplier does not have business activities and assets
									                                                                            </div>
									                                                                        </div>
									                                                                   @endif

									                                                                   <input type="hidden" value="{{$busines_show}}" name="busines_show" >
									                                                            </div>
									                                                      </div>
									                                                      @if(\MSLST\Helpers\Common::canAccessLeak('sitemaster',null, $sitemaster))
									                                                      <div class="box-footer clearfix" style="display: block;">
									                                                           <button id="addassests" class="btn btn-primary " type="button">Modify profile</button>
									                                                           <button id="save_leak_analysis" class="btn btn-primary " type="button">Save</button>
									                                                      </div>
									                                                      @endif 
									                                                 </div>
									                                             </div>
									                                      </div>        
									                                     <!-- Leak Risk Analysis /-->
									                                     <!-- leak Prevention Action Plan -->
									                                      <div class="row">
									                                           <div class="col-md-12">
									                                                <div class="box box-primary">
									                                                      <div class="box-header with-border">
									                                                       <i class="fa fa-fw fa-table"></i>
									                                                       <h3 class="box-title">IP protection and confidentiality action plan</h3>

									                                                        <div class="box-tools pull-right">
									                                                           <span class=""> <i class="fa fa-th-list text-grey"></i> Predefined Risks</span>&nbsp;
									                                                            <span class=""> <i class="fa fa-th-list text-light-blue"></i> Manual Risks</span>&nbsp;
									                                                            <span class=""> <i class="fa fa-th-list  text-yellow"></i> Incident Risks</span> &nbsp;
									                                                        </div>
									                                                      </div>
									                                                      <div class="box-body">
									                                                            <div class="col-lg-12">
									                                                              @if(!$leak_prevention->isEmpty())
									                                                                  <div class="table-responsive ca-form-tabs">
									                                                                         <table class="table table-hover table-striped" id="leak_risk_analysis_tab">
									                                                                              <thead id="suppliers-head">
									                                                                              @if($sitemaster->user_id == Auth::User()->id || Auth::User()->isManager()) <th>&nbsp;</th> @endif
									                                                                                <!--<th>Risk</th>-->
									                                                                                <th>Action</th>
									                                                                                <th>Status</th>
									                                                                                <th>Date</th>
									                                                                                <!--<th>File</th>-->
									                                                                                <th>Verified</th>
									                                                                                <th>Verified Date</th>
									                                                                                <th>Verified By</th>
									                                                                              </thead>
									                                                                               <tbody>
									                                                                                  @foreach($leak_prevention as $lk_pr)
									                                                                                  <?php  
									                                                                                      $tdclass = "";
									                                                                                      if(!empty($lk_pr->leak_id))   $tdclass = "well well-sm";
									                                                                                      else if(!empty(($lk_pr->inc_id)))  $tdclass = "alert alert-warning";
									                                                                                      else  $tdclass = "alert alert-info";
									                                                                                  ?>
									                                                                                  <tr class="{{$tdclass}}">
									                                                                                      @if($sitemaster->user_id == Auth::User()->id || Auth::User()->isManager())
									                                                                                      <td class="{{$tdclass}} leak_head" data-id="{{$lk_pr->id}}" data-type="@if(!empty($lk_pr->leak_id) || !empty($lk_pr->inc_id)) auto @else manual @endif" style="width:4%;" >
									                                                                                              <i class="fa fa-edit risk_mitigation_manual text-navy" aria-hidden="true" title="Edit"></i>
									                                                                                              @if((empty($lk_pr->leak_id) && empty($lk_pr->inc_id)) &&  ($sitemaster->user_id == Auth::User()->id))
									                                                                                              <i class="fa fa-trash-o text-navy manual_risk_delete" aria-hidden="true" title='Delete'></i>
									                                                                                              @endif
									                                                                                      </td>
									                                                                                      @endif   
									                                                                                      <!--<td class="{{$tdclass}} autotip_leak_action">
									                                                                                          <a data-toggle="tooltip" title="{{$lk_pr->risk}}">{{ucfirst($lk_pr->risk)}}</a>
									                                                                                      </td> -->
									                                                                                      @if(!empty($lk_pr->leak_id))  
									                                                                                      <td class="{{$tdclass}} autotip_leak_action">
									                                                                                        <a data-toggle="tooltip" title="{{$lk_pr->action_description}}">{{ucfirst(trim($lk_pr->action_name))}}</a>
									                                                                                      </td>
									                                                                                      @else
									                                                                                        <td class="{{$tdclass}} autotip_leak_action">
									                                                                                           <a data-toggle="tooltip" title="{{$lk_pr->action_description}}">{{ucfirst(trim($lk_pr->action_name))}}</a>
									                                                                                        </td>
									                                                                                      @endif 
									                                                                                      <td class="alert  @if($lk_pr->status == 'Completed') alert-success @elseif($lk_pr->status == 'Not Started') alert-danger @elseif($lk_pr->status == 'In Progress') alert-warning @endif">
									                                                                                          @if(!empty($lk_pr->status)){{$lk_pr->status}}@else - @endif
									                                                                                      </td>
									                                                                                      <td class="{{$tdclass}}">@if(!empty($lk_pr->status_date)){{$lk_pr->status_date->format('d-m-Y')}}@else - @endif</td>
									                                                                                      <!--<td class="{{$tdclass}}"> 
									                                                                                      @if(!empty($lk_pr->file_name))
									                                                                                         <a data-toggle="tooltip" title="{{$lk_pr->file_description}}" href="/sitemaster/download/{{$lk_pr->id}}/{{$sitemaster->id}}/site_leak_prevention" >{{str_limit(ucfirst(trim($lk_pr->file_description)),15)}}</a>
									                                                                                      @else - @endif
									                                                                                      </td> -->
									                                                                                      <td class="{{$tdclass}}"> 
									                                                                                          @if($lk_pr->verified_status == "yes") 
									                                                                                           <span class="label label-success">Completed</span>
									                                                                                          @elseif($lk_pr->verified_status == 'no') 
									                                                                                           <span class="label label-danger">Needs Improvement</span>
									                                                                                          @else  
									                                                                                            <span class="label label-primary">Not Verified</span>
									                                                                                          @endif
									                                                                                      </td>
									                                                                                      <td class="{{$tdclass}}">@if(!empty($lk_pr->verified_date)){{$lk_pr->verified_date->format('d-m-Y')}}@else - @endif</td>
									                                                                                      <td class="{{$tdclass}}">@if(!empty($lk_pr->verified_by)){{$lk_pr->user->name}}@else - @endif </td>
									                                                                                    
									                                                                                  </tr>
									                                                                                  @endforeach                                                            
									                                                                              </tbody>
									                                                                           </table>
									                                                                  </div>
									                                                              @else
									                                                                  <div class="alert alert-warning">
									                                                                      This supplier does not have any leak prevention actions.
									                                                                  </div>
									                                                              @endif
									                                                            </div>
									                                                             
									                                                      </div>

									                                                      <div class="box-footer clearfix" style="display: block;">
									                                                            @if($sitemaster->user_id == Auth::User()->id)
									                                                                     <button id="addrisk"  class="btn btn-primary pull-left" type="button">Add new action</button>
									                                                            @endif
									                                                      </div>
									                                                </div>
									                                          </div>
									                                      </div>
									                                     <!-- leak Prevention Action Plan /-->
									                                      <div class="row">
									                                           <div class="col-md-12">
									                                                <div class="box box-danger">
									                                                     <div class="box-header with-border">
									                                                          <i class="fa fa-fw fa-table"></i>
									                                                          <h3 class="box-title">Leak incident history</h3>
									                                                          <div class="box-tools pull-right">
									                                                              &nbsp;
									                                                          </div>
									                                                     </div>
									                                                     <div class="box-body">
									                                                          <div class="col-xs-12">
									                                                                @if(!$leak_incident_history->isEmpty())
									                                                                 <div class="table-responsive">
									                                                                          <table  class="table table-hover table-striped" id="leak_incident_history_tab">
									                                                                            <thead>
									                                                                             @if($sitemaster->user_id == Auth::User()->id) <th >&nbsp;</th>@endif
									                                                                              <th>Title</th>
									                                                                              <th>Date</th>
									                                                                              <th>Type</th>
									                                                                              <th>Corrective action</th>
									                                                                              <th>Overdue</th> 
									                                                                            </thead>
									                                                                            <tbody>
									                                                                            @foreach($leak_incident_history as $lih)
									                                                                            <tr  data-id="{{$lih->id}}" class="alert alert-warning leak_inc_tr">
									                                                                               @if($sitemaster->user_id == Auth::User()->id)
									                                                                                <td class="leak_head"> 
									                                                                                      <i class="fa fa-edit incident_history" aria-hidden="true" title="Edit"></i>
									                                                                                      <i class="fa fa-trash-o incident_history_remove" aria-hidden="true" title="Delete"></i>
									                                                                                 
									                                                                                </td>
									                                                                              @endif
									                                                                              <td>
									                                                                                <a data-toggle="tooltip" title="{{$lih->title}}">{{str_limit(ucfirst($lih->title),15)}}</a>
									                                                                              </td>
									                                                                              <td>{{$lih->incident_date->format('d-m-Y')}}</td>
									                                                                              <td>{{ucfirst($lih->incident_type)}}</td>
									                                                                              <td>
									                                                                                 <a data-toggle="tooltip" title="{{$lih->corrective_action_description}}">{{str_limit(ucfirst($lih->corrective_action_title),15)}}</a>
									                                                                              </td>
									                                                                              <td> <?php  $days = $lih->deadline_date->diffInDays(\Carbon\Carbon::today(),false);  ?>
									                                                                              @if(($days < 0) || $lih->status == 'Completed')
									                                                                                <span class="label label-primary">No</span>
									                                                                              @else
									                                                                               <span class="label label-danger">Yes</span>
									                                                                              @endif</td>
									                                                                            
									                                                                            </tr>
									                                                                          @endforeach
									                                                                             
									                                                                            </tbody>
									                                                                          </table>
									                                                                 </div>
									                                                                @else
									                                                                 <div class="alert alert-warning">
									                                                                        This supplier does not have any incident history.
									                                                                 </div>
									                                                                @endif
									                                                          </div>
									                                                     </div>
									                                                     <div class="box-footer clearfix" style="display: block;">
									                                                          @if($sitemaster->user_id == Auth::User()->id)                                        
									                                                            <button id="addnewincident" class="btn btn-primary" type="button">Add new incident</button>
									                                                          @endif
									                                                     </div>
									                                                </div>
									                                           </div>
									                                      </div>

									                                     <!-- Corrective Action Plan Start /-->
									                                     <div class="row">
									                                     	  <div class="col-md-12">
									                                     	  	   <div class="box box-primary">
									                                                    <div class="box-header with-border">
									                                                     <i class="fa fa-fw fa-table"></i>
									                                                     <h3 class="box-title">Confidentiality requirements on site assessment - Corrective actions</h3>
									                                                      <div class="box-tools pull-right">
									                                                       
									                                                      </div> 
									                                                    </div>
									                                                    <div class="box-body">
									                                                          <div class="col-lg-12">
									                                                             @if(!empty($lp_corrective_action))
									                                                                  <div class="table-responsive ca-form-tabs">
									                                                                         <table class="table table-hover table-striped" id="corrective_action_tb">
									                                                                              <thead id="suppliers-head">
									                                                                                <th>&nbsp;</th>
									                                                                                <!--<th>ID</th> -->
									                                                                                <th>Requirement</th>
									                                                                                <th>Severity</th>
									                                                                                <th>Assessment comments</th>
									                                                                                <th>Initial due date</th>
									                                                                                <th>Ext. due date</th>
									                                                                                <th>Protection PM Approval</th>
									                                                                                <th id="overdue">Overdue</th> 
									                                                                              </thead>
									                                                                               <tbody>
									                                                                               		<?php //print "<pre>"; print_r($lp_corrective_action); exit;	?>
									                                                                                  @foreach($lp_corrective_action as $lp_ca)
									                                                                                  <tr data-id="{{$lp_ca->id}}">
									                                                                                      <td>
									                                                                                        <i class="fa fa-edit lp_correctiv_action_edit" aria-hidden="true" title="Edit"></i>
									                                                                                      </td>
									                                                                                      <!--<td>{{$lp_ca->id}}</td>-->
									                                                                                      <td class="autotip_corrective_action">
									                                                                                        <a data-toggle="tooltip" title="{{$lp_ca->requirement_text}}" data-placement="left">{{str_limit($lp_ca->requirement_text,200)}}</a>
									                                                                                      </td>
									                                                                                      <td>{{-- */ $p_r_severity  = ucfirst(strtolower(trim($lp_ca->severity))); /*--}}
									                                                                                        <span class="label {{$PR_Severity['ClassName'][$p_r_severity]}}">{{$p_r_severity}}</span>
									                                                                                      </td>
									                                                                                      <td class="autotip_corrective_action"><a data-toggle="tooltip" title="{{$lp_ca->assessment_comments}}" data-placement="left">{{($lp_ca->assessment_comments)? str_limit($lp_ca->assessment_comments,50) : 'Not Specified'}}</a></td>
									                                                                                      <td>{{$lp_ca->initial_due_date->format('d-M-Y')}}</td>
									                                                                                      <td>@if(!empty($lp_ca->due_date_extension)){{$lp_ca->due_date_extension->format('d-M-Y')}}@elseif($lp_ca->days_past_due == null && $lp_ca->supplier_request_closure=='inprogress')<span class="label label-pending"> Pending </span>@else N/A @endif</td>
									                                                                                      <td>  
									                                                                                          <span class="label @if($lp_ca->pm_approval == 'accept') label-success @else label-danger @endif">
									                                                                                               @if($lp_ca->pm_approval == 'accept') Closed @else Open @endif
									                                                                                          </span>
									                                                                                      </td>
									                                                                                      <td> 
									                                                                                          <?php  $intial_due_date = $lp_ca->initial_due_date->diffInDays(\Carbon\Carbon::today(),false); 
									                                                                                          if(!empty($lp_ca->due_date_extension)){$due_date_extension = $lp_ca->due_date_extension->diffInDays(\Carbon\Carbon::today(),false);}else$due_date_extension=0;?>
									                                                                                          @if(($intial_due_date < 0 && $due_date_extension <= 0 ) || $lp_ca->pm_approval == 'accept')
									                                                                                            <span class="label label-primary">No</span>
									                                                                                          @else
									                                                                                           <span class="label label-danger">Yes</span>
									                                                                                          @endif
									                                                                                      </td>
									                                                                                  </tr>
									                                                                                   {{-- */ $lp_ca_json[$lp_ca->id] = $lp_ca; /* --}}
									                                                                                    {{-- */ $lp_ca_json[$lp_ca->id]['severity'] = $lp_ca->severity; /* --}}  
									                                                                                  @endforeach                                                            
									                                                                              </tbody>
									                                                                           </table>
									                                                                  </div>
									                                                              @else
									                                                                  <div class="alert alert-warning">
									                                                                      This site master does not have any corrective actions.
									                                                                  </div>
									                                                              @endif
									                                                          </div>
									                                                           
									                                                    </div>
									                                              </div>
									                                     	  </div>
									                                     </div>
									                                     <!-- Corrective Action Plan End /-->
									                                      <div class="row">
									                                      	   <div class="col-md-12">
									                                                <div class="box box-success">
									                                                     <div class="box-header with-border">
									                                                          <i class="fa fa-fw fa-columns"></i>
									                                                          <h3 class="box-title">Confidentiality requirements self-assessment results</h3>

									                                                          <div class="box-tools pull-right">
									                                                               @if(\Auth::user()->access_leak_prevention && $sitemaster->supplier_handle)
									                                                                   @if((Auth::user()->isManager() && count($leak_risk_analysis)>0) || ($sitemaster->user_id == Auth::User()->id && count($leak_risk_analysis)>0))
										                                                                    @if($sitemaster->user_id == Auth::User()->id && count($leak_risk_analysis)>0)
										                                                                     <div class="btn-group">
										                                                                        {{ Form::open(['route' => ['sitemaster.self',$sitemaster->id], 'method' => 'get']) }}
										                                                                            {{ Form::button('Self-Assessment', ['type' => 'submit', 'class' => 'btn btn-primary btn-xs']) }}
										                                                                        {{ Form::close() }}
										                                                                     </div>
										                                                                    @endif

										                                                                    @if($lp_access_name == 'pm_user' && count($leak_risk_analysis)>0)
										                                                                     <div class="btn-group">
										                                                                        {{ Form::open(['route' => ['sitemaster.onsite',$sitemaster->id], 'method' => 'get']) }}
										                                                                            {{ Form::button('Onsite-Assessment', ['type' => 'submit', 'class' => 'btn btn-primary btn-xs']) }}
										                                                                        {{ Form::close() }}
										                                                                     </div> <!-- -->
										                                                                    @endif

										                                                                    <div class="btn-group">
										                                                                    	{{ HTML::decode(HTML::link('/UserManual/LP questionnaire.xls', '<i class="fa fa-file-excel-o"></i> Download as Excel', [ 'target' => '_blank' ,'class' => 'btn btn-primary btn-xs', 'data-toggle'=>"tooltip" ,'data-original-title'=>"Download as excel for Assessment guide"] )) }} 
										                                                                    </div>
										                                                                @endif
									                                                              @endif

									                                                          </div>
									                                                     </div>
										                                                 <div class="box-body">
										                                                	 <div class="col-lg-6"> 
																				                <div class="panel panel-default">
																				                  <div class="panel-heading">
																				                      <i class="fa fa-fw fa-list"></i> Self-Assessment
																				                  </div>
																				                  <!-- /.panel-heading -->
																				                   <div class="panel-body">
																				                    @if(!empty($assessment_data[0][0]))
																				                        <i ></i> <span class="font-bold">Categories</span>
																				                        <div class="panel-group" id="accordion">
																				                          @foreach($categories as $category_id=>$category)
																				                          <?php $cat=md5('self'.$category);$activitykey=0;?>
																				                          <div class="panel panel-default">
																				                            <div class="panel-heading">
																				                                <h4 class="panel-title">
																				                                  <a data-toggle="collapse" data-parent="#accordion" href="#{{ $cat }}">
																				                                      {{ $category }}
																				                                  </a>
																				                                </h4>
																				                            </div>
																				                            <div id="{{ $cat }}" class="panel-collapse collapse">
																				                                <div class="panel-body">
																				                                    <i></i> <span class="font-bold">Answers</span>
																				                                    <div class="panel-group" id="accordion_{{ $cat }}">
																				                                        @foreach($answers as $answer=>$answer_name)
																				                                          <?php $ans=md5('self'.$category.$answer); $activitykey=0;?>
																				                                            <div class="panel panel-default">
																				                                              <div class="panel-heading">
																				                                                  <h4 class="panel-title">
																				                                                    <a data-toggle="collapse" data-parent="#accordion_{{ $cat }}" href="#{{ $ans }}">
																				                                                        {{ $answer_name }}
																				                                                    </a>
																				                                                  </h4>
																				                                              </div>
																				                                              <div id="{{ $ans }}" class="panel-collapse collapse">
																				                                                  <div class="panel-body">
																				                                                    <div class="panel-group" id="accordion_{{ $ans }}">
																				                                                    {{--*/ $i=1; /*--}}
																				                                                    @if(!empty($assessment_data[$activitykey]))
																				                                                      @foreach($assessment_data[$activitykey] as $assessment)
																				                                                        @if(($assessment['self_answer_id']==$answer) && ($questions[$assessment['question_id']]['category_id']==$category_id))
																				                                                          <div class="question-wrapper">
																				                                                              <div class="question-circle answer{{ $answer }}"  data-toggle="tooltip" data-placement="bottom">
																				                                                                  &nbsp;
																				                                                              </div>
																				                                                              <div class="answer-wrapper">
																				                                                                <!--span>{{ $i++ }}.</span-->
									                                                                                    						<h5>
																				                                                                  {{wordwrap($questions[$assessment['question_id']]['name'])}}
																				                                                                </h5>
																				                                                                @if($assessment['self_comment']){{'Comment'.':  '.wordwrap($assessment['self_comment'])  }}@else {{'Comment'.':  '.'NA'  }}@endif
																				                                                              </div>
																				                                                          </div>
																				                                                        @endif
																				                                                      @endforeach
																				                                                    @endif
																				                                                  </div>   
																				                                                  </div>
																				                                              </div>
																				                                            </div>
																				                                        @endforeach
																				                                    </div>
																				                                </div>
																				                            </div>
																				                          </div>
																				                          @endforeach
																				                        </div>
																				                    @else
																				                        <p>There are no questions & answers.</p>
																				                    @endif
																				                  </div>
																				                  <!-- /.panel-body -->
																				                </div>
																				              </div>
																				              <div class="col-lg-6"> 
																				                   <div class="panel panel-default">
																					                <div class="panel-heading">
																					                    <i class="fa fa-fw fa-list"></i> Onsite-Assessment
																					                </div>
																				                        <div class="panel-body">
																						                  @if(!empty($assessment_data[0][0]))
																						                    <i></i> <span class="font-bold">Categories</span>
																						                    <div class="panel-group" id="accordion_onsite">
																						                      @foreach($categories as $category_id=>$category)
																						                      <?php $cat=md5('onsite'.$category);$activitykey=0;?>
																						                      <div class="panel panel-default">
																						                        <div class="panel-heading">
																						                            <h4 class="panel-title">
																						                              <a data-toggle="collapse" data-parent="#accordion_onsite" href="#{{ $cat }}">
																						                                  {{ $category }}
																						                              </a>
																						                            </h4>
																						                        </div>
																						                        <div id="{{ $cat }}" class="panel-collapse collapse">
																						                            <div class="panel-body">
																						                                <i></i> <span class="font-bold">Answers</span>
																						                                <div class="panel-group" id="accordion_{{ $cat }}">
																						                                    @foreach($answers as $answer=>$answer_name)
																						                                      <?php $ans=md5('onsite'.$category.$answer);?>
																						                                        <div class="panel panel-default">
																						                                          <div class="panel-heading">
																						                                              <h4 class="panel-title">
																						                                                <a data-toggle="collapse" data-parent="#accordion_{{ $cat }}" href="#{{ $ans }}">
																						                                                    {{ $answer_name }}
																						                                                </a>
																						                                              </h4>
																						                                          </div>
																						                                          <div id="{{ $ans }}" class="panel-collapse collapse">
																						                                              <div class="panel-body">
																						                                                <div class="panel-group" id="accordion_{{ $ans }}">
																						                                                {{--*/ $i=1; /*--}}

																						                                                @if(!empty($assessment_data[$activitykey]))
																						                                                @foreach($assessment_data[$activitykey] as $assessment)
																						                                                  @if($assessment['onsite_answer_id']==$answer && $questions[$assessment['question_id']]['category_id']==$category_id)
																						                                                    <div class="question-wrapper">
																						                                                        <div class="question-circle answer{{ $answer }}"  data-toggle="tooltip" data-placement="bottom">
																						                                                            &nbsp;
																						                                                        </div>
																						                                                        <div class="answer-wrapper">
																						                                                          <h5>
																						                                                            <!-- <span>
																						                                                              {{ $i++ }}
																						                                                            </span>. --> {{ $questions[$assessment['question_id']]['name'] }}
																						                                                          </h5>
																						                                                          @if($assessment['onsite_comment']!=' '){{'Comment'.':  '.wordwrap($assessment['onsite_comment'])  }}@else {{'Comment'.':  '.'NA'  }}@endif

																						                                                        </div>
																						                                                    </div>
																						                                                  @endif
																						                                                @endforeach
																						                                                @endif
																						                                               
																						                                              </div>   
																						                                              </div>
																						                                          </div>
																						                                        </div>
																						                                    @endforeach
																						                                </div>
																						                            </div>
																						                        </div>
																						                      </div>
																						                      @endforeach
																						                    </div>
																						                
																						                    @else
																						                        <p>There are no questions & answers.</p>
																						                    @endif
																						                </div>
																				                	    <!-- /.panel-body -->
																				                    </div>
																				              </div>
										                                                 </div>
										                                                 <div class="box-footer clearfix" style="display: block;">
										                                                 </div>
									                                                </div>
									                                            </div>
									                                      </div>


									                                      <div class="row">
									                                           <div class="col-md-12">
									                                                <div class="box box-success">
									                                                     <div class="box-header with-border">
									                                                          <i class="fa fa-fw fa-columns"></i>
									                                                          <h3 class="box-title">Supplier confidentiality status</h3>

									                                                          <div class="box-tools pull-right">
									                                                              &nbsp;
									                                                          </div>
									                                                     </div>
									                                                     <div class="box-body">
									                                                          <div class="col-lg-9">
									                                                                 <div class="row">
									                                                                      {{ Form::label('action_plan_status', 'Action plan status', ['class' => 'col-sm-2 control-label']) }}
									                                                                      <div class="col-sm-4">
									                                                                        {{ Form::text('action_plan_status',$sitemaster->action_plan_status ? $sitemaster->action_plan_status ."%" : 0 ."%", ['class' => 'form-control leak_status','readonly' => 'true' ]) }}
									                                                                      </div>
									                                                                  </div>
									                                                                  <div class="row">
									                                                                    &nbsp;
									                                                                  </div>
									                                                                  <div class="row">
									                                                                          {{ Form::label('assessment_status', 'Assessment status', ['class' => 'col-sm-2 control-label']) }}
									                                                                          <div class="col-sm-4">
									                                                                            {{ Form::text('assessment_status',$sitemaster->assessment_status, ['class' => 'form-control leak_status','readonly' => 'true']) }}
									                                                                          </div>
									                                                                      </div>
									                                                                      <div class="row">
									                                                                          {{ Form::label('assessment_score', 'Assessment score', ['class' => 'col-sm-2 control-label']) }}
									                                                                          <div class="col-sm-4">
									                                                                            {{ Form::text('assessment_score',$sitemaster->assessment_score, ['class' => 'form-control leak_status','readonly' => 'true']) }}
									                                                                          </div>
									                                                                      </div>
									                                                                  <div class="row">
									                                                                    &nbsp;
									                                                                  </div>
									                                                                   <div class="row">
									                                                                      {{ Form::label('summary', 'Summary', ['class' => 'col-sm-2 control-label']) }}
									                                                                      <div class="col-sm-4">
									                                                                        @if(Auth::user()->access_leak_prevention == 1 && \Auth::user()->site_user_level== 'protection_pm' )
									                                                                        <?php $ary_dis = ['class' => 'form-control leak_summary_desc','size' => '20x5','maxlength' => '300']; ?>
									                                                                        @else
									                                                                         <?php $ary_dis = ['disabled'=>'disabled','class' => 'form-control','size' => '20x5','maxlength' => '300']; ?>
									                                                                        @endif
									                                                                        {{ Form::textarea('summary',$sitemaster->leak_prevention_summary ? : null,  $ary_dis) }}
									                                                                        <a href="#" class="small-box-footer btn-success pull-right save-summary-leak-desc">
									                                                                             Save summary <i class="fa fa-arrow-circle-right"></i>
									                                                                        </a>
									                                                                      </div>
									                                                                  </div>
									                                                                  <div class="row">
									                                                                    &nbsp;
									                                                                  </div>
									                                                                  <div class="row">
									                                                                      {{ Form::label('overall_status', 'Overall status (calculated)', ['class' => 'col-sm-2 control-label']) }}

									                                                                      <div class="col-sm-4">
									                                                                        
									                                                                        <?php $overall_status = ceil($sitemaster->overall_status); ?>
									                                                                          <select class="selectpicker overall_status bs-select-hidden" name="cal_overall_status" style="width:300px;">
									                                                                           @if($overall_status == 0  && $sitemaster->supplier_handle == 0)
									                                                                            <option data-content="<span class='label label-default'>Not in scope</span>" value="1" @if($overall_status == 0) selected="selected" @endif>Not in scope</option>
									                                                                           @elseif($overall_status >= 85)
									                                                                            <option data-content="<span class='label label-success'>Compliant</span>" value="2" @if($overall_status <= 85) selected="selected" @endif>Compliant</option>
									                                                                           @elseif($overall_status >= 50 && $overall_status <= 85) 
									                                                                            <option data-content="<span class='label label-warning'>Partially compliant</span>" value="3" @if($overall_status > 50 && $overall_status <= 85 ) selected="selected" @endif>Partially compliant</option>
									                                                                           @elseif($overall_status <= 50 && $sitemaster->supplier_handle == 1)  
									                                                                            <option data-content="<span class='label label-danger'>Non compliant</span>" value="4" @if($overall_status >= 50) selected="selected" @endif>Non compliant</option>
									                                                                           @endif
									                                                                          </select>
									                                                                      </div>
									                                                                  </div>

									                                                                   @if(!empty($sitemaster->determined_overall_status) || \Auth::user()->site_user_level == 'protection_pm' )
									                                                                  <div class="row">
									                                                                  	   {{ Form::label('overall_status', 'Overall Status (risk based decision)', ['class' => 'col-sm-2 control-label']) }}
									                                                                  	   <div class="col-sm-4">
									                                                                  	   <?php // print "<pre>"; print_r($sitemaster->determined_overall_status); exit;?>
									                                                                  	   @if(\Auth::user()->site_user_level == 'protection_pm')
									                                                                  	   		<select class="selectpicker overall_status bs-select-hidden" name="deter_overall_status" style="width:300px;" >
											                                                                            <option data-content="<span class='label label-default'>Not in scope</span>" @if($sitemaster->determined_overall_status == 1) selected='selected' @endif value="1" >Not in scope</option>
											                                                                            <option data-content="<span class='label label-success'>Compliant</span>" @if($sitemaster->determined_overall_status == 2) selected='selected' @endif value="2" >Compliant</option>
											                                                                            <option data-content="<span class='label label-warning'>Partially compliant</span>" @if($sitemaster->determined_overall_status == 3) selected='selected' @endif value="3" >Partially compliant</option>
											                                                                            <option data-content="<span class='label label-danger'>Non compliant</span>" @if($sitemaster->determined_overall_status == 4) selected='selected' @endif value="4">Non compliant</option>
									                                                                           </select>
									                                                                        @else  
									                                                                            <span class="label  label-success">{{ !empty($sitemaster->determined_overall_status) ?  \MSLST_Site::$Determined_status[$sitemaster->determined_overall_status]['val'] : 'Not in Scope' }}</span>                                                                  	  
									                                                                        @endif    
									                                                                      </div>
									                                                                  </div>
									                                                                @endif 
									                                                          </div>
									                                                     </div>
									                                                     <div class="box-footer clearfix" style="display: block;">
									                                                     </div>
									                                                </div>
									                                           </div>
									                                      </div>

									 
									                                   </div>
									                                @else
									                                <div class="alert alert-warning">
									                                       This supplier does not handle any Microsoft components/products.
									                                        
									                                </div>
									                                @endif
									                          </div>
									            </div>
								           </div>
								           <!-- /.col-lg-12 -->
								          @endif
									</div>
								</div>
							</div>
						</div>


					</div>



				</div>
			</div>

	</div>


<!--<script src="https://js.api.here.com/ee/2.5.4/jsl.js?with=all" type="text/javascript" charset="utf-8"></script> -->
<script type="text/javascript" charset="utf-8" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
	var Sitemasters = {
		mapElement: 'sitemaster_map',
		coordinates: '{{$coordinates}} '
	};
  var incident_history_json = {{json_encode($leak_incident_history)}};
  var incident_prevention_json = {{json_encode($leak_prevention)}};
  var business_activity = {{json_encode($business_activities)}};
  var business_assets = {{json_encode($business_assets)}};
  var business_lob = {{json_encode($business_lob)}};
  var business_risk = {{json_encode($business_risk)}};
  var business_actions = {{json_encode($business_actions)}};
  var leak_risk_analysis = {{json_encode($leak_risk_analysis)}};
  var corrective_actions = {{json_encode($ca_json)}};
  var lp_corrective_actions = {{json_encode($lp_ca_json)}};
  var accessname = {
    pr_access_name: '{{$pr_access_name}}',
    lp_access_name: '{{$lp_access_name}}'
  };
</script>

@stop
