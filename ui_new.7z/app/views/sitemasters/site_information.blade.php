@extends('layouts.master')

@section('content')

<div class="body_content">
      <div id="wrapper">
               @if($edit)
                  <h2 class="page-header">Edit Site</h2>
                @else
                  <h2 class="page-header">Create Site</h2>
                @endif
      </div>

      <div class="wrapper-content animated fadeInRight">
        <div class="row">
          <div class="col-lg-12">
             <div class="ibox">
                <div class="ibox-title">
                    <h5>Site Information</h5>
                    <div class="ibox-tools">
                      <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>  
                    </div>
                </div>
                <div class="ibox-content">
                     <div class="wizard">
                                        <a>
                                          <span>1. Basic Information</span>
                                        </a>
                                        <a  class="current">
                                          <span>2. Site Information</span>
                                        </a>
                                        <a>
                                          <span>3. Contact Information</span>
                                        </a>
                     </div>
                     <div class="panel panel-default wizard_body" > 
                         
                       {{ Form::open(['route' => ($edit ? ['sitemaster.update', $data->id] : 'sitemaster.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal sitemaster-form', 'role' => 'form', 'id' => 'sitemaster-form-basic']) }}
                        {{ Form::hidden('step', 1) }}
                            <div class="panel-body"  >
                                <!-- end form-errors -->
                                <div class="row">
                                    <div class="col-lg-9">
                                      @if($errors->all())
                                      <div id="form-errors" class="alert alert-danger" role="alert">
                                        <ul>
                                          @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                          @endforeach
                                        </ul>
                                      </div>
                                      @endif


                                  <div class="form-group">
                                     {{ Form::label('supplier_handle', 'Does the supplier handle unannounced components/ products containing device ID (size, look, specifications, etc.)? *', ['class' => 'col-lg-7 control-label required']) }}
                                    <div class="col-lg-2">
                                     {{ Form::checkbox('supplier_handle',1,$data->supplier_handle) }}
                                    </div>
                                  </div>
                                   
                                  <div class="form-group">
                                    {{ Form::label('lob', 'Line of Business *', ['class' => 'col-lg-3 control-label required']) }}
                                    <div class="col-lg-6" id="supp_type">
                                      {{ Form::select('lob[]',$lineofbusiness,is_array($data->lob)?$data->lob:json_decode($data->lob), ['class' => 'form-control bus_assests_sel selectpicker','multiple' => 'Multiple','title'=>'Select Line Of Business']) }}
                                    </div>
                                  </div>
                                  <div class="form-group  @if($data->lob_other_type)  lob_other_type_id @endif" id="lob_other_type_id">
                                    {{ Form::label('lob_other_type', 'Other Line of Business *', ['class' => 'col-lg-3 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('lob_other_type',$data->lob_other_type, ['class' => 'form-control','maxlength'=>250]) }}
                                    </div>
                                  </div>

                                  <div class="form-group">
                                    {{ Form::label('process', 'Process', ['class' => 'col-lg-3 control-label ']) }} 
                                    <div class="col-lg-6"  id="supp_type">
                                      {{ Form::select('process[]',$process,is_array($data->process)?$data->process:json_decode($data->process), ['class' => 'form-control bus_assests_sel selectpicker','multiple' => 'Multiple','title'=>'Select Site Process']) }}
                                    </div>
                                  </div>
                                  <div class="form-group  @if($data->process_other_type)  process_other_type_id @endif" id="process_other_type_id">
                                    {{ Form::label('process_other_type', 'Other Process', ['class' => 'col-lg-3 control-label']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('process_other_type',$data->process_other_type, ['class' => 'form-control','maxlength'=>250]) }}
                                    </div>
                                  </div>

                                  <div class="form-group">
                                    {{ Form::label('parent_site', 'Parent Site', ['class' => 'col-lg-3 control-label ']) }} <i  title="" data-toggle="tooltip" class="fa fa-question-circle" data-original-title="Please enter Parent site"></i>
                                    <div class="col-lg-6">
                                      {{ Form::text('parent_site', $data->parent_site, ['class' => 'form-control','maxlength'=>150]) }}
                                    </div>
                                  </div>
                  <div class="form-group">
                                    {{ Form::label('primary_stakeholder', 'Primary Stakeholder', ['class' => 'col-lg-3 control-label']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('primary_stakeholder', $data->primary_stakeholder, ['class' => 'form-control','maxlength'=>150]) }}
                                    </div>
                                  </div>
                  <div class="form-group">
                                    {{ Form::label('sec_stakeholder', 'Secondary Stakeholder', ['class' => 'col-lg-3 control-label ']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('sec_stakeholder', $data->sec_stakeholder, ['class' => 'form-control','maxlength'=>150]) }}
                                    </div>
                                  </div>
                  <div class="form-group">
                                    {{ Form::label('channel_manager', 'Channel Manager *', ['class' => 'col-lg-3 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('channel_manager', $data->channel_manager, ['class' => 'form-control','maxlength'=>150]) }}
                                    </div>
                                  </div>
                 
                  <div class="form-group">
                                    {{ Form::label('last_inspection_date', 'Last P+R Inspection Date', ['class' => 'col-lg-3 control-label']) }} <i  title="" data-toggle="tooltip" class="fa fa-question-circle" data-original-title="Please select Last Inspection Date"></i>
                                    <div class="col-lg-6">
                                      <div class="input-group" id="wizard_date">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        @if($edit)
                                        {{ Form::text('last_inspection_date', (!empty($data->last_inspection_date)) ?  $data->last_inspection_date->format('Y-m-d') : '', ['class' => 'form-control','maxlength'=>150]) }}
                                        @else
                                        {{Form::text('last_inspection_date',$data->last_inspection_date, ['class' => 'form-control','maxlength'=>150]) }}
                                        @endif
                                      </div>
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('c_tpat_svi_number', 'C-TPAT SVI Number', ['class' => 'col-lg-3 control-label']) }}
                                    <div class="col-lg-6">
                                      <div class="input-group">
                                        @if($edit)
                                        {{ Form::text('c_tpat_svi_number', (!empty($data->c_tpat_svi_number)) ?  $data->c_tpat_svi_number : '', ['class' => 'form-control required-field','maxlength'=>24]) }}
                                        @else
                                        {{Form::text('c_tpat_svi_number',$data->c_tpat_svi_number, ['class' => 'form-control','maxlength'=>24]) }}
                                        @endif
                                      </div>
                                    </div>
                                  </div>

                                        

                                    </div>

                                    <div class="col-lg-3">
                                         <div class="pull-right text-danger">
                                            (*) Mandatory Field
                                        </div>
                                        <div class="text-center">
                                          <div style="margin-top: 20px">
                                            <i style="font-size: 180px; color: #e5e5e5" class="fa fa-sign-in"></i>
                                          </div>
                                        </div>
                                     </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                             @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.show', $data->id),'id'=>'sitemaster_cancel_edit']) }}
                           @else
                          <div class="clearfix">
                            <div class="pull-left">
                              {{-- Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) --}}
                              <a href="{{($edit ? ['sitemaster.update', $data->id] : '0')}}" class='btn btn-default'>Back</a>
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.index'),'id'=>'sitemaster_cancel']) }}
                            </div>
                          </div>
                        @endif
                            </div>
                        {{ Form::close() }}
                     </div> 
                </div>  
              </div>
          </div>
        </div>
      </div>


</div>

<script type="text/javascript">
  var Sitemasters = {'coordinates': null, 'mapElement': null};

  var incident_history_json = null;
  var incident_prevention_json = null;
  var business_activity = null;
  var business_assets = null;
  var business_lob = null;
  var business_risk = null;
  var business_actions= null;
  var leak_risk_analysis = null;
  var corrective_actions = null;
  var lp_corrective_actions = null;
  var accessname = null;
</script>
@stop