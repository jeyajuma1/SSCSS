@extends('layouts.master')

@section('content')
<div class="body_content">
      <div id="wrapper">
               @if($edit)
                  <h2 class="page-header">Edit Site</h2>
                @else
                  <h2 class="page-header">Create Site</h2>
                @endif
      </div> <!--/*wrapper -->

      <div class="wrapper-content animated fadeInRight">
        <div class="row">
          <div class="col-lg-12">
             <div class="ibox">
                <div class="ibox-title">
                    <h5>Basic Information</h5>
                    <div class="ibox-tools">
                      <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>  
                    </div>
                </div> <!--/*ibox-title -->
                <div class="ibox-content">
                     <div class="wizard">
                                        <a class="current">
                                          <span>1. Basic Information</span>
                                        </a>
                                        <a>
                                          <span>2. Site Information</span>
                                        </a>
                                        <a>
                                          <span>3. Contact Information</span>
                                        </a>
                     </div> <!--/*wizard -->
                     <div class="panel panel-default wizard_body"> 
                         
                        {{ Form::open(['route' => ($edit ? ['sitemaster.update', $data->id] : 'sitemaster.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal sitemaster-form', 'role' => 'form', 'id' => 'sitemaster-form-basic']) }}
                            {{ Form::hidden('step', 0) }}
                            <div class="panel-body"  >
                                <!-- end form-errors -->
                                <div class="row">
                                    <div class="col-lg-9">
                                      @if($errors->all())
                                      <div id="form-errors" class="alert alert-danger" role="alert">
                                        <ul>
                                          @foreach($errors->all() as $error)
                                            <li>{{ $error }}</li>
                                          @endforeach
                                        </ul>
                                      </div>
                                      @endif


                                       <div class="form-group">
                                        {{ Form::label('site_name', 'Site Name *', ['class' => 'col-sm-3 control-label required']) }}
                                        <div class="col-sm-6">
                                          {{ Form::text('site_name', $data->site_name, ['class' => 'form-control','maxlength'=>250]) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('status', 'Status', ['class' => 'col-lg-3 control-label ']) }}
                                        <div class="col-sm-3">
                                          {{ Form::select('status',['Active'=>'Active','Inactive'=>'Inactive'],$data->status, ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('supplier_type', 'Supplier Type *', ['class' => 'col-sm-3 control-label required']) }}
                                        <div class="col-lg-6 " id="supp_type">
                                          {{ Form::select('supplier_type[]',$supplier_type,is_array($data->supplier_type)?$data->supplier_type:json_decode($data->supplier_type), ['class' => 'form-control bus_assests_sel selectpicker','multiple' => 'Multiple','title'=>'Select Supplier Type']) }}
                                        </div>
                                      </div>
                                       <div class="form-group  @if($data->supplier_other_type)  supplier_type_other_type_id @endif" id="supplier_type_other_type_id">
                                        {{ Form::label('supplier_other_type', 'Supplier Other Type *', ['class' => 'col-sm-3 control-label required']) }}
                                        <div class="col-lg-6">
                                          {{ Form::text('supplier_other_type',$data->supplier_other_type, ['class' => 'form-control','maxlength'=>250]) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('region', 'Region *', ['class' => 'col-sm-3 control-label required']) }}
                                        <div class="col-sm-3">
                                          {{ Form::select('region', $regions, $data->region, ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('country', 'Country *', ['class' => 'col-sm-3 control-label required ']) }}
                                        <div class="col-sm-3">
                                          {{ Form::select('country', $countries, $data->country, ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('city', 'City *', ['class' => 'col-sm-3 control-label required']) }}
                                        <div class="col-sm-6">
                                          {{ Form::text('city', $data->city, ['class' => 'form-control','maxlength'=>150]) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('country_state', 'Country State', ['class' => 'col-sm-3 control-label ']) }}
                                        <div class="col-lg-6">
                                          {{ Form::text('country_state', $data->country_state, ['class' => 'form-control','maxlength'=>150]) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('address', 'Address', ['class' => 'col-sm-3 control-label']) }}
                                        <div class="col-sm-6">
                                          {{ Form::textarea('address', $data->address, ['rows'=>2,'class' => 'form-control','maxlength'=>250]) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('postal_code', 'Postal Code', ['class' => 'col-sm-3 control-label']) }}
                                        <div class="col-lg-6">
                                          {{ Form::text('postal_code', $data->postal_code, ['class' => 'form-control','maxlength'=>50]) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        {{ Form::label('coordinates', 'Coordinates', ['class' => 'col-sm-3 control-label']) }}
                                        <div class="col-sm-4">
                                          {{ Form::text('coordinates', $data->coordinates, ['class' => 'form-control', 'placeholder' => 'Coordinate format: latitude, longitude', 'id' => 'coordinates','maxlength'=>250]) }}
                                        </div>
                                        <div class="col-sm-2">
                                          <input type="hidden" id="myField" value="" />
                                          {{ Form::button('Validate', ['type' => 'button', 'class' => 'form-control btn btn-primary btn-validate', 'id' => 'sitemaster-coordinate-check']) }}
                                        </div>
                                      </div>
                                      <div class="form-group">
                                        
                                        <div class="col-sm-6 col-sm-offset-3" id="sitemaster-coordinate-pick"></div>
                                      </div>
                                      <div class="form-group">
                                        <div class="col-sm-6 col-sm-offset-3 description">
                                        (Example: 42.374335,-71.116991 (Decimal Degrees) or N30 17.477,W97 44.315 (GPS) or N42 21 30,W71 06 14 (Degrees, Minutes &amp; Seconds) or 19N 326727 4691707 (UTM))
                                        </div>
                                      </div>

                                    </div>

                                    <div class="col-lg-3">
                                         <div class="pull-right text-danger">
                                            (*) Mandatory Field
                                        </div>
                                        <div class="text-center">
                                          <div style="margin-top: 20px">
                                            <i style="font-size: 180px; color: #e5e5e5" class="fa fa-sign-in"></i>
                                          </div>
                                        </div>
                                     </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                            @if($edit)
                                {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.show', $data->id),'id'=>'sitemaster_cancel_edit']) }}
                            @else
                                {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.index'),'id'=>'sitemaster_cancel']) }}
                            @endif
                            </div>
                        {{ Form::close() }}
                     </div>  <!--/* wizard_body -->
                </div>    <!--/* ibox-content -->
              </div>  <!--/* ibox -->
          </div> <!--/* col-lg-12 -->
        </div>  <!--/* row-->
      </div>  <!--/* animated-->


</div>
 
 
<!--script src="https://js.api.here.com/ee/2.5.4/jsl.js?with=all" type="text/javascript" charset="utf-8"></script-->
<script type="text/javascript" charset="utf-8" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script> 
<script type="text/javascript">
  var Sitemasters = {'coordinates': null, 'mapElement': null};
  Sitemasters.regions = '{{ $regions_json }}';
  Sitemasters.country = '{{ Input::old("country")?:$data->country}}';
  var incident_history_json = null;
  var incident_prevention_json = null;
  var business_activity = null;
  var business_assets = null;
  var business_lob = null;
  var business_risk = null;
  var business_actions= null;
  var leak_risk_analysis = null;
  var corrective_actions = null;
  var lp_corrective_actions = null;
  var accessname = null;
 
   
</script>
 
@stop
