@extends((preg_match('/sitemaster\/prinspection\/([0-9]+)\/create\/(online|(online\/(4)))/',Request::path()))? 'layouts.master' :'layouts.pop-master')
@section('content')
		{{-- */ $inspec_type = (preg_match('/sitemaster\/prinspection\/([0-9]+)\/create\/(online|(online\/(4)))/',Request::path()))? 'online' :'offline'; /* --}}

<div class="body_content">
     <div class="row border-bottom white-bg page-heading">
        <div class="row">
            <div class="col-lg-12">
              <h2 class="show_page_header">P+R Inspection Summary </h2>
              <div class="pull-right page_header_btn">
               
              </div>
            </div>
          </div>
     </div>
     <div class="alert alert-warning"> 
           <h4>Data not yet saved. Please review the information and confirm once done.</h4> 
     </div>
</div>

<div class="page-wrapper">
 
   <div class="panel-body">
      <div class="tab-content sitemaster-show">
         <!--/. tab d -->
         <div class="tab-pane active">
            <div class="col-lg-12">
            {{-- */ $confirm_detail = "true"; /* --}}

                @if(!empty($errormsg))
                      <div id="form-errors" class="alert alert-danger" role="alert">
                        <ul>
                          @foreach($errormsg as $error)
                            <li>{{ $error }}</li>
                          @endforeach
                        </ul>
                      </div>
                  {{-- */ $confirm_detail = "false"; /* --}}
                @endif

               <input type="hidden" name="confirm_detail" value="{{$confirm_detail}}">
            </div>
             {{-- */ $not_specified = 'Not Specified' /* --}}
            <div class="row">
               <div class="col-lg-12">
                  <div class="box box-primary">
                     <div class="box-header with-border">
                        <i class="fa fa-fw fa-table"></i>
                        <h3 class="box-title">Inspection Main</h3>
                        <div class="box-tools pull-right">
                           &nbsp;
                        </div>
                     </div>
                     <div class="box-body">
                        <div class="table-responsive">
                           <table class="incidents-basic-table">
                              <tbody>
                                 <tr class="font-darkblue-first" style="vertical-align: top;" data-id="1382">
                                    <td>Inspection Date</td>
                                    <td>Number of separate buildings at this site</td>
                                    <td>Number of buildings With Microsoft-related functions </td>
                                 </tr>
                                 <tr>
                                    <td>
                                       <p>{{$insp_main_data['ins_main_date']? date('M d, Y',strtotime($insp_main_data['ins_main_date'])):$not_specified}}</p>
                                    </td>
                                    <td>
                                       <p>{{$insp_main_data['ins_main_num_sep_buliding_at_this_site']?:$not_specified}}</p>
                                    </td>
                                    <td>
                                       <p>{{$insp_main_data['ins_main_num_buliding_ms_related_functions']?:$not_specified}}</p>
                                    </td>
                                 </tr>
                                 <tr class="font-darkblue" data-id="1382">
                                    <td>Number of full-time employees at this facility</td>
                                    <td>Supplier Subcontractor(s) Handling Microsoft product or IP</td>
                                    <td>Employees with Microsoft System Accounts</td>
                                 </tr>
                                 <tr>
                                    <td>
                                       <p>{{$insp_main_data['ins_main_num_full_time_emp_facility']?:$not_specified}}</p>
                                    </td>
                                    <td>
                                       <p>{{$insp_main_data['ins_main_supp_subcontract_handling_ms_product_ip']?:'Not Specified'}}</p>
                                    </td>
                                    <td>
                                       <p>{{$insp_main_data['ins_main_emp_ms_system_account']?:$not_specified}}</p>
                                    </td>
                                 </tr>
                                 <tr class="font-darkblue" data-id="1382">
                                    <td>Comments:</td>
                                    
                                 </tr>
                                 <tr>
                                    <td>
                                       {{$insp_main_data['ins_main_comments']}}
                                    </td>
                                    
                                 </tr>
                                 <tr class="font-darkblue" data-id="1382">
                                    <td>Inspectors:</td>
                                    <td>Employees with Microsoft System Access:</td>
                                 </tr>
                                 <tr>
                                    <td>
                                     @if(!empty($insp_main_data['ins_main_inspectors']))
                                      {{-- */ $inspector = json_decode($insp_main_data['ins_main_inspectors']) /* --}}
                                       <div class="col-lg-12">
                                          <div class="score-content ca-form-tabs">
                                             <table class="table">
                                                <thead>
                                                   <tr>
                                                      <th>Firm</th>
                                                      <th>Name</th>
                                                   </tr>
                                                </thead>
                                                <tbody>
                                                @foreach($inspector as $ky=>$value)
                                                   <tr>
                                                      <td>{{trim($inspector[$ky]->firm)}}</td>
                                                      <td>{{trim($inspector[$ky]->name)}}</td>
                                                   </tr>
                                                @endforeach
                                                </tbody>
                                             </table>
                                          </div>
                                       </div>
                                     @else
                                       {{$not_specified}}
                                     @endif
                                    </td>
                                    <td>
                                    @if(!empty($insp_main_data['ins_main_name_alias_access']))
                                       {{-- */ 
                                                $ms_alias_access = json_decode($insp_main_data['ins_main_name_alias_access']);
                                                $ms_alias_access = array_filter($ms_alias_access);                                               
                                       /* --}}
                                       <div class="col-lg-12">
                                          <div class="score-content ca-form-tabs">
                                             <table class="table">
                                                <thead>
                                                   <tr>
                                                      <th>Name</th>
                                                      <th>Alias</th>
                                                      <th>Access</th>
                                                   </tr>
                                                </thead>
                                                <tbody>
                                                @foreach($ms_alias_access as $ky=>$value)
                                                   @if(!empty(trim($ms_alias_access[$ky]->name)))
                                                   <tr>
                                                      <td>{{trim($ms_alias_access[$ky]->name)}}</td>
                                                      <td>{{trim($ms_alias_access[$ky]->alias)}}</td>
                                                      <td>{{trim($ms_alias_access[$ky]->access)}}</td>
                                                   </tr>
                                                   @endif
                                                @endforeach
                                                </tbody>
                                             </table>
                                          </div>
                                       </div>
                                    @else
                                        {{$not_specified}}
                                    @endif
                                    </td>
                                 </tr>
                              </tbody>
                           </table>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
            <div class="row">
               <div class="col-lg-12">
               <div class="box box-primary">
                  <div class="box-header with-border">
                     <i class="fa fa-fw fa-table"></i>
                     <h3 class="box-title">Inspection Summary</h3>
                     <div class="box-tools pull-right">
                        &nbsp;
                     </div>
                  </div>
                  <?php 
                                          //print "<pre>"; 
($summary_main_data);
                                  ?>
                                  
                  <div class="box-body inspection_summary">
                     <div class="table-responsive">
                        <table class="incidents-basic-table">
                           <tbody>
                              <tr>
                                 <td>
                                    <div class="col-lg-12">
                                       <div class="score-content ca-form-tabs">
                                          <table class="table">
                                             <thead>
                                                <tr>
                                                   <th>Scoring</th>
                                                   <th>Expected</th>
                                                   <th>Required</th>
                                                   <th>Accumulate</th>
                                                   <th>%</th>
                                                   <th>Calculate Score</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td>P&R Requirement</td>
                                                   <td>{{$summary_main_data['sc_pr_req_excepted']?:$not_specified}}</td>
                                                   <td>{{$summary_main_data['sc_pr_req_required']?:$not_specified}}</td>
                                                   <td>{{$summary_main_data['sc_pr_req_accumulated']?:$not_specified}}</td>
                                                   <td>{{round($summary_main_data['sc_pr_req_percent']*100,2)}}%</td>
                                                    	@if(!empty($summary_main_data['sc_scoring_rules_final_rating']))
                                                      <?php
		                                                   			$fin_rating = $summary_main_data['sc_scoring_rules_final_rating'];
		                                                   			$classname = 'text-nav';
		                                                   			if($fin_rating == 'Low Risk') $classname = 'text-success';
		                                                   			if($fin_rating == 'Medium Risk') $classname = 'text-warning';
		                                                   			if($fin_rating == 'High Risk') $classname = 'text-danger';
		                                                   			if($fin_rating == 'Eminent Risk') $classname = 'text-info';
		                                                   	 ?>
                                                    <td rowspan="2" class="{{$classname}}"><i class="fa fa-level-down"></i>{{round($summary_main_data['sc_calulated_score']*100,2)}}%</td>
                                                     @else
                                                      {{$not_specified}}
                                                     @endif
                                                </tr>
                                                <tr>
                                                   <td>P&R Score</td>
                                                   <td>{{$summary_main_data['sc_pr_score_excepted']?:$not_specified}}</td>
                                                   <td>{{$summary_main_data['sc_pr_score_required']?:$not_specified}}</td>
                                                   <td>{{$summary_main_data['sc_pr_score_accumulated']?:$not_specified}}</td>
                                                   <td>{{round($summary_main_data['sc_pr_score_percent']*100,2)}}%</td>                                                   
                                                </tr>
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                 </td>
                                 <td>
                                    <div class="col-lg-12">
                                       <div class="score-content ca-form-tabs">
                                          <table class="table table-bordered">
                                             <thead>
                                                <tr>
                                                   <th>Scoring Rules</th>
                                                   <th>Final Rating</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td>The Calculated Score is a guideline meant for the consideration of the Inspector. The opinion of the inspector is the one that provides the Final Rating.</td>
                                                   <td class="text-nav">
 														@if($inspec_type == 'online')
															{{Form::select("sc_scoring_rules_final_rating",['Low Risk'=>'Low Risk','Eminent Risk'=>'Eminent Risk','High Risk'=>'High Risk','Medium Risk'=>'Medium Risk'],$summary_main_data['sc_scoring_rules_final_rating'], ['class' => 'form-control'])}}
														@else
															{{$summary_main_data['sc_scoring_rules_final_rating']}}
														@endif
													</td>
                                                </tr>
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                 </td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                     <div class="table-responsive">
                        <table class="incidents-basic-table">
                           <tbody>
                              <tr>
                                 <td>
                                    <div class="col-lg-12">
                                       <div class="ibox inspection-summary-wrapper ">
                                          <div class="ibox-title summary_head list-group-item-heading">
                                             <h5>Company Background; Type of product/service provided by supplier to Microsoft; Key customers; Historical information (prior inspections, reported losses, etc.); any other relevant information</h5>
                                          </div>
                                          <div class="inspection-summary-content">
                                             <div class="list-group"> 
                                                <p class=" list-group-item list-group-item-text summary_body_hght"> &nbsp;{{$summary_main_data['summ_company_background']}}</p>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </td>
                                 <td>
                                    <div class="col-lg-12">
                                       <div class="ibox inspection-summary-wrapper ">
                                          <div class="ibox-title summary_head list-group-item-heading">
                                             <h5>Overview of Inspection Work and Recommended controls</h5>
                                          </div>
                                          <div class="inspection-summary-content">
                                             <div class="list-group">
                                                <p class=" list-group-item list-group-item-text summary_body_hght"> &nbsp;{{$summary_main_data['summ_overview_inspection_work']}}</p>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </td>
                              </tr>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                     <div class="table-responsive">
                        <table class="incidents-basic-table">
                           <tbody>
                              <tr>
                                 <td>
                                    <div class="col-lg-12">
                                       <div class="ibox inspection-summary-wrapper ">
                                          <div class="ibox-title summary_head_2 list-group-item-heading">
                                             <h5>Facility and site description, including security features; any other relevant information</h5>
                                          </div>
                                          <div class="inspection-summary-content">
                                             <div class="list-group"> 
                                                <p class=" list-group-item list-group-item-text summary_body_hght"> &nbsp;{{$summary_main_data['summ_facility_site_desc']}}</p>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </td>
                                 <td>
                                    <div class="col-lg-12">
                                       <div class="ibox inspection-summary-wrapper ">
                                          <div class="ibox-title summary_head_2 list-group-item-heading">
                                             <h5>People Interviewed during Inspection</h5>
                                          </div>
                                          <div class="inspection-summary-content">
                                             <div class="col-lg-12  summary_body_hght">
                                                <div class="score-content ca-form-tabs">
                                                @if(!empty($summary_main_data['summ_people_interview_during_inspec']))
                                                   <table class="table table-bordered">
                                                      <thead>
                                                         <tr>
                                                            <th>Name</th>
                                                            <th>Title/Role</th>
                                                         </tr>
                                                      </thead>
                                                      <tbody>
                                                      {{-- */$int_dur_inspec = json_decode($summary_main_data['summ_people_interview_during_inspec']) /* --}}
                                                      @foreach($int_dur_inspec as $ky=>$value)
                                                         @if(!empty($int_dur_inspec[$ky]->name))
                                                         <tr>
                                                            <td>{{$int_dur_inspec[$ky]->name}}</td>
                                                            <td>{{$int_dur_inspec[$ky]->title}}</td>
                                                         </tr>
                                                        @endif
                                                      @endforeach
                                                      </tbody>
                                                   </table>
                                                @else
                                                   {{$not_specified}}
                                                @endif
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </td>
                              </tr>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
 
</div> <!-- page-wrapper 
 

<script type="text/javascript">
  $("#offline_confirm").on('click',function(){
      bootbox.confirm("Are you sure that the information is correct? If yes, then data will be saved.",function(ok){
                if(ok){
                    alert("Done!");
                }else{

                }
            });
   });
</script-->
   @if($inspec_type == 'online')
      <div class="panel-footer summary_footer">
        <div class="clearfix">
          <div class="pull-left">
           <!-- {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }} -->
              <a href="{{'3'}}" class ='btn btn-default' alt='Back'>Back</a>
          </div>
          <div class="pull-right">
          {{ Form::open(['route' => ($edit ? ['sitemaster.update', $data->id] : ['sitemaster.inspectionprstore',$data->id,'online']), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal sitemaster-form', 'role' => 'form', 'id' => 'sitemaster-form-basic']) }}  
          {{ Form::hidden('step', 4) }}
		  {{ Form::hidden("new_sc_scoring_rules_final_rating",$summary_main_data['sc_scoring_rules_final_rating'], ['class' => "form_control",'id'=>'new_sc_scoring_rules_final_rating']) }}
          {{ Form::button('Confirm', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
          {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.show',$data->id),'id'=>'sitemaster_cancel']) }}
          </div>
        </div>
      </div>

   @endif   
@stop

