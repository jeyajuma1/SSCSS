@extends('layouts.master')

@section('content')

<div class="body_content">
      <div id="wrapper">
                @if($edit)
                  <h2 class="page-header">Edit Inspection Summary</h2>
                @else
                  <h2 class="page-header">Create Inspection Summary</h2>
                @endif
      </div> <!--/*wrapper -->

      <div class="wrapper-content animated fadeInRight">
        <div class="row">
          <div class="col-lg-12">
             <div class="ibox">
                <div class="ibox-title">
                    <h5>P+R Inspection</h5>
                    <div class="ibox-tools">
                      <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>  
                    </div>
                </div> <!--/*ibox-title -->
                <div class="ibox-content">
                     <div class="wizard">
                                        <a >
                                          <span>1. Inspection Main</span>
                                        </a>
                                        <a>
                                          <span>2. Questions</span>
                                        </a>
                                        <a class="current">
                                          <span>3. Summary</span>
                                        </a>
 
                     </div> <!--/*wizard -->
                     <div class="panel panel-default wizard_body"> 
                         
                           {{ Form::open(['route' => ($edit ? ['sitemaster.inspectionupdate', $data->id,$data->inspection_num,1] : ['sitemaster.inspectionprstore',$data->id,'online']), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal sitemaster-form', 'role' => 'form', 'id' => 'sitemaster-form-basic']) }}
                          {{ Form::hidden('step', 3) }}
                            <div class="panel-body"  >
                                <!-- end form-errors -->
                                <div class="row">
                                    <div class="col-lg-9">
                                        @if($errors->all())
                                          <div id="form-errors" class="alert alert-danger" role="alert">
                                            <ul>
                                              @foreach($errors->all() as $error)
                                                <li>{{ $error }}</li>
                                              @endforeach
                                            </ul>
                                          </div>
                                          @elseif(Session::has('success'))
                                            <div id="form-success" class="alert alert-success" role="alert">
                                                <span>
                                                    {{ trans(Session::get('success')) }}
                                                </span>
                                            </div>
                                            <!-- end form-success -->
                                        @endif

                                         <div class="form-group">
                                    {{ Form::label('summ_company_background', 'Company Background; Type of product/service provided by supplier to Microsoft; Key customers; Historical information (prior inspections, reported losses, etc.); any other relevant information', ['class' => 'col-lg-6 control-label ']) }}
                                    <div class="col-lg-6">
                                      {{ Form::textarea('summ_company_background', $data->summ_company_background, ['class' => 'form-control','rows' => 3,"cols" => 120,]) }}
                                    </div>
                                  </div> 

                                  <div class="form-group">
                                    {{ Form::label('summ_overview_inspection_work', 'Overview of Inspection Work and Recommended controls', ['class' => 'col-lg-6 control-label ']) }}
                                    <div class="col-lg-6">
                                      {{ Form::textarea('summ_overview_inspection_work', $data->summ_overview_inspection_work, ['class' => 'form-control','rows' => 3,"cols" => 120,]) }}
                                    </div>
                                  </div> 

                                  <div class="form-group">
                                    {{ Form::label('summ_facility_site_desc', 'Facility and site description, including security features; any other relevant information', ['class' => 'col-lg-6 control-label ']) }}
                                    <div class="col-lg-6">
                                      {{ Form::textarea('summ_facility_site_desc', $data->summ_facility_site_desc, ['class' => 'form-control','rows' => 3,"cols" => 120,]) }}
                                    </div>
                                  </div> 
                                  <div class="form-group">
                                        <div class="row">
                                          {{ Form::label('summ_people_interview_during_inspec', 'People Interviewed during Inspection *', ['class' => 'col-lg-6 control-label required']) }}
                                          {{ Form::label('summ_people_interview_during_inspec_name', 'Name', ['class' => 'colsm3s']) }}
                                          {{ Form::label('summ_people_interview_during_inspec_title', 'Title / Role', ['class' => 'colsm3s']) }}
                                           <button id="peopleinterviewed" class="onlinebtn" type="button"><b>+</b></button>
                                        </div>
                                        <?php 
                                        $i=1; 
                                        $summ_people_interview_during_inspec=json_decode($data->summ_people_interview_during_inspec);?> 
                                        @if(isset($data->summ_people_interview_during_inspec) && count($summ_people_interview_during_inspec))
                                          @foreach($summ_people_interview_during_inspec as $sum_key => $summ_people_interview_during_inspec_data)

                                            <div class="row activty-rows" id="activty-rows<?php echo $i?>"style="margin-bottom: 15px;">
                                                <div class="col-sm-1 activty-cols" style="display:none;">
                                                  <span class="form-control activty-counts" >{{$i}}</span>
                                                </div>
                                                <div class="col-lg-6">                                             
                                                </div>
                                                <div class="col-lg-3" style="padding: 0px;width: 205px;margin-left: 15px;">
                                                  <input type="text" name="summ_people_interview_during_inspec[<?php echo $i;?>][name]" id="summ_people_interview_during_inspec[<?php echo $i;?>][name]" class="form-control inter_inspec" value="{{$summ_people_interview_during_inspec_data->name}}" />            
                                                </div>
                                                <div class="col-lg-3" style="padding: 0px;width: 205px;margin-left: 15px;">
                                                 <input type="text" name="summ_people_interview_during_inspec[<?php echo $i;?>][title]" id="summ_people_interview_during_inspec[<?php echo $i;?>][title]" class="form-control inter_inspec1" value="{{$summ_people_interview_during_inspec_data->title}}"> 
                                                </div>
                                                <div class="col-lg-1" style="width:20px;margin-left: 12px;">
                                                 <span class="glyphicon glyphicon-remove people_interviewd_remove"  style="cursor:pointer;float:right;margin:10px 0px 0px 0px;"  id="people_interviewd_remove<?php echo $i; ?>"  aria-hidden="true"></span>                                  
                                              </div>
                                            </div>
                                             <?php $i=$i+1; ?>
                                          @endforeach
                                        @else

                                      <div class="row">                                 
                                          <div class="col-lg-6"> </div>  
                                          <div class="row activty-rows" id="activty-rows1" style="float:left;margin-left:15px; margin-bottom: -12px;">
                                                  <div class="col-sm-1 activity-cols" style=" display:none;">
                                                     <span class="form-control activty-counts" >1</span>
                                                  </div>  
                                                  <div class="col-lg-3" style="width:205px;">
                                                      <div class="form-group">
                                                           <input type="text" name="summ_people_interview_during_inspec[1][name]" id="summ_people_interview_during_inspec[1][name]" class="form-control inter_inspec" />            
                                                      </div>
                                                  </div> 
                                                  <div class="col-lg-3" style="width: 205px;margin-left: 15px;">
                                                    <div class="form-group">
                                                           <input type="text" name="summ_people_interview_during_inspec[1][title]" id="summ_people_interview_during_inspec[1][title]" class="form-control inter_inspec1" />
                                                    </div>
                                                  </div>
                                          </div>                     
                                      </div>
                           
                                    </div>
                                    @endif 
                                   
                                     <div class="row">
                                         <div class="col-lg-6"> </div>
                                        <div id="insfirmname" style="float: left;width:462px;margin-top:0px;">                                            
                                        </div>                      
                                     </div>
                                       {{ Form::hidden("sc_pr_req_excepted",'', ['class' => "form_control"]) }}
                                      {{ Form::hidden("sc_pr_req_required",'', ['class' => "form_control"]) }}
                                      {{ Form::hidden("sc_pr_req_accumulated",'', ['class' => "form_control"]) }}
                                      {{ Form::hidden("sc_pr_req_percent", '', ['class' => "form_control"]) }}
                                      {{ Form::hidden("sc_pr_score_excepted",'', ['class' => "form_control"]) }}
                                      {{ Form::hidden("sc_pr_score_required",'', ['class' => "form_control"]) }}
                                      {{ Form::hidden("sc_pr_score_accumulated",'', ['class' => "form_control"]) }}
                                      {{ Form::hidden("sc_pr_score_percent",'', ['class' => "form_control"]) }}
                                      {{ Form::hidden("sc_calulated_score",'', ['class' => "form_control"]) }}
                                      {{ Form::hidden("sc_scoring_rules_final_rating",'', ['class' => "form_control"]) }}

 
                                    </div>

                                    <div class="col-lg-3">
                                         <div class="pull-right text-danger">
                                            (*) Mandatory Field
                                        </div>
                                        <div class="text-center">
                                          <div style="margin-top: 20px">
                                            <i style="font-size: 180px; color: #e5e5e5" class="fa fa-sign-in"></i>
                                          </div>
                                        </div>
                                     </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                               @if($edit)
                                      {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                      {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.show', $data->id),'id'=>'sitemaster_cancel_edit']) }}
                               @else
                                  <div class="clearfix">
                                      <div class="pull-left">
                                         <a href="{{($edit ? ['sitemaster.inspectionupdate', $data->id,$data->inspection_num,1] : '2')}}" class='btn btn-default'>Back</a>
                                      </div>
                                      <div class="pull-right">
                                      {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                      {{ Form::button('Save as Draft', ['type' => 'button', 'class' => 'btn btn-info','alt'=>route('sitemaster.inspectionprstore',[$data->id,'draft']),'id'=>'sitemaster_inspection_save_draft']) }}
                                      {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.index'),'id'=>'sitemaster_cancel']) }}
                                    </div>
                                  </div>
                                @endif
                            </div>
                        {{ Form::close() }}
                     </div>  <!--/* .wizard_body -->
                </div>    <!--/* .ibox-content -->
              </div>  <!--/* .ibox -->
          </div> <!--/* .col-lg-12 -->
        </div>  <!--/* .row-->
      </div>  <!--/. animated-->
</div><!-- /.body_content -->  
                         
@stop
