@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
            Add Question
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <span class="font-bold">
                     Add a new question  
                 </span>
                </div>
                {{ Form::open(['route' => 'questions.store', 'class' => 'form-horizontal', 'role' => 'form', 'id' => 'question-add']) }}
                    <div class="panel-body">

                        @if($errors->all())
                        <div id="form-errors" class="alert alert-danger" role="alert">
                          <ul>
                            @foreach($errors->all() as $error)
                              <li>{{ $error }}</li>
                            @endforeach
                          </ul>
                        </div>
                        @endif

                        <div class="form-group">
                            {{ Form::label('text', 'Text', ['class' => 'col-lg-2 control-label required']) }}
                            <div class="col-sm-6">
                            	{{ Form::textarea('text', '', ['class' => 'form-control', 'rows' => 3]) }}
                            </div>
                        </div>
                        <div class="form-group">
                        	{{ Form::label('availability', 'Availability', ['class' => 'col-lg-2 control-label required']) }}
                            <div class="col-sm-6">
                              {{ Form::select('availability', $availabilities, '', ['class' => 'form-control']) }}
                            </div>
                        </div>
                        <div class="form-group category">
                            {{ Form::label('category', 'Category', ['class' => 'col-lg-2 control-label required']) }}
                            <div class="col-sm-6">
                              {{ Form::select('category', $categories, '', ['class' => 'form-control']) }}
                            </div>
                        </div>
                        <!-- <div class="form-group">
                            {{ Form::label('order', 'Order', ['class' => 'col-lg-2 control-label required']) }}
                            <div class="col-sm-6">
                            	{{ Form::text('order', '1', ['class' => 'form-control']) }}
                            </div>
                        </div> -->
                        <div class="form-group mandatory">
                            {{ Form::label('mandatory', 'Mandatory', ['class' => 'col-lg-2 control-label']) }}
                            <div class="col-sm-6">
                            	{{ Form::checkbox('mandatory', 1, false, ['class' => 'checkbox-top-margin']) }}
                            </div>
                        </div>
                        <div class="form-group archived">
                            {{ Form::label('archived', 'Archived', ['class' => 'col-lg-2 control-label']) }}
                            <div class="col-sm-6">
                            	{{ Form::checkbox('archived', 1, false, ['class' => 'checkbox-top-margin']) }}
                            </div>
                        </div>
                        <div class="form-group certifications">
                            <label for="certifications" class="col-sm-2 control-label required">Certifications</label>
                            <div class="col-sm-6">
							 <div id="audit_group">
                                <h5 class="certification-h5">TAPA</h5>
                                <?php $i = 1; ?>
                                @foreach($certifications[MSLST_Site::TAPA_GROUP] as $id => $item)
	                                <label class="control-label">
                                        {{ Form::checkbox("certifications[$i]", $id, false) }} {{ $item['name'] }} ({{ $availabilities[$item['availability']] }}) 
	                                </label><br />
	                                <?php $i++; ?>
                                @endforeach
                                <h5 class="certification-h5">C-TPAT</h5>
                                @foreach($certifications[MSLST_Site::C_TPAT_GROUP] as $id => $item)
	                                <label class="control-label">
	                                    {{ Form::checkbox("certifications[$i]", $id, false) }} {{ $item['name'] }} ({{ $availabilities[$item['availability']] }}) 
	                                </label><br />
	                                <?php $i++; ?>
                                @endforeach
                                <h5 class="certification-h5">AEO</h5>
                                @foreach($certifications[MSLST_Site::AEO_GROUP] as $id => $item)
	                                <label class="control-label">
	                                    {{ Form::checkbox("certifications[$i]", $id, false) }} {{ $item['name'] }} ({{ $availabilities[$item['availability']] }}) 
	                                </label><br />
	                                <?php $i++; ?>
                                @endforeach
							  </div>	
							  <div id="p_r_group"> 
									<h5 class="certification-h5">P+R</h5>
									@foreach($certifications[MSLST_Site::P_R] as $id => $item)
										<label class="control-label">
											{{ Form::checkbox("certifications[$i]", $id, false) }} {{ $item['name'] }} ({{ $availabilities[$item['availability']] }}) 
										</label><br />
										<?php $i++; ?>
									@endforeach
                                    <div class="form-group">
                                            {{ Form::label('subsection', 'Sub-section', ['class' => 'col-lg-2 control-label']) }}
                                            <div class="col-sm-6">
                                            {{ Form::text('subsection', '',['class' => 'form-control']) }}
                                            </div>
                                    </div>
                                    <div class="form-group">
                                            {{ Form::label('reference', 'Reference', ['class' => 'col-lg-2 control-label']) }}
                                            <div class="col-sm-6">
                                            {{ Form::text('reference','', ['class' => 'form-control']) }}
                                            </div>
                                    </div>
                                    <div class="form-group">
                                            {{ Form::label('severity', 'Severity', ['class' => 'col-lg-2 control-label']) }}
                                            <div class="col-sm-6">
                                            {{ Form::select('severity', $severities, '', ['class' => 'form-control']) }}
                                            </div>
                                    </div>
                                    <div class="form-group">
                                            {{ Form::label('version', 'Version', ['class' => 'col-lg-2 control-label']) }}
                                            <div class="col-sm-6">
                                            {{ Form::text('version', '',['class' => 'form-control']) }}
                                            </div>
                                    </div>
							  </div>
                            </div>
                        </div>
                        <div class="form-group activities">
                            <label for="activities" class="col-sm-2 control-label required">Activities</label>
                            <div class="col-sm-6">
                            <div> 
                                    @foreach($activities as $id => $item)
                                        <label class="control-label">
                                            {{ Form::checkbox("activities[$id]", $id, false) }} {{ $item}} 
                                        </label><br />
                                    @endforeach
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'href' => '/questions']) }}
                    </div>
                {{ Form::close() }}
            </div>
            <!-- /.col-lg-12 -->
        </div>
    <!-- /.row -->
	</div>
<!-- /#page-wrapper -->
</div>
@stop