@extends('layouts.master') @section('content')
<div id="page-wrapper">
	<div class="row">
		<div class="col-lg-12">
			<h2 class="page-header">
				Questions @if(Auth::User()->isAdmin())
				<div class="btn-group pull-right incident-btns">
					{{ Form::button('<i class="fa fa-plus "></i> Add New User', ['type'
					=> 'button', 'class' => 'btn btn-primary', 'href' =>
					route('questions.create')]) }}
				</div>
				@endif
			</h2>
		</div>
		<!-- /.col-lg-12 -->
	</div>


	@if(Session::has('success'))
	<div id="form-success" class="alert alert-success" role="alert">
		<span> {{ trans(Session::get('success')) }} </span>
	</div>
	<!-- end form-success -->
	@endif

	<div class="row">
		<div class="col-lg-12">
			<div class="ibox float-e-margins animated flipInX">
				<div class="ibox-title">
					<h5>
						<i class="fa fa-filter" aria-hidden="true"></i> Filters
					</h5>
					<div class="ibox-tools">
						<a class="collapse-link"> <i class="fa fa-chevron-up"></i>
						</a>
					</div>
				</div>
				<div class="ibox-content">
					<div class="row">
						<div class="panel panel-default questions-panel">
							<div class="panel-heading">
								{{ Form::open(['route' => 'users.index', 'method' => 'get', 'id'
								=> 'users-list-form', 'class' => 'form-inline', 'role[]' =>
								'form']) }}
								<div class="form-group-row">
									<div class="form-group">
										<div class="input-group style-avilability">
											<span class="input-group-addon">Availability</span> {{
											Form::select('availability[]', $availabilities,
											Input::get('availability'), ['multiple' => 'multiple',
											'class' => 'form-control']) }}
										</div>
									</div>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon">Category</span> {{
											Form::select('category[]', $certification_groups,
											Input::get('category'), ['multiple' => 'multiple', 'class' =>
											'form-control']) }}
										</div>
									</div>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon">Certification</span> {{
											Form::select('certification[]', $certifications,
											Input::get('certification'), ['multiple' => 'multiple',
											'class' => 'form-control']) }}
										</div>
									</div>
									<div class="form-group">
										<div class="input-group">
											<span class="input-group-addon">Mandatory</span> {{
											Form::select('mandatory[]', ['1' => 'Yes', '0' => 'No'],
											Input::get('mandatory'), ['multiple' => 'multiple', 'class'
											=> 'form-control']) }}
										</div>
									</div>
									<div class="form-group text-left hidden">{{
										Form::button('Filter', ['type' => 'submit', 'class' => 'btn
										btn-primary']) }} {{ Form::button('Reset', ['type' => 'reset',
										'class' => 'btn btn-primary', 'id' =>
										'questions-filter-reset']) }}</div>
								</div>
								{{ Form::close() }}
							</div>
						</div>
					</div>
				</div>
			</div>


			<div class="ibox float-e-margins animated flipInX">
				<div class="ibox-title">
					<h5>
						<i class="fa fa-table" aria-hidden="true"></i> Questions
					</h5>
					<div class="ibox-tools"></div>
				</div>
				<div class="ibox-content">
					<div class="row">
						<div class="col-lg-12">
							<div class="panel panel-default sitemasters-panel">
								<div class="panel-body">
									<div class="table-responsive">
										@if(Input::get('availability')[0]==5)
										<table class="table table-hover table-striped"
											id="questions-list">
											<thead>
												<th class="col-lg-8">Question</th>
												<th class="col-lg-1">Availability</th>
												<th class="col-lg-2">Question Category</th>
												<th class="col-lg-1"></th>
											</thead>
											<tbody>
												@foreach($questions as $question)
												<tr>
													<td class="autotip" title="{{$question->name}}">{{
														$question->name }}</td>
													<td>{{ (!empty($availabilities[$question->availability])) ?
														$availabilities[$question->availability] : '' }}</td>
													<td>{{ $supplier_categories[$question->category] }}</td>
													<td class="action-buttons" nowrap>{{ Form::open(['route' =>
														['questionsedit', $question->id,$question->availability],
														'method' => 'get']) }} {{ Form::button('Edit', ['type' =>
														'submit', 'class' => 'btn btn-primary btn-xs']) }} {{
														Form::close() }} {{ Form::open(['route' =>
														['questionsdestroy',
														$question->id,$question->availability], 'method' =>
														'get']) }} {{ Form::button('Remove', ['type' => 'submit',
														'class' => 'btn btn-danger btn-xs
														question-delete-button']) }} {{ Form::close() }}</td>
												</tr>
												@endforeach
											</tbody>
										</table>
										@elseif(Input::get('availability')[0]==4 || $hideColumns ==
										'show')


										<table class="table table-hover table-striped"
											id="questions-list">
											<thead>
												<th>Question</th>
												<th>Subsection</th>
												<th>Reference</th>
												<th>Severity</th>
												<th>Version</th>
												<th>Availability</th>
												<th>Certifications</th>
												<th>Mandatory</th>
												<th>Archived</th>

												<th></th>
											</thead>
											<tbody>
												@foreach($questions as $question)
												<tr>
													<td class="autotip" title="{{$question->text}}">{{
														$question->text }}</td>
													<td>{{
														!empty($question->subsection)?$question->subsection:' ' }}</td>
													<td>{{ !empty($question->reference)?$question->reference:'
														' }}</td>
													<td>{{
														!empty($severities[$question->severity])?$severities[$question->severity]:'
														' }}</td>
													<td>{{($question->version)}}</td>
													<td>{{ $availabilities[$question->availability] }}</td>
													<td>{{
														MSLST_Common::getCertificationNames($question->certifications->all())
														}}</td>
													<td>{{ $question->is_mandatory ? 'Yes' : 'No' }}</td>
													<td>{{ $question->is_archived ? 'Yes' : 'No' }}</td>

													<td class="action-buttons" nowrap>{{ Form::open(['route' =>
														['questionsedit', $question->id,$question->availability],
														'method' => 'get']) }} {{ Form::button('Edit', ['type' =>
														'submit', 'class' => 'btn btn-primary btn-xs']) }} {{
														Form::close() }} {{ Form::open(['route' =>
														['questionsdestroy',
														$question->id,$question->availability], 'method' =>
														'get']) }} {{ Form::button('Remove', ['type' => 'submit',
														'class' => 'btn btn-danger btn-xs
														question-delete-button']) }} {{ Form::close() }}</td>
												</tr>
												@endforeach
											</tbody>
										</table>
										@else
										<table class="table table-hover table-striped"
											id="questions-list">
											<thead>
												<th>Question</th>
												<th>Availability</th>
												<th>Certifications</th>
												<th>Mandatory</th>
												<th>Archived</th>
												<th></th>
											</thead>
											<tbody>
												@foreach($questions as $question)
												<tr>
													<td class="autotip" title="{{$question->text}}">{{
														$question->text }}</td>
													<td>{{ $availabilities[$question->availability] }}</td>
													<td>{{
														MSLST_Common::getCertificationNames($question->certifications->all())
														}}</td>
													<td>{{ $question->is_mandatory ? 'Yes' : 'No' }}</td>
													<td>{{ $question->is_archived ? 'Yes' : 'No' }}</td>
													<td class="action-buttons" nowrap>{{ Form::open(['route' =>
														['questionsedit', $question->id,$question->availability],
														'method' => 'get']) }} {{ Form::button('Edit', ['type' =>
														'submit', 'class' => 'btn btn-primary btn-xs']) }} {{
														Form::close() }} {{ Form::open(['route' =>
														['questionsdestroy',
														$question->id,$question->availability], 'method' =>
														'get']) }} {{ Form::button('Remove', ['type' => 'submit',
														'class' => 'btn btn-danger btn-xs
														question-delete-button']) }} {{ Form::close() }}</td>
												</tr>
												@endforeach
											</tbody>
										</table>
										@endif
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

</div>


<!-- /#page-wrapper -->
@stop
