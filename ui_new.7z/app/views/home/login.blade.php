@extends('layouts.master')

@section('content')
<div class="loginColumns animated fadeInDown">
            <div class="row">

                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <div class="ibox-content">
                        <h2>Please Sign in</h2>

                        @if(Session::has('success'))
                            <div id="form-success" class="alert alert-success" role="alert">
                                <span>
                                    {{ trans(Session::get('success')) }}
                                </span>
                            </div>
                        <!-- end form-success -->
                        @endif

                        @if(Session::has('error'))
                            <div id="form-errors" class="alert alert-danger" role="alert">
                                <span>
                                    {{ trans(Session::get('error')) }}
                                </span>
                            </div>
                        <!-- end form-errors -->
                        @endif

                        {{ Form::open(['action' => 'HomeController@postLogin', 'method' => 'post', 'autocomplete' => 'off']) }}
                            <div class="form-group">
                                {{ Form::email('email', '', ['class' => 'form-control', 'placeholder' => 'E-mail', 'autofocus' => 'autofocus', 'autocomplete' => 'off']) }}
                            </div>
                            <div class="form-group">
                                {{ Form::password('password', ['class' => 'form-control', 'placeholder' => 'Password', 'autocomplete' => 'off']) }}
                            </div>
                            {{ Form::button('Login', ['type' => 'submit', 'class' => 'btn btn-primary full-width m-b']) }}
                            
                            <div class="form-group">
                                 <div class="row">
                                     <div class="col-lg-6">{{ HTML::linkRoute('accessrequest', 'New User?') }}</div>
                                     <div class="col-lg-6">{{ HTML::linkRoute('password.index', 'Forgot Password?') }}</div>
                                </div>
                            </div>
                            {{ Form::token() }}
                    {{ Form::close() }}
                    </div>
                </div>
            </div>

</div>
@stop