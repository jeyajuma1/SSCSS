@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="error-panel panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Access Denied</h3>
                </div>
                <div class="panel-body">
                    <p>Sorry, You are not permitted to access this page.</p>
                </div>
            </div>
        </div>
    </div>
</div>
@stop