<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		@if(isset($body))
			@if(isset($token))
				{{ str_replace('%reset-url%', URL::to('password', [$token]), $body) }}
			@else
				{{ $body }}
			@endif
		@endif
	</body>
</html>
