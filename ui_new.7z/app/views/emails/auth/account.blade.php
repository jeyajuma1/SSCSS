<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Your Microsoft Logistic Security Tool account</h2>

		<div>
			Dear User,<br/>
			<br/>
			This is an automatic notification e-mail from Microsoft Logistic Security Tool.<br/>
			A new account in Microsoft Logistic Security Tool has been created for you.<br/>
			<br/>
			To create your login password, complete this form: {{ URL::to('password', array($token)) }}.<br/>
			This link will expire in 24 hours.<br/>
			<br/>
			If you need further assistance, please don't hesitate to contact logistics-security@microsoft.com<br/>
			<br/>
			Best regards,<br/>
			Microsoft Logistics Security Team<br/>
		</div>
	</body>
</html>
