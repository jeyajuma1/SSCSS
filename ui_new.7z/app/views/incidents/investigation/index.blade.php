@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
            Investigation
            <div class="btn-group pull-right">
            	{{ Form::button('Add New Investigation', ['type' => 'button', 'class' => 'btn btn-primary', 'href' => route('investigation.create')]) }}
            </div>
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    
    @if(Session::has('success'))
    <div id="form-success" class="alert alert-success" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div>
    <!-- end form-success -->
    @endif

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                     Investigation  
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-striped" id="countries-list">
                        <thead>
                            <th>Name</th>
                            <th></th>
                        </thead>
                        <tbody>
                        	@foreach($inves_lst as $investigation)
                            <tr>
                                <td>{{ $investigation->name }}</td>
                                <td class="action-buttons" nowrap>
                                {{ Form::open(['route' => ['investigation.edit', $investigation->id], 'method' => 'get']) }}
                                	{{ Form::button('Edit', ['type' => 'submit', 'class' => 'btn btn-primary btn-xs']) }}
			                    {{ Form::close() }}
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->
@stop