@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">
            {{(Input::get('type') != 'incident') ? ucfirst(Input::get('type')) : '' }} Incidents
            <div class="btn-group pull-right incident-btns">
            @if(Auth::User()->access_factory_incidents)
                {{ Form::button('<i class="fa fa-plus "></i> Add Factory Incident', ['type' => 'button', 'class' => 'btn btn-primary', 'href' => route('factory.incidents.create')]) }}
            @endif    
                {{ Form::button('<i class="fa fa-plus "></i> Add Incident', ['type' => 'button', 'class' => 'btn btn-primary', 'href' => route('incidents.create')]) }}
            </h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>

     @if(Session::has('success'))
    <div id="form-success" class="alert alert-success" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div>
    <!-- end form-success -->
    @endif

    <div class="row">
        <div class="col-lg-12">
              <div class="ibox float-e-margins animated flipInX">
                    <div class="ibox-title">
                        <h5>
                            <i class="fa fa-filter" aria-hidden="true"></i> Filters
                        </h5>
                        <div class="ibox-tools">
                            <a class="collapse-link"> <i class="fa fa-chevron-up"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                        <div class="row">
                             <div class="panel panel-default incidents-panel">
                                <div class="panel-heading">
                                     {{ Form::open(['route' => 'incidents.index', 'method' => 'get', 'id' => 'incidents-list-form', 'class' => 'form-inline', 'role' => 'form']) }}
                                        <div class="form-group-row">
                                             @if(Auth::User()->access_factory_incidents)
                                                <div class="form-group">
                                                    <div class="input-group">
                                                         <span class="input-group-addon">Type</span>
                                                        {{ Form::select('type',['incident'=>'Logistic','factory'=>'Factory'] ,Input::get('type'), ['class' => 'form-control']) }}
                                                    </div>
                                                </div>
                                             @endif
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                                        {{ Form::text('daterange', Input::get('daterange'), ['class' => 'form-control']) }}
                                                    </div>
                                                </div>
                                            @if(!\Auth::user()->isUser())
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">User</span>
                                                        {{ Form::select('user[]', $users, Input::get('user'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                    </div>
                                                </div>
                                            @endif

                                            @if(Input::get('type') != 'factory')
                                                <div class="form-group" id="customer-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">Customer</span>
                                                        {{ Form::select('customer[]', $customers, Input::get('customer'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">Category</span>
                                                        {{ Form::select('category[]', ['minor' => 'Minor', 'medium' => 'Medium', 'major' => 'Major'], Input::get('category'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                    </div>
                                                </div>
                                            @endif
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">Status</span>
                                                        {{ Form::select('status[]', ['open' => 'Open', 'closed' => 'Closed'], Input::get('status'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                    </div>
                                                </div>
                                            @if(\Auth::user()->isAdmin() || \Auth::user()->isManager())
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">LSP</span>
                                                        {{ Form::select('lsp[]', $lsps, Input::get('lsp'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                    </div>                               
                                                </div>
                                            @endif
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">Region</span>
                                                        {{ Form::select('region[]', $regions, Input::get('region'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                    </div>                               
                                                </div>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">Country&nbsp;&nbsp;</span>
                                                        {{ Form::select('country[]', $countries, Input::get('country'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                    </div>                              
                                                </div>
                                            @if(Input::get('type') != 'factory')
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">Review</span>
                                                        {{ Form::select('review[]', ['1' => 'Requested', '0' => 'Not Requested'], Input::get('review'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                    </div>                              
                                                </div>
                                                <div class="form-group">
                                                        <div class="input-group">
                                                        <span class="input-group-addon">Device Type</span>
                                                        {{ Form::select('type_of_device[]', ['Keyboard'=>'Keyboard','Mouse'=>'Mouse','Phone'=>'Phone','Xbox'=>'Xbox','Proto Device'=>'Proto Device','Other'=>'Other'], Input::get('type_of_device'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                        </div>
                                                </div>
                                            @endif
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">Keywords</span>
                                                        {{ Form::text('keywords', Input::get('keywords'), ['class' => 'form-control keywords']) }}
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">Incident ID</span>
                                                        {{ Form::text('incident_id', Input::get('incident_id'), ['class' => 'form-control incident-id']) }}
                                                    </div>                              
                                                </div>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">Closure</span>
                                                        {{ Form::select('closure[]', ['Requested' => 'Requested', 'Accept' => 'Accept', 'Deny' => 'Deny'], Input::get('closure'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="input-group">
                                                        <span class="input-group-addon">IMEI</span>
                                                         {{ Form::text('imielist', Input::get('imielist'), ['class' => 'form-control IMIELIST']) }}
                                                    </div>
                                                </div>
                                                <div class="form-group text-left hidden">
                                                    {{ Form::button('Filter', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                                    {{ Form::button('Reset', ['type' => 'reset', 'class' => 'btn btn-primary', 'id' => 'incident-filter-reset']) }}
                                                </div>
                                        </div>
                                        {{ Form::close() }}
                                </div>
                             </div>
                        </div>
                    </div>
              </div>

 
              <div class="ibox float-e-margins animated flipInX">
                                <div class="ibox-title">
                                    <h5>
                                        <i class="fa fa-table" aria-hidden="true"></i> {{(Input::get('type') != 'incident') ? ucfirst(Input::get('type')) : '' }} Incidents
                                    </h5>
                                    <div class="ibox-tools">
                                         
                                    </div>
                                </div>
                                <div class="ibox-content">
                                    <div class="row">
                                         <div class="col-lg-12">
                                             <div class="panel panel-default sitemasters-panel">
                                                <div class="panel-body">
                                                     @if(Input::get('type') == 'incident' || empty(Input::get('type')) )
                                                        <table class="table table-hover table-bordered" id="incidents-list">
                                                                <thead id="incident-head">
                                                                    <th></th>
                                                                    <th>ID</th>
                                                                    <th>Date of Event</th>
                                                                    <th>Category</th>
                                                                    <th>Company</th>
                                                                    <th>Loss Value</th>
                                                                    <th>Country</th>
                                                                    <th>City</th>
                                                                    <th width="10%">Customer</th>
                                                                    <th>Added By</th>
                                                                    <th>Status</th>
                                                                </thead>
                                                                <tbody>
                                                                    @foreach($incidents as $incident)
                                                                    <tr class="clickable-row incident-item {{$incident->category}}class" data-id="{{ $incident->id }}"  >
                                                                        <td>
                                                                            @if($incident->review_requested == 1)
                                                                            <span class="glyphicon glyphicon-exclamation-sign icon-red"></span>
                                                                            @endif
                                                                        </td>
                                                                        <td>{{ $incident->id}}</td>
                                                                        <td>{{ $incident->incident_date->format('Y-m-d') }}</td>
                                                                        <td>&nbsp;&nbsp;&nbsp;{{ $incident->category }}&nbsp;&nbsp;&nbsp;</td>
                                                                        <td>@if(!empty($incident->user->lsp->name)) {{ $incident->user->lsp->name }} @else &nbsp; @endif</td>
                                                                        <td>@if($incident->type_of_device!='["Proto Device"]')${{number_format($incident->product->total_value_of_lost_units,'2','.',',')}}@else NA @endif</td>
                                                                        <td>{{ $incident->country->name }}</td>
                                                                        <td>{{ $incident->location_city }}</td>
                                                                        <td>{{ $incident->customer }}</td>
                                                                        <td>{{ $incident->user->name  }}</td>
                                                                        {{--*/ $status = \MSLST\Helpers\Common::getDateStatus($incident->closed_at, 'Closed', 'Open') /*--}}
                                                                        @if($status['code'])
                                                                            <td class="success_close">&nbsp;&nbsp;&nbsp;{{ $status['label'] }}&nbsp;&nbsp;&nbsp;</td>
                                                                        @else
                                                                            <td class="danger_open">&nbsp;&nbsp;&nbsp;{{ $status['label'] }}&nbsp;&nbsp;&nbsp;</td>
                                                                        @endif
                                                                    </tr>
                                                                    @endforeach
                                                                </tbody>
                                                        </table>
                                                     @elseif(Input::get('type') == 'factory')
                                                       <table class="table table-hover table-bordered" id="incidents-list">
                                                            <thead id="factory-head">
                                                                <th></th>
                                                                <th>Date of Event</th>
                                                                <th>Company</th>
                                                                <th>Loss Value</th>
                                                                <th>Country</th>
                                                                <th>Region</th>
                                                                <th>Status</th>
                                                                <th>Added By</th>
                                                            </thead>
                                                            <tbody>
                                                                @foreach($incidents as $incident)
                                                                    <tr class="clickable-row incident-item" data-item='factory' data-id="{{$incident->id}}">
                                                                        <td></td>
                                                                        <td>{{$incident->incident_event_date->format('Y-m-d')}}</td>
                                                                        <td>@if(!empty($incident->user->lsp->name)) {{ $incident->user->lsp->name }} @else &nbsp; @endif</td>
                                                                        <td>{{!empty($incident->product->total_value_of_loss_unit) ? (round($incident->product->total_value_of_loss_unit,2))  : ''}}</td>
                                                                        <td>{{$incident->country->name}}</td>
                                                                        <td>{{$incident->region->name}}</td>
                                                                        {{--*/ $status = \MSLST\Helpers\Common::getDateStatus($incident->closed_at, 'Closed', 'Open') /*--}}
                                                                        @if($status['code'])
                                                                            <td class="success_close">&nbsp;&nbsp;&nbsp;{{ $status['label'] }}&nbsp;&nbsp;&nbsp;</td>
                                                                        @else
                                                                            <td class="danger_open">&nbsp;&nbsp;&nbsp;{{ $status['label'] }}&nbsp;&nbsp;&nbsp;</td>
                                                                        @endif
                                                                        <td>@if(!empty($incident->user->name)) {{ $incident->user->name }} @else &nbsp; @endif</td>
                                                                    </tr>
                                                                @endforeach
                                                            </tbody>
                                                        </table>
                                                      @endif
                                                </div>
                                             </div>
                                         </div>
                                    </div>
                                </div>
              </div>
        </div>
    </div>

</div>

<!-- /#page-wrapper -->
@stop