@extends('layouts.master')

@section('content')

<div class="body_content">
      <div id="wrapper">
               @if($edit)
                  <h1 class="page-header">Edit Factory Incident</h1>
                @else
                  <h1 class="page-header">Create  Factory Incident</h1>
                @endif
      </div> <!--/*wrapper -->

      <div class="wrapper-content animated fadeInRight">
        <div class="row">
          <div class="col-lg-12">
             <div class="ibox">
                <div class="ibox-title">
                    <h5>Basic Information</h5>
                    <div class="ibox-tools">
                      <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>  
                    </div>
                </div> <!--/*ibox-title -->
                <div class="ibox-content">
                      <div class="wizard">
                                    <a class="current">
                                      <span>1. Basic Information</span>
                                    </a>
                                    <a>
                                      <span>2. Incident Details</span>
                                    </a>
                                    <a>
                                      <span>3. Investigation/Attachments </span>
                                    </a>

                      </div>
                      <!--/*wizard -->
                     <div class="panel panel-default wizard_body"> 
                      {{ Form::open(['route' => ($edit ? ['factory.incidents.update', $data->id] : 'factory.incidents.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal factory-incident-form', 'role' => 'form', 'id' => 'incident-form-basic']) }}
                        {{ Form::hidden('step', 0) }}
                            <div class="panel-body"  >
                                <!-- end form-errors -->
                                <div class="row">
                                    <div class="col-lg-9">
                                           @if($errors->all())
                                  <div id="form-errors" class="alert alert-danger" role="alert">
                                    <ul>
                                      @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                      @endforeach
                                    </ul>
                                  </div>
                                  @endif



                                  <div class="form-group">
                                    {{ Form::label('short_description', 'Short description', ['class' => 'col-sm-3 control-label']) }}
                                    <div class="col-sm-6">
                                      {{ Form::textarea('short_description', $data->short_description, ['rows' => 3, 'class' => 'form-control']) }}
                                    </div>
                                  </div>  

                                   <div class="form-group">
                                    {{ Form::label('date_of_event', 'Date of event', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                      <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        @if($edit)
                                        {{ Form::text('incident_event_date', (!empty($data->incident_event_date)) ?  $data->incident_event_date->format('Y-m-d') : '', ['class' => 'form-control']) }}
                                        @else
                                        {{Form::text('incident_event_date',$data->incident_event_date, ['class' => 'form-control']) }}
                                        @endif
                                      </div>
                                    </div>
                                  </div>
                                  <?php $reg_chk = array_keys($regions);?>
                                  @if(in_array(3,$reg_chk) ||  in_array(5,$reg_chk))
                                    <div class="form-group">
                                      {{ Form::label('select_from_existing_event', 'Select From Existing Sites', ['class' => 'col-sm-3 control-label']) }}
                                      <div class="col-sm-8 existing_site">
                                       
                                        @if(in_array(5,$reg_chk))
                                          <div class="col-sm-4">
                                             {{ Form::button('Hanoi', ['type' => 'button', 'class' => 'form-control btn btn-primary', 'id' => 'incident-hanoi-check']) }}
                                          </div>
                                        @endif
                                        @if(in_array(3,$reg_chk))
                                          <div class="col-sm-4">
                                           {{ Form::button('Manaus', ['type' => 'button', 'class' => 'form-control btn btn-primary', 'id' => 'incident-manaus-check']) }}
                                          </div>
                                        @endif
                                        @if(in_array(3,$reg_chk))
                                          <div class="col-sm-4">
                                           {{ Form::button('Reynosa', ['type' => 'button', 'class' => 'form-control btn btn-primary', 'id' => 'incident-reynosa-check']) }}
                                          </div> 
                                        @endif
                                      </div>
                                    </div>
                                  @endif

                                   <div class="form-group">
                                    {{ Form::label('region', 'Region', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                      {{ Form::select('region', $regions, $data->region, ['class' => 'form-control']) }}
                                    </div>
                                  </div>  
                                   <div class="form-group">
                                    {{ Form::label('country', 'Country', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                      {{ Form::select('country', $countries, $data->country,['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                   <div class="form-group">
                                    {{ Form::label('city', 'City', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                      {{ Form::text('city', $data->city,['class' => 'form-control']) }}
                                    </div>
                                  </div>  

                                  <div class="form-group">
                                    {{ Form::label('facility', 'Facility/Site', ['class' => 'col-sm-3 control-label']) }}
                                    <div class="col-sm-6">
                                      {{ Form::text('facility', $data->facility, ['class' => 'form-control']) }}
                                    </div>
                                  </div>  

                                  <div class="form-group">
                                    {{ Form::label('location_address', 'Address', ['class' => 'col-sm-3 control-label']) }}
                                    <div class="col-sm-6">
                                      {{ Form::text('location_address', $data->location_address, ['class' => 'form-control']) }}
                                    </div>
                                  </div>  

                                  <div class="form-group">
                                    {{ Form::label('coordinates', 'Coordinates', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-4">
                                      {{ Form::text('coordinates', $data->coordinates, ['class' => 'form-control', 'placeholder' => 'Coordinate format: latitude, longitude', 'id' => 'coordinates']) }}
                                    </div>
                                    <div class="col-sm-2">
                                      <input type="hidden" id="myField" value="" />
                                      {{ Form::button('Validate', ['type' => 'button', 'class' => 'form-control btn btn-primary btn-validate', 'id' => 'incident-coordinate-check']) }}
                                    </div>
                                  </div>

                                  <div class="form-group">
                                    <div class="col-sm-6 col-sm-offset-3" id="incident-coordinate-pick"></div>
                                  </div>

                                  <div class="form-group">
                                    <div class="col-sm-6 col-sm-offset-3 description">
                                    (Example: 42.374335,-71.116991 (Decimal Degrees) or N30 17.477,W97 44.315 (GPS) or N42 21 30,W71 06 14 (Degrees, Minutes &amp; Seconds) or 19N 326727 4691707 (UTM))
                                    </div>
                                  </div>


                                    </div>

                                    <div class="col-lg-3">
                                         <div class="pull-right text-danger">
                                            (*) Mandatory Field
                                        </div>
                                        <div class="text-center">
                                          <div style="margin-top: 20px">
                                            <i style="font-size: 180px; color: #e5e5e5" class="fa fa-sign-in"></i>
                                          </div>
                                        </div>
                                     </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                                 @if($edit)
                                      {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                      {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('factory.incidents.show', $data->id),'id'=>'incident_cancel_edit']) }}
                                  @else
                                      {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                      {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.index'),'id'=>'incident_cancel']) }}
                                  @endif
                            </div>
                        {{ Form::close() }}
                     </div>  <!--/* wizard_body -->
                </div>    <!--/* ibox-content -->
              </div>  <!--/* ibox -->
          </div> <!--/* col-lg-12 -->
        </div>  <!--/* row-->
      </div>  <!--/* animated-->
</div>
 
<!--<script type="text/javascript" charset="UTF-8" src="https://js.api.here.com/ee/2.5.4/jsl.js?with=all"></script>-->
 <script type="text/javascript" charset="UTF-8"  src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
 var FactoryIncidents = {'coordinates':null ,'mapElement':null};
     FactoryIncidents.regions = '{{$regions_json}}';
     FactoryIncidents.country = '{{Input::old("country")?:$data->country}}'; 
</script>
@stop
