@extends('layouts.master')

@section('content')
<div class="body_content">
     <div class="row border-bottom white-bg page-heading">
        <div class="row">
            <div class="col-lg-12">
              <h2 class="show_page_header"> Factory Incident Summary</h2>
            </div>
          </div>
     </div>
     <div class="alert alert-warning"> 
           <h4>Data not yet saved. Please review the information and confirm once done.</h4> 
     </div>

     <div class="animated fadeIn">
      {{ Form::open(['route' => 'factory.incidents.store', 'method' => 'post', 'class' => 'incident-form', 'role' => 'form', 'id' => 'form-summary', 'files' => true]) }}
            {{ Form::hidden('step', 3) }}
       <div class="panel-body">
           <div class="col-lg-8">
                <div class="ibox float-e-margins">
                     <div class="ibox-title">
                          <h5><i class="fa fa-briefcase"></i>  Basic Information</h5>
                          <div class="ibox-tools">
                                         <button type="button" class="btn btn-default btn-xs" href="{{ route('factory.incidents.create', 0) }}">
                                          Edit
                                      </button>
                                      <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>
                             </div>
                      </div>  <!-- /.ibox-title -->
                       
                     <div class="ibox-content">
                         <div class="table-responsive">
                              <table class="table site_summary">
                                  <tbody>
                                      <tr>
                                          <td>
                                              <b>Description</b><br />
                                              <p>{{ $data['basic_information']->short_description }}</p>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                            <table class="incidents-basic-table">
                                              <tbody>
                                                <tr>
                                                     <td><b>Facility</b></td>
                                                    <td><b>Date of event</b></td>
                                                    <td><b>Region</b></td>
                                                </tr>
                                                <tr>
                                                      <td>{{$data['basic_information']->facility}}</td>
                                                    <td>{{$data['basic_information']->incident_event_date}}</td>
                                                    <td>{{$region[$data['basic_information']->region]}}</td>
                                                </tr>
                                                <tr>  
                                                  <td><b>Country</b></td>
                                                   <td><b>City</b></td>
                                                   <td><b>GPS Coordinates</b></td>
                                                </tr>
                                                <tr>
                                                  <td class='basic_valign'>{{ $country[$data['basic_information']->country] }}</td> 
                                                  <td class='basic_valign'>{{ $data['basic_information']->city }}</td>
                                                 
                                                  <td class='basic_valign'>{{ $data['basic_information']->coordinates }}</td>
                                                </tr>
                                                <tr>
                                                  <td><b>Address</b></td>
                                                </tr>
                                                <tr>
                                                   <td>{{ $data['basic_information']->location_address }}</td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                              <div id="incident_map" class="detail-view-map span12 col-sm-12">
                                              </div>
                                          </td>
                                      </tr>
                                  </tbody>
                              </table>
                         </div>
                     </div>  <!-- /.ibox-content -->
               </div>  <!-- /.ibox float-e-margins -->


                <div class="ibox float-e-margins">
                     <div class="ibox-title">
                          <h5><i class="fa fa-briefcase"></i> Incident Details  </h5>
                          <div class="ibox-tools">
                                     <button type="button" class="btn btn-default btn-xs" href="{{ route('factory.incidents.create', 1) }}">
                                          Edit
                                      </button>
                               <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>
                          </div>
                      </div>  <!-- /.ibox-title -->
                       
                     <div class="ibox-content">
                         <div class="table-responsive">
                                  <table class="table site_summary">
                                        <tbody>
                                            <tr class="active">
                                                <td colspan="3"><b>Customer details</b></td>
                                            </tr>
                                            <tr>
                                                <td><b>Person(s) name(s) Involved</b></td>
                                                <td><b>Loss Discovered By (name & title)</b></td>
                                                <td><b>Location of incident within sitepremises</b></td>
                                            </tr>
                                            <tr>
                                                <td>{{ $data['incident_details']->persons_involved }}</td>
                                                <td>{{ $data['incident_details']->loss_discovered_by }}</td>
                                                <td>{{ $data['incident_details']->location_of_incident_within_sitepremises }}</td>
                                            </tr>
                                             
                                            <tr>
                                                <td><b>Product /item description</b></td>
                                                <td><b>Part number</b></td>
                                                <td><b>Serial number</b></td>
                                            </tr>
                                            @foreach($data['incident_details']->product_description as $ky=>$va)
                                              <tr>
                                                <td style="border:1px solid #ccc;" >{{ $data['incident_details']->product_description[$ky] }}</td>
                                                <td style="border:1px solid #ccc;" >{{ $data['incident_details']->part_number[$ky] }}</td>
                                                <td style="border:1px solid #ccc;" >{{ $data['incident_details']->serial_number[$ky] }}</td>
                                            </tr>
                                            @endforeach
                                            <tr>
                                                <td><b>Product family</b></td>
                                                <td><b>Number of units missing</b></td>
                                                <td><b>Value per unit(USD)</b></td>
                                            </tr>

                                            @foreach($data['incident_details']->product_family as $ky=>$va)
                                            <tr>
                                                <td style="border:1px solid #ccc;">{{ $data['incident_details']->product_family[$ky] }}</td>
                                                <td style="border:1px solid #ccc;">{{ $data['incident_details']->number_of_unit_missing[$ky] }}</td>
                                                <td style="border:1px solid #ccc;">{{ $data['incident_details']->value_per_unit[$ky] }}</td>
                                            </tr>
                                            @endforeach
                                            <tr>
                                             <td class="text-danger" colspan="3"><b>Total value of units(USD)</b></td>
                                            </tr>
                                            <tr>
                                              <td class="text-danger incidentviewtd" colspan="2" >{{ $data['incident_details']->total_value_of_loss_unit }}</td>
                                            </tr>
                                        </tbody>
                                    </table> 
                         </div>
                     </div>  <!-- /.ibox-content -->
               </div>  <!-- /.ibox float-e-margins -->

                <div class="ibox float-e-margins">
                     <div class="ibox-title">
                          <h5><i class="fa fa-briefcase"></i> Investigation/Attachments  </h5>
                          <div class="ibox-tools">
                                       <button type="button" class="btn btn-default btn-xs" href="{{ route('factory.incidents.create', 2) }}">
                                          Edit
                                      </button>
                                  <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>
                             </div>
                      </div>  <!-- /.ibox-title -->
                       
                     <div class="ibox-content">
                         <div class="table-responsive">
                               <table class="table site_summary">
                                        <tbody>
                                            <tr class="active">
                                                <td colspan="3"><b>Investigation details</b></td>
                                            </tr>
                                            <tr>
                                                <td><b>Name of the investigation authority</b></td>
                                                <td><b>Contact information</b></td>
                                                <td><b>Investigation file number</b></td>
                                            </tr>
                                            <tr>
                                                <td>{{ $data['investigation_attachments']->name_of_investigation_authority }}</td>
                                                <td>{{ $data['investigation_attachments']->contact_information }}</td>
                                                <td>{{ $data['investigation_attachments']->investigation_file_number }}</td>
                                            </tr>
                                             
                                            <tr>
                                                <td><b>Incident refered to</b></td>
                                                <td><b>On Date & time</b></td>
                                                <td><b>Investigation description and action taken</b></td>
                                            </tr>
                                            <tr>
                                                <td>{{ $data['investigation_attachments']->incident_refered_to }}</td>
                                                <td>{{ $data['investigation_attachments']->on_date }} , {{ $data['investigation_attachments']->on_time }}</td>
                                                <td>{{ $data['investigation_attachments']->investigation_description_and_action_taken }}</td>
                                            </tr>
                                            <tr>
                                                <td colspan="3"><b>Final investigation findings, root cause analysis & corrective actions</b></td>
                                            </tr>
                                            <tr>
                                               <td > 
                                                    {{ $data['investigation_attachments']->final_investigation_findings_cause_analysis_corrective_actions }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>Current investigation status</b></td>
                                            </tr>
                                            <tr>
                                                <td> 
                                                    <?php $color = [1=>'primary',2=>'danger',3=>'success',4=>'info',5=>'warning'] ?>
                                                    @if(empty($color[$data['investigation_attachments']->current_investigation_status])) <?php $colr = 1; ?> @else <?php $colr = $data['investigation_attachments']->current_investigation_status ?> @endif
                                                    <select  class="selectpicker investigation_status" name='investigation_status'>
                                                           <option data-content="&lt;span class='label label-{{$color[$colr]}}'&gt;{{$InvestigationStus->name}}&lt;/span&gt;" value='{{$InvestigationStus->name}}'>{{$InvestigationStus->name}}</option>
                                                    </select>
                                                </td>

                                            </tr>
                                        </tbody>
                                    </table>     
                         </div>
                     </div>  <!-- /.ibox-content -->
               </div>  <!-- /.ibox float-e-margins -->
           </div><!-- /.col-lg-8 -->
          
          <div class="col-lg-4">
               <div class="ibox float-e-margins">
                           <div class="ibox-title">
                                <h5><i class="fa fa-briefcase"></i>Attachments</h5>
                                <div class="ibox-tools">
                                     <button type="button" class="btn btn-default btn-xs" href="{{ route('factory.incidents.create', 2) }}">
                                          Edit
                                      </button>
                                            <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>
                                   </div>
                            </div>  <!-- /.ibox-title -->
                             
                           <div class="ibox-content">
                               <div class="table-responsive">
                                         <table class="table site_summary">
                                        <tbody>
                                          @if(!empty($data['investigation_attachments']->attachment))
                                              @foreach($data['investigation_attachments']->attachment as $key=>$attachment)
                                              <tr>
                                                <td>
                                                   {{ str_limit($attachment['file_description'], 40) }}<br/>
                                                    <span>{{$attachment['description']}}</span>
                                                </td> 
                                              </tr>
                                              @endforeach
                                          @else
                                            <tr>
                                              <td>No attachments.</td>
                                            </tr>
                                            @endif
                      
                                        </tbody>
                                    </table>
                               </div>
                           </div>  <!-- /.ibox-content -->
               </div>  <!-- /.ibox float-e-margins -->
          </div><!-- /.col-lg-4 -->        
       </div>  <!-- /.panel-body -->
         <div class="panel-footer summary_footer">
                <div class="clearfix">
                            <div class="pull-left">
                              {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }}
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Confirm', ['type' => 'submit', 'class' => 'btn btn-primary','id'=>'summaryform']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.index'),'id'=>'incident_cancel']) }}
                            </div>
                          </div>         
        </div>
    </div> <!-- /#wrapper-content -->
</div>
 
 
<!--<script src="//js.api.here.com/ee/2.5.4/jsl.js?with=all" type="text/javascript" charset="utf-8"></script>-->
<script type="text/javascript" charset="UTF-8"  src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
  var FactoryIncidents = {
    mapElement: 'incident_map',
    coordinates: '{{ $data["basic_information"]->coordinates }}'
  };
</script>
@stop
