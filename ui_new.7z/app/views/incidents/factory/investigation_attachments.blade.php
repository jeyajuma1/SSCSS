@extends('layouts.master')

@section('content')


<div class="body_content">
      <div id="wrapper">
               @if($edit)
                  <h1 class="page-header">Edit Factory Incident</h1>
                @else
                  <h1 class="page-header">Create  Factory Incident</h1>
                @endif
      </div> <!--/*wrapper -->

      <div class="wrapper-content animated fadeInRight">
        <div class="row">
          <div class="col-lg-12">
             <div class="ibox">
                <div class="ibox-title">
                    <h5>Investigation/Attachments </h5>
                    <div class="ibox-tools">
                      <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>  
                    </div>
                </div> <!--/*ibox-title -->
                <div class="ibox-content">
                      <div class="wizard">
                                    <a >
                                      <span>1. Basic Information</span>
                                    </a>
                                    <a>
                                      <span>2. Incident Details</span>
                                    </a>
                                    <a class="current">
                                      <span>3. Investigation/Attachments </span>
                                    </a>

                      </div>
                      <!--/*wizard -->
                     <div class="panel panel-default wizard_body"> 
                         {{ Form::open(['route' => ($edit ? ['factory.incidents.update', $data->id] : 'factory.incidents.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'factory-incident-detail-form', 'role' => 'form', 'id' => 'incident-form-investigation', 'files' => true]) }}
                        {{ Form::hidden('step', 2) }}
                            <div class="panel-body"  >
                                <!-- end form-errors -->
                                <div class="row">
                                    <div class="col-lg-9">
                                            @if($errors->all())
                                            <div id="form-errors" class="alert alert-danger" role="alert">
                                              <ul>
                                                @foreach($errors->all() as $error)
                                                  <li>{{ $error }}</li>
                                                @endforeach
                                              </ul>
                                            </div>
                                            @endif

  
                                  <div class="row">
                                    <div class="col-lg-11">
                                          <div class="form-group">
                                            <h4>Investigation Details</h4>
                                          </div>
                                    </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-lg-4">
                                          <div class="form-group">
                                            {{ Form::label('name_of_investigation_authority', 'Name of the investigation authority', ['class' => 'control-label required']) }}
                                            {{ Form::text('name_of_investigation_authority', $data->name_of_investigation_authority, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                      <div class="col-lg-0">
                                      </div>
                                      <div class="col-lg-4">
                                          <div class="form-group">
                                            {{ Form::label('contact_information', 'Contact information', ['class' => 'control-label required']) }}
                                            {{ Form::text('contact_information', $data->contact_information, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                      <div class="col-lg-0">
                                      </div>
                                      <div class="col-lg-4">
                                          <div class="form-group">
                                            {{ Form::label('investigation_file_number', 'Investigation file number', ['class' => 'control-label required']) }}
                                            {{ Form::text('investigation_file_number', $data->investigation_file_number, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                  </div>

                                  <div class="row">
                                      <div class="col-lg-3">
                                          <div class="form-group">
                                            {{ Form::label('incident_refered_to', 'Incident refered to', ['class' => 'control-label required']) }}
                                            {{ Form::text('incident_refered_to', $data->incident_refered_to, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                      
                                      <div class="col-lg-5">
                                          <div class="form-group clearfix">
                                            {{ Form::label('on_date', 'On Date & time', ['class' => 'control-label required']) }}
                                               <div class="col-md-12 date-time-boxes">
                                                    <div class="col-md-5 date-time-boxes">
                                                      <div class="input-group">
                                                           <span class="input-group-addon"><i class="fa fa-calendar"></i></span> 
                                                          {{ Form::text('on_date', is_object($data->on_date) ? $data->on_date->format('Y-m-d') : $data->on_date, ['class' => 'form-control' ,'id' => 'ondatetime_fields']) }}
                                                      </div>
                                                   </div>
                                                   <div class="col-md-2 text-center incident-at">
                                                       <span> at </span>
                                                    </div>
                                                <div class="col-md-5 date-time-boxes">
                                                    <div class="input-group bootstrap-timepicker">
                                                        <span class="input-group-addon"><i class="fa fa-clock-o"></i></span>
                                                        {{ Form::text('on_time', $data->on_time, ['class' => 'form-control input-small']) }}
                                                    </div>
                                                  </div>
                                              </div>
                                      </div>
                                  </div>
                                  
                                  <div class="row">
                                      <div class="col-lg-11">
                                          <div class="form-group">
                                              {{ Form::label('investigation_description_and_action_taken', 'Investigation description and actions taken', ['class' => 'control-label required']) }}
                                              {{ Form::textarea('investigation_description_and_action_taken', $data->investigation_description_and_action_taken, ['class' => 'form-control', 'rows' => 3]) }}
                                          </div>
                                      </div>
                                  </div>

                                  <div class="row">
                                      <div class="col-lg-11">
                                          <div class="form-group">
                                              {{ Form::label('final_investigation_findings_cause_analysis_corrective_actions', 'Final investigation findings, root cause analysis & corrective actions', ['class' => 'control-label required']) }}
                                              {{ Form::textarea('final_investigation_findings_cause_analysis_corrective_actions', $data->final_investigation_findings_cause_analysis_corrective_actions, ['class' => 'form-control', 'rows' => 3]) }}
                                          </div>
                                      </div>
                                  </div>
                                  
                                  <div class="row">
                                      <div class="col-lg-8">
                                          <div class="form-group">
                                              {{ Form::label('current_investigation_status', 'Current investigation status', ['class' => 'control-label']) }}
                                              {{ Form::select('current_investigation_status',$InvestigationStus ,$data->current_investigation_status, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                  </div>

                                  <div class="row">
                                    <div class="col-lg-11">
                                          <div class="form-group">
                                            <h4>Attachments</h4>
                                          </div>
                                    </div>
                                  </div>
                                  <div class="attachments">
                                      @if($edit && isset($data->attachment))
                                        <?php $i = 0; ?>
                                        @foreach($data->attachment as $id)
                                          <div class="row current_{{ $id }}">
                                            <div class="col-lg-10">
                                                <div class="form-group">
                                                  {{ Form::label('file', 'File: ', ['class' => 'control-label']) }}
                                                  <a href="{{ route('incidents.download', [$id, $data->id, 'attachment']) }}">{{ str_limit($data->filename[$i], 40) }}</a>
                                                  <a href="javascript:void(0);" class="file-remove pull-right" onclick="MsLstIncidents.deleteAttachmentFile('{{$id}}')"><i class="fa fa-trash fa-fw"></i> Remove</a>
                                                  {{ Form::hidden("current_file[$id]", 1) }}
                                                </div>
                                            </div>
                                          </div>
                                          <div class="row current_{{ $id }}">
                                              <div class="col-lg-10">
                                                  <div class="form-group">
                                                    {{ Form::label("current_description[$id]", 'Attachment description', ['class' => 'control-label']) }}
                                                    {{ Form::textarea("current_description[$id]", $data->description[$i], ['class' => 'form-control', 'rows' => 3]) }}
                                                   </div>
                                              </div>
                                          </div>
                                          <?php $i++; ?>
                                          @endforeach
                                      @endif
                                      <div class="row">
                                            <div class="col-lg-10">
                                                <div class="form-group">
                                                  {{ Form::label('attachment[0]', 'File', ['class' => 'control-label']) }}
                                                  {{ Form::file('attachment[0]',array('id'=>'incidentattachment')) }}
                                                </div>
                                            </div>
                                      </div>
                                      <div class="row">
                                            <div class="col-lg-10">
                                                <div class="form-group">
                                                  {{ Form::label('description[0]', 'Description', ['class' => 'control-label']) }}
                                                  {{ Form::textarea('description[0]', null, ['class' => 'form-control', 'rows' => 3]) }}
                                                 </div>
                                            </div>
                                      </div>
                                      <div class="hidden file-index">0</div>
                                  </div>
                                 </div>

                                <div class="row">
                                    <div class="col-lg-10">
                                        {{ Form::button('Add another attachment', ['type' => 'button', 'class' => 'btn btn-primary active pull-left attachment-add-btn']) }}
                                    </div>
                                </div>
                                  <div class="hidden file-index">0</div>


                                    </div>

                                    <div class="col-lg-3">
                                         <div class="pull-right text-danger">
                                            (*) Mandatory Field
                                        </div>
                                        <div class="text-center">
                                          <div style="margin-top: 20px">
                                            <i style="font-size: 180px; color: #e5e5e5" class="fa fa-sign-in"></i>
                                          </div>
                                        </div>
                                     </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                                  @if($edit)
                                      <div class="clearfix">
                                        <div class="pull-left">
                                          {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                          {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('factory.incidents.show', $data->id),'id'=>'incident_cancel_edit']) }}
                                        </div>
                                      </div>
                                    @else
                                      <div class="clearfix">
                                        <div class="pull-left">
                                          <a href="{{($edit ? ['factory.incidents.update', $data->id] : '1')}}" class ='btn btn-default' alt='Back'>Back</a>
                                        </div>
                                        <div class="pull-right">
                                        {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.index'),'id'=>'incident_cancel']) }}
                                        </div>
                                      </div>
                                    @endif
                            </div>
                        {{ Form::close() }}
                     </div>  <!--/* wizard_body -->
                </div>    <!--/* ibox-content -->
              </div>  <!--/* ibox -->
          </div> <!--/* col-lg-12 -->
        </div>  <!--/* row-->
      </div>  <!--/* animated-->
</div>
 
<script type="text/javascript">
  var Incidents = {'coordinates': null, 'mapElement': null};
</script>
@stop