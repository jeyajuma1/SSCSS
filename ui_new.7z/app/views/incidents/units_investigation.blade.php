@extends('layouts.master')

@section('content')



<div class="body_content">
      <div id="wrapper">
               @if($edit)
                  <h1 class="page-header">Edit Incident</h1>
                @else
                  <h1 class="page-header">Create Incident</h1>
                @endif
      </div> <!--/*wrapper -->

      <div class="wrapper-content animated fadeInRight">
        <div class="row">
          <div class="col-lg-12">
             <div class="ibox">
                <div class="ibox-title">
                    <h5>Units/Investigation</h5>
                    <div class="ibox-tools">
                      <a class="collapse-link"> <i class="fa fa-chevron-up"></i></a>  
                    </div>
                </div> <!--/*ibox-title -->
                <div class="ibox-content">

                    <div class="wizard">
                                    <a >
                                      <span>1. Basic Information</span>
                                    </a>
                                    <a>
                                      <span>2. Customer/Transportation</span>
                                    </a>
                                    <a  class="current">
                                      <span>3. Units/Investigation</span>
                                    </a>
                                    <a>
                                      <span>4. Attachments</span>
                                    </a>
                     </div> <!--/*wizard -->
                     <div class="panel panel-default wizard_body"> 
                          
                       
                    {{ Form::open(['route' => ($edit ? ['incidents.update', $data->id] : 'incidents.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'incident-form', 'role' => 'form', 'id' => 'incident-form-units', 'files' => true]) }}
                        {{ Form::hidden('step', 2) }}
                            <div class="panel-body"  >
                                <!-- end form-errors -->
                                <div class="row">
                                    <div class="col-lg-9">
                                           @if($errors->all())
                                            <div id="form-errors" class="alert alert-danger" role="alert">
                                              <ul>
                                                @foreach($errors->all() as $error)
                                                  <li>{{ $error }}</li>
                                                @endforeach
                                              </ul>
                                            </div>
                                            @endif

                                               <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group">
                                          <h4>Details of Units Missing</h4>
                                        </div>
                                    </div>
                                  </div>
                                  <div>
                                  <div class="row">
                                      <div class="col-lg-8">
                                        <div class="form-group" title="Multiple device types can be selected">
                                          {{ Form::label('type_of_device', 'Type of Device', ['class' => 'control-label required']) }}
                                          {{ Form::select('type_of_device[]',['Phone'=>'Phone','Xbox'=>'Xbox','Keyboard'=>'Keyboard','Mouse'=>'Mouse','Proto Device'=>'Proto Device','Other'=>'Other'],$data->type_of_device, ['class' => 'form-control']) }}
                                        </div>    
                                      </div>  
                                      <div class="col-xs-5 typeofotherdevice">
                                        <div class="form-group">
                                          {{ Form::label('type_of_other_device', 'Specify the device type', ['class' => 'control-label required']) }}
                                          {{ Form::text('type_of_other_device', $data->type_of_other_device, ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                      <div class="col-xs-12"> </div>
                                      <div class="col-lg-5">
                                          <div class="form-group">
                                            {{ Form::label('number_of_plts_missing', 'Number of Plts/Crts Missing', ['class' => ' control-label required']) }}
                                            {{ Form::text('number_of_plts_missing', $data->number_of_plts_missing, ['class' => 'form-control protolosshide']) }}
                                          </div>
                                      </div>
                                  </div>
                                  <div class="row product-row ">
                                      <div class="col-lg-1">
                                        <label class="control-label">&nbsp;</label>
                                        <span class="form-control product-count">#1</span>
                                      </div>
                                      <div class="col-lg-4">
                                          <div class="form-group">
                                            {{ Form::label('product_description0', 'Product/item Description', ['class' => 'control-label required']) }}
                                            {{ Form::text('product_description[0]', null, ['class' => 'form-control', 'id' => 'product_description0']) }}
                                          </div>
                                      </div>
                                      <div class="col-lg-3">
                                          <div class="form-group">
                                            {{ Form::label('number_of_units_missing0', 'Number of Units Missing', ['class' => 'control-label required']) }}
                                            {{ Form::text('number_of_units_missing[0]', null, ['class' => 'form-control', 'id' => 'number_of_units_missing0']) }}
                                          </div>
                                      </div>
                                      <div class="col-lg-3">
                                          <div class="form-group">
                                            {{ Form::label('value_per_unit0', 'Value per Unit (USD)', ['class' => 'control-label required']) }}
                                            {{ Form::text('value_per_unit[0]', null, ['class' => 'form-control protolosshide', 'id' => 'value_per_unit0']) }}
                                          </div>
                                      </div>
                                  </div>
                                  <div class="row ">
                                    <div class="col-lg-10">
                                        <button type="button" class="btn btn-primary active pull-left product-add-btn">Add another product</button>
                                    </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-lg-5 ">
                                          <div class="form-group">
                                            {{ Form::label('total_value_of_lost_units', 'Total Value of lost Units (USD)', ['class' => 'control-label required']) }}
                                            {{ Form::text('total_value_of_lost_units', $data->total_value_of_lost_units, ['class' => 'form-control protolosshide']) }}
                                          </div>
                                      </div>
                                        <div class="col-lg-5">
                                          <div class="form-group">
                                            <label class="control-label">Category</label>
                                            <span class="form-control category-span"> None </span>
                                          </div>
                                      </div>
                                  </div>
                                </div>
                                  <div class="row">
                                    <div class="col-lg-11">
                                          <div class="form-group">
                                            <h4>Official Investigation Details</h4>
                                          </div>
                                    </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-lg-5">
                                          <div class="form-group">
                                            {{ Form::label('name_of_investigation_authority', 'The name of the investigation authority', ['class' => 'control-label required']) }}
                                            {{ Form::text('name_of_investigation_authority', $data->name_of_investigation_authority, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                      <div class="col-lg-1">
                                      </div>
                                      <div class="col-lg-5">
                                          <div class="form-group">
                                            {{ Form::label('investigation_file_number', 'The investigation file number', ['class' => 'control-label required']) }}
                                            {{ Form::text('investigation_file_number', $data->investigation_file_number, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                  </div>
                                  <div class="row">
                                     <div class="col-lg-5">
                                          <div class="form-group">
                                            {{ Form::label('DQI Number', 'DQI Number', ['class' => 'control-label']) }}
                                            {{ Form::text('dq','', ['class' => 'form-control','pattern'=>'[a-zA-Z0-9]+','title'=>'It will allowed only Alpha numeric values']) }}
                                          </div>
                                      </div>
                                  </div>                                  
                                 <div class="row">
                                    <div class="col-lg-11">
                                        <div class="form-group">
                                            {{ Form::label('contact_information', 'Contact information for the investigating law enforcement agency', ['class' => 'control-label']) }}
                                            {{ Form::textarea('contact_information', $data->contact_information, ['class' => 'form-control', 'rows' => 3]) }}
                                        </div>
                                    </div>
                                  </div>
                                  
                                  <div class="row">
                                    <div class="col-lg-11">
                                        <div class="form-group">
                                            {{ Form::label('first_findings', 'First Findings, Lessons learned, Short Term Actions, Loss Type (Pilferage, Theft, Robbery, etc.)', ['class' => 'control-label required']) }}
                                            {{ Form::textarea('first_findings', $data->first_findings, ['class' => 'form-control', 'rows' => 3]) }}
                                        </div>
                                    </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-lg-11">
                                        <div class="form-group">
                                            {{ Form::label('final_investigation_findings', 'Final investigation findings, root cause analysis & long term corrective actions', ['class' => 'control-label']) }}
                                            {{ Form::textarea('final_investigation_findings', $data->final_investigation_findings, ['class' => 'form-control', 'rows' => 3]) }}
                                        </div>
                                    </div>
                                  </div>

                                    </div>

                                    <div class="col-lg-3">
                                         <div class="pull-right text-danger">
                                            (*) Mandatory Field
                                        </div>
                                        <div class="text-center">
                                          <div style="margin-top: 20px">
                                            <i style="font-size: 180px; color: #e5e5e5" class="fa fa-sign-in"></i>
                                          </div>
                                        </div>
                                     </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                                   @if($edit)
                                      <div class="clearfix">
                                        <div class="pull-left">
                                          {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                          {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.show', $data->id),'id'=>'incident_cancel_edit']) }}
                                        </div>
                                      </div>
                                    @else
                                      <div class="clearfix">
                                        <div class="pull-left">
                                           <a href="{{($edit ? ['incidents.update', $data->id] : '1')}}" class ='btn btn-default' alt='Back'>Back</a>
                                        </div>
                                        <div class="pull-right">
                                        {{ Form::submit('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.index'),'id'=>'incident_cancel']) }}
                                        </div>
                                      </div>
                                    @endif
                            </div>
                        {{ Form::close() }}
                     </div>  <!--/* wizard_body -->
                </div>    <!--/* ibox-content -->
              </div>  <!--/* ibox -->
          </div> <!--/* col-lg-12 -->
        </div>  <!--/* row-->
      </div>  <!--/* animated-->
</div>
 
<script type="text/javascript">
  var Incidents = {'coordinates': null, 'mapElement': null};
</script>

@if(isset($data->product_description))

  <?php $product_description = $data->product_description; ?>
  <?php $number_of_units_missing = $data->number_of_units_missing; ?>
  <?php $value_per_unit = $data->value_per_unit; ?>

  @if(is_array($product_description))
    <?php $product_description = json_encode($product_description); ?>
    <?php $number_of_units_missing = json_encode($number_of_units_missing); ?>
    <?php $value_per_unit = json_encode($value_per_unit); ?>
  @endif

  <script type="text/javascript">
  var Products = {};
  Products['description'] = JSON.parse('{{ $product_description }}');
  Products['units'] = JSON.parse('{{ $number_of_units_missing }}');
  Products['value'] = JSON.parse('{{ $value_per_unit }}');
  </script>

@endif

@stop