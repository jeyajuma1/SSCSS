@extends('layouts.master')

@section('content')


<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">
                Company List  
            </h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>

 


    <div class="ibox float-e-margins animated flipInX">
        <div class="ibox-title">
            <h5>
                <i class="fa fa-table" aria-hidden="true"></i> Company
            </h5>
            <div class="ibox-tools"></div>
        </div>
        <div class="ibox-content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default sitemasters-panel">
                        <div class="panel-body">
                           <table class="table table-hover table-striped" id="lsps-list">
                                <thead>
                                    <th>Name</th>
                                    <th></th>
                                </thead>
                                <tbody>
                                    @foreach($lsps as $lsp)
                                    <tr>
                                        <td>{{ $lsp->name }}</td>
                                        <td class="action-buttons" nowrap>
                                        {{ Form::open(['route' => ['lsps.edit', $lsp->id], 'method' => 'get']) }}
                                            {{ Form::button('Edit', ['type' => 'submit', 'class' => 'btn btn-primary btn-xs']) }}
                                        {{ Form::close() }}
                                        {{ Form::open(['route' => ['lsps.destroy', $lsp->id], 'method' => 'delete']) }}
                                            {{ Form::button('Remove', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs lsp-delete-button']) }}
                                        {{ Form::close() }}
                                        </td>
                                    </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
 
<!-- /#page-wrapper -->
@stop