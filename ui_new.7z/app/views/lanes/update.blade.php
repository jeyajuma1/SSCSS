@extends('layouts.master')
@section('content')
{{ HTML::script('//js.api.here.com/ee/2.5.4/jsl.js?with=all') }}
{{ HTML::script('js/maps/cluster.js') }}
<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Update Lane</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">Lane Details</div>
						@if(Session::has('message'))
						<div class="visible-lg-block">
							<h4> ✔ {{ Session::get('message') }}</h4>
						</div>
						@endif
                        <form role="form"   method="post" action="update"  id="integerForm" >
                            <div class="panel-body">
                                <div class="row">
                                    <div class="col-lg-12">
                                      <div class="form-group">
                                         @if($chklane[$lane_id] != 'yes')
                                        <div class="bs-callout bs-callout-info">
                                            <h4>Update a lane</h4>
                                            <p>Update/complete the lane by clicking on 'Add a Location' button.</p>
                                        </div>
                                        @endif
									   @if(!empty($lanelist))
                                <div role="form">
                                  <div class="form-group">
                                    <ol class="lane-locations clearfix">
                                    <?php
                                          $cord = array();
                                          $waypoints = reset($lanelist)->lane->waypoints+2 ;
                                          $positionArry = [];
                                          $datadetail = []; $AlllocationId=[];
                                         //print "<pre>"; print_r($lanelist); exit;
                                    ?>
                                    @foreach(range(1,$waypoints) as $key => $node)
                                        <li class="@if($waypoints == $node) last-location @else first-location @endif">
                                          <span class="location-name" style='height:60px;'>
                                            @if(!empty($lanelist[$node]->location->address) )
                                                                  @if(Auth::User()->isAdmin() || (Auth::user()->id == $lanelist[$node]->location->auditor_id) || Auth::User()->isManager() )
                                                                        @if((int)$lanelist[$node]->location->tapa_needed != 0 && empty($lanelist[$node]->location->deleted_at))
                                                                            <a href="/locations/{{$lanelist[$node]->location->id}} " class="lanesredirectlnk">
                                                                        @else
                                                                             <a href="/locations/incomplete/{{$lanelist[$node]->location->id}} " class="lanesredirectlnk">
                                                                        @endif
                                                                  @endif
                                                            {{wordwrap(preg_replace('/((\w+\W*){2}(\w+))(.*)/', '${1}',$lanelist[$node]->location->address),5,"<br/>")}} &nbsp; <br/>
                                                                 @if(Auth::User()->isAdmin() || (Auth::user()->lsp_id == $lanelist[$node]->lane->lsp_id) || Auth::User()->isManager())
                                                                        </a>
                                                                    @endif
                                            @endif
                                          </span>
                                          <span class="location-num  @if(!empty($lanelist[$node]->transport)) location-mode-{{$lanelist[$node]->transport}} @endif">{{$node}}</span>
                                        </li>
                                         @if(($node) != $waypoints)
                                        <li>
                                          <span class="location-transport">
                                            @if(!empty($lanelist[$node]->transport))

                                               @if($lanelist[$node]->transport == 'sea')
                                                        <?php $transportwidth = array('width' =>90); ?>
                                               @else
                                                        <?php $transportwidth = array('width' =>95); ?>
                                               @endif
                                               @if(Session::get('steps') == 3)
                                                        <?php $datadetail = array('id'=>'auto_route_create','data-start'=>$lanelist[$node]->location->id,'data-end'=>$lanelist[$node+1]->location->id);  ?>
                                               @endif
                                               <?php $datadetail = array_merge($transportwidth,$datadetail); ?>

                                                {{HTML::image('css/images/'.$lanelist[$node]->transport.'-lane.png',$alt=$lanelist[$node]->transport,$datadetail)}}
                                            @else
                                              {{HTML::image('css/images/empty.png',$alt='No node',array('width'=>95))}}
                                            @endif
                                          </span>
                                          <span class="@if(!empty($lanelist[$node]->transport)) location-transport-{{$lanelist[$node]->transport}}bridge @else location-transport-emptybridge @endif "></span>
                                        </li>
                                        @endif
                                        <?php
                                           $cord[] = $lanelist[$node]->location;
                                           $positionArry[] = @$lanelist[$node]->position;
                                         ?>
                                      @endforeach
                                    </ol>
                                  </div>
                                </div>

            										<div class="map_common">
            											<div id="map_canvas{{$key}}" class="map_canvas"></div>
            										</div>
                                  @if(Session::get('laststep') == 'yes')
                                      <script type="text/javascript">
                                          ShowMaplanes({{$key}},{{json_encode($cord)}});
                                      </script>
                                  @else
                  										<script type="text/javascript">
                                          var cordinates =  {{$location_audit}};
                                          showNokiaMapLanesLocationbyAddresses(cordinates, 'map_canvas{{$key}}');
                  										</script>
                                  @endif
										@endif
										<p>&nbsp;</p>
										<!-- Button trigger add location modal -->
                                @if($startlane != 'new')
                                      @if( (int)count($lanelist) != (int)(count($positionArry)) )
                                        <button class="btn btn-primary btn-md" type="button" data-toggle="modal" data-target="#addLocation" data-keyboard="false" data-backdrop="static">
                                          Add a location
                                        </button>
                                         <?php $steps = 2; ?>
                                      @else
                                        <?php $steps = 3; ?>
                                      @endif
                                        <!-- Add Location Modal -->
                                        <div class="modal fade addnodes" id="addLocation" role="dialog" aria-labelledby="addLocationLabel" aria-hidden="true">
                                          <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                    <h4 class="modal-title" id="addRouteLabel">Add a location</h4>
                                                </div>
                                                <div class="modal-body">
                                                @if($errors->all())
                                                    <div id="form-errors" class="alert alert-danger" role="alert">
                                                        <ul>
                                                            @foreach($errors->all() as $messages)
                                                            <li>{{$messages}}</li>
                                                            @endforeach
                                                        </ul>
                                                    </div>
                                                @endif
                                                <div class="form-horizontal" role="form">
                                                    <div class="form-group existingtag">
                                                        <label class="col-sm-4 control-label">Existing</label>
                                                        <div class="col-sm-8">
                                                          @if(!empty($Locationlist))
                                                            {{Form::checkbox('type', 'existing',true )}}
                                                            {{Form::hidden('existOne','Yes')}}
                                                          @else
                                                            {{Form::checkbox('type', 'existing',false )}}
                                                            {{Form::hidden('existOne','No')}}
                                                          @endif
                                                        </div>
                                                    </div>
                                                    <div class="route-existing-location" id="existlocationtag">
                                                        <div class="form-group">
                                                         <label for="existingLocation" class="col-sm-4 control-label">Location</label>
                                                         <div class="input-group select2-bootstrap-prepend col-sm-6"> {{Form::select('existingLocation',$Locationlist,null,['class'=>'form-control'])}}</div>
                                                        </div>
                                                    </div>
                                                    <div id="existpoistion">
                                                        <div class="form-group">
                                                         <label for="existingLocation" class="col-sm-4 control-label">Position</label>
                                                       <div class="input-group select2-bootstrap-prepend col-sm-6">
                                                       {{Form::select('position',array_diff(array_combine(range(1,$waypoints),range(1,$waypoints)),$positionArry) ,notnull,['class'=>'form-control','id'=>'nodeposition'])}}
                                                          </div>
                                                        </div>
                                                    </div>
                                                    <div class="route-new-location">
                                                      <div class="form-group">
                                                        <label for="country" class="col-sm-4 control-label">Country</label>
                                                        <div class="col-sm-8">{{Form::select('country',$Countrylist,null,['class'=>'form-control'])}}
                                                        </div>
                                                      </div>
                                                      <div class="form-group">
                                                        <label for="sitename" class="col-sm-4 control-label">Site Name</label>
                                                        <div class="col-sm-8">{{Form::text('site','',['class'=>'form-control','id'=>'sitename','placeholder'=>'Site, building, warehouse, hub names...'])}}
                                                        </div>
                                                      </div>
                                                      <div class="form-group">
                                                        <label for="address" class="col-sm-4 control-label">Address</label>
                                                        <div class="col-sm-8">{{Form::text('address','',['class'=>'form-control','id'=>'address'])}}
                                                        </div>
                                                      </div>
                                                      <div class="form-group coordinate-inputs">
                                                        <label for="coordinates" class="col-sm-4 control-label">Coordinates</label>
                                                        <div class="col-sm-6">{{Form::text('coordinates','',['class'=>'form-control','id'=>'coordinates','placeholder'=>'Coordinate format: latitude, longitude'])}}
                                                        </div>
                                                        <div class="col-sm-2">
                                                          <button type="button" id="lane-coordinate-check" class="btn btn-info pull-left">validate</button>
                                                        </div>
                                                      </div>
                                                      <div class="form-group">
                                                        <div class="col-sm-8 col-sm-offset-4" id="lane-coordinate-pick"></div>
                                                      </div>
                                                    </div>
                                                    <div class="form-group transport-selection">
                                                        <label for="transport" class="col-sm-4 control-label">Transport Mode</label>
                                                        <div class="col-sm-8">
                                                            <div class="btn-group" data-toggle="buttons">
                                                              <label class="btn btn-primary active">
                                                                <input type="radio" name="transport" id="transport1" value="truck" checked>
                                                                <i class="fa fa-truck fa-fw"></i> Truck
                                                              </label>
                                                              <label class="btn btn-primary">
                                                                <input type="radio" name="transport" id="transport2" value="flight">
                                                                <i class="fa fa-plane fa-fw"></i> Flight
                                                              </label>
                                                              <label class="btn btn-primary">
                                                                <input type="radio" name="transport" id="transport3" value="sea">
                                                                <i class="fa fa-css3 fa-fw"></i> Ship
                                                              </label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                </div>
                                                <div class="modal-footer">
                                                    {{Form::hidden('process','',['class'=>'form-control','id'=>'process'])}}
                                                    {{Form::hidden('laneid',$lane_id,['class'=>'form-control','id'=>'process'])}}
                                                    {{Form::hidden('waypoints',count($positionArry),['class'=>'form-control','id'=>'process'])}}

                                                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                                                    <input type="submit" value="Add" class="btn btn-primary">
                                                    <!--input type="submit" value="Add &amp; Make Destination" name="success" class="btn btn-success"-->
                                                </div>
                                            </div>
                                          </div>
                                        </div>
                                    @endif

                                      </div>
                                    </div>
                                </div>
                            </div>
                            <div class="panel-footer">
                            {{Form::hidden('steps',$steps,['class'=>'form-control','id'=>'steps'])}}
                              @if(Session::get('laststep') == 'yes')
                                {{Form::hidden('final','yes',['class'=> 'btn btn-primary'])}}
                                {{Form::submit('Save',['class'=> 'btn btn-primary'])}}
                              @else
                                <button class="btn btn-primary" type="submit">Continue</button>
                              @endif
                                <button class="btn btn-default" type="button" href="/lanes">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
        </div>


            <!-- Modal -->
            <div class="modal fade bs-example-modal-sm" id="finallanes" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" id="myModalLabel">Note</h4>
                  </div>
                  <div class="modal-body" >
                    All Node Lanes are filled , Please click the continue button for next step.
                  </div>
                  <div class="modal-footer">
                  </div>
                </div>
              </div>
            </div>

        <!-- /#page-wrapper -->
		{{-- HTML::script('js/maps/map.js') --}}
@stop
