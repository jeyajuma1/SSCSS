@extends('layouts.master')
@section('content')
{{ HTML::script('//code.jquery.com/jquery-1.10.1.min.js') }}
{{ HTML::script('js/main.js') }}
{{ HTML::script('//js.api.here.com/ee/2.5.4/jsl.js?with=all') }}
{{ HTML::script('js/maps/cluster.js') }}
 <?php
   $resizelabel = ($_COOKIE['lanelabelext']) ? ($_COOKIE['lanelabelext']-45) : 90;
 ?>
 <div id="page-wrapper">
            <div class="row">
				   @if(Session::has('success'))
						<div class="bs-callout bs-callout-info">
							<h4> ✔ {{ Session::get('success') }}</h4>
						</div>
					@endif
                <div class="col-lg-12">
                    <h1 class="page-header">
                    All Lanes
                    @if(Auth::User()->isAdmin() || Auth::User()->access_lanes)
                       <a href="#" class="btn btn-primary pull-right" id="create_lanes" >Create Lane</a>
                    @endif
                    </h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel-group lane-listing" id="accordion">
                        <div class="panel panel-default audits-panel">
                          <div class="panel-heading">
                              {{ Form::open(['action' => 'LanesController@index','method' => 'get','id'=>'lanes-list-form','role'=>'form','class'=>'form-inline'])}}
                              <div class="form-group-row">
                                  <div class="form-group">
                                      <div class="input-group">
                                          <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                          {{Form::text('daterange',Input::get('daterange'),['class'=>'form-control'])}}
                                      </div>
                                  </div>
                                  <div class="form-group">
                                      <div class="input-group">
                                          <span class="input-group-addon">LSP</span>
                                          {{ Form::select('lsp[]', $lsps, Input::get('lsp'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                      </div>
                                  </div>
                                <!--  <div class="form-group">
                                      <div class="input-group">
                                          <span class="input-group-addon">Audit ID</span>
                                          {{Form::text('aid',Input::get('aid'),['class'=>'form-control'])}}
                                      </div>
                                  </div> -->
                                  <div class="form-group text-left hidden">
                                    {{ Form::button('Filter', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                    {{ Form::button('Reset', ['type' => 'reset', 'class' => 'btn btn-primary', 'id' => 'lanes-filter-reset']) }}
                                 </div>
                              </div>
                              </form>
                              {{Form::close()}}
                          </div>
                      </div>
                @if($lanes != false)
                      <div class="panel panel-default">
            					   <?php $lanid = '';  ?>
            					   @foreach($lanes as $ky=>$lane)
                        <div class="panel-heading panel-headingminor @if(reset($lane)->laneend == 'no') panel-pending @endif">
                                      <h4 class="panel-title">
                                       <!-- <a data-toggle="collapse" data-parent="#accordion" href="#collapse{{$ky}}">
                                            {{str_replace('-',' : ',$ky)}}  <i class="fa fa-building-o fa-fw"></i> {{reset($lane)->site}}
                                            @if(count($lane) >= 3 ) <i class="fa fa-arrow-right fa-fw"></i><b>&#8230;</b>@endif
                                            <i class="fa fa-arrow-right fa-fw"></i> <i class="fa fa-building-o fa-fw"></i> @if(!empty(end($lane)->site)) {{end($lane)->site}} @endif
                                            @if(reset($lane)->laneend == 'no')<span class="glyphicon glyphicon-exclamation-sign icon-red"></span>@endif
                                        </a> -->
                                         {{preg_replace('/([a-zA-Z]+)-(\d+)/', '\1 (\2)',$ky)}}   <?php $ext = ''; ?>
                                        @foreach($lane as $labellane)
                                          <?php $ext = strlen($labellane->site) + $ext;  ?>
                                          <a data-toggle="collapse" data-parent="#accordion" href="#collapse{{$ky}}">
                                           @if($ext >= $resizelabel ) 
                                                   @if(end($lane)->site != $labellane->site) 
                                                      <?php continue ?>
                                                   @endif
                                                 <b>&#8230;</b> <i class="fa fa-arrow-right fa-fw"></i>
                                            @endif 
                                           <i class="fa fa-building-o fa-fw"></i>  {{$labellane->site}}
                                           
                                           @if(end($lane)->site != $labellane->site) <i class="fa fa-arrow-right fa-fw"></i> @endif
                                        </a> 
                                        @endforeach

                                        @if(reset($lane)->laneend == 'no')<span class="glyphicon glyphicon-exclamation-sign icon-red"></span>@endif

                                        @if(Auth::User()->isAdmin() || (reset($lane)->userid == Auth::User()->id) )
            	                           	<a href="#" class="pull-right" id="lane_del" tag='{{$ky}}' data-toggle="modal" data-target="#myModal" ><i class="fa fa-trash-o fa-fw"></i> Remove </a>
            	                           	@if(reset($lane)->laneend == 'no')
            	                            	<a href="#" class="pull-right" id="pending_lane" tag='{{str_replace('-','',strstr($ky,"-"))}}'  ><i class="fa fa-edit fa-fw"></i> Resume </a>
            	                            @endif
            	                          @endif
                                      </h4>
                        </div>
            						<div id="collapse{{$ky}}" class="panel-collapse">
                                      <div class="panel-body">
                                         <div role="form">
                                            <div class="form-group">
                                                <ol class="lane-locations clearfix lanelisting-trans">
                                                 <?php $cord = array(); ?>
                                                 <?php $waypoints = (reset($lane)->waypoints+2); ?>
            									                   @foreach(range(1,$waypoints) as $key => $node)
                                                           <li class="@if($waypoints == $node) last-location @else first-location @endif">
                                                                <span class="location-name" title="{{$lane[$node]->site}}">
                                                                @if(!empty($lane[$node]->site) )
                                                                  @if(Auth::User()->isAdmin() || (Auth::user()->id == $lan->auditor_id) || Auth::User()->isManager() )
                                                                        @if((int)$lane[$node]->location_tapaNeeded != 0 && empty($lane[$node]->location_deletedAt))
                                                                            <a href="/locations/{{$lane[$node]->locationid}} " class="lanesredirectlnk">
                                                                        @else
                                                                             <a href="/locations/incomplete/{{$lane[$node]->locationid}} " class="lanesredirectlnk">
                                                                        @endif
                                                                  @endif

                                                                  {{wordwrap(preg_replace('/((\w+\W*){2}(\w+))(.*)/', '${1}',$lane[$node]->site),5,"<br/>")}} &nbsp; <br/>
                                                                         @if($lane[$node]->score > 75 )
                                                                              <?php $label = "label-success";  $score = (int)$lane[$node]->score." %"; ?>
                                                                         @elseif($lane[$node]->score >= 70)
                                                                              <?php $label = "label-warning";  $score = (int)$lane[$node]->score." %"; ?>
                                                                         @elseif($lane[$node]->score == 0)
                                                                              <?php $label = "label-default";  $score = "?"; ?>
                                                                         @else
                                                                              <?php $label = "label-danger";   $score = (int)$lane[$node]->score." %"; ?>
                                                                        @endif
                                                                        <span class="label {{$label}}">{{$score}}</span>

                                                                    @if(Auth::User()->isAdmin() || (Auth::user()->lsp_id == $lane[$node]->lspid) || Auth::User()->isManager())
                                                                        </a>
                                                                    @endif
                                                                 @endif

                                                                </span>
                                                                  <span class="location-num  @if(!empty($lane[$node]->transport)) location-mode-{{$lane[$node]->transport}} @endif ">{{$node}}</span>
                                                              </li>
                                                              @if(($node) != $waypoints)
                                                              <li >
                                                                  <span class="location-transport">
                                                                   @if(!empty($lane[$node]->transport))
                                                                        @if($lane[$node]->transport == 'sea')
                                                                             <?php $transportwidth ='90'; ?>
                                                                        @else
                                                                             <?php $transportwidth ='95'; ?>
                                                                        @endif
                                                                      {{HTML::image('css/images/'.$lane[$node]->transport.'-lane.png',$alt=$lane[$node]->transport,array('width'=>$transportwidth))}}
                                                                   @else
                                                                      {{HTML::image('css/images/empty.png',$alt='No node',array('width'=>95))}}
                                                                   @endif
                                                                  </span>
                                                                  <span class="@if(!empty($lane[$node]->transport)) location-transport-{{$lane[$node]->transport}}bridge @else location-transport-emptybridge @endif location-transport-listbridge "></span>
                                                              </li>
                                                              @endif
                                                               <?php
                                                                    $cord[$key] = $lane[$node];
                                                                    $cord[$key]['id'] = $lane[$node]['locationid'];
                                                                    $cord[$key]['created_at'] = $lane[$node]['location_createdAt'];
                                                              ?>
                                                        @endforeach
                                                 </ol>
                                            </div>
                                           <?php $kyone = preg_split('/[(A-Za-z)]+/',$ky); $ky = trim($kyone[1]); ?>
                        								<div class="map_common">
                        									<div id="map_canvas{{$ky}}" class="map_canvas"></div>
                        								 </div>
                                         <script type="text/javascript">
                                            ShowMaplanes({{$ky}},{{json_encode($cord)}});
                                         </script>
                                        </div>
                                      </div>
                                    </div>

                                  @endforeach
                          </div>


                      </div>
				   @else
						<div class="bs-callout bs-callout-info"><h4>No Lanes Found</h4>@if(isset($back) && !empty($back)){{HTML::link("/lanes","Back to Lanes",array("class"=>"btn btn-primary custom-back"))}} @endif</div>
				   @endif
               </div>
                <!-- /.col-lg-12 -->

            </div>
            <!-- /.row -->


			<!-- Modal -->
			<div class="modal fade bs-example-modal-sm" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
			  <div class="modal-dialog">
				<div class="modal-content">
				  <div class="modal-header">
					<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
					<h4 class="modal-title" id="myModalLabel">Delete Lanes</h4>
				  </div>
				  <div class="modal-body" >
					Do you want to delete this lanes ?
				  </div>
				  <div class="modal-footer">
					 <input type="hidden" value="" name="dellane" id="dellane">
					<button type="button" class="btn btn-primary" id="delete_yes" data-dismiss="modal">Yes</button>
					<button type="button" class="btn btn-default" data-dismiss="modal">No</button>
				  </div>
				</div>
			  </div>
			</div>

</div>
<!-- /#page-wrapper -->
 <script type="text/javascript">
  $(document).ready(function(){
	   $(".panel-collapse").addClass('collapse');
  });
 </script>
@stop
