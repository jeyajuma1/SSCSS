@extends('layouts.master')

@section('content')
<div class="loginColumns animated fadeInDown">
            <div class="row">

                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <div class="ibox-content">
                        <h2>Password recovery</h2>

                        @if(Session::get('error'))
                        <div id="form-errors" class="alert alert-danger" role="alert">
                            <span>
                                {{ trans(Session::get('error')) }}
                            </span>
                        </div>
                        <!-- end form-errors -->
                        @endif

                         {{ Form::open(['route' => 'password.store', 'method' => 'post', 'autocomplete' => 'off']) }}
                            <fieldset>
                                <div class="form-group">
                                    {{ Form::email('email', '', ['class' => 'form-control', 'placeholder' => 'Please insert your email address', 'autofocus' => 'autofocus', 'autocomplete' => 'off']) }}
                                </div>
                                {{ Form::button('Reset', ['type' => 'submit', 'class' => 'btn btn-primary full-width m-b']) }}
                            </fieldset>
                             <div class="form-group">
                                     {{ HTML::link('/', 'Back to login') }}
                                </div>
                            {{ Form::token() }}
                        {{ Form::close() }}
                    </div>
                </div>
            </div>

</div>
 
@stop