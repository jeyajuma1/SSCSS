@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">
             Certifications

            </h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>

    @if(Session::has('success'))
    <div id="form-success" class="alert alert-success" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div>
    <!-- end form-success -->
    @endif

    <div class="row">
        <div class="col-lg-12">
                  <div class="ibox float-e-margins animated flipInX">
                                <div class="ibox-title">
                                    <h5>
                                        <i class="fa fa-table" aria-hidden="true"></i> Certifications
                                    </h5>
                                    <div class="ibox-tools">
                                         
                                    </div>
                                </div>
                                <div class="ibox-content">
                                    <div class="row">
                                         <div class="col-lg-12">
                                             <div class="panel panel-default sitemasters-panel">
                                                <div class="panel-body">
                                                     <table class="table table-hover table-bordered" id="certifications-list">
                                                            <thead>
                                                                <th>Name</th>
                                                                <th>Group</th>
                                                                <th>Availability</th>
                                                                <th></th>
                                                            </thead>
                                                            <tbody>
                                                                @foreach($certifications as $certification)
                                                                <tr>
                                                                    <td>{{ $certification->name }}</td>
                                                                    <td>{{ $certification_groups[$certification->certification_group_id] }}</td>
                                                                    <td colspan='2'>{{ $certification_availabilities[$certification->availability] }}</td>
                                                                    <!--td nowrap>
                                                                    {{ Form::open(['route' => ['certifications.edit', $certification->id], 'method' => 'get']) }}
                                                                        {{ Form::button('Edit', ['type' => 'submit', 'class' => 'btn btn-primary btn-xs']) }}
                                                                    {{ Form::close() }}
                                                                    </td-->

                                                                </tr>
                                                                @endforeach
                                                            </tbody>
                                                     </table>
                                                </div>
                                             </div>
                                         </div>
                                    </div>
                                </div>
              </div>
        </div>
    </div>

</div>


<!-- /#page-wrapper -->
@stop
