$(function() {

	$('#addLocation').on('show.bs.modal', function () {
		var coord = undefined;
		var items = showNokiaGPSCoordinateSelector('lane-coordinate-pick', 'coordinates', coord);

		var map = items[0];
		var marker = items[1];
		var checkExist = $('[name="existOne"]').val(); // Checking If user has Location Audit List

		$('#lane-coordinate-check').on('click', function () {
			if (checkCoordFormat($('#coordinates').val())) {
				checkCoordMovement(showNokiaMapMoveCoordinate(map, marker, '#coordinates'));
			}
			else {
				checkCoordMovement(false);
			}
		});

		$('.route-existing-location').show();
		$('.route-new-location').hide();

		if(checkExist == 'No' ){
			$('.route-existing-location').hide();
			$('.route-new-location').show();
			$('.existingtag').hide();			
		}


		$('#existingLocation').select2({ placeholder: "Select location" });
		$('#country').select2({ placeholder: "Select country" });

		function changeLocationType(event, state) {
			
			if (! state) {
				$("#process").val('new');
				$('.route-new-location').show();
				$('.route-existing-location').hide();
			}
			else {
				$("#process").val('exist');
				$('.route-new-location').hide();
				$('.route-existing-location').show();
			}
		}

		// Turn the checkboxes and radios in to switches
		$("[name='type']").bootstrapSwitch({onText: "Yes", offText: 'No', size: 'normal', onSwitchChange: changeLocationType});
		$("[name='audit_required']").bootstrapSwitch({onText: "Yes", offText: 'No', size: 'normal'});
	});

	$('#addLocation').on('hidden.bs.modal', function(){
	    // Remove all active data and remove the cordinate pick map
	    $(this).data('bs.modal', null);
	    // $("#existpoistion").show();
	    $('#lane-coordinate-pick').html('');
	    
	    // Reset all the location fields
	    $('#type').attr('checked', 'checked');
	    $('select').val('');
	    $('input[type="text"]').val('');

	    $("#existpoistion").hide();
		$(".existingtag").show();
		$("#process").val('exist');

	    // Reset all the transport selections
	    $('.transport-selection div.btn-group label').removeClass('active');
	    $('.transport-selection div.btn-group input').removeAttr('checked');
	    $('.transport-selection div.btn-group label:first').addClass('active');
	    $('.transport-selection div.btn-group input').attr('checked', 'checked');
	});

	
	$('.audit-required').tooltip();
});