if (typeof nokia != 'undefined')
{

	function extend(B, A) {
	  function I() {}
	  I.prototype = A.prototype;
	  B.prototype = new I();
	  B.prototype.constructor = B;
	}

	function RestrictMap(minZoom, maxZoom, boundingBox) {
	  boundingBox = {
		topLeft: {latitude: 0, longitude: 0},
		bottomRight: {latitude: 0, longitude: 0}
	  };
	  nokia.maps.map.component.Component.call(this);
	  this.init(minZoom, maxZoom, boundingBox);
	}
	extend(RestrictMap, nokia.maps.map.component.Component);


	RestrictMap.prototype.init = function (minZoom, maxZoom, boundingBox) {
	  var that = this;
	  that.set('boundingBox', boundingBox);
	  that.set('minZoom', minZoom);
	  that.set('maxZoom', maxZoom);


	  that.eventHandlers = {
		restrictCenter : function (evt) {
		  if (that.__map.center.latitude > that.boundingBox.topLeft.latitude
			  || that.__map.center.longitude < that.boundingBox.topLeft.longitude
			  || that.__map.center.latitude < that.boundingBox.bottomRight.latitude
			  || that.__map.center.longitude > that.boundingBox.bottomRight.longitude) {
			var latitude =  Math.max(Math.min(that.__map.center.latitude,
				that.boundingBox.topLeft.latitude), that.boundingBox.bottomRight.latitude),
			  longitude = Math.min(Math.max(that.__map.center.longitude,
				that.boundingBox.topLeft.longitude), that.boundingBox.bottomRight.longitude);
			that.__map.setCenter(new nokia.maps.geo.Coordinate(latitude, longitude));
			evt.cancel();
		  }
		},
		baseMapTypeObserver : function (obj, key, newValue, oldValue) {
		  if (oldValue) {
			oldValue.min = that.unrestrictedMin;
			oldValue.max = that.unrestrictedMax;
		  }
		  if (newValue) {
			that.unrestrictedMin = newValue.min;
			that.unrestrictedMax = newValue.max;
			if (that.minZoom) {
			  newValue.min = that.minZoom;
			}
			if (that.maxZoom) {
			  newValue.max = that.maxZoom;
			}
		  }
		}
	  };
	};

	RestrictMap.prototype.attach = function (map) {
	  this.__map = map;
	  map.addListener('dragend', this.eventHandlers.restrictCenter);
	  map.addListener('mapviewchangeend', this.eventHandlers.restrictCenter);
	  map.addObserver('baseMapType', this.eventHandlers.baseMapTypeObserver);
	  this.eventHandlers.baseMapTypeObserver(map, 'baseMapType', map.get('baseMapType'), null);
	};

	RestrictMap.prototype.detach = function (map) {
	  map.removeListener('dragend',  this.eventHandlers.restrictCenter);
	  map.removeListener('mapviewchangeend',  this.eventHandlers.restrictCenter);
	  this.eventHandlers.baseMapTypeObserver(map, 'baseMapType', null, map.get('baseMapType'));
	  map.removeObserver('baseMapType', this.eventHandlers.baseMapTypeObserver);
	  this.__map = null;

	};

	RestrictMap.prototype.getId = function () {
	  return 'RestrictMap';
	};
	RestrictMap.prototype.getVersion = function () {
	  return '1.0.0';
	};

}

function createMapElement(containerId) {
	//$('#'+containerId).css({'position':'relative'});
	//$('#'+containerId).append($('<div></div>').css({'height': '100%', 'width':'100%'}));
	var mapElement = $('#'+containerId).find('div')[0];
	//$('#'+containerId).append($('<div id="map-canvas"><div><p>Loading map...</p></div></div>').css({'height': '10%', 'width':'45%', 'position':'absolute', 'top':'10px', 'left':'500px', 'background-color':'white'}));
	//$('#map-canvas > p').css({'text-align':'center', 'margin-top':'20px'});
	//$('#map-canvas > p > img').css({'margin-right':'10px', 'position':'relative','top':'3px'});
	return mapElement;
}

function showMapLocationsByAddresses(locations_list, mapElementId) {
	if (locations_list.length == 0) {
	  var mapElement = createMapElement(mapElementId);
	  $('#map-canvas > div > p').html('There are no audits to display.');
	  return;
	}

	var util = {
	objIsArray: function (obj) {
	  return !!obj && /array/i.test(obj.constructor.toString());
	},
	// JavaScript inheritance helper function
	extend: function (B, A) {
	  function I() {};
	  I.prototype = A.prototype;
	  B.prototype = new I;
	  B.prototype.constructor = B;
	}
	};

	/* CLUSTERING-RELATED BELOW */
	// Cache the namespace for faster access
	// Extend from the standard theme
	var mapsNS = nokia.maps,
	  clusterNS = mapsNS.clustering,
	  gfxNS = mapsNS.gfx,
	  Graphics = gfxNS.Graphics,
	  BitmapImage = gfxNS.BitmapImage,
	  GraphicsImage = gfxNS.GraphicsImage,
	  MarkerTheme = clusterNS.MarkerTheme,
	  CLSTheme = function () {
	    MarkerTheme.call(this, clusterNS.MarkerTheme.POSITION_WEIGHT_CENTER);
	  };

	nokia.Settings.set("appId", "KyW1GWWaS-K-XOSNl-Wa");
	nokia.Settings.set("authenticationToken", "pn1eUyiFnolEPuHju8sy5g");

	var map = new mapsNS.map.Display(document.getElementById(mapElementId), {
	  //center: [52.51, 13.4],
	  zoomLevel: 13,
	  components:[new mapsNS.map.component.Behavior(),new mapsNS.map.component.ZoomBar(),new mapsNS.map.component.TypeSelector()]
	});

	//map.components.add(new RestrictMap(2, 20));

	util.extend(CLSTheme, MarkerTheme);

	var clsTheme = new CLSTheme(),
	// Create a nokia.maps.clustering.ClusterProvider to handle clustering
	globalClusterProvider = new clusterNS.ClusterProvider(map, {
	  eps: 30,
	  minPts: 2,
	  max: 20, //max zoom level to provide clustering
	  min: 2, // min zoom level to provide clustering
	  theme: clsTheme,
	  dataPoints: [],
	  //strategy: clusterNS.ClusterProvider.STRATEGY_DENSITY_BASED
	  strategy: clusterNS.ClusterProvider.STRATEGY_GRID_BASED
	});

	// Define a different representation of a noise point (any singular point that doesn't belong to a cluster)
	CLSTheme.prototype.getNoisePresentation = function (dataPoint) {
		var bgMarker,
		    poiMarker,
		    coords = [dataPoint.latitude, dataPoint.longitude],
		    clusterNoisePoiContainer = new mapsNS.map.Container();

		bgMarker = new mapsNS.map.StandardMarker(new mapsNS.geo.Coordinate(dataPoint.latitude, dataPoint.longitude), {brush: {color: dataPoint.color}});

		// Create the numeric text marker to put on top
		poiMarker = new mapsNS.map.Marker(coords, {
		    icon: new GraphicsImage(function (gfx, graphicsImage) {
		      // This will clear the canvas and set it's size to 20 x 20 pixel
		      gfx.beginImage(25, 35, "Cluster");
		    }),
		    anchor: {
		      x: 13,
		      y: 20
		    }
		});

		bgMarker['html'] = dataPoint.name;
		poiMarker['html'] = dataPoint.name;

		clusterNoisePoiContainer.objects.addAll([bgMarker, poiMarker]);
		return clusterNoisePoiContainer;
	};

    var infoBubbles = new mapsNS.map.component.InfoBubbles();
	map.addComponent(infoBubbles);

	// Employ event delegation: Add a click listener to the clusterProvider's container, to react on
	// each "marker" being clicked
	globalClusterProvider.getContainer().addListener("click", function (e) {
	  var eventEmmiter = e.target;
	  if (eventEmmiter instanceof mapsNS.map.Marker) {
	    // Check for special attribute '$infoIndex' passed on by the marker who reported the click event.
	    // 'html' is added by us on marker creation time, it's not built-in in JSLA
	    if ('html' in eventEmmiter) {
	    	infoBubbles.openBubble(eventEmmiter['html'], eventEmmiter.coordinate);
		}
	  }
	}, false);

	// How to "feed" data to the cluster provider and then trigger clustering
	var clusterData = [];

	// Show different colors for different incident categories
//	var categories = {'green': "#007233", 'yellow': "#FCD116", 'red': "#BA141A"};

	var locations = [];
	var myContainer = new nokia.maps.map.Container();

	for (var i = 0; i < locations_list.length; i++) {
	  var cordinates = locations_list[i]['coordinates'].split(',');
	  var category = locations_list[i]['category'];
	  if (cordinates[0] != undefined && cordinates[1] != undefined) {
	    var latitude = parseFloat(cordinates[0].trim());
	    var longitude = parseFloat(cordinates[1].trim());
	    if (latitude == 0 || longitude == 0 || isNaN(latitude) || isNaN(longitude)) continue;
	  }
	  var html = "<div style='width: 250px; word-wrap: break-word; word-break: break-all; white-space:normal;'>"+
	  			"<h3 style='color:#fff;font-size:11px;'>"+
	  			"#"+ locations_list[i]['id'] +" "+ locations_list[i]['company'] + " (" +locations_list[i]['city'] +", "+ locations_list[i]['country'] + ")" +
	  			"</h3>"+
	  			"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
	  			"by " + locations_list[i]['auditor'] +" on "+ locations_list[i]['date'] +
	  			"</h4>"+
	  			"<h4 style='color:#fff;font-size:11px;'>"+
	  			"Score: " + locations_list[i]['score']
	  			"</h4>";
	if (locations_list[i]['show_view_link']) {
		html += "<p style='font-size:11px;padding-top:6px;'><a style='text-decoration: underline;' target='_blank' href='/locations/"+ locations_list[i]['id'] +"'>Go to audit</a></p></div>";
	}
	/* Adding each entry to the clusterData array */
	  clusterData.push({
	    name: html,
	    latitude: latitude,
	    longitude: longitude,
	    dataIndex: i,
	    dataId: i
	  });

	  myContainer.objects.add(new nokia.maps.map.StandardMarker(new nokia.maps.geo.Coordinate(latitude, longitude)));
	}

	// Add the datapoints to the cluster provider
	globalClusterProvider.addAll(clusterData);
	// Trigger clustering
	globalClusterProvider.cluster();

	var promise = (function (map) {
	var def = jQuery.Deferred();
	map.addObserver('copyrightPosition', function (obj, key, value, oldValue) {
	  def.resolve();
	});

	return def;
	})(map);

	promise.then(function () {
		map.zoomTo(myContainer.getBoundingBox());
	});
}

function showMapIncidentsByAddresses(locations_list, mapElementId) {
	if (locations_list.length == 0) {
	  var mapElement = createMapElement(mapElementId);
	  $('#map-canvas > div > p').html('There are no incidents to display.');
	  return;
	}

	var util = {
	objIsArray: function (obj) {
	  return !!obj && /array/i.test(obj.constructor.toString());
	},
	// JavaScript inheritance helper function
	extend: function (B, A) {
	  function I() {};
	  I.prototype = A.prototype;
	  B.prototype = new I;
	  B.prototype.constructor = B;
	}
	};

	/* CLUSTERING-RELATED BELOW */
	// Cache the namespace for faster access
	// Extend from the standard theme
	var mapsNS = nokia.maps,
	  clusterNS = mapsNS.clustering,
	  gfxNS = mapsNS.gfx,
	  Graphics = gfxNS.Graphics,
	  BitmapImage = gfxNS.BitmapImage,
	  GraphicsImage = gfxNS.GraphicsImage,
	  MarkerTheme = clusterNS.MarkerTheme,
	  CLSTheme = function () {
	    MarkerTheme.call(this, clusterNS.MarkerTheme.POSITION_WEIGHT_CENTER);
	  };

	nokia.Settings.set("appId", "KyW1GWWaS-K-XOSNl-Wa");
	nokia.Settings.set("authenticationToken", "pn1eUyiFnolEPuHju8sy5g");

	var map = new mapsNS.map.Display(document.getElementById(mapElementId), {
	  center: [52.51, 13.4],
	  zoomLevel: 13,
	  components:[new mapsNS.map.component.Behavior(),new mapsNS.map.component.ZoomBar(),new mapsNS.map.component.TypeSelector()]
	});

	//map.components.add(new RestrictMap(2, 20));

	util.extend(CLSTheme, MarkerTheme);

	var clsTheme = new CLSTheme(),
	// Create a nokia.maps.clustering.ClusterProvider to handle clustering
	globalClusterProvider = new clusterNS.ClusterProvider(map, {
	  eps: 30,
	  minPts: 2,
	  max: 20, //max zoom level to provide clustering
	  min: 2, // min zoom level to provide clustering
	  theme: clsTheme,
	  dataPoints: [],
	  //strategy: clusterNS.ClusterProvider.STRATEGY_DENSITY_BASED
	  strategy: clusterNS.ClusterProvider.STRATEGY_GRID_BASED
	});

	// Define a different representation of a noise point (any singular point that doesn't belong to a cluster)
	CLSTheme.prototype.getNoisePresentation = function (dataPoint) {
		var bgMarker,
		    poiMarker,
		    coords = [dataPoint.latitude, dataPoint.longitude],
		    clusterNoisePoiContainer = new mapsNS.map.Container();

		bgMarker = new mapsNS.map.StandardMarker(new mapsNS.geo.Coordinate(dataPoint.latitude, dataPoint.longitude), {brush: {color: dataPoint.color}});

		// Create the numeric text marker to put on top
		poiMarker = new mapsNS.map.Marker(coords, {
		    icon: new GraphicsImage(function (gfx, graphicsImage) {
		      // This will clear the canvas and set it's size to 20 x 20 pixel
		      gfx.beginImage(25, 35, "Cluster");
		    }),
		    anchor: {
		      x: 13,
		      y: 20
		    }
		});

		bgMarker['html'] = dataPoint.name;
		poiMarker['html'] = dataPoint.name;

		clusterNoisePoiContainer.objects.addAll([bgMarker, poiMarker]);
		return clusterNoisePoiContainer;
	};

    var infoBubbles = new mapsNS.map.component.InfoBubbles();
	map.addComponent(infoBubbles);

	// Employ event delegation: Add a click listener to the clusterProvider's container, to react on
	// each "marker" being clicked
	globalClusterProvider.getContainer().addListener("click", function (e) {
	  var eventEmmiter = e.target;
	  if (eventEmmiter instanceof mapsNS.map.Marker) {
	    // Check for special attribute '$infoIndex' passed on by the marker who reported the click event.
	    // 'html' is added by us on marker creation time, it's not built-in in JSLA
	    if ('html' in eventEmmiter) {
	    	infoBubbles.openBubble(eventEmmiter['html'], eventEmmiter.coordinate);
		}
	  }
	}, false);

	// How to "feed" data to the cluster provider and then trigger clustering
	var clusterData = [];

	// Show different colors for different incident categories
	var categories = {'minor': "#F2EE66", 'medium': "#F2AC66", 'major': "#F75E5E"};

	var locations = [];
	var myContainer = new nokia.maps.map.Container();

	for (var i = 0; i < locations_list.length; i++) {
	  var cordinates = locations_list[i]['location'].split(',');
	  var category = locations_list[i]['category'];
	  if (cordinates[0] != undefined && cordinates[1] != undefined) {
	    var latitude = parseFloat(cordinates[0].trim());
	    var longitude = parseFloat(cordinates[1].trim());
	    if (latitude == 0 || longitude == 0 || isNaN(latitude) || isNaN(longitude)) continue;
	  }
	  var html = "<div style='width: 250px; word-wrap: break-word; word-break: break-all; white-space:normal;'>"+
	  			"<h3 style='color:#fff;font-size:11px;'>"+
	  			"#"+ locations_list[i]['id'] +" "+ locations_list[i]['company'] + " (" +locations_list[i]['city'] +", "+ locations_list[i]['country'] + ")" +
	  			"</h3>"+
	  			"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
	  			"by " + locations_list[i]['name'] +" on "+ locations_list[i]['date'] +
	  			"</h4>"+
	  			"<h4 style='color:#fff;font-size:11px;'>"+
	  			"Loss Value: &#36;" + locations_list[i]['value'] +
	  			"</h4>";
	if (locations_list[i]['show_view_link']) {
		html += "<p style='font-size:11px;'><a style='text-decoration: underline;' target='_blank' href='/incidents/view/"+ locations_list[i]['id'] +"'>Go to incident</a></p></div>";
	}
	/* Adding each entry to the clusterData array */
	  clusterData.push({
	    name: html,
	    latitude: latitude,
	    longitude: longitude,
	    color: categories[category],
	    dataIndex: i,
	    dataId: i
	  });

	  myContainer.objects.add(new nokia.maps.map.StandardMarker(new nokia.maps.geo.Coordinate(latitude, longitude)));
	}

	// Add the datapoints to the cluster provider
	globalClusterProvider.addAll(clusterData);
	// Trigger clustering
	globalClusterProvider.cluster();

	var promise = (function (map) {
		var def = jQuery.Deferred();
		map.addObserver('copyrightPosition', function (obj, key, value, oldValue) {
		  def.resolve();
		});

		return def;
	})(map);

	promise.then(function () {
		if (locations_list.length == 1) {
			map.set('zoomLevel', 2);
			map.set('center', [latitude, longitude]);
		}
		else {
			map.zoomTo(myContainer.getBoundingBox());
		}
	});
}

/**
 * Show Lanes
 *
 **/
 function  ShowMaplanes(laneid,lanesplot){
  	nokia.Settings.set("appId", "KyW1GWWaS-K-XOSNl-Wa");
	nokia.Settings.set("authenticationToken", "pn1eUyiFnolEPuHju8sy5g");
		// Get the DOM node to which we will append the map
	var mapContainer = document.getElementById("map_canvas"+laneid);
	// Create a map inside the map container DOM node
	var map = new nokia.maps.map.Display(mapContainer, {
		// Initial center and zoom level of the map
		center: [52.51, 13.4],
		zoomLevel: 13,
		components: [
			// ZoomBar provides a UI to zoom the map in & out
			new nokia.maps.map.component.ZoomBar(),
			// we add the behavior component to allow panning / zooming of the map
			new nokia.maps.map.component.Behavior(),
			// creates UI to easily switch between street map satellite and terrain mapview modes
			new nokia.maps.map.component.TypeSelector()
		]
	});

	//map.components.add(new RestrictMap(2, 20));

	// JavaScript inheritance helper function
	function extend(B, A) {
		function I() {}
		I.prototype = A.prototype;
		B.prototype = new I();
		B.prototype.constructor = B;
	}


	var infoBubbles = new  nokia.maps.map.component.InfoBubbles();
	map.addComponent(infoBubbles);

    map.addListener("click", function (e) {
	 	var eventEmmiter = e.target;
		infoBubbles.openBubble(e.target.html, eventEmmiter.coordinate);
	}, false);

	/* We create a new helper object MarkerPolyline which
	 * create polylines with standard Markers on every
	 * point in its path
	 */
	var MarkerPolyline = function (coords, props) {
		// Call the "super" constructor to initialize properties inherited from Container
		nokia.maps.map.Container.call(this);

		// Calling MarkerPolyline constructor
		this.init(coords, props);
	};

	extend(MarkerPolyline, nokia.maps.map.Container);

	// MarkerPolyline constructor function
	MarkerPolyline.prototype.init = function (coords, props) {
		var i,
			coord,
			marker,
			lineProps = props.polyline || {},
			markerProps = (this.markerProps = props.marker || {});

		this.coords = {};

		// Create a polyline
		this.polyline = new nokia.maps.map.Polyline(coords, lineProps);

		// Add the polyline to the container
		this.objects.add(this.polyline);

		/* We loop through the point to create markers
		 * for each of the points and we store them
		 */
		for (i = 0; coord = coords[i]; i++) {

			marker = new nokia.maps.map.StandardMarker(coord, markerProps);
			this.coords[coord.latitude + "_" + coord.longitude] = { idx: i + 1, marker: marker };
			marker.set('text',i+1);

			html = "<div style='width: 250px; word-wrap: break-word; word-break: break-all; white-space:normal;'>"+
	  			"<h3 style='color:#fff;font-size:11px;'>"+
	  			"#"+ lanesplot[i]['id'] +" "+ lanesplot[i]['site'] +
	  			"</h3>"+
	  			"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
	  			"Created  on "+ lanesplot[i]['created_at'] +
	  			"</h4>"+"<h4  style='color:#fff;font-size:11px;font-style:italics;'>"+
				//"Location: "+lanesplot[i]['country_id']+" </h4>"+
	  			"<h4 style='color:#fff;font-size:11px;'>"+
	  			"Score: " + lanesplot[i]['score']+"</h4><p style='font-size:11px;padding-top:6px;'><a style='text-decoration: underline;' target='_blank' href='/locations/"+lanesplot[i]['id'] +"'>Go to audit</a></p></div>";
            marker.set('html',html);
			this.objects.add(marker);
		}
	};

	// The add function allows you to add a new point to a MarkerPolyline


	// Set of initial geo coordinates to create the polyline
	var coords = [];
	var corsplt;
	/*var coords = [
			new nokia.maps.geo.Coordinate(52.5032, 13.2790),
			new nokia.maps.geo.Coordinate(52.5102, 13.2818),
			new nokia.maps.geo.Coordinate(52.5121, 13.3224)
			]; */
			//alert(coordspts.length);
	for(var i=0;i<lanesplot.length;i++){

	    corsplt = lanesplot[i]['coordinates'].split(',');
	   // alert(coordspts[0]);
		coords[i] = new nokia.maps.geo.Coordinate(parseFloat(corsplt[0]),parseFloat(corsplt[1]));
	}

	// Create a new polyline with markers
	var markerPolyline = new MarkerPolyline(
		coords,
		{
			polyline: { pen: { strokeColor: "#00F8", lineWidth: 4 } },
			marker: { brush: { color: "#1080dd" }}
		}
	);

	/* Add the markerPolyline to the map's object collection so
	 * all of its containing shapes  will be rendered onto the map.
	 */
	map.objects.add(markerPolyline);

	// Zoom the map to encapsulate the initial polyline, once the map is initialized and ready
	map.addListener("displayready", function () {
		map.zoomTo(markerPolyline.getBoundingBox());
		//map.set('zoomLevel', 13);
	});
}



// JavaScript inheritance helper function
function extend(B, A) {
	function I() {}
	I.prototype = A.prototype;
	B.prototype = new I();
	B.prototype.constructor = B;
}

/**
 *  Statistic Map Plotting
 **/

function showNokiaMapRoutesByAddresses(routes_list,mapElementId){

	/*if ( routes_list == null) {
	  //var mapElement = createMapElement(mapElementId);
          //$('#map-canvas > div > p').html('The current filter selection does not have any results.Please use another filter combination');
          $.blockUI({ message: '<h3> The current filter selection does not have any results. Please use another filter combination   </h3> <button id="okclose"  onclick="$.unblockUI()" type="button">OK</button>' ,css : {width: '500px' }});
	  //return;
	}*/

	if (routes_list.length == 0) {
	  var mapElement = createMapElement(mapElementId);
	  $("#map-controls").css({position:'absolute',left:'3%',top:'10%'});
	  $('#map-canvas > div > p').html('<p style="text-align:center;font-family: segoe_ui;margin:0px auto;padding:10px 0 0 100px;width:400px;">The current filter selection does not have any results.Please use another filter combination</p>');
         // $.blockUI({ message: '<h3> The current filter selection does not have any results. Please use another filter combination   </h3> <button id="okclose"  onclick="$.unblockUI()" type="button">OK</button>' ,css : {width: '500px' }});
	  return;
	}


	nokia.Settings.set("appId", "KyW1GWWaS-K-XOSNl-Wa");
	nokia.Settings.set("authenticationToken", "pn1eUyiFnolEPuHju8sy5g");



	 // Get the DOM node to which we will append the map
	var mapContainer = document.getElementById(mapElementId);
	// Create a map inside the map container DOM node



	var map = new nokia.maps.map.Display(mapContainer, {
		// Initial center and zoom level of the map
		center: [52.51, 13.4],
		zoomLevel: 13,
		components: [
			// ZoomBar provides a UI to zoom the map in & out
			new nokia.maps.map.component.ZoomBar(),
			// we add the behavior component to allow panning / zooming of the map
			new nokia.maps.map.component.Behavior(),
			// creates UI to easily switch between street map satellite and terrain mapview modes
			new nokia.maps.map.component.TypeSelector()
		]
	});

	//map.components.add(new RestrictMap(2, 20));

	/*alert(mapElementId); return false;*/



    var infoBubbles = new  nokia.maps.map.component.InfoBubbles();
	map.addComponent(infoBubbles);

    map.addListener("click", function (e) {
 	var eventEmmiter = e.target;
//alert(jQuery.parseHTML(e.target.text));

	 //  if (eventEmmiter instanceof  nokia.maps.map.Marker) {
		/*	if ('html' in eventEmmiter) {
				infoBubbles.openBubble('dfgsdfg', eventEmmiter.coordinate);
			}*/
			infoBubbles.openBubble(e.target.html, eventEmmiter.coordinate);
	   //}

	}, false);

	var MarkerPolyline = function (coords, props) {
		nokia.maps.map.Container.call(this);
		this.init(coords, props);
	};

	extend(MarkerPolyline, nokia.maps.map.Container);


		// MarkerPolyline constructor function
	MarkerPolyline.prototype.init = function (coords, props) {
		var i,
			coord,
			marker,html,valnum,
			lineProps = props.polyline || {},
			markerProps = (this.markerProps = props.marker || {});

		this.coords = {};

		//Customized Code remove unwanted route line

		for(var j=0;j< coords.length;j += 2){
	        var coordlin = [];
	   	    coordlin[0] = coords[j];
			coordlin[1] = coords[j+1];
			   // Create a polyline
	           this.polyline = new nokia.maps.map.Polyline(coordlin, lineProps);
			   // Add the polyline to the container
	           this.objects.add(this.polyline);
	    }

		/* We loop through the point to create markers
		 * for each of the points and we store them
		 */
		for (i = 0; coord = coords[i]; i++) {
			marker = new nokia.maps.map.StandardMarker(coord, markerProps);
			this.coords[coord.latitude + "_" + coord.longitude] = { idx: i + 1, marker: marker };
                        valnum = Math.floor(i/2);
 			html = "<div style='width: 250px; word-wrap: break-word; word-break: break-all; white-space:normal;'>"+
	  			"<h3 style='color:#fff;font-size:11px;'>"+
	  			"#"+ routes_list[valnum]['id'] +" "+ routes_list[valnum]['company_name'] +
	  			"</h3>"+
	  			"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
	  			"Created by " + routes_list[valnum]['auditor_name'] +" on "+ routes_list[valnum]['date'] +
	  			"</h4>"+
                                "<h4  style='color:#fff;font-size:11px;font-style:italics;'>"+
				"Origin: "+routes_list[valnum]['start_country_name']+" </h4><h4  style='color:#fff;font-size:11px;font-style:italics;'> Destination: "+routes_list[valnum]['end_country_name']+
	                        "</h4>"+
	  			"<h4 style='color:#fff;font-size:11px;'>"+
	  			"Score: " + routes_list[valnum]['score']+"</h4><p style='font-size:11px;padding-top:6px;'><a style='text-decoration: underline;' target='_blank' href='/routes/"+routes_list[valnum]['id'] +"'>Go to audit</a></p></div>";
                         marker.set('html',html);

			this.objects.add(marker);
		}
	};

	var coords = [];
	var j=0;
	for(var i=0; i < routes_list.length; i++){
	  var start_crods = routes_list[i]['start_coordinates'].split(',');
	  var end_crods   = routes_list[i]['end_coordinates'].split(',');
	  coords[j] = new nokia.maps.geo.Coordinate(parseFloat(start_crods[0]),parseFloat(start_crods[1]));
	  j++;
	  coords[j] = new nokia.maps.geo.Coordinate(parseFloat(end_crods[0]),parseFloat(end_crods[1]));
	  j++;
	}


		// Set of initial geo coordinates to create the polyline
	//var coords = JSON.parse("["+ cord +"]");

	// Create a new polyline with markers
	var markerPolyline = new MarkerPolyline(
		coords,
		{
			polyline: { pen: { strokeColor: "#00F8", lineWidth: 2 } },
			marker: { brush: { color: "#1080dd" ,} },
		}
	);

	/* Add the markerPolyline to the map's object collection so
	 * all of its containing shapes  will be rendered onto the map.
	 */
	map.objects.add(markerPolyline);

	/* We would like to add event listener on mouse click or finger tap so we check
	 * nokia.maps.dom.Page.browser.touch which indicates whether the used browser has a touch interface.
	 */
	var TOUCH = nokia.maps.dom.Page.browser.touch,
		CLICK = TOUCH ? "tap" : "click",
		addedCoords = [];



	// Zoom the map to encapsulate the initial polyline, once the map is initialized and ready
	map.addListener("displayready", function () {
		map.zoomTo(markerPolyline.getBoundingBox());
	});


}

/**
 * Statistics Map plotting for Incidents
 *
 **/

function showIncidentMapLocationsByAddresses111(locations, mapElementId){
	if (locations.length == 0) {
	  var mapElement = createMapElement(mapElementId);
	  $("#map-controls").css({position:'absolute',left:'3%',top:'10%'});
	  $('#map-canvas > div > p').html('<p style="text-align:center;font-family: segoe_ui;">There are no incidents to display.</p>');
	  return;
	}

	nokia.Settings.set("appId", "KyW1GWWaS-K-XOSNl-Wa");
	nokia.Settings.set("authenticationToken", "pn1eUyiFnolEPuHju8sy5g");


	var map = new nokia.maps.map.Display(document.getElementById(mapElementId), {
		center: [52.51, 13.4],
		zoomLevel: 13,
		components:[new nokia.maps.map.component.Behavior(),new nokia.maps.map.component.ZoomBar(),new nokia.maps.map.component.TypeSelector()]
	});

	//map.components.add(new RestrictMap(2, 20));

	// Show different colors for different incident categories
	var category = {'minor': "#F2EE66", 'medium': "#F2AC66", 'major': "#F75E5E"};

	var markers = [];
	var dataPoints = [];

	var infoBubbles = new nokia.maps.map.component.InfoBubbles();
	map.addComponent(infoBubbles);

	for (var i = 0; i < locations.length; i++) {

	  var cordinates = locations[i]['coordinates'].split(',');
	  var cat = locations[i]['category'];
	  if (cordinates[0] != undefined && cordinates[1] != undefined) {
	    var latitude = parseFloat(cordinates[0].trim());
	    var longitude = parseFloat(cordinates[1].trim());
	    if (latitude == 0 || longitude == 0 || isNaN(latitude) || isNaN(longitude)) continue;
	  }
	  var marker = new nokia.maps.map.StandardMarker(new nokia.maps.geo.Coordinate(latitude, longitude), {brush: {color: category[cat]}});
	  marker.html = "<div>"+ new String(locations[i]['description']).substring(0, 40) +"<br /><i>"+ locations[i]['city'] +"</i></div>";
	  marker.addListener("click" ,  function(evt) { infoBubbles.addBubble(evt.target.html, evt.target.coordinate); }, false);
	  markers.push(marker);
	}

	var myContainer = new nokia.maps.map.Container();
	for (var i = 0; i < markers.length; i++) {
	  myContainer.objects.add(markers[i]);
	}
	map.objects.add(myContainer);

	map.zoomTo(myContainer.getBoundingBox());

	var markerCluster = new MarkerClusterer();
	markerCluster.objects.addAll(markers);
	map.addComponent(markerCluster);
}


/**
 * Statistics Map plotting for Incidents
 *
 **/


function showIncidentMapLocationsByAddresses(locations_list, mapElementId) {
/* --------------------- Moved to bottom
	/*if (locations_list.length == 0) {
	  var mapElement = createMapElement(mapElementId);
	   $("#map-controls").css({position:'absolute',left:'3%',top:'10%'});
	   $('#map-canvas > div > p').html('<p style="text-align:center;font-family: segoe_ui;">There are no incidents to display.</p>');
	 //  $('#map-canvas div p').css({text-align:'center'});
	 	bootbox.alert("There are no incidents to display.");
	  return;
	}*/

	var util = {
	objIsArray: function (obj) {
	  return !!obj && /array/i.test(obj.constructor.toString());
	},
	// JavaScript inheritance helper function
	extend: function (B, A) {
	  function I() {};
	  I.prototype = A.prototype;
	  B.prototype = new I;
	  B.prototype.constructor = B;
	}
	};

	/* CLUSTERING-RELATED BELOW */
	// Cache the namespace for faster access
	// Extend from the standard theme
	var mapsNS = nokia.maps,
	  clusterNS = mapsNS.clustering,
	  gfxNS = mapsNS.gfx,
	  Graphics = gfxNS.Graphics,
	  BitmapImage = gfxNS.BitmapImage,
	  GraphicsImage = gfxNS.GraphicsImage,
	  MarkerTheme = clusterNS.MarkerTheme,
	  CLSTheme = function () {
	    MarkerTheme.call(this, clusterNS.MarkerTheme.POSITION_WEIGHT_CENTER);
	  };

	nokia.Settings.set("appId", "KyW1GWWaS-K-XOSNl-Wa");
	nokia.Settings.set("authenticationToken", "pn1eUyiFnolEPuHju8sy5g");

	var map = new mapsNS.map.Display(document.getElementById(mapElementId), {
	  center: [52.51, 13.4],
	  zoomLevel: 13,
	  components:[new mapsNS.map.component.Behavior(),new mapsNS.map.component.ZoomBar(),new mapsNS.map.component.TypeSelector()]
	});


	//map.components.add(new RestrictMap(2, 20));

	util.extend(CLSTheme, MarkerTheme);

	var clsTheme = new CLSTheme(),
	// Create a nokia.maps.clustering.ClusterProvider to handle clustering
	globalClusterProvider = new clusterNS.ClusterProvider(map, {
	  eps: 30,
	  minPts: 2,
	  max: 20, //max zoom level to provide clustering
	  min: 2, // min zoom level to provide clustering
	  theme: clsTheme,
	  dataPoints: [],
	  //strategy: clusterNS.ClusterProvider.STRATEGY_DENSITY_BASED
	  strategy: clusterNS.ClusterProvider.STRATEGY_GRID_BASED
	});

	// Define a different representation of a noise point (any singular point that doesn't belong to a cluster)
	CLSTheme.prototype.getNoisePresentation = function (dataPoint) {
		var bgMarker,
		    poiMarker,
		    coords = [dataPoint.latitude, dataPoint.longitude],
		    clusterNoisePoiContainer = new mapsNS.map.Container();

		bgMarker = new mapsNS.map.Marker(new mapsNS.geo.Coordinate(dataPoint.latitude, dataPoint.longitude), {brush: {color: dataPoint.color}});

		// Create the numeric text marker to put on top
		poiMarker = new mapsNS.map.Marker(coords, {
		    icon: new GraphicsImage(function (gfx, graphicsImage) {
		      // This will clear the canvas and set it's size to 20 x 20 pixel
				gfx.beginImage(25, 35, "Cluster");
		    }),
		    anchor: {
		      x: 13,
		      y: 20
		    }
		});

		bgMarker['html'] = dataPoint.name;
		poiMarker['html'] = dataPoint.name;
		

		/*if (cordinates.category == "minor") {
		bgMarker.set("icon", "/images/NewSupplier.png"); }
		else {
		bgMarker.set("icon", "/images/supplier.png");
		}*/
		
		bgMarker.set("icon", "/images/newicon.png");
		
		clusterNoisePoiContainer.objects.addAll([bgMarker, poiMarker]);
		return clusterNoisePoiContainer;
	};

    var infoBubbles = new mapsNS.map.component.InfoBubbles();
	map.addComponent(infoBubbles);

	// Employ event delegation: Add a click listener to the clusterProvider's container, to react on
	// each "marker" being clicked
	globalClusterProvider.getContainer().addListener("click", function (e) {
	  var eventEmmiter = e.target;
	  if (eventEmmiter instanceof mapsNS.map.Marker) {
	    // Check for special attribute '$infoIndex' passed on by the marker who reported the click event.
	    // 'html' is added by us on marker creation time, it's not built-in in JSLA
	    if ('html' in eventEmmiter) {
	    	infoBubbles.openBubble(eventEmmiter['html'], eventEmmiter.coordinate);
		}
	  }
	}, false);

	// How to "feed" data to the cluster provider and then trigger clustering
	var clusterData = [];

	// Show different colors for different incident categories
	var categories = {'minor': "#F2EE66", 'medium': "#F2AC66", 'major': "#F75E5E"};

	var locations = [];
	var myContainer = new nokia.maps.map.Container();

	for (var i = 0; i < locations_list.length; i++) {
	  var cordinates = locations_list[i]['coordinates'].split(',');
	  var category = locations_list[i]['category'];
	  if (cordinates[0] != undefined && cordinates[1] != undefined) {
	    var latitude = parseFloat(cordinates[0].trim());
	    var longitude = parseFloat(cordinates[1].trim());
	    if (latitude == 0 || longitude == 0 || isNaN(latitude) || isNaN(longitude)) continue;
	  }
	  var html = "<div style='width: 250px; word-wrap: break-word; word-break: break-all; white-space:normal;'>"+
	  			"<h3 style='color:#fff;font-size:11px;'>"+
	  			"#"+ locations_list[i]['id'] +" "+ locations_list[i]['company_name'] + " (" +locations_list[i]['city'] +", "+ locations_list[i]['country_name'] + ")" +
	  			"</h3>"+
	  			"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
	  			"by " + locations_list[i]['name'] +" on "+ locations_list[i]['date'] +
	  			"</h4>"+
	  			"<h4 style='color:#fff;font-size:11px;'>"+
	  			"Loss Value: &#36; " + locations_list[i]['value'] +
	  			"</h4>";
	if (locations_list[i]['incident_type']=='logistic') {
		html += "<p style='font-size:11px;'><a style='text-decoration: underline;' target='_blank' href='/incidents/"+ locations_list[i]['id'] +"'>Go to incident</a></p></div>";
	}
	else
	{
		html += "<p style='font-size:11px;'><a style='text-decoration: underline;' target='_blank' href='/factory/incidents/"+ locations_list[i]['id'] +"'>Go to factory incident</a></p></div>";
	}
	/* Adding each entry to the clusterData array */
	  clusterData.push({
	    name: html,
	    latitude: latitude,
	    longitude: longitude,
	    color: categories[category],
	    dataIndex: i,
	    dataId: i
	  });

	  myContainer.objects.add(new nokia.maps.map.StandardMarker(new nokia.maps.geo.Coordinate(latitude, longitude)));
	}

	// Add the datapoints to the cluster provider
	globalClusterProvider.addAll(clusterData);
	// Trigger clustering
	globalClusterProvider.cluster();

	var promise = (function (map) {
		var def = jQuery.Deferred();
		map.addObserver('copyrightPosition', function (obj, key, value, oldValue) {
		  def.resolve();
		});

		return def;
	})(map);

	promise.then(function () {
		if (locations_list.length == 1) {
			map.set('zoomLevel', 2);
			map.set('center', [latitude, longitude]);
		}
		else {
			map.zoomTo(myContainer.getBoundingBox());
		}
	});
	if (locations_list.length == 0) {
	  var mapElement = createMapElement(mapElementId);
	   //$("#map-controls").css({position:'absolute',left:'3%',top:'10%'});
	   $('#map-canvas > div > p').html('<p style="text-align:center;font-family: segoe_ui;margin:0px auto;width:400px;">The current filter selection does not have any results.Please use another filter combination</p>');
	 //  $('#map-canvas div p').css({text-align:'center'});
	 	//bootbox.alert("There are no incidents to display.");
	  return;
	}
}


/**
 *
 * Statistics Map plotting for Location Audit
 *
 *
 **/

function showNokiaMapLocationsByAddresses(locations_list, mapElementId) {
	
	
	/* Moved to bottom
	if (locations_list.length == 0) {
	  var mapElement = createMapElement(mapElementId);
	   $("#map-controls").css({position:'absolute',left:'3%',top:'10%'});
	   $('#map-canvas > div > p').html('<p style="text-align:center;font-family: segoe_ui;margin:0px auto;width:400px;">The current filter selection does not have any results.Please use another filter combination</p>');
        // $.blockUI({ message: '<h3> The current filter selection does not have any results. Please use another filter combination   </h3> <button id="okclose"  onclick="$.unblockUI()" type="button">OK</button>' ,css : {width: '500px' }});
	  return;
	}*/

	var util = {
	objIsArray: function (obj) {
	  return !!obj && /array/i.test(obj.constructor.toString());
	},
	// JavaScript inheritance helper function
	extend: function (B, A) {
	  function I() {};
	  I.prototype = A.prototype;
	  B.prototype = new I;
	  B.prototype.constructor = B;
	}
	};

	/* CLUSTERING-RELATED BELOW */
	// Cache the namespace for faster access
	// Extend from the standard theme
	var mapsNS = nokia.maps,
	  clusterNS = mapsNS.clustering,
	  gfxNS = mapsNS.gfx,
	  Graphics = gfxNS.Graphics,
	  BitmapImage = gfxNS.BitmapImage,
	  GraphicsImage = gfxNS.GraphicsImage,
	  MarkerTheme = clusterNS.MarkerTheme,
	  CLSTheme = function () {
	    MarkerTheme.call(this, clusterNS.MarkerTheme.POSITION_WEIGHT_CENTER);
	  };

	nokia.Settings.set("appId", "KyW1GWWaS-K-XOSNl-Wa");
	nokia.Settings.set("authenticationToken", "pn1eUyiFnolEPuHju8sy5g");
	nokia.Settings.set("secureConnection", "force");

	var map = new mapsNS.map.Display(document.getElementById(mapElementId), {
	  //center: [52.51, 13.4],
	  zoomLevel: 2,
	  components:[new mapsNS.map.component.Behavior(),new mapsNS.map.component.ZoomBar(),new mapsNS.map.component.TypeSelector()]
	});

	//map.components.add(new RestrictMap(2, 20));

	util.extend(CLSTheme, MarkerTheme);

	var clsTheme = new CLSTheme(),
	// Create a nokia.maps.clustering.ClusterProvider to handle clustering
	globalClusterProvider = new clusterNS.ClusterProvider(map, {
	  eps: 30,
	  minPts: 2,
	  max: 20, //max zoom level to provide clustering
	  min: 2, // min zoom level to provide clustering
	  theme: clsTheme,
	  dataPoints: [],
	  //strategy: clusterNS.ClusterProvider.STRATEGY_DENSITY_BASED
	  strategy: clusterNS.ClusterProvider.STRATEGY_GRID_BASED
	});

	// Define a different representation of a noise point (any singular point that doesn't belong to a cluster)
	CLSTheme.prototype.getNoisePresentation = function (dataPoint) {
		var bgMarker,
		    poiMarker,
		    coords = [dataPoint.latitude, dataPoint.longitude],
		    clusterNoisePoiContainer = new mapsNS.map.Container();

		bgMarker = new mapsNS.map.StandardMarker(new mapsNS.geo.Coordinate(dataPoint.latitude, dataPoint.longitude), {brush: {color: dataPoint.color}});

		// Create the numeric text marker to put on top
		poiMarker = new mapsNS.map.Marker(coords, {
		    icon: new GraphicsImage(function (gfx, graphicsImage) {
		      // This will clear the canvas and set it's size to 20 x 20 pixel
		      gfx.beginImage(25, 35, "Cluster");
		    }),
		    anchor: {
		      x: 13,
		      y: 20
		    }
		});

		bgMarker['html'] = dataPoint.name;
		poiMarker['html'] = dataPoint.name;

		clusterNoisePoiContainer.objects.addAll([bgMarker, poiMarker]);
		return clusterNoisePoiContainer;
	};

    var infoBubbles = new mapsNS.map.component.InfoBubbles();
	map.addComponent(infoBubbles);

	// Employ event delegation: Add a click listener to the clusterProvider's container, to react on
	// each "marker" being clicked
	globalClusterProvider.getContainer().addListener("click", function (e) {
	  var eventEmmiter = e.target;
	  if (eventEmmiter instanceof mapsNS.map.Marker) {
	    // Check for special attribute '$infoIndex' passed on by the marker who reported the click event.
	    // 'html' is added by us on marker creation time, it's not built-in in JSLA
	    if ('html' in eventEmmiter) {
	    	infoBubbles.openBubble(eventEmmiter['html'], eventEmmiter.coordinate);
		}
	  }
	}, false);

	// How to "feed" data to the cluster provider and then trigger clustering
	var clusterData = [];

	// Show different colors for different incident categories
	var categories = {'green': "#007233", 'yellow': "#FCD116", 'red': "#BA141A"};

	var locations = [];
	var myContainer = new nokia.maps.map.Container();

	for (var i = 0; i < locations_list.length; i++) {
	  var cordinates = locations_list[i]['coordinates'].split(',');
	  var category = locations_list[i]['category'];
	  if (cordinates[0] != undefined && cordinates[1] != undefined) {
	    var latitude = parseFloat(cordinates[0].trim());
	    var longitude = parseFloat(cordinates[1].trim());
	    if (latitude == 0 || longitude == 0 || isNaN(latitude) || isNaN(longitude)) continue;
	  }
	  var html = "<div style='width: 250px; word-wrap: break-word; word-break: break-all; white-space:normal;'>"+
	  			"<h3 style='color:#fff;font-size:11px;'>"+
	  			"#"+ locations_list[i]['id'] +" "+ locations_list[i]['company_name'] + " (" +locations_list[i]['country_name'] +", "+ locations_list[i]['region_name'] + ")" +
	  			"</h3>"+
	  			"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
	  			"Created by " + locations_list[i]['auditor_name'] +" on "+ locations_list[i]['date'] +
	  			"</h4>"+
				"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
				"Location: "+locations_list[i]['country_name']+
				"</h4>"+
	  			"<h4 style='color:#fff;font-size:11px;'>"+
	  			"Score: " + locations_list[i]['score']
	  			"</h4>";
				//if (locations_list[i]['show_view_link']) {
		html += "<p style='font-size:11px;padding-top:6px;'><a style='text-decoration: underline;' target='_blank' href='/locations/"+ locations_list[i]['id'] +"'>Go to audit</a></p></div>";
	//}
	/* Adding each entry to the clusterData array */
	  clusterData.push({
	    name: html,
	    latitude: latitude,
	    longitude: longitude,
	    color: categories[category],
	    dataIndex: i,
	    dataId: i
	  });

	  myContainer.objects.add(new nokia.maps.map.StandardMarker(new nokia.maps.geo.Coordinate(latitude, longitude)));
    }

	// Add the datapoints to the cluster provider
	globalClusterProvider.addAll(clusterData);
	// Trigger clustering
	globalClusterProvider.cluster();

	var promise = (function (map) {
		var def = jQuery.Deferred();
		map.addObserver('copyrightPosition', function (obj, key, value, oldValue) {
		  def.resolve();
		});

		return def;
	})(map);

	promise.then(function () {
		if (locations_list.length == 1) {
			map.set('zoomLevel', 2);
			map.set('center', [latitude, longitude]);
		}
		else {
			map.zoomTo(myContainer.getBoundingBox());
		}
	});
	if (locations_list.length == 0) {
	  var mapElement = createMapElement(mapElementId);
	   $("#map-controls").css({position:'absolute',left:'3%',top:'10%'});
	   //$('#map-canvas > div > p').html('<p style="text-align:center;font-family: segoe_ui;margin:0px auto;width:400px;">The current filter selection does not have any results.Please use another filter combination</p>');
        // $.blockUI({ message: '<h3> The current filter selection does not have any results. Please use another filter combination   </h3> <button id="okclose"  onclick="$.unblockUI()" type="button">OK</button>' ,css : {width: '500px' }});
	  return;
	}
}


/**
 *
 * Statistics Map plotting for Suppliers Audit
 *
 *
 **/

function showSuppliersMapByAddress(suppliers_list, mapElementId) {
	if (suppliers_list.length == 0) {
	  var mapElement = createMapElement(mapElementId);
	   $("#map-controls").css({position:'absolute',left:'3%',top:'10%'});
	   $('#map-canvas > div > p').html('<p style="text-align:center;font-family: segoe_ui;margin:0px auto;padding:10px 0 0 100px;width:400px;">The current filter selection does not have any results.Please use another filter combination</p>');
        // $.blockUI({ message: '<h3> The current filter selection does not have any results. Please use another filter combination   </h3> <button id="okclose"  onclick="$.unblockUI()" type="button">OK</button>' ,css : {width: '500px' }});
	  return;
	}

	var util = {
	objIsArray: function (obj) {
	  return !!obj && /array/i.test(obj.constructor.toString());
	},
	// JavaScript inheritance helper function
	extend: function (B, A) {
	  function I() {};
	  I.prototype = A.prototype;
	  B.prototype = new I;
	  B.prototype.constructor = B;
	}
	};

	/* CLUSTERING-RELATED BELOW */
	// Cache the namespace for faster access
	// Extend from the standard theme
	var mapsNS = nokia.maps,
	  clusterNS = mapsNS.clustering,
	  gfxNS = mapsNS.gfx,
	  Graphics = gfxNS.Graphics,
	  BitmapImage = gfxNS.BitmapImage,
	  GraphicsImage = gfxNS.GraphicsImage,
	  MarkerTheme = clusterNS.MarkerTheme,
	  CLSTheme = function () {
	    MarkerTheme.call(this, clusterNS.MarkerTheme.POSITION_WEIGHT_CENTER);
	  };

	nokia.Settings.set("appId", "KyW1GWWaS-K-XOSNl-Wa");
	nokia.Settings.set("authenticationToken", "pn1eUyiFnolEPuHju8sy5g");
	nokia.Settings.set("secureConnection", "force");

	var map = new mapsNS.map.Display(document.getElementById(mapElementId), {
	  //center: [52.51, 13.4],
	  zoomLevel: 2,
	  components:[new mapsNS.map.component.Behavior(),new mapsNS.map.component.ZoomBar(),new mapsNS.map.component.TypeSelector()]
	});

	//map.components.add(new RestrictMap(2, 20));

	util.extend(CLSTheme, MarkerTheme);

	var clsTheme = new CLSTheme(),
	// Create a nokia.maps.clustering.ClusterProvider to handle clustering
	globalClusterProvider = new clusterNS.ClusterProvider(map, {
	  eps: 30,
	  minPts: 2,
	  max: 20, //max zoom level to provide clustering
	  min: 2, // min zoom level to provide clustering
	  theme: clsTheme,
	  dataPoints: [],
	  //strategy: clusterNS.ClusterProvider.STRATEGY_DENSITY_BASED
	  strategy: clusterNS.ClusterProvider.STRATEGY_GRID_BASED
	});

	// Define a different representation of a noise point (any singular point that doesn't belong to a cluster)
	CLSTheme.prototype.getNoisePresentation = function (dataPoint) {
		var bgMarker,
		    poiMarker,
		    coords = [dataPoint.latitude, dataPoint.longitude],
		    clusterNoisePoiContainer = new mapsNS.map.Container();

		bgMarker = new mapsNS.map.Marker(new mapsNS.geo.Coordinate(dataPoint.latitude, dataPoint.longitude), {brush: {color: dataPoint.color}});

		// Create the numeric text marker to put on top
		poiMarker = new mapsNS.map.Marker(coords, {
		    icon: new GraphicsImage(function (gfx, graphicsImage) {
		      // This will clear the canvas and set it's size to 20 x 20 pixel
		      gfx.beginImage(25, 35, "Cluster");
		    }),
		    anchor: {
		      x: 13,
		      y: 20
		    }
		});

		bgMarker['html'] = dataPoint.name;
		poiMarker['html'] = dataPoint.name;

		bgMarker.set("icon", "/images/icontop.png");

		clusterNoisePoiContainer.objects.addAll([bgMarker, poiMarker]);
		return clusterNoisePoiContainer;
	};

    var infoBubbles = new mapsNS.map.component.InfoBubbles();
	map.addComponent(infoBubbles);

	// Employ event delegation: Add a click listener to the clusterProvider's container, to react on
	// each "marker" being clicked
	globalClusterProvider.getContainer().addListener("click", function (e) {
	  var eventEmmiter = e.target;
	  if (eventEmmiter instanceof mapsNS.map.Marker) {
	    // Check for special attribute '$infoIndex' passed on by the marker who reported the click event.
	    // 'html' is added by us on marker creation time, it's not built-in in JSLA
	    if ('html' in eventEmmiter) {
	    	infoBubbles.openBubble(eventEmmiter['html'], eventEmmiter.coordinate);
		}
	  }
	}, false);

	// How to "feed" data to the cluster provider and then trigger clustering
	var clusterData = [];

	// Show different colors for different incident categories
	var categories = {'green': "#007233", 'yellow': "#FCD116", 'red': "#BA141A"};

	var locations = [];
	var myContainer = new nokia.maps.map.Container();

	for (var i = 0; i < suppliers_list.length; i++) {
	  var cordinates = suppliers_list[i]['coordinates'].split(',');
	  var category = suppliers_list[i]['category'];
	  if (cordinates[0] != undefined && cordinates[1] != undefined) {
	    var latitude = parseFloat(cordinates[0].trim());
	    var longitude = parseFloat(cordinates[1].trim());
	    if (latitude == 0 || longitude == 0 || isNaN(latitude) || isNaN(longitude)) continue;
	  }
	  var html = "<div style='width: 250px; word-wrap: break-word; word-break: break-all; white-space:normal;'>"+
	  			"<h3 style='color:#fff;font-size:11px;'>"+
	  			"#"+ suppliers_list[i]['id'] +" "+ suppliers_list[i]['vendor_name'] + " (" +suppliers_list[i]['country_name'] +", "+ suppliers_list[i]['region_name'] + ")" +
	  			"</h3>"+
	  			"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
	  			"Created by " + suppliers_list[i]['auditor_name'] +" on "+ suppliers_list[i]['date'] +
	  			"</h4>"+
				"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
				"Location: "+suppliers_list[i]['country_name']+
				"</h4>";
				html += "<p style='font-size:11px;'><a style='text-decoration: underline;' target='_blank' href='/suppliers/"+ suppliers_list[i]['id'] +"'>Go to supplier</a></p></div>";
				//if (locations_list[i]['show_view_link']) {
		
	//}
	/* Adding each entry to the clusterData array */
	  clusterData.push({
	    name: html,
	    latitude: latitude,
	    longitude: longitude,
	    color: '#1080DD',
	    dataIndex: i,
	    dataId: i
	  });

	  myContainer.objects.add(new nokia.maps.map.StandardMarker(new nokia.maps.geo.Coordinate(latitude, longitude)));
    }

	// Add the datapoints to the cluster provider
	globalClusterProvider.addAll(clusterData);
	// Trigger clustering
	globalClusterProvider.cluster();

	var promise = (function (map) {
		var def = jQuery.Deferred();
		map.addObserver('copyrightPosition', function (obj, key, value, oldValue) {
		  def.resolve();
		});

		return def;
	})(map);

	promise.then(function () {
		if (suppliers_list.length == 1) {
			map.set('zoomLevel', 2);
			map.set('center', [latitude, longitude]);
		}
		else {
			map.zoomTo(myContainer.getBoundingBox());
		}
	});
}



/**
 *
 * Statistics Map plotting for Sitemasters Audit
 *
 *
 **/

function showSitemastersMapByAddress(sitemasters_list, mapElementId) {
	if (sitemasters_list.length == 0) {
	  var mapElement = createMapElement(mapElementId);
	   $("#map-controls").css({position:'absolute',left:'3%',top:'10%'});
	   $('#map-canvas > div > p').html('<p style="text-align:center;font-family: segoe_ui;margin:0px auto;padding:10px 0 0 100px;width:400px;">The current filter selection does not have any results.Please use another filter combination</p>');
        // $.blockUI({ message: '<h3> The current filter selection does not have any results. Please use another filter combination   </h3> <button id="okclose"  onclick="$.unblockUI()" type="button">OK</button>' ,css : {width: '500px' }});
	  return;
	}

	var util = {
	objIsArray: function (obj) {
	  return !!obj && /array/i.test(obj.constructor.toString());
	},
	// JavaScript inheritance helper function
	extend: function (B, A) {
	  function I() {};
	  I.prototype = A.prototype;
	  B.prototype = new I;
	  B.prototype.constructor = B;
	}
	};

	/* CLUSTERING-RELATED BELOW */
	// Cache the namespace for faster access
	// Extend from the standard theme
	var mapsNS = nokia.maps,
	  clusterNS = mapsNS.clustering,
	  gfxNS = mapsNS.gfx,
	  Graphics = gfxNS.Graphics,
	  BitmapImage = gfxNS.BitmapImage,
	  GraphicsImage = gfxNS.GraphicsImage,
	  MarkerTheme = clusterNS.MarkerTheme,
	  CLSTheme = function () {
	    MarkerTheme.call(this, clusterNS.MarkerTheme.POSITION_WEIGHT_CENTER);
	  };

	nokia.Settings.set("appId", "KyW1GWWaS-K-XOSNl-Wa");
	nokia.Settings.set("authenticationToken", "pn1eUyiFnolEPuHju8sy5g");
	nokia.Settings.set("secureConnection", "force");

	var map = new mapsNS.map.Display(document.getElementById(mapElementId), {
	  //center: [52.51, 13.4],
	  zoomLevel: 2,
	  components:[new mapsNS.map.component.Behavior(),new mapsNS.map.component.ZoomBar(),new mapsNS.map.component.TypeSelector()]
	});

	//map.components.add(new RestrictMap(2, 20));

	util.extend(CLSTheme, MarkerTheme);

	var clsTheme = new CLSTheme(),
	// Create a nokia.maps.clustering.ClusterProvider to handle clustering
	globalClusterProvider = new clusterNS.ClusterProvider(map, {
	  eps: 30,
	  minPts: 2,
	  max: 20, //max zoom level to provide clustering
	  min: 2, // min zoom level to provide clustering
	  theme: clsTheme,
	  dataPoints: [],
	  //strategy: clusterNS.ClusterProvider.STRATEGY_DENSITY_BASED
	  strategy: clusterNS.ClusterProvider.STRATEGY_GRID_BASED
	});

	// Define a different representation of a noise point (any singular point that doesn't belong to a cluster)
	CLSTheme.prototype.getNoisePresentation = function (dataPoint) {
		var bgMarker,
		    poiMarker,
		    coords = [dataPoint.latitude, dataPoint.longitude],
		    clusterNoisePoiContainer = new mapsNS.map.Container();

		bgMarker = new mapsNS.map.Marker(new mapsNS.geo.Coordinate(dataPoint.latitude, dataPoint.longitude), {brush: {color: dataPoint.color}});

		// Create the numeric text marker to put on top
		poiMarker = new mapsNS.map.Marker(coords, {
		    icon: new GraphicsImage(function (gfx, graphicsImage) {
		      // This will clear the canvas and set it's size to 20 x 20 pixel
		      gfx.beginImage(25, 35, "Cluster");
		    }),
		    anchor: {
		      x: 13,
		      y: 20
		    }
		});

		bgMarker['html'] = dataPoint.name;
		poiMarker['html'] = dataPoint.name;

		bgMarker.set("icon", "/images/sitemaster.png");

		clusterNoisePoiContainer.objects.addAll([bgMarker, poiMarker]);
		return clusterNoisePoiContainer;
	};

    var infoBubbles = new mapsNS.map.component.InfoBubbles();
	map.addComponent(infoBubbles);

	// Employ event delegation: Add a click listener to the clusterProvider's container, to react on
	// each "marker" being clicked
	globalClusterProvider.getContainer().addListener("click", function (e) {
	  var eventEmmiter = e.target;
	  if (eventEmmiter instanceof mapsNS.map.Marker) {
	    // Check for special attribute '$infoIndex' passed on by the marker who reported the click event.
	    // 'html' is added by us on marker creation time, it's not built-in in JSLA
	    if ('html' in eventEmmiter) {
	    	infoBubbles.openBubble(eventEmmiter['html'], eventEmmiter.coordinate);
		}
	  }
	}, false);

	// How to "feed" data to the cluster provider and then trigger clustering
	var clusterData = [];

	// Show different colors for different incident categories
	var categories = {'green': "#007233", 'yellow': "#FCD116", 'red': "#BA141A"};

	var locations = [];
	var myContainer = new nokia.maps.map.Container();

	for (var i = 0; i < sitemasters_list.length; i++) {
	  var cordinates = sitemasters_list[i]['coordinates'].split(',');
	  var category = sitemasters_list[i]['category'];
	  if (cordinates[0] != undefined && cordinates[1] != undefined) {
	    var latitude = parseFloat(cordinates[0].trim());
	    var longitude = parseFloat(cordinates[1].trim());
	    if (latitude == 0 || longitude == 0 || isNaN(latitude) || isNaN(longitude)) continue;
	  }
	  var html = "<div style='width: 250px; word-wrap: break-word; word-break: break-all; white-space:normal;'>"+
	  			"<h3 style='color:#fff;font-size:11px;'>"+
	  			"#"+ sitemasters_list[i]['id'] +" "+ sitemasters_list[i]['site_name'] + " (" +sitemasters_list[i]['country_name'] +", "+ sitemasters_list[i]['region_name'] + ")" +
	  			"</h3>"+
	  			"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
	  			"Created by " + sitemasters_list[i]['auditor_name'] +" on "+ sitemasters_list[i]['date'] +
	  			"</h4>"+
				"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
				"Location: "+sitemasters_list[i]['country_name']+
				"</h4>";
				//if (locations_list[i]['show_view_link']) {
		html += "<p style='font-size:11px;'><a style='text-decoration: underline;' target='_blank' href='/sitemaster/"+ sitemasters_list[i]['id'] +"'>Go to site</a></p></div>";
	//}
	/* Adding each entry to the clusterData array */
	  clusterData.push({
	    name: html,
	    latitude: latitude,
	    longitude: longitude,
	    color: '#1080DD',
	    dataIndex: i,
	    dataId: i
	  });

	  myContainer.objects.add(new nokia.maps.map.StandardMarker(new nokia.maps.geo.Coordinate(latitude, longitude)));
    }

	// Add the datapoints to the cluster provider
	globalClusterProvider.addAll(clusterData);
	// Trigger clustering
	globalClusterProvider.cluster();

	var promise = (function (map) {
		var def = jQuery.Deferred();
		map.addObserver('copyrightPosition', function (obj, key, value, oldValue) {
		  def.resolve();
		});

		return def;
	})(map);

	promise.then(function () {
		if (suppliers_list.length == 1) {
			map.set('zoomLevel', 2);
			map.set('center', [latitude, longitude]);
		}
		else {
			map.zoomTo(myContainer.getBoundingBox());
		}
	});
}


/**
 *
 * Lanes Selecting for Location Audit
 *
 *
 **/

function showNokiaMapLanesLocationbyAddresses(locations_list, mapElementId) {

	if (locations_list === null || locations_list.length == 0) {
      locations_list = "";
	}

	var util = {
	objIsArray: function (obj) {
	  return !!obj && /array/i.test(obj.constructor.toString());
	},
	// JavaScript inheritance helper function
	extend: function (B, A) {
	  function I() {};
	  I.prototype = A.prototype;
	  B.prototype = new I;
	  B.prototype.constructor = B;
	}
	};

	/* CLUSTERING-RELATED BELOW */
	// Cache the namespace for faster access
	// Extend from the standard theme
	var mapsNS = nokia.maps,
	  clusterNS = mapsNS.clustering,
	  gfxNS = mapsNS.gfx,
	  Graphics = gfxNS.Graphics,
	  BitmapImage = gfxNS.BitmapImage,
	  GraphicsImage = gfxNS.GraphicsImage,
	  MarkerTheme = clusterNS.MarkerTheme,
	  CLSTheme = function () {
	    MarkerTheme.call(this, clusterNS.MarkerTheme.POSITION_WEIGHT_CENTER);
	  };

	nokia.Settings.set("appId", "KyW1GWWaS-K-XOSNl-Wa");
	nokia.Settings.set("authenticationToken", "pn1eUyiFnolEPuHju8sy5g");
	nokia.Settings.set("secureConnection", "force");

	var map = new mapsNS.map.Display(document.getElementById(mapElementId), {
//	  center: [52.51, 13.4],
	  zoomLevel: 2,
	  components:[new mapsNS.map.component.Behavior(),new mapsNS.map.component.ZoomBar(),new mapsNS.map.component.TypeSelector()]
	});

	//map.components.add(new RestrictMap(2, 20));

	util.extend(CLSTheme, MarkerTheme);

	var clsTheme = new CLSTheme(),
	// Create a nokia.maps.clustering.ClusterProvider to handle clustering
	globalClusterProvider = new clusterNS.ClusterProvider(map, {
	  eps: 30,
	  minPts: 2,
	  max: 20, //max zoom level to provide clustering
	  min: 2, // min zoom level to provide clustering
	  theme: clsTheme,
	  dataPoints: [],
	  //strategy: clusterNS.ClusterProvider.STRATEGY_DENSITY_BASED
	  strategy: clusterNS.ClusterProvider.STRATEGY_GRID_BASED
	});

	// Define a different representation of a noise point (any singular point that doesn't belong to a cluster)
	CLSTheme.prototype.getNoisePresentation = function (dataPoint) {
		var bgMarker,
		    poiMarker,
		    coords = [dataPoint.latitude, dataPoint.longitude],
		    clusterNoisePoiContainer = new mapsNS.map.Container();

		bgMarker = new mapsNS.map.StandardMarker(new mapsNS.geo.Coordinate(dataPoint.latitude, dataPoint.longitude), {brush: {color: dataPoint.color}});

		// Create the numeric text marker to put on top
		poiMarker = new mapsNS.map.Marker(coords, {
		    icon: new GraphicsImage(function (gfx, graphicsImage) {
		      // This will clear the canvas and set it's size to 20 x 20 pixel
		      gfx.beginImage(25, 35, "Cluster");
		    }),
		    anchor: {
		      x: 13,
		      y: 20
		    }
		});

		bgMarker['html'] = dataPoint.name;
		poiMarker['html'] = dataPoint.name;

		clusterNoisePoiContainer.objects.addAll([bgMarker, poiMarker]);
		return clusterNoisePoiContainer;
	};

    var infoBubbles = new mapsNS.map.component.InfoBubbles();
	map.addComponent(infoBubbles);

	// Employ event delegation: Add a click listener to the clusterProvider's container, to react on
	// each "marker" being clicked
	globalClusterProvider.getContainer().addListener("click", function (e) {
	  $(".existingtag").hide();
	  $("#existpoistion").show();
	  $("#process").val('map');
	  $("#steps").val('2');
	  var positionlength = $("select#nodeposition option").length;

	  var eventEmmiter = e.target;

	  if(positionlength != 0){
		  var auditdetail  = eventEmmiter['html'];
		  var auditID     = auditdetail.match(/<span class='auditid'>([0-9]+)/gi).toString().split('>');
		  $("[name=existingLocation]").val(auditID[1]);
		  $(".addnodes").modal('show');
	   }else{
	   	  $("#steps").val('3');
	   	  $("#finallanes").modal('show');
		}

	  if (eventEmmiter instanceof mapsNS.map.Marker) {
	    // Check for special attribute '$infoIndex' passed on by the marker who reported the click event.
	    // 'html' is added by us on marker creation time, it's not built-in in JSLA
	    if ('html' in eventEmmiter) {
	    	infoBubbles.openBubble(eventEmmiter['html'], eventEmmiter.coordinate);
		}
	  }
	}, false);

	// How to "feed" data to the cluster provider and then trigger clustering
	var clusterData = [];

	// Show different colors for different incident categories
	var categories = {'green': "#007233", 'yellow': "#FCD116", 'red': "#BA141A"};

	var locations = [];
	var myContainer = new nokia.maps.map.Container();

	for (var i = 0; i < locations_list.length; i++) {
	  var cordinates = locations_list[i]['coordinates'].split(',');
	  var category = locations_list[i]['category'];
	  if (cordinates[0] != undefined && cordinates[1] != undefined) {
	    var latitude = parseFloat(cordinates[0].trim());
	    var longitude = parseFloat(cordinates[1].trim());
	    if (latitude == 0 || longitude == 0 || isNaN(latitude) || isNaN(longitude)) continue;
	  }
	  var html = "<div style='width: 250px; word-wrap: break-word; word-break: break-all; white-space:normal;'>"+
	  			"<h3 style='color:#fff;font-size:11px;'>"+
	  			"#<span class='auditid'>"+ locations_list[i]['id'] +"&nbsp;</span><span class='auditname'>"+ locations_list[i]['name'] +"</span>"+
	  			"</h3>"+
	  			"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
	  			"Created on "+ locations_list[i]['date'] +
	  			"</h4>"+
				"<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
				"</h4>"+
	  			"<h4 style='color:#fff;font-size:11px;'>"+
	  			"Score: " + locations_list[i]['score']
	  			"</h4>";
				//if (locations_list[i]['show_view_link']) {
		html += "<p style='font-size:11px;padding-top:6px;'><a style='text-decoration: underline;' target='_blank' href='/locations/"+ locations_list[i]['id'] +"'>Go to audit</a></p></div>";
	//}
	/* Adding each entry to the clusterData array */
	  clusterData.push({
	    name: html,
	    latitude: latitude,
	    longitude: longitude,
	    color: categories[category],
	    dataIndex: i,
	    dataId: i
	  });

	  myContainer.objects.add(new nokia.maps.map.StandardMarker(new nokia.maps.geo.Coordinate(latitude, longitude)));
	}

	// Add the datapoints to the cluster provider
	globalClusterProvider.addAll(clusterData);
	// Trigger clustering
	globalClusterProvider.cluster();

	var promise = (function (map) {
		var def = jQuery.Deferred();
		map.addObserver('copyrightPosition', function (obj, key, value, oldValue) {
		  def.resolve();
		});

		return def;
	})(map);

	promise.then(function () {
		if (locations_list.length == 1) {
			map.set('zoomLevel', 2);
			map.set('center', [latitude, longitude]);
		}
		else {
			map.zoomTo(myContainer.getBoundingBox());
		}
	});
}
