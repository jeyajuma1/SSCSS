if (typeof Microsoft != 'undefined')
{




  
}
        
/**
 * Statistics Map plotting for Incidents
 *
 **/

    function showBingIncidentMapLocationsByAddresses() {
       var  locations = coordinates;
     
    	  var map, clusterLayer;
          var pinInfobox = null;  
        map = new Microsoft.Maps.Map('#map_canvas',{
            credentials: 'AgbUnrKEhOfs69x9OljXuzMN-nmEShW3rL2cP7kx4SaR-o02zvmlEOkbivQKlaK2',
            zoom:3
        });
         //Create an infobox at the center of the map but don't show it.
         infobox = new Microsoft.Maps.Infobox(map.getCenter(), {
            visible: false,
            showCloseButton:false
        }); 
        //Assign the infobox to a map instance.
        infobox.setMap(map);
        Microsoft.Maps.loadModule("Microsoft.Maps.Clustering", function () {
        //var pins = new Microsoft.Maps.EntityCollection();         
        var locations_list = locations;
        var cnt = locations_list.length;
        var pins = Microsoft.Maps.TestDataGenerator.getPushpins(cnt, map.getBounds());
       


        //var pins = new Microsoft.Maps.EntityCollection();
        for (var i in locations_list) {
            if (locations_list.hasOwnProperty(i)) {
                var coordinates = locations_list[i].coordinates;
                var coordinates = coordinates.split(',');
                var lat         = coordinates[0];
                var lng         = coordinates[1];             
            }
            var position  = new Microsoft.Maps.Location(lat,lng);
            var pin       = new Microsoft.Maps.Pushpin(position,{ icon: '/images/newicon.png',title:'dsfds'+locations_list[i]['id']});
            //var pin       = new Microsoft.Maps.Pushpin(position);

           

       

            // alert("#"+ locations_list[i]['id'] +" "+ locations_list[i]['company_name'] + " (" +locations_list[i]['city'] +", "+ locations_list[i]['country_name'] + ")");
              // var infobox = new Microsoft.Maps.Infobox(map.getCenter(),{title: 'Title', description:"#"+ locations_list[i]['id'] +" "+ locations_list[i]['company_name'] + " (" +locations_list[i]['city'] +", "+ locations_list[i]['country_name'] + ")"}); 

              // infobox.setHtmlContent('<div id="infoboxText" style="background-color:White; border-style:solid; border-width:medium; border-color:DarkOrange; min-height:40px; width: 150px; "><p id="infoboxDescription" style="position: absolute; top: 10px; left: 10px; width: 220px; ">'+locations_list[i]['id']+'</p></div>');
              
                
           //    alert(infobox.getTitle());
              /* Microsoft.Maps.Events.addHandler(pin, 'click', function (args)  {
                     
                        infobox.setMap(map);
                         console.log(pin);
                        infobox.setLocation(args.target.getLocation());
                        infobox.setHtmlContent('<div class="Infobox" style=""><a class="infobox-close" href="javascript:void(0)" style="display: none;">x</a><div class="infobox-body"><div class="infobox-title">Incident</div><div class="infobox-info">#528 FedEx (Manaus - AM, Brazil)     by Larissa Campos on 2014-11-18    Loss Value: $ '+locations_list[i]['value']+'</div><div class="infobox-actions" style="display: none;"><ul class="infobox-actions-list"><div></div></ul></div></div><div class="infobox-stalk" style=""></div></div><div id="InfoboxCustom"></div>');
                }); */
                  
             map.entities.push(pin);
            // pins.push(pin);

           if (locations_list[i]['incident_type']=='logistic') {
                 pin.metadata = {
                        title: 'Incident',
                        description: "#"+ locations_list[i]['id'] +" "+ locations_list[i]['company_name'] + " (" +locations_list[i]['city'] +", "+ locations_list[i]['country_name'] + ")"+
                                     "     by " + locations_list[i]['name'] +" on "+ locations_list[i]['date']+
                                     "    Loss Value: $ " + locations_list[i]['value']
                                    // +" <p style='font-size:11px;'><a style='text-decoration: underline;' target='_blank' href='/incidents/"+ locations_list[i]['id'] +"'>Go to incident</a></p>",
                        ,actions : { label: 'Handler2', eventHandler: function () {
                                alert('Handler2');
                            }
                        }   
                    };
                    
                    $( ".infobox-info").addClass( "Inc"+locations_list[i]['id']);
                    $( ".Inc"+locations_list[i]['id']).append( "<p>Test</p>" );
                  console.log($.parseHTML(pin.metadata.description));
            }
            else
            {
                 pin.metadata = {
                        title: 'Factory Incident',
                        description: "#"+ locations_list[i]['id'] +" "+ locations_list[i]['company_name'] + " (" +locations_list[i]['city'] +", "+ locations_list[i]['country_name'] + ")"+
                                     "     by " + locations_list[i]['name'] +" on "+ locations_list[i]['date']+
                                     "    Loss Value: $ " + locations_list[i]['value']
                                     //+" <p style='font-size:11px;'><a style='text-decoration: underline;' target='_blank' href='/factory/incidents/"+ locations_list[i]['id'] +"'>Go to incident</a></p>"
                    };
            }
           Microsoft.Maps.Events.addHandler(pin, 'click', pushpinClicked);   /**/

           
            
        }
        
       //Add an click event handler to the pushpin.
       
        // Adds all pins at once 
         clusterLayer = new Microsoft.Maps.ClusterLayer(pins, {
        //    clusteredPinCallback: createCustomClusteredPin,
            gridSize: 80

            });
            map.layers.insert(clusterLayer);
        });
    } 


   function pushpinClicked(e) {
        //Make sure the infobox has metadata to display.
        if (e.target.metadata) {
            //Set the infobox options with the metadata of the pushpin.
            infobox.setOptions({
                location: e.target.getLocation(),
                title: e.target.metadata.title,
                description: e.target.metadata.description,
                visible: true
            });
        }
    }
    function createCustomClusteredPin(cluster) {
       
        //Define variables for minimum cluster radius, and how wide the outline area of the circle should be.
        var minRadius = 12;
        var outlineWidth = 7;
        //Get the number of pushpins in the cluster
        var clusterSize = cluster.containedPushpins.length;
        //Calculate the radius of the cluster based on the number of pushpins in the cluster, using a logarithmic scale.
        var radius = Math.log(clusterSize) / Math.log(10) * 5 + minRadius;
        //Default cluster color is red.
        var fillColor = 'rgba(255, 40, 40, 0.5)';
        if (clusterSize < 10) {
            //Make the cluster green if there are less than 10 pushpins in it.
            fillColor = 'rgba(20, 180, 20, 0.5)';           
        } else if (clusterSize < 100) {
            //Make the cluster yellow if there are 10 to 99 pushpins in it.
            fillColor = 'rgba(255, 210, 40, 0.5)';
        }
        //Create an SVG string of two circles, one on top of the other, with the specified radius and color.
        var svg = ['<svg xmlns="http://www.w3.org/2000/svg" width="', (radius * 2), '" height="', (radius * 2), '">',
        '<circle cx="', radius, '" cy="', radius, '" r="', radius, '" fill="', fillColor, '"/>',
        '<circle cx="', radius, '" cy="', radius, '" r="', radius - outlineWidth, '" fill="', fillColor, '"/>',
        '</svg>'];
        //Customize the clustered pushpin using the generated SVG and anchor on its center.
        cluster.setOptions({
            icon: svg.join(''),
            anchor: new Microsoft.Maps.Point(radius, radius),
            textOffset: new Microsoft.Maps.Point(0, radius - 8) //Subtract 8 to compensate for height of text.
        });
    }   