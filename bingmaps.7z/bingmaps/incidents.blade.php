@extends('layouts.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                    @if(Session::has('message'))
                        <div class="bs-callout bs-callout-info">
                            <h4> {{ Session::get('message') }}</h4>
                        </div>
                    @endif
                <div class="col-lg-12">
					@if(Input::get('type') == 'chart')
                    <h1 class="page-header">
                    Incidents
                     @if(count(json_decode($incident_result)) != 0 )
                       {{ Form::open(['action' => 'StatisticsController@getExportXLS', 'method' => 'post', 'id' => 'stat_excel', 'name' => 'stat_excel']) }}
                            <input type="hidden" name="data_chart" id="data_chart" value="" />
                            <input type='hidden' name='data_json' id='data_json' value='{{$incident_result}}' />
                            <input type='hidden' name='data_type' id='data_type' value='' />
                            <div class="btn-group pull-right audit-btns" id="export_xls">
                                <button href="#" class="btn btn-primary" type="button">Export as XLS</button>
                            </div>
                          {{Form::close()}}
                       @endif
                    </h1>
					@endif
                </div>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->

            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default statistics-panel">
						@if(Input::get('type') == 'chart')
                        <div class="panel-heading">
                            <?php $Any = array(''=>'Any'); ?>
                            <!--<form class="form-inline" role="form" id="statistics_search"> -->
                            {{Form::open(['action'=>'StatisticsController@getIncidents','method'=>'get' ,'id'=>'statistics_search','class'=>'form-inline','role'=>'form'])}}
                            <div class="form-group-row">
                                {{ Form::select('statistics-switch', array('audits'=>'Audits','incidents'=>'Incidents'), 'incidents', ['class' => 'form-control', 'id' => 'statistics-switch']) }}
                                {{ Form::hidden('type', Input::get('type'), ['class' => 'form-control', 'id' => 'type']) }}
                            </div>
                            <div class="form-group-row">
                                @if(Input::get('type') != 'map')
                                <div class="form-group">
                                    {{ Form::select('incident_type', array('logistic'=>'Logistic','factory'=>'Factory'), Input::get('incident_type'), ['class' => 'form-control']) }}
                                </div>
                                @endif
                            </div>
                            <div class="form-group-row">
                                @if(Input::get('type') != 'map')
                                <div class="form-group">
                                    {{ Form::select('report', array('incidents'=>'Number of incidents','value'=>'Incident value'), Input::get('report'), ['class' => 'form-control']) }}
                                </div>
                                @endif
                            </div>
                            <div class="form-group-row">
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-filter"></i> Filters</span>
                                        {{ Form::select('filters[]', $filter_labels_chart,$filters, ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                    </div>
                                </div>
                            </div>

                             <div class="form-group-row">
                                <div class="form-group-row statistics-filter-control form-inline" id="Statistics_first_field">
                                </div>
                                <div class="form-group-row statistics-filter-control form-inline" id="Statistics_middle_field">
                                    <div class="form-group daterange-filter">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                             {{Form::text('daterange',Input::get('daterange'),['class'=>'form-control'])}}
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group-row statistics-filter-control form-inline" id="Statistics_second_field">
                                </div>
                            </div>
                            
                            <input type="hidden" value="{{$filters_sel}}" name="flt_sel" id="flt_sel" />
                             <input type="hidden" value="chart" name="seltype" id="seltype" />
                            {{Form::close()}}

                            <div class="form-group-row statistics-filter-control form-inline">
                            @if(Input::get('incident_type') != 'factory')
                                <div id="category-filter">
                                    <div class="form-group category-filter">
                                        <div class="input-group">
                                            <span class="input-group-addon">Severity</span>
                                            {{Form::select('category',array(''=>'Any','major'=>'Major','medium'=>'Medium','minor'=>'Minor'),Input::get('category'),['class'=>'form-control'])}}
                                        </div>
                                    </div>
                                </div>
                             @endif   
                                <div id="status-filter">
                                    <div class="form-group status-filter">
                                        <div class="input-group">
                                            <span class="input-group-addon">Status</span>
                                            {{Form::select('status',array(''=>'Any','0'=>'Open','1'=>'closed'),Input::get('status'),['class'=>'form-control'])}}
                                        </div>
                                    </div>
                                </div>
                                <div id="lsp-filter">
                                    <div class="form-group lsp-filter">
                                        <div class="input-group">
                                            <span class="input-group-addon">LSP</span>
                                            {{Form::select('lsp',$Any+$lsp_list,Input::get('lsp'),['class'=>'form-control'])}}
                                        </div>
                                    </div>
                                </div>
                                <div id="region-filter">
                                    <div class="form-group region-filter">
                                        <div class="input-group">
                                            <span class="input-group-addon">Region</span>
                                            {{Form::select('region',$Any+$region_list,Input::get('region'),['class'=>'form-control'])}}
                                        </div>
                                    </div>
                                </div>
                                <div id="country-filter">
                                    <div class="form-group country-filter">
                                        <div class="input-group">
                                            <span class="input-group-addon">Country</span>
                                            {{Form::select('country',$Any+$country_list,Input::get('country'),['class'=>'form-control'])}}
                                        </div>
                                    </div>
                                </div>
                                <div id="type_of_device-filter">
                                    <div class="form-group type_of_device-filter">
                                        <div class="input-group">
                                            <span class="input-group-addon">Type Of Device</span>
                                          {{ Form::select('type_of_device',array(''=>'Any','Phone'=>'Phone','Xbox'=>'Xbox','Keyboard'=>'Keyboard','Mouse'=>'Mouse','Proto Device'=>'Proto Device','Other'=>'Other'),Input::get('type_of_device'),['class'=>'form-control']) }}
                                        </div>
                                    </div>
                                </div>
                                <div id="monthrange-filter">
                                    <div class="form-group monthrange-filter" >
                                        <div class="input-group">
                                            <span class="input-group-addon">Start Range</span>
                                                            {{Form::select('start_month',$monthrangeOpt,Input::get('start_month'),['class'=>'form-control'])}}
                                            <span class="input-group-addon">End Range</span>
                                                            {{Form::select('end_month',$monthrangeOpt,Input::get('end_month'),['class'=>'form-control'])}}
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
						@endif
                        <div class="panel-body">
                        @if(Input::get('type') == 'map')
							<div id="map-wrapper">
								<div id="map_canvas" style="position: fixed; right: 0;height: 100%; width: 100%; background-color: grey; border: solid 0px #B3B3B3; margin-bottom: 10px;"></div>
									<div id="map-controls" class="col-md-3">
									   <div class="panel panel-default">
									   <div class="panel-heading">
										Incidents
									   </div>
									   <div class="panel-body">
											<?php $Any = array(''=>'Any'); ?>
											<!--<form class="form-inline" role="form" id="statistics_search"> -->
											{{Form::open(['action'=>'StatisticsController@getIncidents','method'=>'get' ,'id'=>'statistics_search','class'=>'form-inline','role'=>'form'])}}
											<div class="form-group-row">
												{{ Form::select('statistics-switch', array('incidents'=>'Incidents','audits'=>'Audits','suppliers' =>'Suppliers','sitemaster' =>'Sites'), 'incidents', ['class' => 'form-control', 'id' => 'statistics-switch']) }}
												{{ Form::hidden('type', Input::get('type'), ['class' => 'form-control', 'id' => 'type']) }}
											</div>
											<div class="form-group-row">
	                                			<div class="form-group">
	                                    			{{ Form::select('incident_type', array('logistic'=>'Logistic','factory'=>'Factory'), Input::get('incident_type'), ['class' => 'form-control']) }}
	                                			</div>
	                                		</div>
											<div class="form-group-row">
												@if(Input::get('type') != 'map')
												<div class="form-group">
													{{ Form::select('report', array('incidents'=>'Number of incidents','value'=>'Incident value'), Input::get('report'), ['class' => 'form-control']) }}
												</div>
												@endif
											</div>
											<div class="form-group-row">
												<div class="form-group">
													<div class="input-group">
														<span class="input-group-addon"><i class="fa fa-filter"></i> Filters</span>
														{{ Form::select('filters[]', $filter_labels_map,Input::get('filters'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
													</div>
												</div>
											</div>
                                            <div class="form-group-row">
                                                <div class="form-group-row statistics-filter-control form-inline" id="Statistics_first_field">
                                                </div>
                                                <div class="form-group-row statistics-filter-control form-inline" id="Statistics_middle_field">
                                                    <div class="form-group daterange-filter">
                                                        <div class="input-group">
                                                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                                             {{Form::text('daterange',Input::get('daterange'),['class'=>'form-control'])}}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group-row statistics-filter-control form-inline" id="Statistics_second_field">
                                                </div>
                                            </div>
											<input type="hidden" value="{{$filters_sel}}" name="flt_sel" id="flt_sel" />
                                            <input type="hidden" value="map" name="seltype" id="seltype" />
											{{Form::close()}}
                                            <div class="form-group-row statistics-filter-control form-inline">
                                                <div id="category-filter">
                                                    <div class="form-group category-filter">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">Severity</span>
                                                            {{Form::select('category',array(''=>'Any','major'=>'Major','medium'=>'Medium','minor'=>'Minor'),Input::get('category'),['class'=>'form-control'])}}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="status-filter">
                                                    <div class="form-group status-filter">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">Status</span>
                                                            {{Form::select('status',array(''=>'Any','0'=>'Open','1'=>'closed'),Input::get('status'),['class'=>'form-control'])}}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="lsp-filter">
                                                    <div class="form-group lsp-filter">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">LSP</span>
                                                            {{Form::select('lsp',$Any+$lsp_list,Input::get('lsp'),['class'=>'form-control'])}}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="region-filter">
                                                    <div class="form-group region-filter">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">Region</span>
                                                            {{Form::select('region',$Any+$region_list,Input::get('region'),['class'=>'form-control'])}}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div id="type_of_device-filter">
                                                    <div class="form-group type_of_device-filter">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">Type Of Device</span>
                                                          {{ Form::select('type_of_device',array(''=>'Any','Phone'=>'Phone','Xbox'=>'Xbox','Keyboard'=>'Keyboard','Mouse'=>'Mouse','Proto Device'=>'Proto Device','Other'=>'Other'),Input::get('type_of_device'),['class'=>'form-control']) }}
                                                        </div>
                                                    </div>
                                               </div>
                                                <div id="country-filter">
                                                    <div class="form-group country-filter">
                                                        <div class="input-group">
                                                            <span class="input-group-addon">Country</span>
                                                            {{Form::select('country',$Any+$country_list,Input::get('country'),['class'=>'form-control'])}}
                                                        </div>
                                                    </div>
                                                </div>
                                                <!--<div id="monthrange-filter">
                                                    <div class="form-group monthrange-filter" >
                                                        <div class="input-group">
                                                            <span class="input-group-addon">Start Range</span>
                                                                            {{Form::select('start_month',$monthrangeOpt,Input::get('start_month'),['class'=>'form-control'])}}
                                                            <span class="input-group-addon">End Range</span>
                                                                            {{Form::select('end_month',$monthrangeOpt,Input::get('end_month'),['class'=>'form-control'])}}
                                                        </div>
                                                    </div>
                                                </div>-->
                                            </div>
									   </div>
									   </div>
									</div>
							</div>
						<!--	<div class="statistics-map-legend">
								<ul>
									<li><span class="map-legend-minor"></span> minor</li>
									<li><span class="map-legend-medium"></span> medium</li>
									<li><span class="map-legend-major"></span> major</li>
								</ul>
							</div>-->
                        @else
                            <!--<div id="statistics-incidents-chart"></div>-->

                             <div class="panel-body">       
                              <div class="statistics-incidents-chartdiv">                
                                    <canvas id="statistics-incidents-chart"></canvas>
                              </div>
                            </div>
                        @endif

                        </div>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
            <!-- /.row -->

            <canvas id='drawingArea' style="display:hidden;"></canvas>
</div>

<!-- /#page-wrapper -->
 <script type="text/javascript" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
{{ HTML::script('https://code.jquery.com/jquery-1.11.1.min.js') }}
<script type="text/javascript">
    var Statistics = {};
        Statistics.incident_report = JSON.parse('{{$incident_result}}');
        Statistics.incidentYaxis = JSON.parse('{{$incidentYaxis}}');
        Statistics.incidentlabel = JSON.parse('{{$incidentYaxis}}');
        Statistics.incidentXaxis = '{{$incidentXaxis}}';
        Statistics.plottype      = 'chart';
        Statistics.reportdis     = "{{Input::get('report')}}";
        Statistics.incidentChartJSXaxais = JSON.parse('{{$chartjsXaxis}}');
        Statistics.incidentChartJSYaxais = JSON.parse('{{$chartjsYaxis}}');
        Statistics.incidentfltSel ="{{$filters_sel}}";
</script>
@if(Input::get('type') == 'map')
{{ HTML::script('//js.api.here.com/ee/2.5.4/jsl.js?with=all') }}
{{ HTML::script('js/maps/bing_cluster.js') }}
<script type="text/javascript">
  var coordinates = {{$mapresults}};
  Statistics.plottype      = 'map';
  showIncidentMapLocationsByAddresses(coordinates,'map_canvas');
  
</script>
@endif

@if(Input::get('type') == 'map')
<style type="text/css">
    
	 #page-wrapper {
        padding : 0px 15px !important;
        min-height :100% !important;
        height: auto !important;
    }
    #wrapper {
       min-height :100% !important;
       height: auto !important;
    }
    #map_canvas{
       /*height: 830px !important;*/
    }
    footer{
        background :none repeat scroll 0 0 rgba(0, 0, 0, 0.4) !important;
        position:relative;
        padding: 0 15px 5px !important;
    }
    .footer-wrap {
        position: absolute;
        bottom: 0px;
    }
    .container p {
        margin: 0px !important;
    }
    .container .footer-links {
        padding-bottom: 0px !important;
    }
    .footer-links a {
        color :#001b51 !important;
    }
</style>
@endif
<script type="text/javascript">
            

</script>
@stop
