if (typeof Microsoft != 'undefined'){
  
}
/**
 * Statistics Map plotting for Incidents
 *
 **/ 
var map = null;
var greenLayer; 
function showIncidentMapLocationsByAddresses(locations, mapElementId) { 
    map = new Microsoft.Maps.Map(document.getElementById('map_canvas'), {
        credentials: 'AgbUnrKEhOfs69x9OljXuzMN-nmEShW3rL2cP7kx4SaR-o02zvmlEOkbivQKlaK2',
        mapTypeId:Microsoft.Maps.MapTypeId.road,
        showMapTypeSelector: false,
        enableSearchLogo:false,
        showScalebar:false,
        zoom:2  ,
        enableClickableLogo:false,
        showCopyright:false
    });  
    Microsoft.Maps.registerModule('clusterModule', 'https://www.bingmapsportal.com/scripts/V7ClientSideClustering.js');        
    Microsoft.Maps.loadModule('clusterModule', { callback: customModuleLoaded });           
} 
function customModuleLoaded(){    
    var DataGenerator = new function (){                   
        this.generateData = function (numPoints, callback) {          
        var data = [{"id":"258","rid":"5","company_name":"Primetime Express","cid":"31","country_name":"India","coordinates":"24.877716,92.789154","name":"Naba Kumar Chakraborty","userid":"217","date":"2012-08-07","value":"276.55","incident_date":"2012-08-07 00:00:00.000","category":"minor","description":"","city":"Guwahati","incident_type":"logistic"},{"id":"1","rid":"2","company_name":"DHL","cid":"5","country_name":"France","coordinates":"48.824441,2.618330","name":"Ron Vannimwegen","userid":"34","date":"2012-11-09","value":"3291.77","incident_date":"2012-11-09 00:00:00.000","category":"minor","description":"","city":"Paris","incident_type":"logistic"},{"id":"5","rid":"4","company_name":"Agility","cid":"7","country_name":"Saudi Arabia","coordinates":"24.975710,46.69378","name":"Patrik Hofer","userid":"10","date":"2012-12-23","value":"102.98","incident_date":"2012-12-23 00:00:00.000","category":"minor","description":"","city":"Riyadh","incident_type":"logistic"},{"id":"243","rid":"5","company_name":"DTDC India","cid":"28","country_name":"India","coordinates":"30.816609,75.171754","name":"Shweta Agnihotri","userid":"215","date":"2012-12-24","value":"157.68","incident_date":"2012-12-24 00:00:00.000","category":"minor","description":"","city":"Moga","incident_type":"logistic"},{"id":"240","rid":"5","company_name":"DTDC India","cid":"28","country_name":"India","coordinates":"23.049091,72.566357","name":"Shweta Agnihotri","userid":"215","date":"2013-01-01","value":"86.48","incident_date":"2013-01-01 00:00:00.000","category":"minor","description":"","city":"BARODA","incident_type":"logistic"},{"id":"13","rid":"3","company_name":"TNT","cid":"6","country_name":"Brazil","coordinates":"-16.6799,-49.255","name":"Luis Calixto","userid":"182","date":"2013-01-03","value":"548.53","incident_date":"2013-01-03 00:00:00.000","category":"minor","description":"","city":"Goiania","incident_type":"logistic"},{"id":"15","rid":"3","company_name":"TNT","cid":"6","country_name":"Brazil","coordinates":"-3.10719,-60.0261","name":"Luis Calixto","userid":"182","date":"2013-01-03","value":"1806.01","incident_date":"2013-01-03 00:00:00.000","category":"minor","description":"","city":"Manaus","incident_type":"logistic"},{"id":"11","rid":"3","company_name":"TNT","cid":"6","country_name":"Brazil","coordinates":"-9.66625,-35.7351","name":"Luis Calixto","userid":"182","date":"2013-01-10","value":"2852.85","incident_date":"2013-01-10 00:00:00.000","category":"minor","description":"","city":"Maceio","incident_type":"logistic"},{"id":"241","rid":"5","company_name":"DTDC India","cid":"28","country_name":"India","coordinates":"32.265217,75.642042","name":"Shweta Agnihotri","userid":"215","date":"2013-01-10","value":"271.04","incident_date":"2013-01-10 00:00:00.000","category":"minor","description":"","city":"PATHANKOT","incident_type":"logistic"},{"id":"12","rid":"3","company_name":"TNT","cid":"6","country_name":"Brazil","coordinates":"-30.0375,-51.220278","name":"Luis Calixto","userid":"182","date":"2013-01-15","value":"82.89","incident_date":"2013-01-15 00:00:00.000","category":"minor","description":"","city":"Porto Alegre","incident_type":"logistic"},{"id":"238","rid":"5","company_name":"DTDC India","cid":"28","country_name":"India","coordinates":"26.912274,75.78701","name":"Shweta Agnihotri","userid":"215","date":"2013-01-16","value":"104.41","incident_date":"2013-01-16 00:00:00.000","category":"minor","description":"","city":"JAIPUR","incident_type":"logistic"},{"id":"2","rid":"5","company_name":"DHL","cid":"5","country_name":"Malaysia","coordinates":"2.75474,101.70582","name":"Suraidah Rajab","userid":"19","date":"2013-01-17","value":"401.32","incident_date":"2013-01-17 00:00:00.000","category":"minor","description":"","city":"KLIA","incident_type":"logistic"},{"id":"3","rid":"2","company_name":"TNT","cid":"6","country_name":"United Kingdom","coordinates":"52.276994,-0.835798","name":"Darragh O Mahony","userid":"35","date":"2013-01-18","value":"1.33","incident_date":"2013-01-18 00:00:00.000","category":"minor","description":"","city":"Northampton","incident_type":"logistic"},   {"id":"271","rid":"5","company_name":"Primetime Express","cid":"31","country_name":"India","coordinates":"23.843138,91.282654","name":"Naba Kumar Chakraborty","userid":"217","date":"2013-01-18","value":"202.80","incident_date":"2013-01-18 00:00:00.000","category":"minor","description":"","city":"AGARTALA","incident_type":"logistic"},{"id":"14","rid":"3","company_name":"TNT","cid":"6","country_name":"Brazil","coordinates":"-8.0675,-34.916667","name":"Luis Calixto","userid":"182","date":"2013-01-24","value":"18339.49","incident_date":"2013-01-24 00:00:00.000","category":"minor","description":"","city":"Recife","incident_type":"logistic"},{"id":"4","rid":"4","company_name":"Agility","cid":"7","country_name":"Saudi Arabia","coordinates":"24.975710,46.693783","name":"Patrik Hofer","userid":"10","date":"2013-01-28","value":"55.96","incident_date":"2013-01-28 00:00:00.000","category":"minor","description":"","city":"Ryiadh","incident_type":"logistic"},{"id":"6","rid":"3","company_name":"DHL","cid":"5","country_name":"United States","coordinates":"32.714384,-117.113210","name":"Minna Fagerstrom","userid":"179","date":"2013-01-29","value":"659.30","incident_date":"2013-01-29 00:00:00.000","category":"minor","description":"","city":"San Diego","incident_type":"logistic"},{"id":"82","rid":"2","company_name":"Schenker","cid":"1","country_name":"Russia","coordinates":"55.33028,37.524116","name":"Barbara Unger","userid":"178","date":"2013-02-01","value":"298.63","incident_date":"2013-02-01 00:00:00.000","category":"minor","description":"","city":"Lvovskiy","incident_type":"logistic"},{"id":"83","rid":"2","company_name":"Schenker","cid":"1","country_name":"Russia","coordinates":"55.33028,37.524116","name":"Barbara Unger","userid":"178","date":"2013-02-06","value":"167.69","incident_date":"2013-02-06 00:00:00.000","category":"minor","description":"","city":"Lvovskiy","incident_type":"logistic"},{"id":"84","rid":"2","company_name":"Schenker","cid":"1","country_name":"Russia","coordinates":"55.33028,37.524116","name":"Barbara Unger","userid":"178","date":"2013-02-07","value":"436.82","incident_date":"2013-02-07 00:00:00.000","category":"minor","description":"","city":"Lvovskiy","incident_type":"logistic"}];
            var exampleDataModel = function (latitude, longitude,name) {                        
                this.Latitude  = latitude;
                this.Longitude = longitude;
                this.Name      = name;
            };
            //var data = locations;
            var cnt  = data.length;                        
            for (var key in data) {          
                var coordinates      = data[key].coordinates;
                var coordinates      = coordinates.split(',');
                var randomLatitude   = coordinates[0];
                var randomLongitude  = coordinates[1];                     
                //var name             = data[key].name+','+data[key].id+','+data[key].company_name+','+data[key].city+','+data[key].country_name+','+data[key].incident_date+','+data[key].value;
                 var name = "<div style='background-color: rgb(0, 15, 26);width: 250px;height:81px; word-wrap: break-word; word-break: break-all; white-space:normal;'>"+
                "<h3 style='color:#fff;font-size:11px;'>"+
                "#"+ data[key].id +" "+ data[key].company_name + " (" +data[key].city +", "+ data[key].country_name + ")" +
                "</h3>"+
                "<h4 style='color:#fff;font-size:11px;font-style:italics;'>"+
                "by " + data[key].name +" on "+ data[key].date +
                "</h4>"+
                "<h4 style='color:#fff;font-size:11px;'>"+
                "Loss Value: &#36; " + data[key].value +
                "</h4>";
                if (data[key].incident_type=='logistic') {
                    name += "<p style='font-size:11px;'><a style='text-decoration: underline;' target='_blank' href='/incidents/"+ data[key].id +"'>Go to incident</a></p></div>";
                } else {
                    name += "<p style='font-size:11px;'><a style='text-decoration: underline;' target='_blank' href='/factory/incidents/"+ data[key].id +"'>Go to factory incident</a></p></div>";
                } 
                data.push(new exampleDataModel(randomLatitude, randomLongitude,name));              
            }       
            if (callback) {
                callback(data);
            }
        };
    }
    greenLayer = new ClusteredEntityCollection(map, {
        singlePinCallback: createPin,
        clusteredPinCallback: createClusteredPin
    });
    DataGenerator.generateData(200,requestGreenDataCallback);
}
function createPin(data) { 
    console.log(data.Name); 
    var pin      = new Microsoft.Maps.Pushpin(data._LatLong);
    pin.description = data.Name;
    Microsoft.Maps.Events.addHandler(pin, 'click', displayInfo);  
    //}         
    return pin;
} 
function createClusteredPin(cluster, latlong){
    var count = cluster.length;        
    var pushpinOptions = {width: null, height: null, htmlContent: "<div style='border-radius: 50%; width: 30px;height: 30px;background:#58D68D;opacity:0.7;text-align:center; border: 1px solid #CCCCCC;padding:5px;color:#FFFFFF;font-weight:bold;'>"+count+"</div>",visible: true};
    var pin = new Microsoft.Maps.Pushpin(latlong,pushpinOptions);
    return pin;
}       
function requestGreenDataCallback(response){
    if (response != null) {
        greenLayer.SetData(response);
    }
}   
function displayInfo(e) {           
    if (e.targetType == "pushpin") {
        showInfobox(e.target);
    }
}
function showInfobox(shape) {   
    for(var i = map.entities.getLength() - 1; i >= 0; i--) {
        var pushpin = map.entities.get(i);
        if (pushpin.toString() == '[Infobox]'){
            map.entities.removeAt(i);
        };
    }
    var infoboxOptions = {
            offset: new Microsoft.Maps.Point(10, 0), showPointer: true, title: shape.title,
            htmlContent:'<div class="nm_infoBubble nm_alignRightBelow" aria-hidden="false" role="tooltip"><div class="nm_bubble"><div class="nm_bubble_bg nm_contentBG" style="background-color: rgb(0, 15, 26);"></div><div class="nm_bubble_controls"></div><div class="nm_bubble_content">'+shape.description+'</div><div class="nm_bubble_linksbar"></div><div class="nm_bubble_tail" style="left: -8px; right: auto; top: -8px; bottom: auto;"><img src="http://scss_r2.localhost/images/arrow.png"></div></div></div>'
            };
    //var infoboxOptions = { width: 170, height: 80, showCloseButton: true, zIndex: 10, offset: new Microsoft.Maps.Point(10, 0), showPointer: true, title: shape.title, description: shape.description 
    
    var defInfobox = new Microsoft.Maps.Infobox(shape.getLocation(), infoboxOptions);
    map.entities.push(defInfobox);
}
$('span.nm_bubble_control_close').click(function() {
    alert('Am here');
    return false;
    window.close();    
});

