	/**
 * Common utilities and helper functions
 */
var MsLstUtils = {
    formatDateAsMonthYear: function (date) {
        var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        return months[date.getMonth()] + " " + date.getFullYear();
    },
   formatCharJSDateAsMonthYear: function (data) {
        var dateObj = new Date(data);
        var months  = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        return months[dateObj.getMonth()] + " " + dateObj.getFullYear();
     },
    createCoordinatePicker: function (input, validate, map) {
        if (typeof nokia == 'undefined') return;

        var createMovementSelector = function (map, input) {
            var current_value = $('#' + input).val();
            var coord = undefined;
            if (isCoordinate(current_value)) {
                coord = getCoordinate(current_value);
            }
            var items = showNokiaGPSCoordinateSelector(map, input, coord);

            var mapi = items[0];
            var marker = items[1];
            $('#' + validate).on('click', function () {
              var coord_value = $('#' + input).val();
              if (checkCoordFormat(coord_value)) {
                checkCoordMovement(showNokiaMapMoveCoordinate(mapi, marker, '#' + input));
              }
              else {
                checkCoordMovement(false);
              }
            });
        };

        createMovementSelector(map, input);
    },
    createBingCoordinatePicker: function(input, validate, map) {
      
        if (typeof Microsoft == 'undefined') return;

        var createMovementSelector = function (map, input) {
            var current_value = $('#' + input).val();
            var coord = undefined;
            if (isCoordinate(current_value)) {
                coord = getCoordinate(current_value);
            }

            var items = showBingGPSCoordinateSelector(map, input, coord); 
            var mapi =  items[0];
            var marker = items[1];
           
            $('#' + validate).on('click', function () {
              var coord_value = $('#' + input).val();
              if (checkCoordFormat(coord_value)) {
                 checkCoordMovement(showBingMapMoveCoordinate(mapi, marker, '#' + input));
              }
              else {
                checkCoordMovement(false);
              }
            });  
            if(current_value != '')  $('#' + validate).trigger('click');
        };

        createMovementSelector(map, input);
    },
    createDateRangePicker: function (targetElm, maxDate, callback, format) {
        maxDate = maxDate || new Date();
        callback = callback || function (start, end, label) {};
        format = format || 'YYYY-MM-DD';
        targetElm.daterangepicker({
            format: format,
            maxDate: moment().add(1, 'days'),
            showDropdowns: true,
            showWeekNumbers: true
        },
        callback);
    },
    createSingleDatePicker: function(targetElm, maxDate ,startDate ) {
        maxDate = maxDate || new Date();
        startDate = new Date();
      //  else  startDate = '2012-01-01';

        targetElm.daterangepicker({
          format: 'YYYY-MM-DD',
          maxDate: maxDate,
          singleDatePicker: true,
          startDate: startDate
        });
    },
    createTimePicker: function(targetElm) {
        targetElm.timepicker();
    },
    createSelect2s: function(targetElms) {
        $.each(targetElms, function () {
            options = this.options || {};
            this.element.select2(options);
        });
    },
    resetSelect2s: function(targetElms) {
        $.each(targetElms, function () {
            this.select2('data', null);
        });
    },
    createBootstrapSwicth: function(targetElm, options) {
        targetElm.bootstrapSwitch(options);
    },
    createSummerNote: function(targetElm, options) {
        targetElm.summernote(options);
    },
    createDataTable: function (targetElm, name, disable, order, menu, length,sdm,columnwidth) {
        order = order || [[ 5, "desc" ]];
        menu = menu || [[15, 50, 100, -1], [15, 50, 100, "All"]];
        length = length || 15;
        disable = disable || false;
        columnwidth = columnwidth || false;
        tableSetting = {
        "order": order,
        "destroy":true,
        "aLengthMenu": menu,
        "iDisplayLength ": length,
        "sDom": "rftip",
          "oLanguage": {
              "sSearch": "<span>Search: </span> _INPUT_",
              "sEmptyTable": "No "+ name +" are available.",
              "sInfoEmpty": "No "+ name +" to list.",
              "sInfo": " Showing _START_ to _END_ of _TOTAL_ "+ name
            }
        };
        if (disable) {
            tableSetting["aoColumnDefs"] = [{ "bSortable": false, "aTargets": disable }];
        }
        if(columnwidth) {
          tableSetting["columnDefs"] = [{ "width": '2%', "targets": 8 }];
        }

        targetElm.dataTable(tableSetting);
    },
    createAreaChart: function (targetElm, data, xKey, xLabels, yKeys, yLabels, xLabelFormat, yLabelFormat) {
        var chartParams = {
            element: targetElm,
            data: data,
            xkey: xKey,
            xLabels: xLabels,
            ykeys: yKeys,
            labels: yLabels,
            pointSize: 2,
            hideHover: 'auto',
            resize: true
        };

        if (xLabelFormat) {
            chartParams.xLabelFormat = xLabelFormat;
        }
        if (yLabelFormat) {
            chartParams.yLabelFormat = yLabelFormat;
        }

        Morris.Area(chartParams);
    },
    createLineChart: function (targetElm, data, xKey, xLabels, yKeys, yLabels, xLabelFormat, yLabelFormat) {
        var chartParams = {
            element: targetElm,
            data: data,
            xkey: xKey,
            xLabels: xLabels,
            ykeys: yKeys,
            labels: yLabels,
            pointSize: 2,
            hideHover: 'auto',
            resize: true,
            smooth : false,
            lineColors : ['#0b62a4', '#006600']
        };

        if (xLabelFormat) {
            chartParams.xLabelFormat = xLabelFormat;
        }
        if (yLabelFormat) {
            chartParams.yLabelFormat = yLabelFormat;
        }
        
        Morris.Line(chartParams);
    },
    createChartJsLineChart : function(targetelm,type,label,data,dataOne){

            var labelobj  = label;
            var labelchg  = [];
            for(var i=0;i<labelobj.length;i++){
                    labelchg[i] =  MsLstUtils.formatCharJSDateAsMonthYear(labelobj[i]);
            }

            var ctx = document.getElementById(targetelm).getContext("2d");
            var data = {
                        labels: labelchg,
                        datasets: [
                            {
                               label: type[0],
                               fillColor: "rgba(151,187,205,0.5)",
                               strokeColor: "rgba(103, 157, 198, 1)",
                               pointColor:  "rgba(103, 157, 198, 0.8)",
                               pointStrokeColor: "#fff",
                               pointHighlightFill: "#fff",
                               pointHighlightStroke: "rgba(220,220,220,1)",
                               data: data
                            },
                           {
                             label: type[1],
                             fillColor: "rgba(151,187,205,0.5)",
                             strokeColor: "rgba(0, 102, 0, 0.8)",
                             pointColor:  "rgba(0, 103, 0, 0.8)",
                             pointStrokeColor: "#fff",
                             pointHighlightFill: "#fff",
                             pointHighlightStroke: "rgba(220,220,220,1)",
                             data: dataOne
                           }
                          ]
                        };


            var myLineChart = new Chart(ctx).Line(data, {
                responsive : true,
                bezierCurve : false,
                multiTooltipTemplate: function(valuesObject){
                                      var xtoolval ;
                                      if(type[1] == 'Value: $')
                                        xtoolval = MsLstUtils.formatNumber(valuesObject.value);
                                      else
                                        xtoolval = valuesObject.value;

                                        return valuesObject.datasetLabel+' '+xtoolval;
                                    },
                datasetFill : false,
                scaleGridLineColor : "rgba(10,10,10,.08)",
                scaleGridLineWidth      : 1,
                scaleFontFamily: "segoe_ui",
                scaleFontSize: 12,
                scaleFontStyle: "normal",
            });
           /*  var canv = document.getElementById(targetelm);
             canv.width = '300';
             canv.height = '300';*/
     },
    createChartJsAreaChart : function(targetelm,type,label,data,dataOne){

            var labelobj  = label;
            var labelchg  = [];
            for(var i=0;i<labelobj.length;i++){
                    labelchg[i] =  MsLstUtils.formatCharJSDateAsMonthYear(labelobj[i]);
            }

            var ctx = document.getElementById(targetelm).getContext("2d");
            var data = {
                        labels: labelchg,
                        datasets: [
                            {
                               label: type[0],
                               fillColor: "rgba(151,187,205,0.5)",
                               strokeColor: "rgba(103, 157, 198, 0.8)",
                               pointColor:  "rgba(103, 157, 198, 0.8)",
                               pointStrokeColor: "#fff",
                               pointHighlightFill: "#fff",
                               pointHighlightStroke: "rgba(220,220,220,1)",
                               data: data
                            },
                           {
                             label: type[1],
                             fillColor: "rgba(93,196,91,0.5)",
                             strokeColor: "rgba(93,196,91, 0.8)",
                             pointColor:  "rgba(0, 103, 0, 0.8)",
                             pointStrokeColor: "#fff",
                             pointHighlightFill: "#fff",
                             pointHighlightStroke: "rgba(220,220,220,1)",
                             data: dataOne
                           }
                          ]
                        };

            var myLineChart = new Chart(ctx).Line(data, {
                responsive : true,
                bezierCurve : false,
                multiTooltipTemplate: function(valuesObject){
                                      var xtoolval ;
                                      if(type[1] == 'Value: $')
                                        xtoolval = MsLstUtils.formatNumber(valuesObject.value);
                                      else
                                        xtoolval = valuesObject.value;

                                        return valuesObject.datasetLabel+' '+xtoolval;
                                    },
                datasetFill : true,
                scaleGridLineColor : "rgba(10,10,10,.08)",
                scaleGridLineWidth      : 1
            });
    },
    createChartJsBarChart : function(targetelm,type,label,data,dataOne){

             var labelobj  = label;
             var labelchg  = [];
             for(var i=0;i<labelobj.length;i++){
                    labelchg[i] =  MsLstUtils.formatCharJSDateAsMonthYear(labelobj[i]);
             }

            var ctx = document.getElementById(targetelm).getContext("2d");
            var data = {
                            labels: labelchg,
                            datasets: [
                                {
                                   label: type[0],
                                   fillColor: "#0B62A4",
                                   strokeColor: "#0B62A4",
                                   pointColor:  "#0B62A4",
                                   pointStrokeColor: "#fff",
                                   pointHighlightFill: "#fff",
                                   pointHighlightStroke: "rgba(220,220,220,1)",
                                   data: data
                                }
                              ]
                            };
            if(dataOne){
                   data.datasets[1] = {
                                 label: type[1],
                                 fillColor: "rgba(93,196,91,0.5)",   
                                 strokeColor: "rgba(93,196,91, 0.8)",
                                 pointColor:  "rgba(0, 103, 0, 0.8)",
                                 pointStrokeColor: "#fff",
                                 pointHighlightFill: "#fff",
                                 pointHighlightStroke: "rgba(220,220,220,1)",
                                 data: dataOne
                               };
            }

            var myLineChart = new Chart(ctx).Bar(data, {
                    responsive : true,
                    bezierCurve : false,
                    showTooltip: true,
                    multiTooltipTemplate: function(valuesObject){
                                      var xtoolval ;
                                      if(type[1] == 'Value: $')
                                        xtoolval = MsLstUtils.formatNumber(valuesObject.value);
                                      else
                                        xtoolval = valuesObject.value;

                                            return valuesObject.datasetLabel+' '+xtoolval;
                                        },
                    tooltipTemplate : function(valuesObject) {
                                      var xtoolval ;
                                      if(type[1] == 'Value: $')
                                        xtoolval = MsLstUtils.formatNumber(valuesObject.value);
                                      else
                                        xtoolval = valuesObject.value;

                                            return valuesObject.label+' - '+valuesObject.datasetLabel+' '+xtoolval;
                                        },
                    scaleGridLineColor : "rgba(10,10,10,.08)",
                    scaleGridLineWidth      : 1
            });
    },
    randomColorFactor : function(){ 
      return "#"+((1<<24)*Math.random()|0).toString(16);
    },
    formatNumber: function(digitval){
        var results;

        if(digitval != 0)
         results = new RegExp(digitval.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,")).toString().replace(/\//g,'');
        else
          results = digitval;

         return results;  
    },
    createStatisticsChartJsBarChart : function(targetelm,yaxis,xaxis,tooltipval){
  //    MsLstUtils.RemoveCanvasElement(targetelm);
      //console.log(targetelm+"####"+yaxis+"####"+xaxis);
        var labels  = [];
        var si=0,sm;
        var sj=0;
       var color = {0:'#428BCA',1:'#C296B6',2:'#ffce49',3:'#E23D80',4:'#00FF00',5:'#d82b25',6:'#073ca5',7:'#728CB0',8:'#99CC66',9:'#2ca29f',10:'#a97c7a',11:'#d3edce',12:'#b8dbd3',13:'#b1b2ec',14:'#f0a6a6',15:'b9a3cc',16:'#64af9c',17:'#ddb365',18:'#e3dbad',19:'#31b4b1',20:'#eb9592',21:'#115a9d',22:'#496076',23:'#936269',24:'#adbad5',25:'#ffb56f'};
      for(var sx in xaxis){
            labels[si] = xaxis[sx];
      }
 
      var ctx = document.getElementById(targetelm).getContext("2d");
      var data = {
                    labels: xaxis,
                    datasets: []
                  };


    for(var sy in yaxis){
            var values = [];
            sm=0;
            
         for(var yval in yaxis[sy]){
                 values[sm] = yaxis[sy][yval];

                 sm++;
            }
               data.datasets[sj] = {
                            label: sy,
                            fillColor: color[sj],
                            strokeColor: color[sj],
                            data: values
               };
          sj++;
      }

      //console.log(data);

            var myLineChart = new Chart(ctx).Bar(data, {
                    responsive : true,
                    bezierCurve : false,
                    maintainAspectRatio : false,
                    showTooltip: true,
                    multiTooltipTemplate: function(valuesObject){
                                         // console.log(valuesObject);
                                      var xtoolval ;
                                     if(tooltipval == 'value')
                                        xtoolval = "$"+ MsLstUtils.formatNumber(valuesObject.value);
                                      else
                                        xtoolval = valuesObject.value;

                                            return valuesObject.datasetLabel+'   '+xtoolval;
                                        },
                    tooltipTemplate : function(valuesObject) {
                                      var xtoolval ;
                                    if(tooltipval == 'value')
                                        xtoolval = "$"+ MsLstUtils.formatNumber(valuesObject.value);
                                    else
                                        xtoolval = valuesObject.value;

                                            return valuesObject.datasetLabel+'   '+xtoolval;
                                        },
                    scaleGridLineColor : "rgba(10,10,10,.08)"
            });
    },
    createStatisticsChartJsEmptyChart : function(targetelm){
            var ctx = document.getElementById(targetelm).getContext("2d");
            var data = {
                  labels: ["", "", "", "", "", "", "", "", "", "", "", ""],
                  datasets: [
                    {
                        label: "Empty:",
                        fillColor: "rgba(151,187,205,0.5)",
                        strokeColor: "#fff",
                        pointColor:  "rgba(100,100,100,.5)",
                        pointStrokeColor: "rgba(100,100,100,.5)",
                        pointHighlightFill: "rgba(100,100,100,.5)",
                        pointHighlightStroke: "rgba(220,220,220,1)",
                        legendColors :'#ff000',
                        data: [5,10,15,20,25,30,35,40,45]
                    }
                  ]
              };

            var myBarChart = new Chart(ctx).Line(data, {
              responsive : true,
              bezierCurve : false,
              scaleGridLineColor : "rgba(100,100,100,.08)",
              datasetFill : false,
              datasetStroke : true,
              scaleShowLabels : false,
              pointDot : false,
              pointDotRadius : -1,
              showTooltips: false
            });
    },
    RemoveCanvasElement: function(targetelm){
                $('canvas#'+targetelm).remove();
                var canvas = document.createElement('canvas');
                canvas.id = targetelm;
                var mainDiv = document.getElementById(targetelm+"div");
                mainDiv.appendChild(canvas);
    },
    NameCapitalize:function(name){
       return name.charAt(0).toUpperCase() + name.slice(1);
    },
    createDonutChart: function (targetElm, data,select) {
        var chartParams = {
            element: targetElm,
            data: data,
            resize: true
        };
         var donut = Morris.Donut(chartParams);
         donut.select(select);
    },
    isCurrentPath: function (pattern) {
		if (window.window.location.pathname.indexOf('/') === 0) {
		  	return window.window.location.pathname.match(new RegExp("^\/" + pattern));
        }
        else {
            return window.window.location.pathname.match(new RegExp("^" + pattern));
        }
    },
    createMapByCoordinates: function (coordinates, elementId) {
        var coords = coordinates.split(',');
        intializeMap(function () {
            showNokiaMapLocationByCoordinate(coords[0], coords[1], elementId);
        });
    },
    createBingMapByCoordinates:function (coordinates, elementId) {
   
       var coords = coordinates.split(',');
        intializeBingMap(function () {
            showBingMapLocationByCoordinate(coords[0], coords[1], elementId);
        });
    },
    createRouteByCoordinates: function (startCoordinates, endCoordinates, elementId) {
        intializeBingMap(function () {
            showBingMapRouteWrap(startCoordinates, endCoordinates, elementId);
            //showMapRouteWrap(startCoordinates, endCoordinates, elementId);
        });
    },
    applyCountryFilter: function (regions, regionElm, countryElm, initVal) {
        if (typeof regions != 'undefined') {
            regions = JSON.parse(regions);
            var selected = regionElm.val();

            selected_country = initVal || null;

            countryElm.find('option').remove();
            $.each(regions[selected], function (i) {
                if (selected_country && selected_country == regions[selected][i]['id']) {
                    country_option = $("<option></option>")
                                    .attr('value', regions[selected][i]['id'])
                                    .attr('selected', 'selected')
                                    .text(regions[selected][i]['text']);

                    countryElm.select2("data", { id: regions[selected][i]['id'], text: regions[selected][i]['text'] });
                }
                else {
                    country_option = $("<option></option>")
                                    .attr('value', regions[selected][i]['id'])
                                    .text(regions[selected][i]['text']);

                }
                countryElm.append(country_option);
            });
        }
    },
    setUpDeleteConfirmation: function (text, elementClass) {
        if (elementClass) {
            $(elementClass).each(function(){
                $(this).live('click', function (e) {
                    var $form = $(this).closest('form');
                    e.preventDefault();
                    bootbox.confirm(text, function(ok) {
                        if (ok) {
                            $form.trigger('submit');
                        }
                    });
                });
            });
        }
    },
    setUpReviewNotification: function (text, elementClass, messageField) {
        if (elementClass) {
            $(elementClass).each(function(){
                $(this).live('click', function (e) {
                    var $form = $(this).closest('form');
                    e.preventDefault();
                    var options = {
                        title: text,
                        inputType: 'textarea',
                        callback: function(input) {
                            if (input !== null) {
                                $(messageField).val(input);
                                $form.trigger('submit');
                            }
                        }
                    };

                    bootbox.prompt(options);
                });
            });
        }
    },
    UrlPrams: function(name){
        var results = new RegExp('[\?&amp;]' + name + '=([^&amp;#]*)').exec(window.location.href);
        return results[1] || 0;
    },
    createBarChart: function (targetElm, data, xKey, yKeys, Labels,axis) {
        var chartParams = {
            element: targetElm,
            data: data,
            xkey: xKey,
            ykeys: yKeys,
            axes : axis,
            pointSize: 3,
            hideHover: 'auto',
            resize: true,
            barSizeRatio:0.34
        };
		
		if(Labels != '') {
			chartParams.labels = Labels;
		}
		

        Morris.Bar(chartParams);
    },
    createDashboardBarChart: function (targetElm, data, xKey, yKeys, Labels,axis,hoveropt,barratio) {
        var chartParams = {
            element: targetElm,
            data: data,
            xkey: xKey,
            ykeys: yKeys,
            labels: Labels,
            axes : axis,
            pointSize: 3,
            hideHover: 'auto',
            resize: true,
            barSizeRatio: barratio,
            hoverCallback: function (index, options, content, row) {
               var data = options.data[index];
               var year = data.period.split("-");
               var months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
               if(hoveropt == 'incidents'){
                    $(".morris-hover").html('<div>' + months[Number(year[1])-Number(1)] +" "+ year[0] + '</div><div> Incidents :' + data.incidents + '</div>');
                }else if(hoveropt == 'audits'){
                    $(".morris-hover").html('<div>' + months[Number(year[1])-Number(1)] +" "+ year[0] + '</div><div> location :' + data.location + '</div> <div>route: '+ data.route +'</div>');
                 }
            }
        };

        Morris.Bar(chartParams);
    },
    getParam: function(name) {
        return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search)||[,""])[1].replace(/\+/g, '%20'))||null;
    },
    startSpin: function() {
        // Attach the spinner
        $('body').append('<div id="spinner-div"></div>');
        $('#spinner-div').css({position: 'fixed', top: '50%', left: '50%'});
        $('#spinner-div').spin();
    },
    stopSpin: function () {
        // Remove the spinner
        $('#spinner-div').spin(false);
        $('#spinner-div').remove();
    },
    getCollapse: function (){
          $('.collapse-link:not(.binded)').addClass("binded").click( function() {
                var ibox = $(this).closest('div.ibox');
                var button = $(this).find('i');
                var content = ibox.find('div.ibox-content');
                content.slideToggle(200);
                button.toggleClass('fa-chevron-up').toggleClass('fa-chevron-down');
                ibox.toggleClass('').toggleClass('border-bottom');
                setTimeout(function () {
                    ibox.resize();
                    ibox.find('[id^=map-]').resize();
                }, 50);
            });   

        }
};

/**
 * The global page elements setup
 */
var MsLstGlobal = {
    init: function () {
        MsLstGlobal.config = {
            sideMenu: $('#side-menu'),
            buttons: $('button'),
            sideBar: $('div.sidebar-collapse')
        };

        MsLstGlobal.setUp();
    },
    setUp: function () {
        MsLstGlobal.loadSideMenu();
        MsLstGlobal.buttonClickHrefHandle();
        MsLstGlobal.sideBarCollapse();
        MsLstGlobal.pageToolTips();
        MsLstGlobal.backButtons();
        MsLstGlobal.Summaryconfirm();
        MsLstGlobal.Footersetup();
    },
    loadSideMenu: function () {
        //MsLstGlobal.config.sideMenu.metisMenu();
        document.cookie = "lanelabelext="+parseInt($("#page-wrapper").innerWidth() / 10)+";365";
       /* $(".user_manual").on('click',function(){
          MsLstUtils.startSpin();
            $.post('/users/usermanual', function(data) {
                                                       bootbox.confirm(data,function(result){
                                                          
                                                        });
                                                    });
          MsLstUtils.stopSpin();
        });*/

        $('#nestable-menu').on('click', function (e) {
                 var target = $(e.target),
                         action = target.data('action');
                 if (action === 'expand-all') {
                     $('.dd').nestable('expandAll');
                 }
                 if (action === 'collapse-all') {
                     $('.dd').nestable('collapseAll');
                 }
             });
    },
    buttonClickHrefHandle: function () {
        MsLstGlobal.config.buttons.on('click', function () {
            var link = $(this).attr('href');
            if (link != undefined) {
                window.location.href = link;
            }
        });
    },
    sideBarCollapse: function () {
        $(window).bind("load resize", function() {
            if ($(this).width() < 768) {
                MsLstGlobal.config.sideBar.addClass('collapse')
            } else {
                MsLstGlobal.config.sideBar.removeClass('collapse')
            }
        });
    },
    pageToolTips: function() {
        $("body").tooltip({ selector: '[data-toggle=tooltip]' });
    },
    backButtons: function () {
        $('#btn-back').on('click', function (event) {
            window.history.go(-1);
            event.preventDefault();
        });
    },
    Summaryconfirm: function(){
        $("#summaryform").on('click',function(event){
             event.preventDefault();
              bootbox.confirm("Are you sure that the information is correct? If yes, then data will be saved.",function(ok){
                if(ok){
                    $("#form-summary").trigger("submit");
                }else{

                }
            });
        });
        $("#audit_cancel").click(function(event){
            bootbox.confirm("The audit will not be saved. Press OK to discard",function(ok){
                if(ok){
                    window.location.href = $("#audit_cancel").attr('alt');
                }
            });
            event.preventDefault();
        });
    },
    Footersetup: function(){
        var windHight = $(window).height();
     //   console.log($(document).height()+"###"+windHight+"##"+$(".incidents-panel").height());

        if($(document).height() > windHight ) {
          $(".footer-wrap").removeClass( "footer-bottom" );
        }else{
          $(".footer-wrap").addClass( "footer-bottom" );
        }

        $("#region_name,#country_name,#llsp_name").bind('keypress',function(e){
          var k = e.which;
          var ok = k >= 65 && k <= 90 || // A-Z
              k >= 97 && k <= 122; // a-z

              if (!ok){
                  e.preventDefault();
              }
        });
    }
};

/**
 * Handlers for audits create/edit and listing
 */
var MsLstAudits = {
    init: function (settings) {
        MsLstAudits.config = {
            locationForm: $('#location-form-details'),
            routeForm: $('#route-form-details'),
            auditList: $('#audits-list'),
            auditAnswerSelects: $('.audit-form-tabs select'),
            certificates: ['tapa', 'ctpat', 'aeo'],
            auditsFilterResetButton: $('#audit-filter-reset'),
            auditsList: $('#audits-list'),
            coordinates: null,
            startCoordinates: null,
            endCoordinates: null,
            mapElement: null
        };

        $.extend(MsLstAudits.config, settings);

        MsLstAudits.setUp();
    },
    setUp: function () {
        MsLstAudits.setUpLocationView();
        MsLstAudits.setUpRouteView();
        MsLstAudits.setUpAuditForms();
        MsLstAudits.setUpLocationAuditForms();
        MsLstAudits.setUpRouteAuditForms();
        MsLstAudits.setUpCertificationForms();
        MsLstAudits.setUpQuestionForm();
        MsLstAudits.setUpAuditsListing();
    },
    setUpLocationView: function () {
           // Coordinate picker for the location Summary/view
        if (MsLstAudits.config.coordinates && MsLstAudits.config.mapElement) {
            //MsLstUtils.createMapByCoordinates(MsLstAudits.config.coordinates, MsLstAudits.config.mapElement);
             MsLstUtils.createBingMapByCoordinates(MsLstAudits.config.coordinates, MsLstAudits.config.mapElement);
        }

        MsLstUtils.createSelect2s([
            {element: $('select[name="owners"]'), options: { placeholder: "Select Owners" }}
        ]);

        $('.locations select[name="owners"]').on('change', function () {
            var id = window.location.pathname.split("/")[2];
            MsLstUtils.startSpin();
            $.post('/locations/update-owners', {'id': id, 'owners': $(this).val()}, function () {
                MsLstUtils.stopSpin();
            });
        });

        MsLstUtils.setUpDeleteConfirmation("Are you sure you want to delete this location audit?", '.location-delete-button');
        MsLstUtils.setUpReviewNotification("Please add your comments below. They will be sent to the respective user.", '.location-review-button', 'input[name="review_message"]');
    },
    setUpRouteView: function () {
         // Coordinate picker for the location Summary/view
        if (MsLstAudits.config.startCoordinates && MsLstAudits.config.endCoordinates && MsLstAudits.config.mapElement) {
            MsLstUtils.createRouteByCoordinates(MsLstAudits.config.startCoordinates, MsLstAudits.config.endCoordinates, MsLstAudits.config.mapElement);
        }

        MsLstUtils.createSelect2s([
            {element: $('select[name="owners"]'), options: { placeholder: "Select Owners" }}
        ]);

        $('.routes select[name="owners"]').on('change', function () {
            var id = window.location.pathname.split("/")[2];
            MsLstUtils.startSpin();
            $.post('/routes/update-owners', {'id': id, 'owners': $(this).val()}, function () {
                MsLstUtils.stopSpin();
            });
        });

        MsLstUtils.setUpDeleteConfirmation("Are you sure you want to delete this route audit?", '.route-delete-button');
        MsLstUtils.setUpReviewNotification("Please enter your review message. This will be notified to the corresponding user.", '.route-review-button', 'input[name="review_message"]');
    },
    setUpAuditForms: function () {
        $('.certification-content').each(function () {
          $(this).find('.list-certification').each(function () {
            $(this).find('label').each(function () {
              var label = $(this);
              $(this).find('input').each(function () {
                if($(this).is(':checked')) {
                    label.addClass('active');
                    MsLstAudits.showHideCertificateUpload(this);
                }
                else {
                    label.removeClass('active');
                }
              });
            });
          });
        });

        $("#svi_num,#aeo_num").bind("keypress",function(e){
            var  k = e.which;
            var ok = k >= 65 && k <= 90 || // A-Z
            k >= 97 && k <= 122 || // a-z
            k >= 48 && k <= 57 || (k == 44 || k == 8 || k==0) ; // 0-9

            if (!ok){
                e.preventDefault();
            }
        });

         $("#svi_num,#aeo_num").bind("copy paste cut",function(e){   
                e.preventDefault();
        });


    },
    setUpLocationAuditForms: function () {
        MsLstUtils.createSelect2s([
            {element: $('select[name="country"]'), options: { placeholder: "Select Country" }}
        ]);

        // Coordinate picker for the location create/edit form
        if ($('#coordinates').length > 0) {
            //MsLstUtils.createCoordinatePicker('coordinates', 'location-coordinate-check', 'location-coordinate-pick');
            MsLstUtils.createBingCoordinatePicker('coordinates', 'location-coordinate-check', 'location-coordinate-pick');
        }
    },
    setUpRouteAuditForms: function () {
        MsLstUtils.createSelect2s([
            {element: $('select[name="start_country"]'), options: {placeholder: "Select Country"}},
            {element: $('select[name="end_country"]'), options: {placeholder: "Select Country"}}
        ]);

        // Coordinate picker for the from location in route create/edit
        if ($('#start_coordinates').length > 0) {
            //MsLstUtils.createCoordinatePicker('start_coordinates', 'route-start-coordinate-check', 'start-coordinate-pick');
            MsLstUtils.createBingCoordinatePicker('start_coordinates', 'route-start-coordinate-check', 'start-coordinate-pick');
        }

        // Coordinate picker for the to location in route create/edit
        if ($('#end_coordinates').length > 0) {
            //MsLstUtils.createCoordinatePicker('end_coordinates', 'route-end-coordinate-check', 'end-coordinate-pick');
            MsLstUtils.createBingCoordinatePicker('end_coordinates', 'route-end-coordinate-check', 'end-coordinate-pick');
        }
    },
    setUpCertificationForms: function () {
        for (i in MsLstAudits.config.certificates) {
            var cert = MsLstAudits.config.certificates[i];
            $('input[name="'+ cert +'"]').on('change', function () {
                MsLstAudits.showHideCertificateUpload(this);
            });
        }
    },
    showHideCertificateUpload: function (that) {
        if (parseInt(that.value) > 0) {
            $(that).parents().filter('.certification-content').parent().next().next().find('.certification-upload').show();
            $(that).parents().filter('.certification-content').parent().next().find('.certification-number').show();
        }
        else {
            $(that).parents().filter('.certification-content').parent().next().next().find('.certification-upload').hide();
            $(that).parents().filter('.certification-content').parent().next().find('.certification-number').hide();
        }
    },
    setUpQuestionForm: function () {
        MsLstAudits.config.auditAnswerSelects.select2({ placeholder: "Select Answer", dropdownCssClass: 'bigdrop' });

        var tapa_visible = $('#tapa-tab').is(':visible');
        var ctpat_visible = $('#ctpat-tab').is(':visible');
        var aeo_visible = $('#aeo-tab').is(':visible');
        if (ctpat_visible) {
            $('#tapa').removeClass('active');
            $('#tapa-tab').removeClass('active');
            $('#ctpat').addClass('active');
            $('#ctpat-tab').addClass('active');
        }
        else if (aeo_visible && !ctpat_visible) {
            $('#tapa').removeClass('active');
            $('#tapa-tab').removeClass('active');
            $('#aeo').addClass('active');
            $('#aeo-tab').addClass('active');
        }

       $("#location-form-questions,#route-form-questions").submit(function(event){
            $("#location-form-questions select,#route-form-questions select").each(function(){
               if($(this).val().trim() == ""){
                    $("#error_questions").css('display','block');
                    $("#error_questions h4").html("Please answer all the questions");
                    event.preventDefault();
                }
            });
        });

    },
    setUpAuditsListing: function () {
        $('#audits-list-form select').on('change', function () {
            $('#audits-list-form').trigger('submit');
        });

        $('#audits-list-form input[name="aid"]').on('blur', function () {
            $('#audits-list-form').trigger('submit');
        }).bind('keypress',function(e){
          var key = e.which;
          if(key == 13){
            $('#audits-list-form').trigger('submit');
          }
        });

        MsLstUtils.createSelect2s([
            {element: $('select[name="type"]')},
            {element: $('select[name="auditor[]"]')},
            {element: $('select[name="lsp[]"]')},
            {element: $('select[name="region[]"]')},
            {element: $('select[name="country[]"]')},
            {element: $('select[name="score[]"]')},
            {element: $('select[name="review[]"]')},
            {element: $('select[name="status[]"]')}
        ]);

        MsLstUtils.createDateRangePicker($('input[name="daterange"]'), new Date(), function () {
            $('#audits-list-form').trigger('submit');
        });

        MsLstAudits.config.auditsFilterResetButton.on('click', function () {
            $('input[name="daterange"]').val('');
            MsLstUtils.resetSelect2s([
                $('select[name="type"]'),
                $('select[name="auditor[]"]'),
                $('select[name="lsp[]"]'),
                $('select[name="region[]"]'),
                $('select[name="country[]"]'),
                $('select[name="score[]"]'),
                $('select[name="review[]"]')
            ]);
        });

        if($('#audits-list thead').attr('id') == 'location-head')
            MsLstUtils.createDataTable($('#audits-list'), 'audits', [0, 1], [[ 2, "desc" ]],'','',"rtip");
       else
            MsLstUtils.createDataTable($('#audits-list'), 'audits', [0, 1], [[ 2, "desc" ]],'','',"rtip");


        $('.location-item td').live('click', function () {

            if($(this).parent('tr').data('status') == 0 ){
                 window.location.href = '/locations/incomplete/' + $(this).parent('tr').data('id');
            }else
            {
                window.location.href = '/locations/' + $(this).parent('tr').data('id');
            }
        });

        $('.route-item td').live('click', function () {
            if($(this).parent('tr').data('status') == 0 ){
                 window.location.href = '/routes/incomplete/' + $(this).parent('tr').data('id');
            }else
            {
                window.location.href = '/routes/' + $(this).parent('tr').data('id');
            }
        });
    }
};

/**
 * Handlers for certification edit and listing
 */
var MsLstCertifications = {
    init: function () {
        MsLstCertifications.config = {
            availabilitySelect: $('select[name="availability"]')
        };

        MsLstCertifications.setUp();
    },
    setUp: function () {
        MsLstCertifications.attachAvailabilitySelect2();
    },
    attachAvailabilitySelect2: function () {
        MsLstCertifications.config.availabilitySelect.select2({ placeholder: "Select Availability" });
        MsLstUtils.getCollapse();
    }
};

/**
 * Handlers for country create/edit and listing
 */
var MsLstCountries = {
    init: function () {
        MsLstCountries.config = {
            regionSelect: $('select[name="region"]'),
            countryList: $('#countries-list')
        };

        MsLstCountries.setUp();
    },
    setUp: function () {
        MsLstCountries.attachRegionSelect2();
        MsLstCountries.createCountryListDataTable();
        MsLstUtils.getCollapse();
    },
    attachRegionSelect2: function () {
        MsLstUtils.createSelect2s([
            {element: MsLstCountries.config.regionSelect, options: { placeholder: "Select Region" }}
        ]);

    },
    createCountryListDataTable: function () {
        MsLstUtils.setUpDeleteConfirmation("Are you sure you want to delete the selected country?", '.country-delete-button');
        MsLstUtils.createDataTable(MsLstCountries.config.countryList, 'countries', [ 2 ], [[ 0, "asc" ]],'','',"rtip");
    }
};

/**
 * The dashboard setup functions
 */
var MsLstDashboard = {
    init: function (settings) {
        MsLstDashboard.config = {
            incidentsElm: 'incidents-area-chart',
            incidents: [],
            auditsElm: 'audits-area-chart',
            audits: [],
            incidentStatusElm: 'incident-status-donut-chart',
            incidentStatus: [],
            incidentLspElm: 'incident-lsp-donut-chart',
            incidentLsp: [],
            incidentCategoryElm: 'incident-category-donut-chart',
            incidentCategory: [],
            userStatusElm: 'user-status-donut-chart',
            userStatus: [],
            inspectAuditStatusElm: 'inspect-audit-status-donut-chart',
            inspectAuditStatus:[],
            incidentsdate: $('#incidentsdate'),
            auditdate: $('#auditdate'),
            incidenttype: $('#incidenttype'),
            incidentcharttype: $('#incidentcharttype'),
            auditcharttype: $('#auditcharttype'),
            user_role: '',
        }

        $.extend(MsLstDashboard.config, settings);

        MsLstDashboard.setUp();
    },
    setUp: function () {
        MsLstDashboard.sortWidgets();
        MsLstDashboard.makePanelDraggable();
        MsLstDashboard.drawIncidentsTrend();
    		MsLstDashboard.onChangeIncidentchartType();
    		MsLstDashboard.onChangeType();
    		MsLstDashboard.onChangeDate();
    		MsLstDashboard.drawAuditsTrend();
    		MsLstDashboard.onChangeAuditchartType();
    		MsLstDashboard.showMoreAlerts();
        MsLstDashboard.drawIncidentStatus();
        MsLstDashboard.drawIncidentLsp();
        MsLstDashboard.drawIncidentCategoryStatus();
        MsLstDashboard.drawinspectAuditStatus();        
        MsLstDashboard.drawuserStatus();
        MsLstDashboard.onIncidentDateChange();
        MsLstDashboard.CaSummary();     
    },
    sortWidgets: function () {
      // Extend jQuery with list sorting functionality
      jQuery.fn.sortUl = function () {
          $("> li", this[0]).sort(dec_sort).appendTo(this[0]);
          function dec_sort(a, b){ return ($(b).data("sort")) < ($(a).data("sort")) ? 1 : -1; }
      };

      // Sort the left and right panels on page load
      $('#draggableLeftPanel').sortUl();
      $('#draggableRightPanel').sortUl();
    },
    makePanelDraggable: function () {
        // Make the left and right panels sortable
        $('#draggableLeftPanel, #draggableRightPanel').sortable({
            handle: '.ibox',
            update: function () {
                var data = {
                  'left': $('#draggableLeftPanel').sortable('toArray'),
                  'right': $('#draggableRightPanel').sortable('toArray')
                };

                if (Object.prototype.toString.call(data['left']) !== '[object Array]') {
                  data['left'] = null;
                }

                if (Object.prototype.toString.call(data['right']) !== '[object Array]') {
                  data['right'] = null;
                }

                MsLstUtils.startSpin();
                $.post('/saveorder', data, function() {
                    MsLstUtils.stopSpin();
                });
            }
        });
    },
	drawAuditsTrend: function () {
     if($("#audit_trend").length > 0 ){
        
        $("#audit_fy_slider").ionRangeSlider({
             type: 'double',
             grid: true,
             min: 12,
             max: 16,
             from: 16,
             to: 16,
             prefix: "FY",
             onFinish: function (data) {
               //console.log(data);
                /* Change values based on slider - Start */
                 MsLstUtils.startSpin();
                   var targetelm = MsLstDashboard.config.auditsElm;
                   var charttype = MsLstDashboard.config.auditcharttype.val();
                   var type = ['Locations: ', 'Routes: '];
                    MsLstUtils.RemoveCanvasElement(targetelm); // Chart JS
         
                   var auditval = '';
                   var options   = auditval.split("#");
                   var barRatio  = 0.75;
                   var start = data.fromNumber;
                   var end   = data.toNumber;
                   var fy_audit = 2016;
                   if(start == end) fy_audit = '20'+start;

                if(auditval == '1#month')  barRatio  = 0.24;

                $.post('/dashboard/options',{'fy_audit':fy_audit,'fy_start':'20'+start,'fy_end':'20'+end},function (data){
                 //   console.log(data);
                    var auditdata = JSON.parse(data);
                    $("#audits-area-chart").html('');

                    var label   = auditdata['period'];
                    var data    = auditdata['location'];
                    var dataOne = auditdata['route'];

                     
                    if(charttype == 'line')
                        MsLstUtils.createChartJsLineChart(targetelm,type,label,data,dataOne); // Chart JS
                    else if(charttype == 'area')
                        MsLstUtils.createChartJsAreaChart(targetelm,type,label,data,dataOne); // Chart JS
                    else if(charttype == 'bar')
                        MsLstUtils.createChartJsBarChart(targetelm,type,label,data,dataOne); // Chart JS
                     
                       MsLstUtils.stopSpin();
                    

                   
                });
                /* Change values based on slider - Stop */
             }
        }); 


          if((typeof MsLstDashboard.config.audits['location'] != 'undefined') ||  (typeof MsLstDashboard.config.audits['route']  != 'undefined')){
              var targetelm = MsLstDashboard.config.auditsElm;
              var type = ['Locations: ', 'Routes: '];
              var label = MsLstDashboard.config.audits['period'];
              var data = MsLstDashboard.config.audits['location'];
              var dataOne = MsLstDashboard.config.audits['route'];
              MsLstUtils.createChartJsLineChart(targetelm,type,label,data,dataOne);
          }
      }
    
    },
    drawIncidentsTrend: function () {
       if($("#incident_trend").length > 0 ){

        $("#incident_fy_slider").ionRangeSlider({
             type: 'double',
             grid: true,
             min: 12,
             max: 16,
             from: 16,
             to: 16,
             prefix: "FY",
             onFinish: function (data) {
                 //console.log(data);
                /* Change values based on slider - Start */
                var targetelm = MsLstDashboard.config.incidentsElm;
               // $('#incidents-area-chartdiv').spin();
                MsLstUtils.RemoveCanvasElement(targetelm); // Chart JS
 

                var incidentval = '';
                var incidenttype = $("#incidenttype").val();
                var Options     =  incidentval.split("#");
                var barRatio  = 0.34;
                var charttype = MsLstDashboard.config.incidentcharttype.val();
                var start = data.fromNumber;
                var end   = data.toNumber;
                var fy_incident = 2016;
                if(start == end) fy_incident = '20'+start;
  
                if(incidentval == '1#month')  barRatio  = 0.14;
  
                var type = [];

                if(incidenttype == 'number')
                   type = ['No. of incidents: ','No. of incidents: '];
                else
                   type = ['Value: $','Value: $'];
                MsLstUtils.startSpin();
                 console.log('3');
                $.post('/dashboard/options',{'incidentdate': '' ,'incidenttype': incidenttype ,'fy_incident':fy_incident,'fy_start':'20'+start,'fy_end':'20'+end},function (data){
                            var incdentdata = JSON.parse(data);

                            var label = incdentdata['period'];
                            var data = incdentdata['incidents'];
                            
                            if(charttype == 'line')
                                MsLstUtils.createChartJsLineChart(targetelm,type,label,data); // Chart JS
                            else if(charttype == 'area')
                                MsLstUtils.createChartJsAreaChart(targetelm,type,label,data); // Chart JS
                            else if(charttype == 'bar')
                                MsLstUtils.createChartJsBarChart(targetelm,type,label,data); // Chart JS
                               MsLstUtils.stopSpin();
                           
                            // $('#incidents-area-chartdiv').spin(false);
                });
                /* Change values based on slider - Stop */
             }
        }); 

    
       
         if(typeof MsLstDashboard.config.incidents['incidents'] != 'undefined'){
            var data = MsLstDashboard.config.incidents['incidents'];
            var targetelm = MsLstDashboard.config.incidentsElm;
            var type = ['No. of incidents: ','No. of incidents: '];
            var label = MsLstDashboard.config.incidents['period'];
            var charttype = MsLstDashboard.config.incidentcharttype.val();
          if(charttype == 'line')
                MsLstUtils.createChartJsLineChart(targetelm,type,label,data); // Chart JS
            else if(charttype == 'area')
                MsLstUtils.createChartJsAreaChart(targetelm,type,label,data); // Chart JS
            else if(charttype == 'bar')
                MsLstUtils.createChartJsBarChart(targetelm,type,label,data); // Chart JS
          }

          $("select[name=fy_incident]").on('change',function(){
             
             //
                var targetelm = MsLstDashboard.config.incidentsElm;
                $('#incidents-area-chartdiv').spin();
                MsLstUtils.RemoveCanvasElement(targetelm); // Chart JS


                var incidentval = $(this).val();
                var incidenttype = $("#incidenttype").val();
                var Options     =  incidentval.split("#");
                var barRatio  = 0.34;
                var charttype = MsLstDashboard.config.incidentcharttype.val();

                if(incidentval == '1#month')  barRatio  = 0.14;

                var type = [];

                if(incidenttype == 'number')
                   type = ['No. of incidents: ','No. of incidents: '];
                else
                   type = ['Value: $','Value: $'];
                MsLstUtils.startSpin();
                $.post('/dashboard/options',{'incidentdate': incidentval ,'incidenttype': incidenttype ,'fy_incident':$(this).val()},function (data){
                            var incdentdata = JSON.parse(data);

                            var label = incdentdata['period'];
                            var data = incdentdata['incidents'];
                            
                            if(charttype == 'line')
                                MsLstUtils.createChartJsLineChart(targetelm,type,label,data); // Chart JS
                            else if(charttype == 'area')
                                MsLstUtils.createChartJsAreaChart(targetelm,type,label,data); // Chart JS
                            else if(charttype == 'bar')
                                MsLstUtils.createChartJsBarChart(targetelm,type,label,data); // Chart JS
                               MsLstUtils.stopSpin();
                           
                             $('#incidents-area-chartdiv').spin(false);
                });
             //
          });

        }
    },
    
    drawIncidentStatus: function () {
      if($("#incident_status").length > 0){
          

          if(typeof  MsLstDashboard.config.incidentStatus != 'undefined'){
              var data = MsLstDashboard.config.incidentStatus ;
             if(data.length > 0 ){
                MsLstUtils.createDonutChart(MsLstDashboard.config.incidentStatusElm, MsLstDashboard.config.incidentStatus,0);
             }
          }
          $("select[name=fy_inc_status]").on('change' ,function(){
               $.post('dashboard/options',{'fy_incident_status':$(this).val()},function(data) {
                          var incdentdata = JSON.parse(data);
                          console.log(incdentdata);
                          if(incdentdata.length >0 ) {
                            $("#incident-status-donut-chart").empty();
                              MsLstUtils.startSpin();
                              MsLstUtils.createDonutChart(MsLstDashboard.config.incidentStatusElm, incdentdata,0);
                              MsLstUtils.stopSpin();
                          } 

                  });
          });
      }
    },
    drawIncidentLsp :function(){
      if($("#incident_lsp").length > 0 ){

          if(typeof MsLstDashboard.config.incidentLsp != 'undefined') {
             var data = MsLstDashboard.config.incidentLsp;
             if(data.length >0 ) {
               MsLstUtils.createDonutChart(MsLstDashboard.config.incidentLspElm, MsLstDashboard.config.incidentLsp,0);
             }
          }

           

           $("select[name=fy_incident_lsp],select[name=incidenttype_lsp]").on('change',function(){
                
                var incidenttype_lsp =  $("select[name=incidenttype_lsp]").val();
                var fy_incident_lsp =  $("select[name=fy_incident_lsp]").val();
                $.post('dashboard/options',{'fy_incident_lsp':fy_incident_lsp,'incidenttype_lsp':incidenttype_lsp},function(data) {
                          var incdentdata = JSON.parse(data);
                          console.log(incdentdata);
                          if(incdentdata.length >0 ) {
                            $("#incident-lsp-donut-chart").empty();
                              MsLstUtils.startSpin();
                              MsLstUtils.createDonutChart(MsLstDashboard.config.incidentLspElm, incdentdata,0);
                              MsLstUtils.stopSpin();
                          }
                  });

          });

      }
    },
    drawIncidentCategoryStatus: function () {
      if($("#incident_category").length > 0) {
          
          if(typeof  MsLstDashboard.config.incidentStatus != 'undefined'){
             var data = MsLstDashboard.config.incidentStatus ;
             if(data.length > 0 ){
                 MsLstUtils.createDonutChart(MsLstDashboard.config.incidentCategoryElm, MsLstDashboard.config.incidentCategory,0);
              }
          }

          $("select[name=fy_incident_category]").on('change',function(){
                
                var fy_incident_category =  $("select[name=fy_incident_category]").val();
                $.post('dashboard/options',{'fy_incident_category':fy_incident_category},function(data) {
                          var incdentdata = JSON.parse(data);
                          console.log(incdentdata);
                          if(incdentdata.length >0 ) {
                            $("#incident-category-donut-chart").empty();
                              MsLstUtils.startSpin();
                              MsLstUtils.createDonutChart(MsLstDashboard.config.incidentCategoryElm, incdentdata,0);
                              MsLstUtils.stopSpin();
                          }
                  });

          });


      }
    },
     drawinspectAuditStatus: function(){
        
       if(typeof  MsLstDashboard.config.inspectAuditStatus != 'undefined'){
          var data_insA = MsLstDashboard.config.inspectAuditStatus;
      
          if(data_insA.length > 0 ){
               MsLstUtils.createDonutChart(MsLstDashboard.config.inspectAuditStatusElm, MsLstDashboard.config.inspectAuditStatus,0);
            }

          $(".sitemasters-item td").live("click",function(){
              window.location.href='sitemaster/'+ $(this).parent('tr').data('sid')+"?pr&uid="+ $(this).parent('tr').data('uid');
          });
        }
    },
   drawuserStatus: function () {
     if(typeof  MsLstDashboard.config.userStatus != 'undefined' && MsLstDashboard.config.user_role == 'admin'){
         var data = MsLstDashboard.config.userStatus;
         if(data.length > 0 ){
             MsLstUtils.createDonutChart(MsLstDashboard.config.userStatusElm, MsLstDashboard.config.userStatus,0);
          }
      }
    },
    showMoreAlerts: function () {
        if (typeof alert_offset == 'undefined') {
            alert_offset = 1;
        }

        $('#more-alerts').on('click', function () {
            $('#alerts-box').spin();
            $('#more-alerts').attr('disabled', true);
            $.post('/alerts', {'offset': alert_offset}, function (data) {
                $('#alerts-box').spin(false);
                $('#alerts-box').html(data);
                $('#more-alerts').removeAttr('disabled');
            });

            alert_offset++;
        });
    },
    onChangeDate : function(){
           
           MsLstDashboard.config.incidentsdate.on('change',function(){
                var targetelm = MsLstDashboard.config.incidentsElm;
                $('#incidents-area-chartdiv').spin();
                MsLstUtils.RemoveCanvasElement(targetelm); // Chart JS


                var incidentval = $(this).val();
                var incidenttype = $("#incidenttype").val();
                var Options     =  incidentval.split("#");
                var barRatio  = 0.34;
                var charttype = MsLstDashboard.config.incidentcharttype.val();

                if(incidentval == '1#month')  barRatio  = 0.14;

                var type = [];

                if(incidenttype == 'number')
                   type = ['No. of incidents: ','No. of incidents: '];
                else
                   type = ['Value: $','Value: $'];
                 //MsLstUtils.startSpin();
                $.post('/dashboard/options',{'incidentdate': incidentval ,'incidenttype': incidenttype },function (data){
                            var incdentdata = JSON.parse(data);

                            var label = incdentdata['period'];
                            var data = incdentdata['incidents'];
                           /* $("#incidents-area-chart").html('');
                           // if(Options[1] == 'year'){
                                MsLstUtils.createLineChart(
                                    MsLstDashboard.config.incidentsElm,
                                    incdentdata,
                                    'period',
                                    'month',
                                    ['incidents'],
                                    ['Incidents'],
                                    MsLstUtils.formatDateAsMonthYear
                                ); */
                            if(charttype == 'line')
                                MsLstUtils.createChartJsLineChart(targetelm,type,label,data); // Chart JS
                            else if(charttype == 'area')
                                MsLstUtils.createChartJsAreaChart(targetelm,type,label,data); // Chart JS
                            else if(charttype == 'bar')
                                MsLstUtils.createChartJsBarChart(targetelm,type,label,data); // Chart JS
                             // MsLstUtils.stopSpin();
                           /* }else{
                                 MsLstUtils.createDashboardBarChart (
                                    MsLstDashboard.config.incidentsElm,
                                    incdentdata,
                                    'period',
                                    ['incidents'],
                                    ['incidents'],
                                    true,
                                    'incidents',
                                    barRatio
                                  );
                            }*/
                             $('#incidents-area-chartdiv').spin(false);
                });
          });

        MsLstDashboard.config.auditdate.on('change',function(){
              //MsLstUtils.startSpin();
               var targetelm = MsLstDashboard.config.auditsElm;
               var charttype = MsLstDashboard.config.auditcharttype.val();
               var type = ['Locations: ', 'Routes: '];
                MsLstUtils.RemoveCanvasElement(targetelm); // Chart JS
     
               var auditval = $(this).val();
               var options   = auditval.split("#");
               var barRatio  = 0.75;

            if(auditval == '1#month')  barRatio  = 0.24;

            $.post('/dashboard/options',{'auditdate':auditval},function (data){
             //   console.log(data);
                var auditdata = JSON.parse(data);
                $("#audits-area-chart").html('');

                var label   = auditdata['period'];
                var data    = auditdata['location'];
                var dataOne = auditdata['route'];

                 
                if(charttype == 'line')
                    MsLstUtils.createChartJsLineChart(targetelm,type,label,data,dataOne); // Chart JS
                else if(charttype == 'area')
                    MsLstUtils.createChartJsAreaChart(targetelm,type,label,data,dataOne); // Chart JS
                else if(charttype == 'bar')
                    MsLstUtils.createChartJsBarChart(targetelm,type,label,data,dataOne); // Chart JS
                  //MsLstUtils.stoptSpin();
                

                $("#audits-area-chart").spin(false);
            });

        })
    },
    onChangeAuditStatus: function(){
        $(".oldaudits").live('click',function(){
                var check='';
            $('.oldaudits').each(function(){
                if($(this).prop("checked") == true){
                      check = true;
                      return false;
                 }else{
                      check = false;
                 }
            });
            if(check == true){
                $("#changestatus").show();
            }else{
                $("#changestatus").hide();
            }
        });

        $("#changestatus").on('click',function(){
             bootbox.confirm("Pressing OK will change the Audit status to Inactive?", function(result) {
                    if (result === true) {
                       var audit = { route:[], location:[]};

                       $(".oldaudits").each(function(){
                            if($(this).prop("checked") == true){
                                //var id   = $(this).attr('id').match(/(\d+)/g);
                                var type = $(this).attr('id').split('-');
                                //var ary  = {'id':type[2]} ;
                                if(type[1] == 'route'){
                                    audit.route.push(type[2]);
                                }else{
                                    audit.location.push(type[2]);
                                }
                                $('#oldaudit').spin();
                                $(".spinner").css('position','relative');
                                $(".spinner").css('top','51px');
                            }
                        });
                        //audit = location.concat(route);
                        //console.log(audit.location+"##"+audit.route);
                        $.post('/oldaudit', {'audit': audit }, function (data) {
                                    $('#oldaudit').spin(false);
                                    $('#oldaudit').html(data);
                                });
                        bootbox.alert("Status of the selected audits are changed to Inactive.");

                    }
            });

        });
    },
    onChangeType: function(){
          MsLstDashboard.config.incidenttype.on('change',function(){
                var incidenttype = $("#incidenttype").val();
                var date = $("#incidentsdate").val();
                var targetelm = MsLstDashboard.config.incidentsElm;
                var charttype = MsLstDashboard.config.incidentcharttype.val();
                var Options = date.split("#");
                var barRatio  = 0.34;
                var type = [];

                if(date == '1#month')  barRatio  = 0.14;


                MsLstUtils.RemoveCanvasElement(targetelm); // Chart JS

                if(incidenttype == 'number')
                 type = ['No. of incidents: ','No. of incidents: '];
                else
                 type = ['Value: $','Value: $'];

                $('#incidents-area-chart').spin();
                $.post('dashboard/options',{'incidenttype':incidenttype,'incidentdate':date},function(data) {

                       var incdentdata = JSON.parse(data);
                       $("#incidents-area-chart").html('');


                        var label = incdentdata['period'];
                        var data  = incdentdata['incidents'];

                    //   if(Options[1] == 'year'){
                             /*   MsLstUtils.createLineChart(
                                    MsLstDashboard.config.incidentsElm,
                                    incdentdata,
                                    'period',
                                    'month',
                                    ['incidents'],
                                    ['Incidents'],
                                    MsLstUtils.formatDateAsMonthYear
                                );*/
                        if(charttype == 'line')
                             MsLstUtils.createChartJsLineChart(targetelm,type,label,data); // Chart JS
                        else if(charttype == 'area')
                            MsLstUtils.createChartJsAreaChart(targetelm,type,label,data); // Chart JS
                        else if(charttype == 'bar')
                            MsLstUtils.createChartJsBarChart(targetelm,type,label,data); // Chart JS


                      /*      }else{
                                 MsLstUtils.createDashboardBarChart (
                                    MsLstDashboard.config.incidentsElm,
                                    incdentdata,
                                    'period',
                                    ['incidents'],
                                    ['incidents'],
                                    true,
                                    'incidents',
                                    barRatio
                                  );
                            }*/
                    $('#incidents-area-chart').spin(false);
                });
          });
    },
    onChangeIncidentchartType: function(){
          
         MsLstDashboard.config.incidentcharttype.on('change',function(){

                var incidenttype = $("#incidenttype").val();
                var date = $("#incidentsdate").val();
                var charttype  = $(this).val();
                var targetelm = MsLstDashboard.config.incidentsElm;
                 var type = [];
                MsLstUtils.RemoveCanvasElement(targetelm); // Chart JS

               if(incidenttype == 'number')
                 type = ['No. of incidents: ','No. of incidents: '];
                else
                 type = ['Value: $','Value: $'];

                $('#incidents-area-chart').spin();
                $.post('dashboard/options',{'incidenttype':incidenttype,'incidentdate':date},function(data) {
                    var incdentdata = JSON.parse(data);
                    var label = incdentdata['period'];
                    var data  = incdentdata['incidents'];
                    
                   if(charttype == 'line')
                             MsLstUtils.createChartJsLineChart(targetelm,type,label,data); // Chart JS
                    else if(charttype == 'area')
                            MsLstUtils.createChartJsAreaChart(targetelm,type,label,data); // Chart JS
                    else if(charttype == 'bar')
                            MsLstUtils.createChartJsBarChart(targetelm,type,label,data); // Chart JS

                    $('#incidents-area-chart').spin(false);
                });

               
         });

    },
    onChangeAuditchartType : function(){
        MsLstDashboard.config.auditcharttype.on('change',function(){

            var charttype = $(this).val();

            $("#audits-area-chart").spin();
            var targetelm = MsLstDashboard.config.auditsElm;
            var type = ['Locations: ', 'Routes: '];
            MsLstUtils.RemoveCanvasElement(targetelm); // Chart JS
     
            var auditval =  MsLstDashboard.config.auditdate.val();
     

            $.post('/dashboard/options',{'auditdate':auditval},function (data){
    
                var auditdata = JSON.parse(data);
                var label   = auditdata['period'];
                var data    = auditdata['location'];
                var dataOne = auditdata['route'];
                
                if(charttype == 'line')
                    MsLstUtils.createChartJsLineChart(targetelm,type,label,data,dataOne); // Chart JS
                else if(charttype == 'area')
                    MsLstUtils.createChartJsAreaChart(targetelm,type,label,data,dataOne); // Chart JS
                else if(charttype == 'bar')
                    MsLstUtils.createChartJsBarChart(targetelm,type,label,data,dataOne); // Chart JS
                    
                $("#audits-area-chart").spin(false);
             });

        });
    },
    onIncidentDateChange: function(){
            $("span.pie").peity("pie", {
                fill: ['#1ab394', '#d7d7d7', '#ffffff']
            });

            $('.collapse-link:not(.binded)').addClass("binded").click( function() {
                var ibox = $(this).closest('div.ibox');
                var button = $(this).find('i');
                var content = ibox.find('div.ibox-content');
                content.slideToggle(200);
                button.toggleClass('fa-chevron-up').toggleClass('fa-chevron-down');
                ibox.toggleClass('').toggleClass('border-bottom');
                setTimeout(function () {
                    ibox.resize();
                    ibox.find('[id^=map-]').resize();
                }, 50);
            });      
   },
   CaSummary: function(){
      if($("#ca_summary").length != 'undefined'){
           $('.ca_summary_tale').DataTable( {
                      responsive: true,
                     "sDom": "rftip",
            } );

            $(".ca_summary_tale tbody tr").live('click',function(){
                window.location.href = 'sitemaster/'+$(this).attr('data-sid')+'?pr&uid='+$(this).attr('data-uid');
           });
      }
  }
};



/**
 * Handlers for Factory incdient create/edit
 */
 var MsLstFactoryIncidents = {
   init : function(settings){
        MsLstFactoryIncidents.config = {
            regionSelect: $('select[name="region"]'),
            countrySelect: $('select[name="country"]'),
            dateEventInput: $('input[name="incident_event_date"]'),
            addevent : $('#additem'),
            regions : null,
            on_date : $('input[name="on_date"]'),
			      on_time : $('input[name="on_time"]'),
            cur_inv_status : $('select[name="current_investigation_status"]'),
            addattachment : $('.attachment-add-btn'),
            coordinates: null,
            mapElement: null,
        };

        $.extend(MsLstFactoryIncidents.config,settings);

        MsLstFactoryIncidents.setUp();
   },
   setUp : function(){
        MsLstFactoryIncidents.setUpFactoryForm();
   },
   setUpFactoryForm: function(){
  
    MsLstUtils.createSingleDatePicker(MsLstFactoryIncidents.config.dateEventInput,'','yes');
    MsLstUtils.createSingleDatePicker(MsLstFactoryIncidents.config.on_date,'','yes');
    MsLstUtils.createTimePicker(MsLstFactoryIncidents.config.on_time,'','yes');
 
      MsLstUtils.createSelect2s([
            {element: MsLstFactoryIncidents.config.regionSelect, options: { placeholder: "Select Region" }},
            {element: MsLstFactoryIncidents.config.countrySelect, options: { placeholder: "Select Country" }},
            //{element: MsLstFactoryIncidents.config.cur_inv_status, options: {placeholder: "Select Investigation Status"}}
        ]);

      if (MsLstFactoryIncidents.config.regions) {
            MsLstUtils.applyCountryFilter(MsLstFactoryIncidents.config.regions, $('select[name="region"]'), $('select[name="country"]'),FactoryIncidents.country);
            
           $('select[name="region"]').on('change', function() {
                $('#s2id_country .select2-chosen').empty();
                MsLstUtils.applyCountryFilter(MsLstFactoryIncidents.config.regions, $('select[name="region"]'), $('select[name="country"]'));
           });
      }

    // on click to add product 
      MsLstFactoryIncidents.config.addevent.on('click',function(){
        $(".product-row").last().after(addProductrow());
      });


       // Product row remove action
        $('.product-row .remove-item button').live('click', function () {
            $(this).parent().parent().parent().remove();

            var index = 1;
            $('.product-row').each(function () {
                $(this).find('.product-count').html("#" + index);
                index++;
            });
        });

      // Append Product in Incident Details
      function addProductrow(description,family,part,units,serial,value,familyid){
          description = description || '';
          family      = family || '';
          part        = part || '';
          units       = units || '';
          serial      = serial || '';
          value       = value || '';

          var string = '<div class="row product-row"> <div class="col-lg-1"><label class="control-label ">&nbsp;</label><span class="form-control product-count">#{{next}}</span></div><div class="col-lg-4"><div class="form-group"><label class="control-label  required" for="product_description{{id}}">Product /item description</label><input type="text" name="product_description[{{id}}]" value="'+description+'" class="form-control"></div><div class="form-group"><label class="control-label required" for="product_family{{id}}">Product Family</label><select name="product_family[{{id}}]" class="form-control"><option value="Lumia(Phone)">Lumia(Phone)</option><option value="Surface(PC)">Surface(PC)</option><option value="Xbox(Gaming)">Xbox(Gaming)</option><option value="High value sub-assembly">High value sub-assembly</option><option value="Component parts">Component parts</option><option value="Other">Other</option></select><div class="col-lg-12 product_family_other" id="product_family_other{{id}}"></div></div></div><div class="col-cust-1"></div><div class="col-lg-2"><div class="form-group"><label class="control-label required" for="part_number{{id}}">Part Number</label><input type="text" name="part_number[{{id}}]" value="'+part+'" class="form-control"></div><div class="form-group"><label class="control-label required" for="number_of_unit_missing{{id}}">Number Of Unit Missing</label><input type="text" name="number_of_unit_missing[{{id}}]" value="'+units+'" class="form-control"></div></div><div class="col-cust-1"></div><div class="col-lg-2"><div class="form-group"><label class="control-label required" for="serial_number{{id}}">Serial Number</label><input type="text" name="serial_number[{{id}}]" value="'+serial+'" class="form-control"></div><div class="form-group"><label class="control-label required" for="value_per_unit{{id}}">Value per unit(USD)</label><input type="text" name="value_per_unit[{{id}}]" value="'+value+'" class="form-control"></div></div><div class="col-lg-1"><label class="control-label ">&nbsp;</label><span class="form-control remove-item"><button class="btn btn-danger btn-xs" type="button"><i class="fa fa-times"></i></button></span></div></div>';

          var last_id = parseInt($(".product-count").last().html().replace('#',''))+1 ;
          string = string.replace(/{{next}}/g,last_id).replace(/{{id}}/g,last_id-1);

          return string;
      }

      // on load, If populate the product rows
      if(typeof Products === "object"){
        var count = Products['product_description'].length;
        console.log(count);
        var fammly = ['Lumia(Phone)','Surface(PC)','Xbox(Gaming)','High value sub-assembly','Component parts'];
              for(var i=0;i<count;i++){

                    var description = Products['product_description'][i];
                    var family      = Products['product_family'][i];
                    var part        = Products['part_number'][i];
                    var unit        = Products['number_of_unit_missing'][i];
                    var serial      = Products['serial_number'][i];
                    var value       = Products['value_per_unit'][i];
                     console.log(family+"#id#"+i);
                if(i == 0){
                     $("input[name='product_description[0]']").val(Products['product_description'][i]);
                     if($.inArray(family,fammly) != -1){
                       $("select[name='product_family["+i+"]'] option[value='"+Products['product_family'][i]+"']").prop('selected',true);
                     }else{
                        $("select[name='product_family["+i+"]']").append('<option value="'+family+'"  selected="selected">'+family+'</option>');
                     }
                     $("input[name='part_number[0]']").val(Products['part_number'][i]);
                     $("input[name='number_of_unit_missing[0]']").val(Products['number_of_unit_missing'][i]);
                     $("input[name='serial_number[0]']").val(Products['serial_number'][i]);
                     $("input[name='value_per_unit[0]']").val(Products['value_per_unit'][i]);
                  }else{
                     $('.product-row').last().after(addProductrow(description,family,part,unit,serial,value,i));
                     
                     if($.inArray(family,fammly) != -1 ){
                        $("select[name='product_family["+i+"]'] option[value='"+family+"']").prop('selected',true);
                     }else{
                        $("select[name='product_family["+i+"]']").append('<option value="'+family+'"  selected="selected">'+family+'</option>');
                     }
                  }
              }
      }


     // Product row remove action
      $('.attachments .remove-item button').live('click', function () {
          $(this).parent().parent().parent().parent().remove();
      });

    // on click to add attachments
     MsLstFactoryIncidents.config.addattachment.on('click',function(){
        $('.attachments').last().after(addAttachment());
     });
     
    // Append Attachment in Investigation
     function addAttachment()
     {
        var string = '<div class="attachments"><div class="row"><div class="col-lg-10"><div class="form-group"><label class="control-label" for="attachment[{{id}}]">File</label><input type="file" name="attachment[{{id}}]" id="incidentattachment"></div></div></div><div class="row"><div class="col-lg-10"><div class="form-group"><label class="control-label" for="description[{{id}}]">Description</label><textarea id="description[{{id}}]" cols="50" name="description[{{id}}]" rows="3" class="form-control"></textarea></div></div> <div class="col-lg-1"><label class="control-label">&nbsp;</label><span class="form-control remove-item"><button type="button" class="btn btn-danger btn-xs"><i class="fa fa-times"></i></button></span></div></div><div class="hidden file-index">{{id}} </div> </div>';
        var last_id = parseInt($('.file-index').last().html())+1;
       
        string = string.replace(/{{id}}/g,last_id);
        return string;
     }

      MsLstUtils.setUpDeleteConfirmation("Are you sure you want to open this factory incident?", '.incident-open-button');
      MsLstUtils.setUpDeleteConfirmation("Are you sure you want to close this factory incident?", '.incident-close-button');
      MsLstUtils.setUpDeleteConfirmation("Are you sure you want to remove this factory incident?", '.incident-delete-button');

         $("#incident-hanoi-check,#incident-manaus-check,#incident-reynosa-check").on('click',function(){
       
         var name = $(this).attr("id").split('-');
         var selval  = name[1];
         $.getJSON('/js/incident/sites.txt', function(json) {
              if(selval == 'hanoi') var jsonsel = json.hanoi[0];
              else if(selval == 'manaus') var jsonsel = json.manaus[0];
              else if(selval == 'reynosa') var jsonsel = json.reynosa[0];

              $('select[name="region"]').select2('val',jsonsel.Region);
              $('#s2id_country .select2-chosen').empty();
              MsLstUtils.applyCountryFilter(MsLstFactoryIncidents.config.regions, $('select[name="region"]'), $('select[name="country"]'));
              $('select[name="country"]').select2('val',jsonsel.Country);
              $('input[name="city"]').val(jsonsel.City); 
               $('input[name="facility"]').val(jsonsel.Facility);
              $('input[name="location_address"]').val(jsonsel.location_address);
              $('input[name="coordinates"]').val(jsonsel.GPS_Coord);
          });
      });


     $('select[name^="product_family"]').live('change',function(){
          var valu = $(this).attr('name');
          var id = valu.replace('product_family[',"").replace("]","");
          if($(this).val() == 'Other'){
            $('#product_family_other'+id).html('');
            $('#product_family_other'+id).append('<input type="text" class="form-control" name="product_family['+id+']">');
          }else{
              $("#product_family_other"+id).html('');
          }
      });
 
     $("#incident_cancel").on('click',function(event){
         bootbox.confirm("The factory incident will not be saved. Press OK to discard.", function(ok) {
                        if(ok){
                             window.location.href = $("#incident_cancel").attr('alt');
                        }
                    });
        event.preventDefault;
     });
     
     $("#incident_cancel_edit").on('click',function(event){
            bootbox.confirm("Are you sure you want to cancel? The changes will not be saved.", function(ok) {
                        if(ok){
                             window.location.href = $("#incident_cancel_edit").attr('alt');
                        }
                    });
        event.preventDefault;
       });     

     /*$("#total_value_of_loss_unit").on('blur',function(event){
        var index = 0;
        var chktotal = 0;
        $("input[name^='number_of_unit_missing']").each(function(){
            chktotal+= parseInt($(this).val())*parseFloat($("input[name^='value_per_unit["+index+"]']").val());
            index++;
        });
       // alert(chktotal);
        if($(this).val() != chktotal) {
          bootbox.alert("Error: The total value of lost units does not match with the sum of all product values.",function(ok){
                       $("#total_value_of_lost_unit").focus();
          });
        }

        //checkproducttotal('total_value_of_loss_unit','number_of_unit_missing');
        event.preventDefault;
     });*/

     $("#factory-incident-detail-form").on('submit',function(){
        //checkproducttotal('total_value_of_loss_unit','number_of_unit_missing');
        var index = 0;
        var chktotal = 0;
        $("input[name^='number_of_unit_missing']").each(function(){
            chktotal+= parseInt($(this).val())*parseFloat($("input[name^='value_per_unit["+index+"]']").val());
            index++;
        });
		
        var totalval = parseFloat($("#total_value_of_loss_unit").val()).toFixed(2);
		if(totalval != chktotal.toFixed(2)) {
          bootbox.alert("Error: The total value of lost units does not match with the sum of all product values.",function(ok){
                       $("#total_value_of_loss_unit").focus();
          });
          return false;
        }else if($("#total_value_of_loss_unit").val() == 0){
          bootbox.alert("Error: Value of lost units cannot be Zero.",function(ok){
                       $("#total_value_of_loss_unit").focus();
          });
          return false;

        }

        //checkproducttotal('total_value_of_loss_unit','number_of_unit_missing');
        //event.preventDefault;
     });

     $("input[name^='number_of_unit_missing'],input[name^='value_per_unit']").live('keypress',function(e){
            var  k = (e.which) ? e.which : e.keyCode;
            var ok =  k != 46 && k > 31 && (k < 48 || k > 57); // 0-9

            //console.log(ok+"#");
            if (ok){
                e.preventDefault();
            }
        });

   /*  function checkproducttotal(total_value,number_unit){
        var index = 0;
        var chktotal = 0;
        $("input[name^='"+number_unit+"']").each(function(){
            chktotal+= parseInt($(this).val())*parseFloat($("input[name^='value_per_unit["+index+"]']").val());
            index++;
        });
        //alert(chktotal);
        if($("#"+total_value).val() != chktotal) {
          bootbox.alert("Error: The total value of lost units does not match with the sum of all product values.",function(ok){
                  $("#"+total_value).focus();
          });
          return false;
        }
     }*/

    // Coordinate picker for the Factory incident summary/view page

    if(MsLstFactoryIncidents.config.coordinates && MsLstFactoryIncidents.config.mapElement){
      //MsLstUtils.createMapByCoordinates(MsLstFactoryIncidents.config.coordinates, MsLstFactoryIncidents.config.mapElement);
      MsLstUtils.createBingMapByCoordinates(MsLstFactoryIncidents.config.coordinates, MsLstFactoryIncidents.config.mapElement);
    }

     
      //MsLstUtils.createCoordinatePicker('coordinates', 'incident-coordinate-check', 'incident-coordinate-pick');
      // Coordinate picker for the Factory incident create/edit form
      if($("#incident-coordinate-pick").length  > 0) {
               MsLstUtils.createBingCoordinatePicker('coordinates', 'incident-coordinate-check', 'incident-coordinate-pick');
      }
   }
 };

/**
 * Handlers for incident create/edit and listing
 */
var MsLstIncidents = {
    init: function (settings) {
        MsLstIncidents.config = {
            typeSelect: $('select[name="type"]'),
            regionSelect: $('select[name="region"]'),
            countrySelect: $('select[name="country"]'),
            investigationSelect : $('select[name="investigation"]'),
            lossSelect: $('select[name="type_of_loss"]'),
            deviceSelect: $('select[name="type_of_device[]"]'),
            p2pCareLink: $("#p2p-care-link"),
            incidentTypeSelect: $(".incident-type-select"),
            dateSelect: $('input[name="incident_date"]'),
            pickUpDateSelect: $('input[name="pickup_date"]'),
            pickUpTimeSelect: $('input[name="pickup_time"]'),
            incidentsDateSelect: $('input[name="daterange"]'),
            incidentsList: $('#incidents-list'),
            incidentsFilterResetButton: $('#incident-filter-reset'),
            coordinates: null,
            mapElement: null,
            regions: null
        };

        $.extend(MsLstIncidents.config, settings);

        MsLstIncidents.setUp();
    },
    setUp: function () {
        MsLstIncidents.setUpIncidentsDisplay();
        MsLstIncidents.setUpIncidentForms();
        MsLstIncidents.setUpIncidentTransportationForms();
        MsLstIncidents.onChangeTypeofdevice();
    },
    onChangeTypeofdevice:function(){
            if($('select[name="type_of_device[]"] :selected').val() == 'Proto Device'){
              //$("input[id^='value_per_unit']").prop("disabled",true).val('');
                $(".protolosshide").prop("disabled",true).val('');
            }else{
              $(".protolosshide").prop("disabled",false);
            }

    },
    setUpIncidentForms: function () {
     

        $(".keywords").keypress(function(e){
            var key = e.which;
              if(key == 13)  // the enter key code
              {
                $('#incidents-list-form').trigger('submit');
              }
        });


        MsLstUtils.createSelect2s([
            {element: MsLstIncidents.config.typeSelect, options: { placeholder: "Select" }},
            {element: MsLstIncidents.config.lossSelect, options: { placeholder: "Select Type of loss" }},
            {element: MsLstIncidents.config.deviceSelect, options: { placeholder: "Select Type of device" }},
            {element: MsLstIncidents.config.regionSelect, options: { placeholder: "Select Region" }},
            {element: MsLstIncidents.config.countrySelect, options: { placeholder: "Select Country" }},
            {element: MsLstIncidents.config.investigationSelect, options : {placeholder: "Select Investigation"}},
            {element: $('select[name="owners"]'), options: { placeholder: "Select Owners" }}
        ]);

        $('.incidents select[name="owners"]').on('change', function () {
            var id = window.location.pathname.split("/")[2];
            MsLstUtils.startSpin();
            $.post('/incidents/update-owners', {'id': id, 'owners': $(this).val()}, function () {
                MsLstUtils.stopSpin();
            });
        });

       $("#incident_cancel").on('click',function(event){
          bootbox.confirm("The incident will not be saved. Press OK to discard.", function(ok) {
                        if(ok){
                             window.location.href = $("#incident_cancel").attr('alt');
                        }
                    });
           event.preventDefault;
       });

       $("#incident_cancel_edit").on('click',function(event){
            bootbox.confirm("Are you sure you want to cancel? The changes will not be saved.", function(ok) {
                        if(ok){
                             window.location.href = $("#incident_cancel_edit").attr('alt');
                        }
                    });
        event.preventDefault;
       });

        /*if (Incidents.type)
        {
            MsLstIncidents.config.incidentTypeSelect.show();
        }*/

        MsLstIncidents.config.p2pCareLink.on('click', function () {
          MsLstIncidents.config.incidentTypeSelect.toggle();
          $('input[name="plant_care"]').val(MsLstIncidents.config.incidentTypeSelect.is(':visible') ? 1 : 0);
        });


        if ($('select[name="type_of_loss"] :selected').text() == 'Other'){
            $(".typeofotherloss").show(); 
        }else{
            $(".typeofotherloss").hide();
          }
    
    MsLstIncidents.config.lossSelect.on('change', function () {
		  if($(this).val() == 'Other') 
               $(".typeofotherloss").show();
          else
               $(".typeofotherloss").hide();			
        });
  
        if ($('select[name="type_of_device[]"] :selected').text() == 'Other'){
          $(".typeofotherdevice").show(); 
        }else{
         $(".typeofotherdevice").hide();
        }

    		MsLstIncidents.onChangeTypeofdevice();
		
    MsLstIncidents.config.deviceSelect.on('change', function () {
          if ($('select[name="type_of_device[]"] :selected').text() == 'Other')
            $(".typeofotherdevice").show(); 
          else 
            $(".typeofotherdevice").hide();
		  MsLstIncidents.onChangeTypeofdevice();
        });

        MsLstUtils.createSingleDatePicker(MsLstIncidents.config.dateSelect,'','yes');

        if (MsLstIncidents.config.regions) {
            MsLstUtils.applyCountryFilter(MsLstIncidents.config.regions, $('select[name="region"]'), $('select[name="country"]'), Incidents.country);

            $('select[name="region"]').on('change', function() {
                $('#s2id_country .select2-chosen').empty();
                MsLstUtils.applyCountryFilter(MsLstIncidents.config.regions, $('select[name="region"]'), $('select[name="country"]'));
            });
        }

        // On click of add product, add new product rows
        $('.product-add-btn').on('click', function () {
            $('.product-row').last().after(addProductRow());
            MsLstIncidents.onChangeTypeofdevice();
        });

        // The product row add helper function
        function addProductRow(description, units, value) {
            description = description || "";
            units = units || "";
            value = value || "";

            var string = '<div class="row product-row"><div class="col-lg-1"><label class="control-label">&nbsp;</label><span class="form-control product-count">#{{next}}</span></div><div class="col-lg-4"><div class="form-group"><label for="product_description{{next}}" class="control-label required">Product/item Description</label><input type="text" class="form-control" name="product_description[{{id}}]" id="product_description{{next}}" value="'+ description +'" /></div></div><div class="col-lg-3"><div class="form-group"><label for="number_of_units_missing{{next}}" class="control-label required">Number of Units Missing</label><input type="text" class="form-control" name="number_of_units_missing[{{id}}]" id="number_of_units_missing{{next}}" value="'+ units +'" /></div></div><div class="col-lg-3"><div class="form-group"><label for="value_per_unit{{next}}" class="control-label required">Value per Unit (USD)</label><input type="text" class="form-control protolosshide" name="value_per_unit[{{id}}]" id="value_per_unit{{next}}" value="'+ value +'" /></div></div><div class="col-lg-1"><label class="control-label">&nbsp;</label><span class="form-control remove-item"><button type="button" class="btn btn-danger btn-xs"><i class="fa fa-times"></i></button></span></div></div>';

            var last_id = parseInt($('.product-row').last().find('.product-count').html().replace('#', "")) + 1;
            string = string.replace(/{{next}}/g, last_id).replace(/{{id}}/g, last_id-1);

            return string;
        }

        // On load, if there are products populate those rows
        if (typeof Products != 'undefined') {
            var count = Products['description'].length;

            for(i = 0; i < count; i++) {

                if (i == 0)
                {
                    $('#product_description0').val(Products['description'][0]);
                    $('#number_of_units_missing0').val(Products['units'][0]);
                    $('#value_per_unit0').val(Products['value'][0]);
                }
                else
                {
                    $('.product-row').last().after(addProductRow(Products['description'][i], Products['units'][i], Products['value'][i]));
                }
            }
        }

        // Product row remove action
        $('.product-row .remove-item button').live('click', function () {
            $(this).parent().parent().parent().remove();

            var index = 1;
            $('.product-row').each(function () {
                $(this).find('.product-count').html("#" + index);
                index++;
            });
        });

        // Append file upload fields in attachments page
        $('.attachment-add-btn').on('click', function () {
            $('.attachments').last().after(function() {
                var string = '<div class="attachments"><div class="row"><div class="col-lg-10"><div class="form-group"><label for="file[{{index}}]" class="control-label">File</label><input type="file" name="file[{{index}}]" id="incidentattachment" /></div></div></div><div class="row"><div class="col-lg-10"><div class="form-group"><label for="description[{{index}}]" class="control-label">Description</label><textarea class="form-control" name="description[{{index}}]"> </textarea></div></div></div><div class="hidden file-index">{{index}}</div></div>';
                var last_id = parseInt($('.attachments').last().find('.file-index').html()) + 1;
                string = string.replace(/{{index}}/g, last_id);
                return string;
            });
        });

        //  validation of Attachment
        $("#incidentattachment").live("change",function(){
            var filename = $(this).val();
            var fileext  = filename.split(".");
            var ext      = ['doc','docx','xls','xlsx','pdf','zip','rar','png','gif','jpg','msg'];

            if($.inArray(fileext[1],ext) == -1 ){
               $("#form-errors").remove();
               $(".wizard").after('<div role="alert" class="alert alert-danger" id="form-errors"><ul><li>The file must be a file of type: doc , docx , xls , xlsx , pdf , zip , rar , png , gif , jpg, msg.</li></ul></div>');
               return false;
            }else{
                 $("#form-errors").remove();
            }
        });

       /* $("#incident-form-attachments").on('submit',function(){
            var ext      = ['doc','docx','xls','xlsx','pdf','zip','rar','png','gif','jpg'];
            var validat  = true;

             $("#incidentattachment").each(function(){
                    var filename = $(this).val();
                    var fileext  = filename.split(".");
                     if($.inArray(fileext[1],ext) == -1 ){
                            validat = false;
                      }
             });

             if(validat == false){
                            $("#form-errors").remove();
                            $(".wizard").after('<div role="alert" class="alert alert-danger" id="form-errors"><ul><li>The file must be a file of type: doc , docx , xls , xlsx , pdf , zip , rar , png , gif , jpg.</li></ul></div>');
                            return false;
            }else{
                 $("#form-errors").remove();
            }

        });*/

        $("#number_of_plts_missing,[id^=number_of_units_missing],#total_value_of_lost_units,[id^=value_per_unit],#investigation_file_number").live("keypress",function(evt){
             var charCode = (evt.which) ? evt.which : event.keyCode;
             if (charCode != 46 && charCode > 31    && (charCode < 48 || charCode > 57))    return false;
        });

        $("#number_of_plts_missing,[id^=number_of_units_missing],#total_value_of_lost_units,[id^=value_per_unit],#investigation_file_number").bind("copy paste cut",function(e){
            e.preventDefault();
         });
       /*$("#hawb,#mawb,[id^=product_description]").keypress(function(e){*/
        $("#hawb,#mawb").bind("keypress",function(e){
            var charval = $(this).val();
            var k = e.which;
            var ok = k >= 65 && k <= 90 || // A-Z
            k >= 97 && k <= 122 || // a-z
            k >= 48 && k <= 57 || (k == 44 || k == 8 || k==0) ; // 0-9

            if (!ok){
                e.preventDefault();
            }
        });
         $("#hawb,#mawb,#originating_facility,#consignee,#customer,#location_of_reporter,#destination_facility").bind("copy paste cut",function(e){
            e.preventDefault();
         });


        if ($('#incident-form-units').length > 0) {
            // Validate if the loss value = sum of all product values
            $('.panel-footer .pull-right button:first,.panel-footer .pull-left button:first').on('click', function(e) {
                e.preventDefault();

                var form = $('#incident-form-units');
                var sum = 0;

                if ($('input[name^="value_per_unit"]').length > 0) {
                    sum = $('input[name^="value_per_unit"]').map(function () {
                        var id = $(this).attr('id').match(/\d+/)[0];
                        var _value = parseFloat(this.value);
                        var _count = parseInt($('#number_of_units_missing' + id).val());

                        // Skip invalid ones
                        if (isNaN(_value) || isNaN(_count)) return 0;
                        return _value * _count;
                    })
                    .toArray()
                    .reduce(function(c, p) {
                        return parseFloat(c) + parseFloat(p);
                    });
                }

                var total = parseFloat($('#total_value_of_lost_units').val()).toFixed(2);
                sum = sum.toFixed(2);
                 if($("#number_of_plts_missing").val().trim() == '' && $('select[name="type_of_device[]"] :selected').val() != 'Proto Device'){
                    bootbox.alert("Error : Number of Plts/Crts Missing",function(ok){
                       $("#number_of_plts_missing").focus();
                    });
                   
                }else if (sum != total && $('select[name="type_of_device[]"] :selected').val() != 'Proto Device'){
                    bootbox.alert("Error: The total value of lost units does not match with the sum of all product values.",function(ok){
                       $("#total_value_of_lost_units").focus();
                     });
                }
                else {
                    form.trigger('submit');
                }
            });
        }


         $("#number_of_plts_missing,[id^=number_of_units_missing],#total_value_of_lost_units,[id^=value_per_unit]").live("keypress",function(evt){
             var charCode = (evt.which) ? evt.which : event.keyCode;
             if (charCode != 46 && charCode > 31    && (charCode < 48 || charCode > 57))    return false;
        });

       /*$("#hawb,#mawb,[id^=product_description]").keypress(function(e){*/
        $("#hawb,#mawb").keypress(function(e){
            var charval = $(this).val();
            var k = e.which;
            var ok = k >= 65 && k <= 90 || // A-Z
            k >= 97 && k <= 122 || // a-z
            k >= 48 && k <= 57 || (k == 44 || k == 8 || k==0) ; // 0-9

            if (!ok){
                e.preventDefault();
            }
        });
    

        //MsLstUtils.createCoordinatePicker('coordinates', 'incident-coordinate-check', 'incident-coordinate-pick');

         if($("#incident-coordinate-pick").length  > 0) {
               MsLstUtils.createBingCoordinatePicker('coordinates', 'incident-coordinate-check', 'incident-coordinate-pick');
          }
    },
    deleteAttachmentFile: function (id) {
        bootbox.confirm("Do you want to delete this file?", function(ok) {
                        if (ok) {
                            $('.current_' + id).hide();
                            $('input[name="current_file['+ id +']"]').val(0);
                        }
                    })
    },
    setUpIncidentTransportationForms: function () {
        MsLstUtils.createSingleDatePicker(MsLstIncidents.config.pickUpDateSelect);
        MsLstUtils.createTimePicker(MsLstIncidents.config.pickUpTimeSelect);
    },
    setUpIncidentsDisplay: function () {
    	 
        $('#incidents-list-form select,#incidents-list-form input').on('change', function () {
                     $('#incidents-list-form').trigger('submit');
          });

        $('#incidents-list-form input[name="incident_id"]').on('blur', function () {
           $('#incidents-list-form').trigger('submit');
        }).bind('keypress',function(e){
          var key = e.which;
          if(key == 13){
            $('#incidents-list-form').trigger('submit');
          }
        });


          $("input[name=imielist]").bind("keypress",function(e){
            var k = e.which;
            var ok = k >= 48 && k <= 57 || (k == 44 || k == 8 || k==0 || k==13) ; // 0-9 , comma (44), enter(13)

            if (!ok){
                e.preventDefault();
            }
        });

        /* Request for Closing incident by Incident owener/ LSP Supervisor */
        $(".request_close").on('click',function(){
           var id = $("input[name=incident_id]").val();
            bootbox.dialog({
              message : '<div class="row">
                              <div class="col-md-12" id="closure_div">
                                <form enctype="multipart/form-data" method="get" class="form-horizontal">
                                        <div class="row">
                                             <label for="risk" class="col-md-12 control-label" style="text-align:justify !important;">Incident closure requests should be made only when there is sufficient information in this incident record. We recommend that you add information in all fields as much as possible and available. Are you sure you want to request closure?</label>
                                        </div>
                                        <div class="form-group" >
                                          <div class="col-md-12">
                                             <textarea class="form-control"  cols="54" rows="3" name="request_comments" id="request_comments" maxlength="200"></textarea>
                                             <h6 id="count_message" class="pull-right">200 remaining</h6>
                                            </div>
                                        </div>
                                </form>
                              </div>
                        </div>',
              title : "Request for Closure",
              buttons : {
                success : {
                  label : "Yes",
                  callback:function(){
                     var comments = $("#request_comments").val().trim();
                      $.ajax({
                              url :'/incidents/request_closure',
                              type: "post",
                              data: "id="+id+"&state=request&comments="+comments,
                              success: function(data){
                                   window.location.href = '/incidents/'+id;
                                  console.log(data);
                              },
                              error:function(){
                                 bootbox.alert("Error:Please contact adminstrator for this issue!")
                              }
                      });
                     
                  }
                },
                main : {
                  label : "No"
                }
              }
            });
            
            var text_max = 200;
        	$('#request_comments').keyup(function(){
        		var tex_len = $(this).val().length;
        		var rem_len = text_max - tex_len;
        		$("#count_message").html(rem_len+" remaining");
        	});           
        });

        /* Reopen incident by Admin/Ms Supervisor*/
        $(".reopen_incident").on('click',function(){
           var id = $("input[name=incident_id]").val();
            bootbox.dialog({
              message : "Do you want to Re-open this Incident ?",
              title : "Request for Re-open",
              buttons : {
                success : {
                  label : "Yes",
                  callback:function(){
                      $.ajax({
                              url :'/incidents/request_closure',
                              type: "post",
                              data: "id="+id+"&state=open",
                              success: function(data){
                                  window.location.href = '/incidents/'+id;
                                  console.log(data);
                              },
                              error:function(){
                                 bootbox.alert("Error:Please contact adminstrator for this issue!")
                              }
                      });
                    
                  }
                },
                main : {
                  label : "No"
                }
              }
            });
           
        });

       /* Closing incident  by Admin/Ms Supervisor*/
       $(".close_incident").on('click',function(){
          var id = $("input[name=incident_id]").val();

           bootbox.dialog({
              message : 'Are you sure you want to close this Incident?',
              title : "Close Incident",
              buttons : {
                success : {
                  label : "Accept",
                  callback:function(){
                     var comments = "";
                       $.ajax({
                              url :'/incidents/request_closure',
                              type: "post",
                              data: "id="+id+"&closure_comments="+comments+"&state=close",
                              success: function(data){
                                  window.location.href = '/incidents/'+id;
                                  console.log(data);
                              },
                              error:function(){
                                 bootbox.alert("Error:Please contact adminstrator for this issue!")
                              }
                      });
                  }
                },
                main : {
                  label : "Deny",
                  callback:function(){
                     var comments = " because of insufficient or incomplete information";
                     
	                 $.ajax({
	                              url :'/incidents/request_closure',
	                              type: "post",
	                              data: "id="+id+"&closure_comments="+comments+"&state=deny",
	                              success: function(data){
	                                  window.location.href = '/incidents/'+id;
	                                  console.log(data);
	                              },
	                              error:function(){
	                                 bootbox.alert("Error:Please contact adminstrator for this issue!")
	                              }
	                 });
                    
                  }
                }
              }
            });
           
           
          
       })
  
        MsLstUtils.createSelect2s([
            {element: $('select[name="user[]"]')},
            {element: $('select[name="closure[]"]')},
            {element: $('select[name="customer[]"]')},
            {element: $('select[name="category[]"]')},
            {element: $('select[name="status[]"]')},
            {element: $('select[name="lsp[]"]')},
            {element: $('select[name="region[]"]')},
            {element: $('select[name="country[]"]')},
            {element: $('select[name="investigation[]"]')},
            {element: $('select[name="review[]"]')},
            {element: $('select[name="type_of_device[]"]')}
        ]);

        MsLstUtils.createDateRangePicker(MsLstIncidents.config.incidentsDateSelect, new Date(), function () {
            $('#incidents-list-form').trigger('submit');
        });
 
        MsLstIncidents.config.incidentsFilterResetButton.on('click', function () {
            MsLstIncidents.config.incidentsDateSelect.val('');
            MsLstUtils.resetSelect2s([
                $('select[name="user[]"]'),
                $('select[name="closure[]"]'),
                $('select[name="customer[]"]'),
                $('select[name="category[]"]'),
                $('select[name="status[]"]'),
                $('select[name="lsp[]"]'),
                $('select[name="region[]"]'),
                $('select[name="country[]"]'),
                $('select[name="review[]"]'),
                $('select[name="type_of_device[]"]')
            ]);
        });
 
        if($("#incidents-list thead").attr('id') == 'incident-head'){
            MsLstUtils.createDataTable(MsLstIncidents.config.incidentsList, 'incidents', [0], [[ 2, "desc" ]],'','',"rtip",true);
        }else{
            MsLstUtils.createDataTable(MsLstIncidents.config.incidentsList, 'factory incidents',[0], [[ 1, "desc" ]],'','',"rtip");
        }

          $('.incident-item td').live('click', function () {
            if($(this).parent('tr').data('item') == 'factory')
              window.location.href = 'factory/incidents/'+$(this).parent('tr').data('id');
            else
              window.location.href = '/incidents/' + $(this).parent('tr').data('id');

        });
 
        /*** Incident view Page Map **/
    

      

        MsLstUtils.setUpDeleteConfirmation("Are you sure you want to remove this incident?", '.incident-delete-button');
        MsLstUtils.setUpReviewNotification("Please add your comments below. They will be sent to the respective user.", '.incident-review-button', 'input[name="review_message"]');
        //MsLstUtils.setUpDeleteConfirmation("Are you sure you want to close this incident?", '.incident-close-button');
        $(".incident-close-button").click(function(event){
            var $form = $(this).closest('form');
            var formaction = $form.attr('action');
            var messagform = "<form accept-charset='UTF-8' enctype='multipart/form-data' action='"+formaction+"' id='closeIncidentForm' method='POST'><fieldset><label for='attachment'>Attachment</label><input type='hidden' value='PATCH' name='_method'><input type='file' id='attachment' name='attachment'><label for='description' style='width:100%;'>Description</label><textarea id='description' name='description' cols='54' rows='3' class='reviewComment'></textarea></fieldset></form>";
            event.preventDefault();
            bootbox.dialog({
                    title : "Are you sure you want to close this incident?",
                    message : messagform ,
                     buttons: {
                                success: {
                                    label: "Close",
                                    className: "btn-success",
                                    callback: function () {
                                        var des = $('textarea#description').val();
                                        var filename = $("input#attachment")[0].files[0];
                                        $("form#closeIncidentForm").trigger("submit");
                                    }
                                },
                                cancel: {
                                    label : "Cancel"
                                }
                            }
            });

            /*bootbox.prompt("Are you sure you want to close this incident?",function(results){
                if(results !== null){
                    $form.trigger("submit");
                }
            });*/
        });
        MsLstUtils.setUpDeleteConfirmation("Are you sure you want to open this incident?", '.incident-open-button');

        $("#new_incident_findings").on('click',function(event){

            bootbox.dialog({
                message: "<textarea class='form-control' name='newfindings' id='newfindings' maxlength='200'></textarea>" +
                		"<h6 class='pull-right' id='count_message'>200 remaining</h6>",
                title: "Add new investigative note for this incident",
                buttons: {
                    main: {
                        label: "Save",
                        className: "btn-primary",
                        callback: function() {
                        	var findings = $('#newfindings').val();
                            var incid    = $("#new_incident_findings").attr('alt');

                            $.post('/incidents/newfind',{'newfindings': findings,'Incid':incid ,'options':'add'},function(data){
                                //if(results == true){
                                    bootbox.dialog({
                                        message: "New investigative note added successfully.",
                                        buttons: {
                                        success: {
                                            label: "OK",
                                            className: "btn-success",
                                                callback: function() {
                                                    window.location.href = '/incidents/'+incid;
                                                }
                                            }
                                        }
                                    });
                                //}
                            });
                        }
                    }
                }
            });
        	var text_max = 200;
        	$('#newfindings').keyup(function(){
        		var tex_len = $(this).val().length;
        		var rem_len = text_max - tex_len;
        		$("#count_message").html(rem_len+" remaining");
        	});
        });
 
        $("#findingedit").live("click",function(event){
        	var rem_num = 200 - parseInt($('#newfindings'+$(this).attr('alt')).val().length);
                bootbox.dialog({
                    message: "<textarea class='form-control' name='newfindings' id='newfindings' maxlength='200' alt="+$(this).attr('alt')+">"+$('#newfindings'+$(this).attr('alt')).val()+"</textarea>" +
                              "<h6 class='pull-right' id='count_message'>"+rem_num+" remaining</h6>",
                    title: "Update the investigative note for this incident",
                    buttons: {
                        main: {
                            label: "Save",
                            className: "btn-primary",
                            callback: function() {
                                var findings = $('#newfindings').val();
                                var findid   = $("#newfindings").attr('alt');
                                var incid    = $("#incidentid").val()
                                MsLstUtils.startSpin();
                               $.post('/incidents/newfind',{'newfindings': findings,'Incid':findid ,'options':'update'},function(data){
                                //if(results == true){
                                    bootbox.dialog({
                                        message: "Investigative note updated successfully",
                                        buttons: {
                                        success: {
                                            label: "OK",
                                            className: "btn-success",
                                                callback: function() {
                                                    window.location.href = '/incidents/'+incid;
                                                }
                                            }
                                        }
                                    });
                                    MsLstUtils.stopSpin();
                                //}
                                });

                            }
                        }
                     }
                });
                var text_max = 200;
            	$('#newfindings').keyup(function(){
            		var tex_len = $(this).val().length;
            		var rem_len = text_max - tex_len;
            		$("#count_message").html(rem_len+" remaining");
            	});
        });
        
        $("#findingdelete").live("click",function(event){
        	 var findid   = $(this).attr('alt');
            bootbox.dialog({
            	message: "Are you sure you want to delete this investigative note?",
                title: "Delete the investigative note for this incident",
                buttons: {
                    success: {
                        label: "Yes",
                        className: "btn-primary",
                        callback: function() {
                            //var findid   = $(this).attr('alt');
                            var incid    = $("#incidentid").val()
                            
                            MsLstUtils.startSpin();
                            $.post('/incidents/newfind',{'Incid':findid ,'options':'delete'},function(data){
                            //if(results == true){
                                bootbox.dialog({
                                    message: "Investigative note deleted successfully",
                                    buttons: {
                                    success: {
                                        label: "OK",
                                        className: "btn-success",
                                            callback: function() {
                                               window.location.href = '/incidents/'+incid;
                                              
                                            }
                                        }
                                    }
                                });
                                MsLstUtils.stopSpin();
                            //}
                            });

                        }
                    },
                    main: {
                    	label : "No"
                    }
                 }
            });
    });
 
    $(".investigation_status").on('change',function(){
           
            bootbox.dialog({
                message: "Are you sure you want to change the investigation status?",
                buttons:{
                          success : {
                            label: "OK",
                            className: "btn-success",
                            callback: function(){
                              var inves_id = $(".investigation_status").val();
                              var inc_id = $("#incidentid").val();
                              //alert($(".investigation_status").val()+"#"+$("#incidentid").val());
                               MsLstUtils.startSpin();
                              $.post('/incident/update-investigation-status',{'inves_id':inves_id,'inc_id':inc_id},function(data){
                                 
                                  bootbox.dialog({ 
                                    message : "Investigation status changed successfully!",
                                     buttons:{
                                              success : {
                                                label: "OK",
                                                className: "btn-success"
                                              }
                                            }
                                    });
                                   MsLstUtils.stopSpin();
                              });
                            }
                          }
                }
            })
      });


	    if (MsLstIncidents.config.coordinates && MsLstIncidents.config.mapElement) {
      //  MsLstUtils.createMapByCoordinates(MsLstIncidents.config.coordinates, MsLstIncidents.config.mapElement);
       MsLstUtils.createBingMapByCoordinates(MsLstIncidents.config.coordinates, MsLstIncidents.config.mapElement);
      } 

    }
};

/**
 * Handlers for LSP create/edit and listing
 */
var MsLstLsp = {
    init: function () {
        MsLstLsp.setUp();
    },
    setUp: function () {
        MsLstLsp.setUpListingsPage();
    },
    setUpListingsPage: function () {
        MsLstUtils.setUpDeleteConfirmation("Are you sure you want to delete the selected LSP?", '.lsp-delete-button');
    }
};

/**
 * Handlers for questions create/edit and listing
 */
var MsLstQuestions = {
    init: function () {
        MsLstQuestions.config = {
            questionsFilterReset: $('#questions-filter-reset'),
            questionsList: $('#questions-list'),
        };
        MsLstQuestions.setUp();
    },
    setUp: function () {
        MsLstQuestions.setUpQuestionsForm();
        MsLstQuestions.setUpQuestionsListing();
    },
    setUpQuestionsForm: function () {
        MsLstUtils.createSelect2s([
            {element: $('select[name="availabilities"]'), options: { placeholder: "Select availability" }}
        ]);
        if($("#availability").val() == 4 && $("#availability").val()!='')
        {     
          $(".category").hide();
          $(".activities").hide();
          $("#audit_group").hide();
          $("#p_r_group").show();
        $("input:checkbox").prop('checked',false);
        }
        else if($("#availability").val() == 5 && $("#availability").val()!='')
        {
            $(".certifications").hide();
            $(".mandatory").hide();
            $(".archived").hide();
            $(".category").show();
            $(".activities").show();
            $("input:checkbox").prop('checked',false);
        }
        else
        { 
            $(".category").hide();
            $("#p_r_group").show();
            $("#audit_group").show();
            $(".activities").hide(); 
            $("input:checkbox").prop('checked',false);
        }

        $("#availability").on('change',function(){
          if($(this).val() == 4){
            $(".category").hide();
            $("#audit_group").hide();
            $("#p_r_group").show();
            $(".activities").hide();  
             $("input:checkbox").prop('checked',false);
          }else if($(this).val() == 5){
            $("#audit_group").hide();
            $("#p_r_group").hide();
            $(".mandatory").hide();
            $(".archived").hide();
            $(".activities").show();
			$(".category").show();
            $("input:checkbox").prop('checked',false);
          }else{
            $(".category").hide();
            $("#p_r_group").hide();
            $("#audit_group").show();
            $(".activities").hide(); 
            $("input:checkbox").prop('checked',false);
          }
        });
    },
    setUpQuestionsListing: function () {
        $('#questions-list-form select').on('change', function () {
            $('#questions-list-form').trigger('submit');
        });

        MsLstUtils.createSelect2s([
            {element: $('select[name="availability[]"]'),options:{ maximumSelectionSize: 1 }},
            {element: $('select[name="category[]"]')},
            {element: $('select[name="certification[]"]')},
            {element: $('select[name="mandatory[]"]')}
        ]);

        MsLstQuestions.config.questionsFilterReset.on('click', function () {
            MsLstUtils.resetSelect2s([
                $('select[name="availability[]"]'),
                $('select[name="category[]"]'),
                $('select[name="certification[]"]'),
                $('select[name="mandatory[]"]')
            ]);

            window.location.href = '/questions';
        });

        if($('select[name="availability[]"]').val()==5)
          MsLstUtils.createDataTable(MsLstQuestions.config.questionsList, 'questions', [ 3 ], [[ 0, "asc" ]],'','',"rtip");
        else if($('select[name="availability[]"]').val()==4)
          MsLstUtils.createDataTable(MsLstQuestions.config.questionsList, 'questions', [ 8 ], [[ 2, "asc" ]],'','',"rtip");
        else if($('select[name="category[]"]').val()==4)
          MsLstUtils.createDataTable(MsLstQuestions.config.questionsList, 'questions', [ 8 ], [[ 2, "asc" ]],'','',"rtip");
        else if($('select[name="certification[]"]').val()==11)
          MsLstUtils.createDataTable(MsLstQuestions.config.questionsList, 'questions', [ 8 ], [[ 2, "asc" ]],'','',"rtip");
        else
        MsLstUtils.createDataTable(MsLstQuestions.config.questionsList, 'questions', [ 5 ], [[ 0, "asc" ]],'','',"rtip");

        MsLstUtils.setUpDeleteConfirmation("Are you sure you want to delete the selected Question?", '.question-delete-button');
		
 	
    }
};

/**
 * Handlers for region create/edit and listing
 */
var MsLstRegions = {
    init: function () {
        MsLstRegions.setUp();
    },
    setUp: function () {
        MsLstRegions.setUpListingsPage();
    },
    setUpListingsPage: function () {
        MsLstUtils.setUpDeleteConfirmation("Are you sure you want to delete the selected region?", '.region-delete-button');
        MsLstUtils.getCollapse();
    }
};

/**
 *
 * Handlers for Suppliers listing
 **/
var MsLstSuppliers = {
  init: function (supply) {  
    MsLstSuppliers.config = {
      suppliersLst : $('#supplierslist'),
      countrySelect : $('select[name="country"]'),
      regionSelect : $('select[name="region"]'),
      suppliersFilterResetButton: $('#supplier-filter-reset'),
      regions : null,
      coordinates: null,
      mapElement: null,
      supplier_handle : $("#supplier_handle"),
      assesed_pr : $("#assesed_pr"),
      leak_risk_analysis_tab : $("#leak_risk_analysis_tab"),
      leak_incident_history_tab : $("#leak_incident_history_tab"),
      incident_history_remove : $(".incident_history_remove"),
      addrisk : $("#addrisk"),
      risk_mitigation_manual : $(".risk_mitigation_manual"),
      manual_risk_delete : $(".manual_risk_delete"),
      addnewincident : $("#addnewincident"),
      incident_history : $(".incident_history"),
      SupplierAnswerSelects :$(".supplier-form-tabs select"),
      busines_activity : $("#busines_activity"),
      busines_assets   : $("#business_assets"),
      business_supp_lob : $("#business_supp_lob"),
      addactivity      : $("#addactivity"),
      addassests       : $("#addassests"),
      ActivitySelects  : $(".activity_row select"),
      AssetsSelects    : $(".assests_row select"),
      inc_hist_json    : null,
      leak_prev_json   : null,
      business_risk : null,
      business_actions : null,
      leak_risk_analysis : null,
    };
    $.extend(MsLstSuppliers.config, supply);
    MsLstSuppliers.setUp();
    },
  setUp: function() {
    MsLstSuppliers.setUpListingPage(); 
    MsLstSuppliers.setUpSupplierdisplay();
    MsLstSuppliers.setUpSupplierForms();
  },
    setUpListingPage: function(){
    
    $('#suppliers-list-form select').on('change', function () {
           $('#suppliers-list-form').trigger('submit');
        });

       $('#suppliers-list-form input[name="vendor_number"],#suppliers-list-form input[name="keywords"]').on('blur', function () {
           $('#suppliers-list-form').trigger('submit');
        }).bind('keypress',function(e){
          var key = e.which;
          if(key == 13){
            $('#suppliers-list-form').trigger('submit');
          }
        });

        MsLstUtils.createSelect2s([
            {element: $('select[name="user[]"]')},
            {element: $('select[name="vendor_name[]"]')},
            {element: $('select[name="category[]"]')},
            {element: $('select[name="region[]"]')},
            {element: $('select[name="country[]"]')}
        ]);

        /*MsLstUtils.createDateRangePicker(MsLstIncidents.config.incidentsDateSelect, new Date(), function () {
            $('#sitemasters-list-form').trigger('submit');
        });*/

        MsLstSuppliers.config.suppliersFilterResetButton.on('click', function () {
            //MsLstIncidents.config.incidentsDateSelect.val('');
            MsLstUtils.resetSelect2s([
                $('select[name="user[]"]'),
                $('select[name="vendor_name[]"]'),
                $('select[name="category[]"]'),
                $('select[name="region[]"]'),
                $('select[name="country[]"]')
            ]);
        });
  
    MsLstUtils.createDataTable(MsLstSuppliers.config.suppliersLst, 'suppliers',[ 6 ], [[ 1, "asc" ]],'','',"rtip");    
    $('.supplier-item td').live('click', function () {
            window.location.href = '/suppliers/' + $(this).parent('tr').data('id');
    });
  },
    setUpSupplierdisplay:function () {   
    $( window ).bind("resize", function(){
      var windowwidth =$(window).width();
      var panelwidth=$('#supplierviewpannel').width();
      var newpanelwidth=windowwidth-(panelwidth/10);
      if(windowwidth<panelwidth)
      $('#supplierviewpannel').width(newpanelwidth);
        });  
  },
  setUpSupplierForms: function () {

    /* Start Leak Prevention assement */
    //$("select[name^=assets]").select2({placeholder:'Select Assets',allowClear: true});
    //$("select[name^=activity]").select2({placeholder:'Select Business Activity',allowClear: true})
    $(".save-summary-leak-desc").hide();
    $(".leak_prevention_assesment").hide();

     var user_id = $("input[name=supplier_user_id]").val();
     var login_user_id = $("input[name=login_user_id]").val();
      
    /*Leak risk Analysis Existing added item listing*/
    if(!$.isEmptyObject(MsLstSuppliers.config.leak_risk_analysis) && (user_id == login_user_id)){

        $.each(MsLstSuppliers.config.leak_risk_analysis,function(i,n){
            var activ = JSON.parse(JSON.stringify(MsLstSuppliers.config.business_assets));
            var assets = null,assets_grp = null;
            var nm = $('.bus_activity_sel'+n.id+'').attr('name');
            var id = nm.replace('activity','');
            $("select[name=assets"+id+"]").empty();
         
            var selected_asset = JSON.parse(n.asset_id);

            if($('.bus_activity_sel'+n.id+'').val().trim() != '') {
                 $.each(activ[$('.bus_activity_sel'+n.id+'').val()],function(i,n){

                   assets_grp = $('<optgroup></optgroup>').attr('label',i);
                   assets = '';
                  $.each(n,function(i_id,n_val){
                   

                    if($.inArray(i_id,selected_asset) !== -1){
                        assets+="<option value='"+i_id+"' selected='selected' >"+n_val+"</option>";
                    }else{
                       assets+="<option value='"+i_id+"'  >"+n_val+"</option>";
                    }

                     $('select[name=assets'+id+']').select2("data", { id: i_id, text: n_val },true);

                  });

                   assets_grp = assets_grp.append(assets);
                    /*assets = $('<option></option>').
                             attr('value',i).
                             text(n);
                            
                    if($.inArray(i,selected_asset) !== -1){
                       assets = assets.attr('selected','selected');
                    }

                    $('select[name=assets'+id+']').select2("data", { id: i, text: n },true);*/
                    $("select[name=assets"+id+"]").append(assets_grp);
                    $('select.selectpicker').selectpicker('refresh');
                 });
            }/**/

       });

    }
   
     
    MsLstUtils.createBootstrapSwicth(MsLstSuppliers.config.supplier_handle, {onText: "Yes", offText: 'No', size: 'normal'});
    MsLstUtils.createBootstrapSwicth(MsLstSuppliers.config.assesed_pr, {onText: "Yes", offText: 'No', size: 'normal'});
    MsLstUtils.createDataTable(MsLstSuppliers.config.leak_incident_history_tab,'Incidents',[], [],'','',"rtip");
    MsLstUtils.createDataTable(MsLstSuppliers.config.leak_risk_analysis_tab,'Risk Items',[], [],'','',"rtip");
    
     /*MsLstSuppliers.config.supplier_handle.on('switchChange.bootstrapSwitch',function(event,state){
        if(state == true) {
          $(".leak_prevention_assesment").show();
        }else if(state == false){
          $(".leak_prevention_assesment").hide();
          $("#summary").val("Not in Scope");
        }
    });*/

    $(".leak_summary_desc").on('click',function(){
       $(".save-summary-leak-desc").show();
    }).on('blur',function(){
        if($(this).val() != ''){
           $(".save-summary-leak-desc").show();
         }else{
           $(".save-summary-leak-desc").hide();
         }
    });

    $(".save-summary-leak-desc").on('click',function(){
         var sumary = $(".leak_summary_desc").val();
         var sid = $("input[name=supplier_id]").val();
          $.ajax({
                                        url:'/supplier/leakpreventionstatus',
                                        type: "post",
                                        data: "sumary="+sumary+"&option=save&sid="+sid,
                                        success : function(data){
                                          console.log("uploaded");
                                           bootbox.dialog({
                                              message: "Summary has been saved successfully.",
                                              buttons: {
                                              success: {
                                                  label: "OK",
                                                  className: "btn-success" 
                                                  }
                                              }
                                             });
                                          window.location.reload(); 
                                        },
                                        error : function(){
                                          console.log("Not uploaded");
                                        }
                                      });
    });




    MsLstSuppliers.config.addrisk.on('click',function(){
      var  role = $("input[name='role']").val();
      var  sid =  $("input[name='supplier_id']").val();
      var  user_id = $("input[name=supplier_user_id]").val();
      var  extra_options = '';
      if(role == 'PM') {
          extra_options = '<div class="form-group"> ' +
                            '<label class="col-md-4 control-label" for="Risk mitigation">Verified:</label> ' +
                            '<div class="col-md-7"> ' +                    
                             '<select name="verified_action" id="verified_action" class="form-control"><option value="NA">N/A</option><option value="yes">Yes</option><option value="no">No</option></select>'+
                            '</div></div>' ;
      }

      var options = {
        title : 'Add New Risk',
        message: '<div class="row new_risk_div">  ' +
                    '<div class="col-md-12"> ' +
                    '<form class="form-horizontal" method="post" enctype="multipart/form-data"> ' +
                    '<div class="form-group" id="risk_div"> ' +
                    '<label class="col-md-4 control-label" for="risk">Risk</label> ' +
                    '<div class="col-md-7"> ' +
                    '<input id="risk" name="risk" type="text" placeholder="Risk" class="form-control input-md"> ' +
                    '</div></div>' +
                    '<div class="form-group" id="action_div"> ' +
                    '<label class="col-md-4 control-label" for="Action">Action</label> ' +
                    '<div class="col-md-7"> ' +
                    '<input id="needaction" name="needaction" type="text" placeholder="Need Action" class="form-control input-md"> ' +
                    '<textarea id="action_description" name="action_description" placeholder="Description" class="form-control custom-control" rows="3" cols="3" style="resize:none"></textarea>'+
                    '</div></div>' +
                    '<div class="form-group" id="risk_action_div"> ' +
                    '<label class="col-md-4 control-label" for="Action">Status</label> ' +
                    '<div class="col-md-7"> ' +
                    '<select name="risk_action" id="risk_action" class="form-control" ><option value="Not Started" >Not Started</option><option value="In Progress" >In Progress</option></select>'+
                    '</div></div>' +
                    '<div class="form-group" id="upload_msg"> ' +
                    '<label class="col-md-4 control-label" >&nbsp;</label> ' +
                    '<div class="col-md-7"> ' +
                    'If you want to add multiple files then please zip or rar them together'+
                    '</div></div>' +
                    '<div class="form-group" id="pic_div"> ' +
                    '<label class="col-md-4 control-label" for="Risk mitigation">File:</label> ' +
                    '<div class="col-md-7"> ' +                    
                    '<input type="file" name="leak_file" id="pic">'+
                    '<input type="hidden" name="addtype" value="new">'+  
                    '</div></div>' + extra_options +
                    '</form> </div></div>',
        buttons : {
                    success: {
                        label: "Save",
                        className: "btn-success",
                        callback: function($form){

                                var risk = $("#risk").val();
                                var action = $("#needaction").val();
                                var action_description = $("#action_description").val();
                                var status = $("#risk_action").val();
                                var addtype = $("input[name=addtype]").val();
                               
                                var form_data = new FormData;

                              

                                if($("input[type='file']")[0].files[0] !=""){
                                  form_data.append('file',$("input[type='file']")[0].files[0]);
                                }

                                form_data.append('sid',sid);
                                form_data.append('risk',risk);
                                form_data.append('action',action);
                                form_data.append('action_description',action_description);
                                form_data.append('option','add');
                                form_data.append('status',status);
                                form_data.append('user_id',user_id);
                                form_data.append('addtype',addtype);

                                var chk_ary = ['risk','needaction'];

                                 
                                for(var i=0;i<chk_ary.length;i++){
                                  validation_incident(chk_ary[i]);
                                }

                                if($('.new_risk_div').find('.has-error').length > 0){
                                  return false;
                                }

                                MsLstUtils.startSpin();
                                $.ajax({
                                        url:'/supplier/leakriskanalysis/add',
                                        processData: false, // Important!
                                        contentType: false, // Important!
                                        type: "post",
                                        data: form_data,
                                        success : function(data){
                                          console.log("uploaded");
                                          window.location.reload(); 
                                        },
                                        error : function(){
                                          console.log("Not uploaded");
                                        }
                                      });
                              }
                    },
                     main: {
                                                label: "Cancel",
                                                className: "btn-default",
                                                callback: function() {
                                                  
                                                }
                            }
                  }
      };
      bootbox.dialog(options);

      
    });


      MsLstSuppliers.config.risk_mitigation_manual.on('click',function(){
        
         var id = $(this).closest('td').attr('data-id').trim();
         var sid = $("input[name=supplier_id]").val();
         var user_id = $("input[name=supplier_user_id]").val();
         var login_user_id = $("input[name=login_user_id]").val();
         var datype = '', statutype = '';
         var predefined = '' ,upload_files = '-' , action_nm='' , action_desc = '' , addtype = 'new',upload_msg='';
 
         if(user_id != login_user_id) statutype = 'disabled="disabled"';
         
          var json_item = $(MsLstSuppliers.config.leak_prev_json).filter(function(i,n){
             return n.id  === id;
          });

          if($(this).closest('td').attr('data-type').trim() == 'auto' || user_id != login_user_id) { datype = 'disabled="disabled"';   addtype = 'predefined'; }
           
        

          console.log(json_item);
           
          if(json_item[0]['leak_id'] != null){

              datype = 'disabled="disabled"';
              predefined = '<div class="form-group"> ' +
                            '<label class="col-md-4 control-label" for="businessactivity">Business Activity </label> ' +
                            '<div class="col-md-7"> ' +
                             '<input class="form-control input-md" type=text disabled=disabled value="'+MsLstSuppliers.config.business_activity[parseInt(json_item[0]['leak_risk_analysis']['activity_id'])]+'">' +
                            '</div>
                            </div>';
                    /*        '<div class="form-group"> ' +
                            '<label class="col-md-4 control-label" for="assets">Assets</label> ' +
                            '<div class="col-md-7"> ' +
                            json_item[0]['risk'] +
                            '</div></div>';*/
                 /*Action Name*/           
                 var div_action = '<div id="s2id_autogen1" class="select2-container select2-container_risk select2-container-multi form-control"><ul class="select2-choices">';
                 var div_action_li = '<li class="select2-search-choice"><div class="label label-primary">'+json_item[0]['action_name']+'</div></li>'; 

                 /* $.each(JSON.parse(json_item[0]['action_name']),function(i,n){
                      div_action_li+='<li class="select2-search-choice"><div class="label label-primary">'+n+'</div></li>';
                  });*/

                 div_action = div_action+div_action_li+'</ul></div>';  

                 /*Action Description*/
                  var div_action_des = '<div id="s2id_autogen1" class="select2-container select2-container_risk  select2-container-multi form-control"><ul class="select2-choices">';
                  var div_action_des_li = '<li class="select2-search-choice"><div class="action_des_alert action_des-info">'+json_item[0]['action_description']+'</div></li>'; 

                  /*$.each(JSON.parse(json_item[0]['action_description']),function(i,n){
                      div_action_des_li+='<li class="select2-search-choice"><div class="action_des_alert action_des-info">'+n+'</div></li>';
                  });*/

                 div_action_des = div_action_des+div_action_des_li+'</ul></div>'; 


                 action_nm = div_action;
                 action_desc = div_action_des;
                 addtype = 'predefined';
            }else{
                action_nm = '<input id="needaction" name="needaction" type="text" placeholder="Need Action" value="'+json_item[0]['action_name']+'" class="form-control input-md"  '+datype+' >';
                action_desc = '<textarea id="action_description" name="action_description" placeholder="Description" class="form-control custom-control" rows="3" cols="3" style="resize:none" '+datype+'>'+json_item[0]['action_description']+'</textarea>';
            } 

            action_desc+="<textarea id='action_comment_detail' name='action_comment_detail' placeholder='Detailed description on how the action is completed'></textarea>";
            
            if(json_item[0]['file_name'] != null){
              upload_files = '<a href="/suppliers/download/'+id+'/'+sid+'/leak_prevention">'+json_item[0]['file_description']+"</a>";
            }
            
         var  role = $("input[name='role']").val();
         var options = {
              title : 'Edit Risk',
              message: '<div class="row">  ' +
                          '<div class="col-md-12"> ' + 
                          '<form class="form-horizontal" method="get" enctype="multipart/form-data"> ' + predefined +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="risk">Risk</label> ' +
                          '<div class="col-md-7"> ' +
                          '<input id="risk" name="risk" type="type"  placeholder="Risk"  value="'+json_item[0]['risk']+'" class="form-control input-md"  '+datype+' > ' +
                          '</div></div>' +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Action">Action</label> ' +
                          '<div class="col-md-7"> '
                          +action_nm+
                          action_desc+
                          '</div></div>' +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Action">Status</label> ' +
                          '<div class="col-md-7"> ' +
                          '<select name="risk_action" id="risk_action" class="form-control" ><option value="Not Started" >Not Started</option><option value="In Progress" >In Progress</option><option value="Completed">Completed</option></select>'+
                          '</div></div>' +
                          '<div class="form-group field-success" id="upload_msg"> ' +
                          '<label class="col-md-4 control-label" >&nbsp;</label> ' +
                          '<div class="col-md-7"> ' +
                          'If you want to add multiple files then please zip or rar them together'+
                          '</div></div>' +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Risk mitigation">File:</label> ' +
                          '<div class="col-md-7"> ' +                    
                          '<input type="file" name="file" id="pic">'+ upload_files +
                          '<input type="hidden" name="addtype" value="'+addtype+'">'+  
                          '</div></div>' +                          
                          '</form> </div></div>',
              buttons : {
                          success: {
                              label: "Update",
                              className: "btn-success",
                              callback: function($form){
                                var risk = $("#risk").val();
                                var action = $("#needaction").val();
                                var action_description = $("#action_description").val();
                                var status = $("#risk_action").val();
                                var addtype = $("input[name=addtype]").val();
                                var form_data = new FormData;
                                form_data.append('file',$("input[type='file']")[0].files[0]);
                                form_data.append('id',id);
                                form_data.append('risk',risk);
                                form_data.append('action',action);
                                form_data.append('action_description',action_description);
                                form_data.append('option','edit');
                                form_data.append('status',status);
                                form_data.append('user_id',user_id);
                                form_data.append('addtype',addtype);

                                
                                MsLstUtils.startSpin();
                                $.ajax({
                                        url:'/supplier/leakriskanalysis/edit',
                                        processData: false, // Important!
                                        contentType: false, // Important!
                                        type: "post",
                                        data: form_data,
                                        success : function(data){
                                          console.log("uploaded");
                                          window.location.reload();
                                        },
                                        error : function(){
                                          console.log("Not uploaded");
                                        }
                                      });

                              }
                          },
                           main: {
                                                label: "Cancel",
                                                className: "btn-default",
                                                callback: function() {
                                                  
                                                }
                                 }
                        }

            };
            // $.extend(options,predefined);

            var verification_done = '',risk_status_supservisor = '', supervisor_upload_option = '';

            if(json_item[0]['verified_date'] != null){
              verification_done = '<div class="form-group"> ' +
                          '<div class="col-md-2">&nbsp;</div> '+
                          '<label class="col-md-10 control-label" for="Risk mitigation">Modified on: '+json_item[0]['verified_date']+' UTC by '+json_item[0]['user']['first_name']+" "+json_item[0]['user']['last_name']+' </label> ' +
                          '</div>';
                }            


 
            if(user_id == login_user_id){
                  risk_status_supservisor = '<select name="risk_action" id="risk_action" class="form-control" ><option value="Not Started" >Not Started</option><option value="In Progress" >In Progress</option><option value="Completed">Completed</option></select>';
                  supervisor_upload_option = '<input type="file" name="file" id="pic">';
                  upload_msg = '<div class="form-group field-success" id="upload_msg"> ' +
                          '<label class="col-md-4 control-label" >&nbsp;</label> ' +
                          '<div class="col-md-7"> ' +
                          'If you want to add multiple files then please zip or rar them together'+
                          '</div></div>';
            }else {
                  risk_status_supservisor = '<input id="risk_action" name="risk_action" type="text" placeholder="Status" value="'+json_item[0]['status']+'" class="form-control input-md"  '+datype+' >';
               
            }

            var PMoptions = {
              title : 'Edit Risk',
              message: '<div class="row">  ' +
                          '<div class="col-md-12"> ' +
                          '<form class="form-horizontal"> ' + predefined +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="risk">Risk</label> ' +
                          '<div class="col-md-7"> ' +
                          '<input id="risk" name="risk" type="text" placeholder="Risk" value="'+json_item[0]['risk']+'" class="form-control input-md" '+datype+'> ' +
                          '</div></div>' +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Action">Action</label> ' +
                          '<div class="col-md-7"> '
                          +action_nm+
                          action_desc+
                          '</div></div>' +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Action">Status</label> ' +
                          '<div class="col-md-7"> ' +
                          risk_status_supservisor +
                          '</div></div>' +
                          '<div class="form-group"> ' +
                            '<label class="col-md-4 control-label" for="Risk mitigation">Verified:</label> ' +
                            '<div class="col-md-7"> ' +                    
                            '<select name="verified_action" id="verified_action" class="form-control"><option value="n/a">N/A</option><option value="yes">Yes</option><option value="no">No</option></select>'+
                          '</div></div>' +
                          upload_msg +
                           '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Risk mitigation">File:</label> ' +
                          '<div class="col-md-7"> ' +                    
                          supervisor_upload_option + upload_files +
                          '<input type="hidden" name="addtype" value="'+addtype+'">'+  
                          '</div></div>' + 
                          verification_done+
                          '</form> </div></div>',
              buttons : {
                          success: {
                              label: "Update",
                              className: "btn-success",
                              callback: function($form){
                                var risk = $("#risk").val();
                                var action = $("#needaction").val();
                                var verified = $("#verified_action").val();
                                var addtype = $("input[name=addtype]").val();
                                var status = $("#risk_action").val();

                                var action_description = $("#action_description").val(); 

                                var form_data = new FormData;
                                form_data.append('file',$("input[type='file']")[0].files[0]);
                                form_data.append('id',id);
                                form_data.append('risk',risk);
                                form_data.append('action',action);
                                form_data.append('action_description',action_description);
                                form_data.append('option','edit');
                                form_data.append('status',status);
                                form_data.append('user_id',user_id);
                                form_data.append('addtype',addtype);
                                form_data.append('verified',verified);


                                MsLstUtils.startSpin();
                                /*$.post('/supplier/leakriskanalysis/edit',{id:id,option:'edit',risk:risk,action:action,verified:verified,user_id:user_id,addtype:addtype,status:status})
                                .done(function(data){
                                //  window.location.reload();
                                });*/

                                  $.ajax({
                                        url:'/supplier/leakriskanalysis/edit',
                                        processData: false, // Important!
                                        contentType: false, // Important!
                                        type: "post",
                                        data: form_data,
                                        success : function(data){
                                          console.log("uploaded");
                                          window.location.reload();
                                        },
                                        error : function(){
                                          console.log("Not uploaded");
                                        }
                                      });
                              }
                          },
                          main: {
                                                label: "Cancel",
                                                className: "btn-default",
                                                callback: function() {
                                                  
                                                }
                                 }
                        }
            }; 

            if(role == 'PM') {
              options = PMoptions;
            } 

            bootbox.dialog(options);

            if(role == 'PM') {
                $("#verified_action option[value='"+json_item[0]['verified_status']+"']").attr('selected','selected');
                if(user_id == login_user_id){
                   $("#risk_action option[value='"+json_item[0]['status']+"']").attr('selected','selected');
                }
            }else{
                $("#risk_action option[value='"+json_item[0]['status']+"']").attr('selected','selected');
            }
      });


      function BootboxContent(){
        var frm_str = '<div class="row incident_history_div">  ' +
                                '<div class="col-md-12"> ' +
                                '<form class="form-horizontal" method="post" > ' +
                                '<div class="form-group" id="title_div"> ' +
                                '<label class="col-md-4 control-label" for="Title">Title</label> ' +
                                '<div class="col-md-7"> ' +
                                '<input id="title" name="title" type="text" placeholder="Title" class="form-control input-md"> ' +
                                '</div></div>' +
                                '<div class="form-group" id="incident_date_div"> ' +
                                '<label class="col-md-4 control-label" for="Date">Date</label> ' +
                                '<div class="col-md-7"> ' +
                                '<input id="incident_date" name="incident_date" type="text" placeholder="Date" class="form-control input-md"> ' +
                                '</div></div>' +
                                '<div class="form-group"  id="type_div"> ' +
                                '<label class="col-md-4 control-label" for="Type">Type</label> ' +
                                '<div class="col-md-7"> ' +
                                '<select name="type" id="type" class="form-control"><option value="a">A</option><option value="b">B</option><option value="c">C</option><option value="d">D</option></select>' +
                                '</div></div>' +
                                '<div class="form-group" id="root_cause_div"> ' +
                                '<label class="col-md-4 control-label" for="Root Cause">Root Cause</label> ' +
                                '<div class="col-md-7"> ' +
                                '<textarea id="root_cause" name="root_cause" placeholder="Root Cause" class="form-control" rows="3" cols="2" style="resize:none"></textarea>' +
                                '</div></div>' +
                                '<div class="form-group" id="corrective_action_title_div"> ' +
                                '<label class="col-md-4 control-label" for="Risk mitigation">Corrective Action:</label> ' +
                                '<div class="col-md-7"> ' +
                                '<input id="corrective_action_title" name="corrective_action_title" type="text" placeholder="Title" class="form-control input-md"> ' +
                                '<textarea id="corrective_action_description" name="corrective_action_description" placeholder="Description" class="form-control custom-control" rows="3" cols="3" style="resize:none"></textarea>'+
                                '</div></div>' +
                                '<div class="form-group" id="supplier_contact_div"> ' +
                                '<label class="col-md-4 control-label" for="Need Action">Supplier Contact</label> ' +
                                '<div class="col-md-7" >' +
                                '<input id="supplier_contact" name="supplier_contact" type="text" placeholder="Supplier Contact" class="form-control input-md"> ' +
                                '</div></div>'+
                                '<div class="form-group" id="deadline_date_div"> ' +
                                '<label class="col-md-4 control-label" for="Need Action">Deadline Date</label> ' +
                                '<div class="col-md-7">' +
                                '<input id="deadline_date" name="deadline_date" type="text" placeholder="Deadline Date" class="form-control input-md"> ' +
                                '<input type="hidden" name="addtype" value="predefined">'+
                                '</div></div>'+
                                '</form> </div></div>';

             /* var object = $('<div/>').html(frm_str).contents();

              object.find('date').daterangepicker({
                                                  format: 'YYYY-MM-DD',
                                                  singleDatePicker: true,
                });*/
              return frm_str;
      }



      MsLstSuppliers.config.addnewincident.on('click',function(){


          var  sid =  $("input[name='supplier_id']").val();
          var options = {
                       title : 'Leak incident report',
                       message: BootboxContent,
                      buttons : {
                                  success: {
                                      label: "Save",
                                      className: "btn-success",
                                      callback: function($form){
                                            var title  = $("#title").val();
                                            var incident_date = $("#incident_date").val();
                                            var type  =  $("#type").val();
                                            var root_cause =  $("#root_cause").val();
                                            var corrective_action_title =  $("#corrective_action_title").val();
                                            var corrective_action_description =  $("#corrective_action_description").val();
                                            var deadline_date =  $("#deadline_date").val();
                                            var supplier_contact = $("#supplier_contact").val();
                                            var addtype =  $("input[name=addtype]").val();

                                            var chk_ary = ['incident_date','title','type','root_cause','corrective_action_title','supplier_contact','deadline_date']

                                            for(var i=0;i<chk_ary.length;i++){
                                              validation_incident(chk_ary[i]);
                                            }

                                            

                                            if($('.incident_history_div').find('.has-error').length > 0){
                                                 return false;
                                            } 

                                            MsLstUtils.startSpin();
                                            $.post('/supplier/leakincidenthistory',{sid:sid,option:'add',title:title,incident_date:incident_date,type:type,root_cause:root_cause,corrective_action_title:corrective_action_title,corrective_action_description:corrective_action_description,deadline_date:deadline_date,supplier_contact:supplier_contact,addtype:addtype})
                                              .done(function(data){
                                                window.location.reload();
                                              });
                                  },
                                   main: {
                                                label: "Cancel",
                                                className: "btn-default",
                                                callback: function() {
                                                  
                                                }
                                          }
                                  }

                                }
      };
       $(".incident_history_div input").attr('disabled','disabled');
      
        bootbox.dialog(options);

        $("#incident_date").daterangepicker({ singleDatePicker: true,
                                                             format: 'YYYY-MM-DD',
                                                             maxDate: new Date(),
                                                             startDate : new Date(),
                                                          });

        $("#deadline_date").daterangepicker({ singleDatePicker: true,
                                                             format: 'YYYY-MM-DD',
                                                             startDate : new Date(),
                                                             minDate :  new Date(),
                                                          });


          $('input#deadline_date,input#incident_date').keydown(function(e) {
             e.preventDefault();
             return false;
          });



        
      });

       function validation_incident(id){

          if($("#"+id).val().trim() == null || $("#"+id).val().trim() == ""){
              $("#"+id).attr('placeholder', 'Please enter '+id.replace(/_/g,' ')); 
              $("#"+id+"_div").addClass('has-error');
          }else{
             $("#"+id+"_div").removeClass('has-error');
          }
        } 

        MsLstSuppliers.config.incident_history.live('click',function(){
          
          var user_id = $("input[name=supplier_user_id]").val();
          var login_user_id = $("input[name=login_user_id]").val();
          var str = String($(this).closest('tr').attr('data-id'));

          var asi = $(MsLstSuppliers.config.inc_hist_json).filter(function(i,n){
               return n.id === str;
          });
          
            for (var i=0;i<asi.length;i++){
                var title = (asi[i].title != "" || asi[i].title != undefined) ? asi[i].title : "" ;
                var incident_date = asi[i].incident_date ? asi[i].incident_date : "" ;
                var incident_type = asi[i].incident_type ? asi[i].incident_type : "" ;
                var root_cause = asi[i].root_cause ? asi[i].root_cause : "" ;
                var corrective_action_title = asi[i].corrective_action_title ? asi[i].corrective_action_title : "" ;
                var corrective_action_action = asi[i].corrective_action_description ? asi[i].corrective_action_description : "" ;
                var supplier_contact = asi[i].supplier_contact ? asi[i].supplier_contact : "" ;
                var deadline_date = asi[i].deadline_date ? asi[i].deadline_date : "" ;
                var modified_date =asi[i].created_at ? asi[i].created_at : asi[i].updated_at;
                var created_by = $("input[name=supplier_user_name]").val();
            }

                    var options = {
                             title : 'Edit Leak incident report',
                             message: '<div class="row incident_history_div">  ' +
                                      '<div class="col-md-12">  ' +
                                      '<form class="form-horizontal"> ' +
                                      '<div class="form-group" id="title_div"> ' +
                                      '<label class="col-md-4 control-label" for="Title">Title</label> ' +
                                      '<div class="col-md-7"> ' +
                                      '<input id="title" name="title" type="text" placeholder="Title" value="'+title+'" class="form-control input-md"> ' +
                                      '</div></div>' +
                                      '<div class="form-group" id="incident_date_div"> ' +
                                      '<label class="col-md-4 control-label" for="Date">Date</label> ' +
                                      '<div class="col-md-7"> ' +
                                      '<input id="incident_date" name="incident_date" type="text" placeholder="Date" value="'+incident_date+'" class="form-control input-md"> ' +
                                      '</div></div>' +
                                      '<div class="form-group" id="incident_type_div"> ' +
                                      '<label class="col-md-4 control-label" for="Type">Type</label> ' +
                                      '<div class="col-md-7"> ' +
                                      '<select name="incident_type" id="incident_type" class="form-control"><option value="a">A</option><option value="b">B</option><option value="c">C</option><option value="d">D</option></select>' +
                                      '</div></div>' +
                                      '<div class="form-group" id="root_cause_div"> ' +
                                      '<label class="col-md-4 control-label" for="Root Cause">Root Cause</label> ' +
                                      '<div class="col-md-7"> ' +
                                      '<textarea id="root_cause" name="root_cause" placeholder="Root Cause" class="form-control" rows="3" cols="2" style="resize:none">"'+root_cause.replace(/"/g,"")+'"</textarea>' +
                                      '</div></div>' +
                                      '<div class="form-group" id="corrective_action_title_div"> ' +
                                      '<label class="col-md-4 control-label" for="Risk mitigation">Corrective Action:</label> ' +
                                      '<div class="col-md-7"> ' +
                                      '<input id="corrective_action_title" name="corrective_action_title" value="'+corrective_action_title+'" type="text" placeholder="Title" class="form-control input-md"> ' +
                                      '<textarea id="corrective_action_action" name="corrective_action_action" placeholder="Description" class="form-control custom-control" rows="3" cols="3" style="resize:none">'+corrective_action_action+'</textarea>'+
                                      '</div></div>' +
                                      '<div class="form-group" id="supplier_contact_div"> ' +
                                      '<label class="col-md-4 control-label" for="Need Action">Supplier Contact</label> ' +
                                      '<div class="col-md-4">' +
                                      '<input id="supplier_contact" name="supplier_contact" type="text" value="'+supplier_contact+'" placeholder="Supplier Contact" class="form-control input-md"> ' +
                                      '</div></div>'+
                                      '<div class="form-group" id="deadline_date_div"> ' +
                                      '<label class="col-md-4 control-label" for="Need Action">Deadline Date</label> ' +
                                      '<div class="col-md-4">' +
                                      '<input id="deadline_date" name="deadline_date" type="text" placeholder="Deadline Date" value="'+deadline_date+'" class="form-control input-md"> ' +
                                      '<input type="hidden" name="addtype" value="predefined">'+
                                      '</div></div>'+
                                      '<div class="form-group"> ' +
                                        '<label class="col-md-9 control-label" for="Risk mitigation">Modified on: '+modified_date+' by '+created_by+' </label> ' +
                                       '</div>' +
                                      '</form> </div></div>',
                            buttons : {
                                        success: {
                                            label: "Update",
                                            className: "btn-success",
                                            callback : function(){
                                                          var title  = $("#title").val();
                                                          var incident_date = $("#incident_date").val();
                                                          var type  =  $("#incident_type").val();
                                                          var root_cause =  $("#root_cause").val();
                                                          var corrective_action_title =  $("#corrective_action_title").val();
                                                          var corrective_action_description =  $("#corrective_action_action").val();
                                                          var supplier_contact = $("#supplier_contact").val();
                                                          var deadline_date =  $("#deadline_date").val();
                                                          var addtype =  $("input[name=addtype]").val();
        
                                                          var chk_ary = ['incident_date','title','incident_type','root_cause','corrective_action_title','supplier_contact','deadline_date']

                                                          for(var i=0;i<chk_ary.length;i++){
                                                            validation_incident(chk_ary[i]);
                                                          } 

                                                         if($('.incident_history_div').find('.has-error').length > 0){
                                                               return false;
                                                          }

                                                          
                                                            MsLstUtils.startSpin();
                                                            $.post('/supplier/leakincidenthistory',{sid:str,option:'edit',title:title,incident_date:incident_date,type:incident_type,root_cause:root_cause,corrective_action_title:corrective_action_title,corrective_action_description:corrective_action_description,deadline_date:deadline_date,user_id:user_id,supplier_contact:supplier_contact,addtype:addtype})
                                                            .done(function(data){
                                                              window.location.reload();
                                                            });
                                                          
                                            }
                                        },
                                        main: {
                                                label: "Cancel",
                                                className: "btn-default",
                                                callback: function() {
                                                  
                                                }
                                              }
                                      }
                    };
                    bootbox.dialog(options);

                     $("#incident_date").daterangepicker({ singleDatePicker: true,
                                                             format: 'YYYY-MM-DD',
                                                             maxDate: new Date(),
                                                             startDate : incident_date,
                                                          });

                     $("#deadline_date").daterangepicker({ singleDatePicker: true,
                                                             format: 'YYYY-MM-DD',
                                                             startDate : new Date(),
                                                             minDate :  new Date(),
                                                          });
                    if(user_id != login_user_id){
                      $(".incident_history_div input,.incident_history_div select,.incident_history_div textarea").attr('disabled','disabled');
                    }

                      $('input#deadline_date,input#incident_date').keydown(function(e) {
                           e.preventDefault();
                           return false;
                       });

        });


   /*Deleting Incident History*/
   MsLstSuppliers.config.incident_history_remove.live('click',function(){
        var incident_detail = {
                                incident_id : $(this).closest('tr').attr('data-id'),
                                supplier_user_id : $("input[name=supplier_user_id]").val(),
                                supplier_id : $("input[name=supplier_id]").val(),
                                login_user_id : $("input[name=login_user_id]").val()
                              };

          if(incident_detail.login_user_id == incident_detail.supplier_user_id){

                bootbox.confirm("Are you sure want to delete this incident?",function(ok){
                  if(ok){
                     $.post('/supplier/leakincidenthistory',{inc:incident_detail,option:'delete'})
                                                   .done(function(data){
                                                      if(data == 'done'){
                                                         
                                                         bootbox.dialog({
                                                          message: "Selected Incident is deleted successfully!",
                                                          title : "Delete Incident",
                                                          buttons: {
                                                           success:{
                                                              label:"OK",
                                                              class:"btn-success",
                                                              callback: function(){
                                                                window.location.reload();
                                                              }
                                                          }
                                                         }
                                                       });
                                                      }
                                                  });
                  }
                });
           }else{
                bootbox.alert("Cannot delete you do not have permission to delete this incident!");
           }
   });

  /*Deleting Manual Risk*/
  MsLstSuppliers.config.manual_risk_delete.live('click',function(){
    var risk_detail = {
                        leak_id : $(this).closest('td').attr('data-id'),
                        supplier_user_id : $("input[name=supplier_user_id]").val(),
                        supplier_id : $("input[name=supplier_id]").val(),
                        login_user_id : $("input[name=login_user_id]").val(),
                        option : 'delete'
                      };
          if(risk_detail.login_user_id == risk_detail.supplier_user_id){
              bootbox.confirm("Are you sure want to delete this Manual Risk?",function(ok){
                if(ok){
                        $.ajax({
                                        type: 'POST',
                                        url: '/supplier/leakriskanalysis',
                                        data: risk_detail,
                                        beforeSend:function(){
                                             MsLstUtils.startSpin();
                                        },
                                        success:function(data){
                                          $('select.selectpicker').selectpicker('refresh');
                                          bootbox.alert("Selected Manual risk is deleted successfully!",function(){
                                            window.location.reload();
                                           });
                                        }
                       });
                }
              });
          }else{
               bootbox.alert("Cannot delete you do not have permission to delete this Risk!");
          }

  });

     
    $("#save_leak_analysis").hide();

    if($("input[name=busines_show]").val() == '2'){
       $("#busines_activity").hide();
    }else{
      $("#save_leak_analysis").show();
    }

    MsLstSuppliers.config.addassests.on('click',function(){
        var i = 1; 
        if($("#busines_activity").is(':visible')){
          if($(".activty-count").length > 0){
               i = parseInt($(".activty-count").last().html().replace("#",""))+1;
          }

          var activty = '<div class="row activty-row" id="activty-row'+i+'">
                                      <div class="col-sm-1 activity-cols">
                                      <span class="form-control activty-count">'+i+'</span>
                                                                            </div>
                                                                            <div class="col-lg-3">
                                                                              <div class="form-group"> 
                                                                                    <select class="form-control bus_activity_sel selectpicker" id="bus_activity_sel'+i+'" name="activity'+i+'">
                                                                                        <option value=""> Select Business Activity</option>
                                                                                        <option value="1">Device and accessory manufacturing</option>
                                                                                        <option value="2">Consumer & UX studies</option>
                                                                                        <option value="3">Creative agencies</option>
                                                                                        <option value="4">Appearance model making</option>
                                                                                        <option value="5">Component Manufacturing</option>
                                                                                        <option value="6">Print & Packaging</option>
                                                                                        <option value="7">R&D</option>
                                                                                    </select>
                                                                              </div>
                                                                            </div>
                                                                            <div class="col-lg-3">
                                                                              <div class="form-group">
                                                                                    <select class="form-control  bus_assests_sel selectpicker" id="bus_assests_sel'+i+'" name="assets'+i+'" multiple="multiple" title=" Select Assets" >
                                                                                         <option value="" data-hidden="true"></option>                                                                                     
                                                                                    </select>
                                                                              </div>
                                                                            </div>
                                                                           <div class="col-lg-1">
                                                                                    <span class="glyphicon glyphicon-remove business_remove"   id="business_remove'+i+'" alt="'+i+'" aria-hidden="true"></span>
                                                                           </div>
                                                                       </div>';
            if(i <= 7){
               MsLstSuppliers.config.busines_activity.append(activty);
            }else{

              bootbox.alert("Note:Maximum limit allowed upto 7.", function() {
                  
              });
            }
            $('.selectpicker').selectpicker('refresh');
            $(".leak_risk_activity_assets").hide();
        }else{
          $("#busines_activity").show();
          $(".leak_risk_activity_assets").hide();
        }
          $("#save_leak_analysis").show(); 

          
         if($("select[name='activity"+i+"']").val() != '')  $("select[name='activity"+i+"']").trigger('change');
     });

    

   

    $("#save_leak_analysis").on('click',function(){

        var i = parseInt($(".activty-count").last().html().replace("#",""));
        var businesAct = [];
        var Assets = [];
        var risk_analys_new = {};
        var risk_analys_exist = {};
        var oldid = null;

          for(var j=1; j<=i;j++){

              if($("select[name=activity"+j+"]").val().trim() !=''){


                if($("#activty-row"+j+"").attr('data-id') == undefined){
                  risk_analys_new[j]  =  {busines : $("select[name=activity"+j+"]").val(), assets : $("select[name=assets"+j+"]").val() };
                }else{
                  oldid = $("#activty-row"+j+"").attr('data-id');
                  risk_analys_exist[oldid]  =  {busines : $("select[name=activity"+j+"]").val(), assets : $("select[name=assets"+j+"]").val() };
                }

              }
              if($("select[name=assets"+j+"]").val() == null){
                  
                 bootbox.alert("Please select the assets from predefined list!",function(){
                                             $("select[name=assets"+j+"]").select2('open').select2('focus');
                                              $('select.selectpicker').selectpicker('refresh');
                                           });

                  return false;
              }
          }

          var id = $("input[name=supplier_id]").val();
          var info  = {risk_analys_new : JSON.stringify(risk_analys_new), risk_analys_exist : JSON.stringify(risk_analys_exist), option : 'exist_analysis', ids : id} ;

              $.ajax({
                                        type: 'POST',
                                        url: '/supplier/leakriskanalysis',
                                        data: info,
                                        beforeSend:function(){
                                             MsLstUtils.startSpin();
                                        },
                                        success:function(data){
                                          $('select.selectpicker').selectpicker('refresh');
                                          bootbox.alert("Selected business activities and assets are updated successfully",function(){
                                            window.location.reload();
                                           });
                                        }
                    });
      });

    $(".business_remove").live('click',function(){
            var i =1 , j=1 , b =1 , a= 1 , r=1 , sv_bt = false;
            var sid = $("input[name=supplier_id]").val();

            $(".activty-row").each(function(){
               if($(this).attr('data-id') != '' && $(".activty-count").length == 1) {
                bootbox.confirm("Are you sure want to delete the business activity and assests",function(results){
                    if(results == true){
                        $("#activty-row1").remove();
                        $.ajax({
                                type: 'POST',
                                url: '/supplier/leakriskanalysis',
                                data: 'id='+sid+'&option=delete_all',
                                beforeSend:function(){
                                     MsLstUtils.startSpin();
                                },
                                success:function(data){
                                  $('select.selectpicker').selectpicker('refresh');
                                  bootbox.alert("Selected business activity and assets are deleted successfully",function(){
                                     window.location.reload();
                                   });
                                }
                         });
                    }else{
                       alert(results);
                    }
                });
               }
            });

            if($("#activty-row1").attr('data-id') != '' && $(".activty-count").length > 1) {

                    $("#activty-row"+$(this).attr('alt')).remove();

                    $(".activty-count").each(function(){
                       $(this).html(i);
                       i++;
                    });

                    $(".activty-row").each(function(){
                       $(this).attr('id','activty-row'+j);
                       j++;
                    });

                    $('.business_remove').each(function(){
                        $(this).attr('alt',r);
                        $(this).attr('id','business_remove'+r);
                       r++;
                    });
         
                    if($(".activty-count").length == 0 ){
                      $("#save_leak_analysis").hide();
                    }

                   $("select[name^=activity]").each(function(){
                      $(this).attr('id',"bus_activity_sel"+b);
                      $(this).attr('name',"activity"+b);
                      b++;
                      $('select.selectpicker').selectpicker('refresh');
                    }); 
                   $("select[name^=assets]").each(function(){
                      $(this).attr('id',"bus_assests_sel"+a);
                      $(this).attr('name',"assets"+a);
                      a++;
                      $('select.selectpicker').selectpicker('refresh');
                    }); 
             }
    });

    $("select[name^='activity']").live('change',function(){
        var activ = JSON.parse(JSON.stringify(MsLstSuppliers.config.business_assets));
        var assets = '' , assets_grp = null;
        var nm = $(this).attr('name');
        var id = nm.replace('activity','');
        
        $("select[name=assets"+id+"]").empty();
        
        if($(this).val().trim() != '') {
             $.each(activ[$(this).val()],function(i,n){
                assets_grp = $('<optgroup></optgroup').attr('label',i);
                assets = '';
               $.each(n,function(i_id,n_val){
                /*assets = $('<option></option>').
                         attr('value',i_id).
                         text(n_val);*/

                  assets+= "<option value='"+i_id+"'>"+n_val+"</option>"
                  $('select[name=assets'+id+']').select2("data", { id: i_id, text: n_val },true);
               });

                assets_grp  = assets_grp.append(assets);
                $("select[name=assets"+id+"]").append(assets_grp);
                $('select.selectpicker').selectpicker('refresh');
             });
        }else{
           $('select.selectpicker').selectpicker('refresh');
        }
       
    });

     /* End  Leak Prevention assement */
  
    MsLstUtils.createSelect2s([
            {element: MsLstSuppliers.config.regionSelect, options: { placeholder: "Select Region" }},
            {element: MsLstSuppliers.config.countrySelect, options: { placeholder: "Select Country" }},
        ]);
    
    if (MsLstSuppliers.config.coordinates && MsLstSuppliers.config.mapElement) {
      MsLstUtils.createMapByCoordinates(MsLstSuppliers.config.coordinates, MsLstSuppliers.config.mapElement);
    }
    if (MsLstSuppliers.config.regions) {
            MsLstUtils.applyCountryFilter(MsLstSuppliers.config.regions, $('select[name="region"]'), $('select[name="country"]'), Suppliers.country);

          $('select[name="region"]').on('change', function() {
                $('#s2id_country .select2-chosen').empty();
                MsLstUtils.applyCountryFilter(MsLstSuppliers.config.regions, $('select[name="region"]'), $('select[name="country"]'));
            });
        }
   
    $("#supplier_cancel").on('click',function(event){
            bootbox.confirm(" The data will not be saved. Press OK to discard.",function(ok) {
        if(ok){
          window.location.href = $("#supplier_cancel").attr('alt');
        }
      }); 
      event.preventDefault();
    });
    $("#supplier_cancel_edit").on('click',function(event){
            bootbox.confirm("Are you sure you want to cancel? The changes will not be saved.",function(ok) {
        if(ok){
          window.location.href = $("#supplier_cancel_edit").attr('alt');
        }
      }); 
    event.preventDefault();
       });
     MsLstUtils.createCoordinatePicker('coordinates', 'supplier-coordinate-check', 'supplier-coordinate-pick'); 
  }
};

/**
 *
 * Handlers for Sitemasters listing
 **/
var MsLstSitemasters = {
  init: function (supply) {  
    MsLstSitemasters.config = {
      sitemasterslist : $('#sitemasterslist'),
      countrySelect : $('select[name="country"]'),
      dateSelect: $('input[name="last_inspection_date"]'),
      regionSelect : $('select[name="region"]'),
      sitemastersFilterResetButton: $('#sitemaster-filter-reset'),
      regions : null,
      coordinates: null,
      mapElement: null,
      supplier_handle : $("#supplier_handle"),
      ins_main_date : $('input[name="ins_main_date"]'),
      assesed_pr : $("#assesed_pr"),
      leak_risk_analysis_tab : $("#leak_risk_analysis_tab"),
      leak_incident_history_tab : $("#leak_incident_history_tab"),
      incident_history_remove : $(".incident_history_remove"),
      addrisk : $("#addrisk"),
      risk_mitigation_manual : $(".risk_mitigation_manual"),
      manual_risk_delete : $(".manual_risk_delete"),
      addnewincident : $("#addnewincident"),
      incident_history : $(".incident_history"),
      SupplierAnswerSelects :$(".supplier-form-tabs select"),
      busines_activity : $("#busines_activity"),
      busines_assets   : $("#business_assets"),
      business_supp_lob : $("#business_supp_lob"),
      business_lob     :  null,
      addactivity      : $("#addactivity"),
      addassests       : $("#addassests"),
      ActivitySelects  : $(".activity_row select"),
      AssetsSelects    : $(".assests_row select"),
      inc_hist_json    : null,
      leak_prev_json   : null,
      business_risk : null,
      business_actions : null,
      leak_risk_analysis : null,
      corrective_action_tb : $("#corrective_action_tb"),
      corrective_actions: null,
      lp_corrective_actions: null,
      access_name:null,
      offline_inspection:$('#offline_inspection'),
      namealiasaccess  : $("#namealiasaccess"),
      empwithmsaccnt   : $("#empwithmsaccnt"),
      insfirmname      : $("#insfirmname"),
      inspectorfirmname: $("#inspectorfirmname"),
      peopleinterviewed: $("#peopleinterviewed"),
      peopleinterviewedlist:$("#peopleinterviewedlist"),
    };
    $.extend(MsLstSitemasters.config, supply);
    MsLstSitemasters.setUp();
    },
  setUp: function() {
    MsLstSitemasters.setUpListingPage(); 
    MsLstSitemasters.setUpLeakPrevention();
    MsLstSitemasters.setUpPRInspection();
    MsLstSitemasters.setUpSitemasterdisplay();
    MsLstSitemasters.setUpSitemasterForms();
    MsLstSitemasters.setUpOnlineInspection();
  },
  setUpOnlineInspection:function(){
        MsLstUtils.getCollapse();

        MsLstSitemasters.config.inspectorfirmname.on('click',function(){  
      
        if($("#insfirmname").is(':visible')){
            var i=1;
          if($(".activty-counts").length > 0){
            i = parseInt($(".activty-counts").last().html().replace("#",""))+1;
          }
        var activty = '<div class="row activty-rows" id="activty-rows'+i+'" style="float:left;">
          <div class="col-sm-1 activity-cols" style="display:none;">
            <span class="form-control activty-counts" >'+i+'</span>
          </div>

          
        <div class="col-lg-3" style="width: 197px;">
            <div class="form-group">
                  <select id="ins_main_inspectors_firm'+i+'" name="ins_main_inspectors['+i+'][firm]" style="width: 182px; height: 34px;" class="ins_inspec">
                        <option value="">- Select -</option>
                        <option value="Microsoft">Microsoft</option>
                        <option value="WGroup">WGroup</option>
                        <option value="IPForensics">IPForensics</option>
                        <option value="FreightWatch">FreightWatch</option>
                        <option value="Cisco">Cisco</option>                  
                  </select>
                  
            </div>
          </div>
          <div class="col-lg-3" style="width: 197px;">
            <div class="form-group">
                  <select id="ins_main_inspectors_name'+i+'" name="ins_main_inspectors['+i+'][name]" style="width: 182px; height: 34px;border:1px solid #CCCCCC;" class="ins_inspec1">
                        <option value="">- Select -</option>
                  </select>
            </div>
          </div>
         <div class="col-lg-1">
                  <span class="glyphicon glyphicon-remove ins_main_remove" style="cursor:pointer;"  id="ins_main_remove'+i+'" alt="'+i+'" aria-hidden="true"></span>
         </div>

       
        </div>';
                    
            MsLstSitemasters.config.insfirmname.append(activty);                            
        }else{
                $("#insfirmname").show(); 
                     
        }                       
      });
      MsLstSitemasters.config.peopleinterviewed.on('click',function(){  
      
        if($("#peopleinterviewed").is(':visible')){
           var i=1;
          if($(".activty-counts").length > 0){
            i = parseInt($(".activty-counts").last().html().replace("#",""))+1;
          }
        var activty = '<div class="row activty-rows" id="activty-rows'+i+'" style="float:left;margin-left:15px;">
          <div class="col-sm-1 activity-cols" style="display:none;">
            <span class="form-control activty-counts" >'+i+'</span>
          </div>

          
        <div class="col-lg-3" style="width: 205px;">
            <div class="form-group">
              <input type="text" name="summ_people_interview_during_inspec['+i+'][name]" id="summ_people_interview_during_inspec['+i+'][name]" class="form-control" >            
            </input>        
                  
            </div>
          </div>
          <div class="col-lg-3" style="width: 205px;margin-left:15px;">
            <div class="form-group">
                   <input type="text" name="summ_people_interview_during_inspec['+i+'][title]" id="summ_people_interview_during_inspec['+i+'][title]" class="form-control" > </input>
            </div>
          </div>
         <div class="col-lg-1" style="width:20px;">
                  <span class="glyphicon glyphicon-remove people_interviewd_remove" style="cursor:pointer;"  id="people_interviewd_remove'+i+'" alt="'+i+'" aria-hidden="true"></span>
         </div>

        </div>
        </div>';
                    
            MsLstSitemasters.config.insfirmname.append(activty);                            
        }else{
                $("#peopleinterviewed").show(); 
                     
        }                       
      });
      $("select[id^='ins_main_inspectors_firm']").live('change',function(){    
        var str =($(this).attr('id'));          
        var id  = str.replace(/[^0-9]+/ig,"");
        Microsoft     = new Array("Tom Stimach"," Allen Gear","Jose Valenzuela"," Bhabajit Nandi","Drew Briggs"," Eric Frazier"," Linda Hartley 
                            ","Ramesh Kumar"," Bob Bullington","Ruben Morales"," Satya Roy","Thorsten Neumann"," Tony Mohr","Jeremy Gomsrud"," Ismael Rios 
                            ","Carlos Corrada"," Tim Pear");
        WGroup        = new Array('Scott Wilcox');
        IPForensics   = new Array('Joe Cully','Brendan Mallen');
        FreightWatch  = new Array('Eric Kready','Tony Yarrell');
        Cisco         = new Array('TBD');
          
        
        $('#ins_main_inspectors_name'+id).html('');
         var ins_main_inspectors_firm = this.value; 
         if(ins_main_inspectors_firm=='Microsoft'){
           Microsoft.forEach(function(t) { 
                $('#ins_main_inspectors_name'+id).append('<option>'+t+'</option>');
            });
        }
        
        if(ins_main_inspectors_firm=='WGroup'){
            WGroup.forEach(function(t) {
                $('#ins_main_inspectors_name'+id).append('<option>'+t+'</option>');
            });
        }
        if(ins_main_inspectors_firm=='IPForensics'){
            IPForensics.forEach(function(t) {
                $('#ins_main_inspectors_name'+id).append('<option>'+t+'</option>');
            });
        }
        if(ins_main_inspectors_firm=='FreightWatch'){
            FreightWatch.forEach(function(t) {
                $('#ins_main_inspectors_name'+id).append('<option>'+t+'</option>');
            });
        }
        if(ins_main_inspectors_firm=='Cisco'){
            Cisco.forEach(function(t) {
                $('#ins_main_inspectors_name'+id).append('<option>'+t+'</option>');
            });
        }
      });   
      $("#namealiasaccess").on('click',function(){
         
          var i = 1; 
          if($("#empwithmsaccnt").is(':visible')){
            //alert('If u cant then who can');
            if($(".activty-count").length > 0){
                 i = parseInt($(".activty-count").last().html().replace("#",""))+1;
            } 

            var activty = '<div class="row activty-row" id="activty-row'+i+'"><div class="col-sm-1 activity-cols" style="display:none;">
              <span class="form-control activty-count">'+i+'</span>
            </div>
            <div class="col-lg-2" style="width:122px;">
              <div class="form-group"> 
                <input type="text" name="ins_main_name_alias_access['+i+'][name]" id="ins_main_name'+i+'" class="form-control ins_main" style="width: 120px;"></input>
             </div>
            </div>
              <div class="col-lg-2" style="width:122px;margin-left:12px;">
                <div class="form-group"> 
                 <input type="text" name="ins_main_name_alias_access['+i+'][alias]" id="ins_main_alias'+i+'"class="form-control ins_main1" style="width: 120px;"></input>
                </div>
              </div>
              <div class="col-lg-2" style="width:122px;margin-left:12px;">
                <div class="form-group">
                      <select id="ins_main_access'+i+'" name="ins_main_name_alias_access['+i+'][access]" style="width:120px; height:34px;" class="ins_main2">
                            <option value="">- Select -</option>
                            <option value="MS System Accounts">MS System Accounts</option>
                            <option value="Team Center">Team Center</option>
                            <option value="RSM">RSM</option>
                            <option value="Orion">Orion</option>
                            <option value="MOO">MOO</option>                          
                      </select>
                </div>
              </div>

              <div class="col-lg-1">
                <span class="glyphicon glyphicon-remove name_alias_access_remove"  style="cursor:pointer;"  id="name_alias_access_remove'+i+'" alt="'+i+'" aria-hidden="true"></span>                                  
              </div> 


                <div id="otherType'+i+'" style="display:none;width:419px;">
                <input type="text" name="others" id="others'+i+'" class="form-control">
                </div> 
                </div>

            </div>';
            
             //window.alert(activty);
          
              MsLstSitemasters.config.empwithmsaccnt.append(activty);
                    
          }else{
            $("#empwithmsaccnt").show();
            
          }                           
      });
      $(".name_alias_access_remove").live('click',function(){            
        var i =1 , j=1 , b =1 , a= 1 , r=1 , sv_bt = false;            
        $(".activty-row").each(function(){
          if($(this).attr('data-id') != '' && $(".activty-count").length == 1) {          
            //$("#activty-row1").remove();                                                                    
          }
        });
        if($("#activty-row1").attr('data-id') != '' && $(".activty-count").length > 1) {
              
              $("#activty-row"+$(this).attr('alt')).remove();     

              $(".activty-count").each(function(){
                   $(this).html(i);
                   i++;
                });
             
                $(".activty-row").each(function(){
                   $(this).attr('id','activty-row'+j);
                  
                   $('#activty-row'+j+' input.ins_main').attr('name','ins_main_name_alias_access['+j+'][name]');
                   $('#activty-row'+j+' input.ins_main').attr('id','ins_main_name'+j);
                   $('#activty-row'+j+' input.ins_main1').attr('name','ins_main_name_alias_access['+j+'][alias]');
                   $('#activty-row'+j+' input.ins_main1').attr('id','ins_main_alias'+j);
                   $('#activty-row'+j+' select.ins_main2').attr('name','ins_main_name_alias_access['+j+'][access]');
                   $('#activty-row'+j+' select.ins_main2').attr('id','ins_main_access'+j);
                   j++;
                });

                $('.name_alias_access_remove').each(function(){
                    $(this).attr('alt',r);
                    $(this).attr('id','name_alias_access_remove'+r);
                   r++;
                });
                
               
         } 
      });
      $(".ins_main_remove").live('click',function(){                
        var i =1 , j=1 , b =1 , a= 1 , r=1 , sv_bt = false;            
        $(".activty-rows").each(function(){
          if($(this).attr('data-id') != '' && $(".activty-counts").length == 1) {  
            //$("#activty-rows1").remove();                                                                       
          }
        });
        if($("#activty-rows1").attr('data-id') != '' && $(".activty-counts").length > 1) {
          $("#activty-rows"+$(this).attr('alt')).remove();
          $(".activty-counts").each(function(){
               $(this).html(i);
               i++;
            });
            $(".activty-rows").each(function(){
               $(this).attr('id','activty-rows'+j);
               $('#activty-rows'+j+' select.ins_inspec').attr('name','ins_main_inspectors['+j+'][firm]');
               $('#activty-rows'+j+' select.ins_inspec').attr('id','ins_main_inspectors_firm'+j);
               $('#activty-rows'+j+' select.ins_inspec1').attr('name','ins_main_inspectors['+j+'][name]');
               $('#activty-rows'+j+' select.ins_inspec1').attr('id','ins_main_inspectors_name'+j);

              // $(this).attr('id','ins_main_inspectors_firm'+j);
               j++;
            }); 
            $('.ins_main_remove').each(function(){
                    $(this).attr('alt',r);
                    $(this).attr('id','ins_main_remove'+r);
                   r++;
                });                     
         }
      });
      $(".people_interviewd_remove").live('click',function(){                
        var i =1 , j=1 , b =1 , a= 1 , r=1 , sv_bt = false;            
        $(".activty-rows").each(function(){
          if($(this).attr('data-id') != '' && $(".activty-counts").length == 1) {  
            //$("#activty-rows1").remove();                                                                       
          }
        });
        if($("#activty-rows1").attr('data-id') != '' && $(".activty-counts").length > 1) {
          $("#activty-rows"+$(this).attr('alt')).remove();
          $(".activty-counts").each(function(){
               $(this).html(i);
               i++;
            });
            $(".activty-rows").each(function(){
               $(this).attr('id','activty-rows'+j);
               $('#activty-rows'+j+' input.inter_inspec').attr('name','summ_people_interview_during_inspec['+j+'][name]');
               $('#activty-rows'+j+' input.inter_inspec').attr('id','summ_people_interview_during_inspec['+j+'][name]');
               $('#activty-rows'+j+' input.inter_inspec1').attr('name','summ_people_interview_during_inspec['+j+'][title]');
               $('#activty-rows'+j+' input.inter_inspec1').attr('id','summ_people_interview_during_inspec['+j+'][title]');

              // $(this).attr('id','ins_main_inspectors_firm'+j);
               j++;
            }); 
            $('.people_interviewd_remove').each(function(){
                    $(this).attr('alt',r);
                    $(this).attr('id','people_interviewd_remove'+r);
                   r++;
                });                     
         }
      });

     $("select[id^='ins_main_access']").live('change',function(){
      var currval = this.value;     
      var str =($(this).attr('id'));          
      var id  = str.replace(/[^0-9]+/ig,"");
      if(currval==6){
        document.getElementById('otherType'+id).style.display = 'block';

      } else {
        document.getElementById('otherType'+id).style.display = 'none';
      }
     });

  },
  setUpListingPage: function(){
     
	  /*Start Offline*/
	  /*delete_inspection Start*/
	  $("#delete_inspection").on('click',function(){
          var inspec_id = $('#selectInspectionID option:selected').val();
          
          bootbox.confirm("Are you sure you want to delete this inspection? ",function(ok) {
	            if(ok){ 
	                      var formdata = new FormData;
	                      formdata.append('id',inspec_id);
	                      formdata.append('type','delete');
	                       $.ajax({
	                            url:'/sitemaster/inspections',
	                            processData: false, // Important!
	                            contentType: false, // Important!
	                            type: "post",
	                            data: formdata,
	                            success : function(data){
	                              console.log(data);
	                               
	                              bootbox.alert("Selected Inspection is deleted successfully!",function() {
	                                 window.location.replace(window.location.pathname+"?pr");
	                              });  
	                              // MsLstUtils.stopSpin();                                                                     
	                              
	                            },
	                            error : function(){
	                              //console.log("Not uploaded");
	                            }
	                        }); 
	
	              }
            });
        });   /*delete_inspection End*/
	  
	  /*offline_inspection Start*/
     $("#offline_inspection").on('click',function(){
        var sid = $("input[name='supplier_id']").val();
        MsLstUtils.startSpin();
         var BootboxContent = '<form id="my-awesome-dropzone" class="dropzone" action="#"><input name="offline_inspec_doc" id="offline_inspec_doc" type="file" multiple=true><div class="kv-fileinput-error file-error-message cust_error_mesage" style="display:none;"></div></form>';
         var options = {
                         title : 'Please upload Offline Inpection',
                         message: BootboxContent,
                         buttons : {
                                    success: {
                                        label: "Save",
                                        className: "btn-success",
                                        callback: function($form){
                                              var form_data = new FormData;
                                              if($("input[type='file']")[0].files[0] !=""){
                                                  form_data.append('file',$("input[type='file']")[0].files[0]);
                                              }                                                   

                                              form_data.append('addtype','summary');
                                              form_data.append('sid',sid);

                                              MsLstUtils.startSpin();

                                              var filnnmae     =  $("input[type='file']")[0].files[0].name.toLowerCase();

                                              if(filnnmae.length >= 25){ 
                                                  var fils      =  filnnmae.toLowerCase();
                                                  var filnme    =  fils.substring(0,20);
                                                  var filformt  =  fils.substring(fils.length,fils.length-4);

                                                  if(filnme!='scs inspection guide' || filformt !='xlsx'){ 

                                                    $(".cust_error_mesage").css('display','block');
                                                    $(".cust_error_mesage").html('Please upload valid file format or click <a target="_blank" href="/UserManual/SCS Inspection Guide FY17.xlsx">here</a>  to download for Inspection file format.');
                                                    return false;
                                                  }else{
                                                    $(".cust_error_mesage").css('display','none');   
                                                  }  
                                              }else{ 
                                                  $(".cust_error_mesage").css('display','block');
                                                  $(".cust_error_mesage").html('Please upload valid file format or click <a target="_blank" href="/UserManual/SCS Inspection Guide FY17.xlsx">here</a>  to download for Inspection file format.');
                                                  return false;
                                              }



                                              

                                              $.ajax({
                                                url:'/sitemaster/offline_confirm',
                                                processData: false, // Important!
                                                contentType: false, // Important!
                                                type: "post",
                                                data: form_data,
                                                beforeSend:function(){
                                                     MsLstUtils.startSpin();
                                                },
                                                success : function(data){
                                                     MsLstUtils.startSpin();
                                                     $.post('/sitemaster/offline_confirm', function(data) {
                                                        bootbox.confirm(data,function(result){
                                                         if(result){

                                                             var confirm_dat = new FormData;
                                                              confirm_dat.append('addtype','confirm');
                                                              confirm_dat.append('sid',sid);

                                                               $.ajax({
                                                                    url:'/sitemaster/offline_confirm',
                                                                    processData: false, // Important!
                                                                    contentType: false, // Important!
                                                                    type: "post",
                                                                    data: confirm_dat,
                                                                    beforeSend:function(){
                                                                           MsLstUtils.startSpin();
                                                                    },
                                                                    success : function(data){
                                                                      if(data != 0) {
                                                                            bootbox.alert("Inspection has been saved successfully!",function() {
                                                                                     window.location.replace(window.location.pathname+"?pr");
                                                                            });
                                                                      }else{
                                                                           bootbox.alert("Inspection has been not saved successfully.So please fill required field in sheets!",function() {
                                                                                     window.location.replace(window.location.pathname+"?pr");
                                                                            });
                                                                      }
                                                                    },
                                                                    error : function(){
                                                                        alert("Error Please try again");
                                                                    }
                                                                });
                                                          }
                                                        }).find("div.modal-dialog").addClass("offlin_summary_content");;
                                                     });
                                                   
                                                },
                                                error : function(){ 
                                                    alert("Error Please try again");
                                                }
                                              });
                                          MsLstUtils.stopSpin();
                                              
                                    },
                                     main: {
                                                  label: "Cancel",
                                                  className: "btn-default",
                                                  callback: function() {
                                                       MsLstUtils.stopSpin();
                                                  }
                                            }
                                    }

                                  },
                                  onEscape: function() { MsLstUtils.stopSpin();}
          };

        bootbox.dialog(options);

        $("#offline_inspec_doc").fileinput({
          showUpload: false,
          showCaption: false,
          browseClass: "btn btn-primary btn-md",
          browseLabel: "Upload Inspection Document ...",
          fileType: "any",
          allowedFileExtensions : ['xlsx'],
          previewFileIcon: "<i class='fa fa-file-excel-o'></i>",
          maxFileSize: 1000,
          slugCallback: function(filename) {

                  if(filename.length >= 25){ 
                      var fils      =  filename.toLowerCase();
                      var filnme    =  fils.substring(0,20);
                      var filformt  =  fils.substring(fils.length,fils.length-4);
   
                      if(filnme!='scs inspection guide' || filformt !='xlsx'){ 
                       
                         $(".cust_error_mesage").css('display','block');
                         $(".cust_error_mesage").html('Please upload valid file format or click <a target="_blank" href="/UserManual/SCS Inspection Guide FY17.xlsx">here</a>  to download for Inspection file format.');
                          
                      }else{
                         $(".cust_error_mesage").css('display','none');   
                      }  
                  }else{ 
                         $(".cust_error_mesage").css('display','block');
                         $(".cust_error_mesage").html('Please upload valid file format or click <a target="_blank" href="/UserManual/SCS Inspection Guide FY17.xlsx">here</a>  to download for Inspection file format.');
                         
                  }
                                           
                 return filename.replace('(', '_').replace(']', '_');
          }
        });
  MsLstUtils.stopSpin();

});  /*offline_inspection End*/ /*End Offline*/
	  
	  
        $('#sitemasters-list-form select').on('change', function () {
           $('#sitemasters-list-form').trigger('submit');
        });

        $('#sitemasters-list-form input[name="sitemaster_id"]').on('blur', function () {
           $('#sitemasters-list-form').trigger('submit');
        }).bind('keypress',function(e){
          var key = e.which;
          if(key == 13){
            $('#sitemasters-list-form').trigger('submit');
          }
        });

        MsLstUtils.createDateRangePicker($('input[name="daterange"]'), new Date(), function () {
            $('#sitemasters-list-form').trigger('submit');
        });


 
        MsLstUtils.createSelect2s([
            {element: $('select[name="user[]"]')},
            {element: $('select[name="site_supplier_type[]"]')},
            {element: $('select[name="channel_manager[]"]')},
            {element: $('select[name="status[]"]')},
            {element: $('select[name="region[]"]')},
            {element: $('select[name="country[]"]')}
        ]);
 
        MsLstSitemasters.config.sitemastersFilterResetButton.on('click', function () {
            //MsLstIncidents.config.incidentsDateSelect.val('');
            MsLstUtils.resetSelect2s([
                $('select[name="user[]"]'),
                $('select[name="site_supplier_type[]"]'),
                $('select[name="channel_manager[]"]'),
                $('select[name="region[]"]'),
                $('select[name="status[]"]'),
                $('select[name="country[]"]')
            ]);
        });

    $('select[name="supplier_type[]"],select[name="lob[]"],select[name="process[]"]').on('change',function(){
      var str = $.trim($(this).val());
      var field = $(this).attr('name').replace('[]','');
       
      if(str.indexOf('Please describe in Comment field') != -1){
         $("#"+field+"_other_type_id").show();
       }else{
         $("#"+field+"_other_type_id").removeClass(field+'_other_type_id');
         $("#"+field+"_other_type_id").hide();
         $('#'+field+'_other_type').val('');
       }
    });

    //MsLstUtils.createDataTable(MsLstSitemasters.config.sitemasterslist, 'sitemasters', [0], [[ 1, "desc" ]],'','',"rtip");
    MsLstUtils.createDataTable(MsLstSitemasters.config.sitemasterslist, 'sites',[], [[7, "asc" ]],'','',"rtip"); 

  

    $('.sitemasters-item td').live('click', function () {
            window.location.href = '/sitemaster/' + $(this).parent('tr').data('id');
    });
  },
  setUpSitemasterdisplay:function () {
	 $("#associated_users").select2("open");
	 // Site visit schedule 
    if($('input[name=sit_vist]').length){
    	
         // MsLstUtils.createSingleDatePicker($('input[name=sit_vist]'),'','yes'); 
          $('input[name=sit_vist]').daterangepicker({ singleDatePicker: true,
              format: 'YYYY-MM-DD',
              startDate : new Date(),
              minDate :  new Date(),
           },
           function(start, end, label)  {
        	   var value = $('input[name=sit_vist]').val();
        	   var sit_id = $("input[name=supplier_id]").val();
        	   if(value.length != 0 && ($('input[name=sit_vist_hidden]').val() != value)) {
             	  MsLstUtils.startSpin();
                     $.ajax({
                         type:'post',
                         url: '/sitemaster/site_visit_schedule',
                         data : 'next_visit_date='+value+"&id="+sit_id,
                         success: function(data){
                            bootbox.alert("Site visit schedule is updated successfully!",function(){
                                   window.location.replace(window.location.pathname);
                             });
                            MsLstUtils.stopSpin();
                         },
                         error:function(){
                            bootbox.alert("Site visit schedule is not updated successfully!",function(){
                                   window.location.replace(window.location.pathname);
                            });   
                         }
                     }); 
               }        	   
           }).keydown(function(e){
               e.preventDefault();
               return false;
           }); 
          
          
         /* $('input[name=sit_vist]').on('blur',function(){
            var sit_id = $("input[name=supplier_id]").val();
              if($(this).val().length != 0 && ($('input[name=sit_vist_hidden]').val() != $(this).val())) {
            	  MsLstUtils.startSpin();
                    $.ajax({
                        type:'post',
                        url: '/sitemaster/site_visit_schedule',
                        data : 'next_visit_date='+$(this).val()+"&id="+sit_id,
                        success: function(data){
                           bootbox.alert("Site visit schedule is updated successfully!",function(){
                                  window.location.replace(window.location.pathname);
                            });
                           MsLstUtils.stopSpin();
                        },
                        error:function(){
                           bootbox.alert("Site visit schedule is not updated successfully!",function(){
                                  window.location.replace(window.location.pathname);
                           });   
                        }
                    }); 
              }
          }).keydown(function(e){
                        e.preventDefault();
                        return false;
                    });*/
    } // Site visit schedule
    
    
    $("input[name=c_tpat_svi_number]").bind("keypress",function(e){
        var  k = e.which;
        var ok = k >= 65 && k <= 90 || // A-Z
        k >= 97 && k <= 122 || // a-z
        k >= 48 && k <= 57 || (k == 44 || k == 8 || k==0) ; // 0-9

        if (!ok){
            e.preventDefault();
        }
    }).bind("copy paste cut",function(e){   
            e.preventDefault();
    });
    
     
  $( window ).bind("resize", function(){
      var windowwidth =$(window).width();
      var panelwidth=$('#sitemasterviewpannel').width();
      var newpanelwidth=windowwidth-(panelwidth/10);
      if(windowwidth<panelwidth)
      $('#sitemasterviewpannel').width(newpanelwidth);
        }); 

 
     if (MsLstSitemasters.config.coordinates && MsLstSitemasters.config.mapElement) {
      //MsLstUtils.createMapByCoordinates(MsLstSitemasters.config.coordinates, MsLstSitemasters.config.mapElement);
       MsLstUtils.createBingMapByCoordinates(MsLstSitemasters.config.coordinates, MsLstSitemasters.config.mapElement);
     } 
  },
  setUpSitemasterForms: function () {
     
    MsLstUtils.createSingleDatePicker(MsLstSitemasters.config.dateSelect,'','yes'); 
    MsLstUtils.createSelect2s([
            {element: MsLstSitemasters.config.regionSelect, options: { placeholder: "Select Region" }},
            {element: MsLstSitemasters.config.countrySelect, options: { placeholder: "Select Country" }},
        ]);
    
    
    if (MsLstSitemasters.config.regions) {
            MsLstUtils.applyCountryFilter(MsLstSitemasters.config.regions, $('select[name="region"]'), $('select[name="country"]'), Sitemasters.country);

          $('select[name="region"]').on('change', function() {
                $('#s2id_country .select2-chosen').empty();
                MsLstUtils.applyCountryFilter(MsLstSitemasters.config.regions, $('select[name="region"]'), $('select[name="country"]'));
            });
        }
   
    $("#sitemaster_cancel").on('click',function(event){
            bootbox.confirm(" The data will not be saved. Press OK to discard.",function(ok) {
        if(ok){
          window.location.href = $("#sitemaster_cancel").attr('alt');
        }
      }); 
      event.preventDefault();
    }); 

    $("#sitemaster_cancel_edit").on('click',function(event){
            bootbox.confirm("Are you sure you want to cancel? The changes will not be saved.",function(ok) {
        if(ok){
          window.location.href = $("#sitemaster_cancel_edit").attr('alt');
        }
      }); 
    event.preventDefault();
       });


    $("#last_inspection_date").bind("copy paste cut keypress",function(e){   
                e.preventDefault();
     });

   if($("#sitemaster-coordinate-pick").length  > 0) {
      MsLstUtils.createBingCoordinatePicker('coordinates', 'sitemaster-coordinate-check', 'sitemaster-coordinate-pick'); 
   }
 
 
   //  MsLstUtils.createCoordinatePicker('coordinates', 'sitemaster-coordinate-check', 'sitemaster-coordinate-pick'); 

  },
  setUpLeakPrevention: function (){ 
     
    /* Start Leak Prevention assement */
    //$("select[name^=assets]").select2({placeholder:'Select Assets',allowClear: true});
    //$("select[name^=activity]").select2({placeholder:'Select Business Activity',allowClear: true})
    /*For tab selection*/
    var tabsel_lp = window.location.href.match(/\?lp/g);
    var tabsel_ca = window.location.href.match(/\?pr/g);
 
    if(tabsel_lp != null){
        $('.nav-tabs li:eq(2) a').tab('show');
    }else if(tabsel_ca != null){
      $('.nav-tabs li:eq(1) a').tab('show');
    }

    $(".save-summary-leak-desc").hide();
    $(".leak_prevention_assesment").hide();

     var user_id = $("input[name=supplier_user_id]").val();
     var login_user_id = $("input[name=login_user_id]").val();
      
    /*Leak risk Analysis Existing added item listing*/
    if(!$.isEmptyObject(MsLstSitemasters.config.leak_risk_analysis)){

        $.each(MsLstSitemasters.config.leak_risk_analysis,function(i,n){

            var activ = JSON.parse(JSON.stringify(MsLstSitemasters.config.business_assets));
            var lob_act = JSON.parse(JSON.stringify(MsLstSitemasters.config.business_lob));
            var assets = null,assets_grp = null , s_lob = ""; 
            var nm = $('.bus_activity_sel'+n.id+'').attr('name');
            var id = nm.replace('activity','');
            $("select[name=assets"+id+"]").empty();
            $("select[name=supp_lob"+id+"]").empty();
         
            var selected_asset = JSON.parse(n.asset_id);

            if($('.bus_activity_sel'+n.id+'').val().trim() != '') {
                 $.each(activ[$('.bus_activity_sel'+n.id+'').val()],function(i,n){

                     assets_grp = $('<optgroup></optgroup>').attr('label',i);
                     assets = '';
                        $.each(n,function(i_id,n_val){
                         

                          if($.inArray(i_id,selected_asset) !== -1){
                              assets+="<option value='"+i_id+"' selected='selected' >"+n_val+"</option>";
                          }else{
                              assets+="<option value='"+i_id+"'  >"+n_val+"</option>";
                          }

                           $('select[name=assets'+id+']').select2("data", { id: i_id, text: n_val },true);

                        });

                      assets_grp = assets_grp.append(assets);
   
                      $("select[name=assets"+id+"]").append(assets_grp);
                      $('select.selectpicker').selectpicker('refresh');
                 });

                 $.each(lob_act,function(i_lob,n_lob){

                    if($.inArray(i_lob,JSON.parse(n.lob_id)) !== -1 ){
                      s_lob+="<option value='"+i_lob+"' selected='selected'>"+n_lob+"</option>";  
                    }else{
                      s_lob+="<option value='"+i_lob+"'>"+n_lob+"</option>";
                    }

                 });
                 
                 $("select[name=supp_lob"+id+"]").append(s_lob);
                 $('select.selectpicker').selectpicker('refresh');
                 // console.log(lob_act);

            }/**/


            
       });

    }

    if(user_id != login_user_id){
    	$("#busines_activity select option").prop("disabled", true);
    	$('select.selectpicker').selectpicker('refresh');
    }
   
     
    MsLstUtils.createBootstrapSwicth(MsLstSitemasters.config.supplier_handle, {onText: "Yes", offText: 'No', size: 'normal'});
    MsLstUtils.createBootstrapSwicth(MsLstSitemasters.config.assesed_pr, {onText: "Yes", offText: 'No', size: 'normal'});
    MsLstUtils.createDataTable(MsLstSitemasters.config.leak_incident_history_tab,'Incidents',[], [],'','',"rtip");
    MsLstUtils.createDataTable(MsLstSitemasters.config.leak_risk_analysis_tab,'action Items',[], [],'','',"rtip");


    $(".leak_summary_desc").on('click',function(){
       $(".save-summary-leak-desc").show();
    }).on('blur',function(){
        if($(this).val() != ''){
           $(".save-summary-leak-desc").show();
         }else{
           $(".save-summary-leak-desc").hide();
         }
    });
    $(".save-summary-leak-desc").on('click',function(){
         var sumary = $(".leak_summary_desc").val();
         var sid = $("input[name=supplier_id]").val();
          $.ajax({
                                        url:'/sitemaster/leakpreventionstatus',
                                        type: "post",
                                        data: "sumary="+sumary+"&sid="+sid,
                                        success : function(data){
                                          console.log("uploaded");
                                           bootbox.dialog({
                                              message: "Summary has been saved successfully.",
                                              buttons: {
                                              success: {
                                                  label: "OK",
                                                  className: "btn-success",
                                                  callback: function(){
                                                       window.location.replace(window.location.pathname+"?lpg");
                                                    }
                                                  }
                                              }
                                             });
                                           
                                        },
                                        error : function(){
                                          console.log("Not uploaded");
                                        }
                                      });
    });




    MsLstSitemasters.config.addrisk.on('click',function(){
      var  role = $("input[name='role']").val();
      var  sid =  $("input[name='supplier_id']").val();
      var  user_id = $("input[name=supplier_user_id]").val();
      var  extra_options = '';
      if(role == 'PM') {
          extra_options = '<div class="form-group"> ' +
                            '<label class="col-md-4 control-label" for="Risk mitigation">Verified:</label> ' +
                            '<div class="col-md-7"> ' +                    
                             '<select name="verified_action" id="verified_action" class="form-control"><option value="NA">N/A</option><option value="yes">Yes</option><option value="no">No</option></select>'+
                            '</div></div>' ;
      }

      var options = {
        title : 'Add New Risk',
        message: '<div class="row new_risk_div">  ' +
                    '<div class="col-md-12"> ' +
                    '<form class="form-horizontal" method="post" enctype="multipart/form-data"> ' +
                    '<div class="form-group" id="risk_div"> ' +
                    '<label class="col-md-4 control-label" for="risk">Risk</label> ' +
                    '<div class="col-md-7"> ' +
                    '<input id="risk" name="risk" type="text" placeholder="Risk" class="form-control input-md"> ' +
                    '</div></div>' +
                    '<div class="form-group" id="action_div"> ' +
                    '<label class="col-md-4 control-label" for="Action">Action</label> ' +
                    '<div class="col-md-7"> ' +
                    '<input id="needaction" name="needaction" type="text" placeholder="Need Action" class="form-control input-md"> ' +
                    '<textarea id="action_description" name="action_description" placeholder="Description" class="form-control custom-control" rows="3" cols="3" style="resize:none"></textarea>'+
                    '</div></div>' +
                    '<div class="form-group" id="risk_action_div"> ' +
                    '<label class="col-md-4 control-label" for="Action">Status</label> ' +
                    '<div class="col-md-7"> ' +
                    '<select name="risk_action" id="risk_action" class="form-control" ><option value="Not Started" >Not Started</option><option value="In Progress" >In Progress</option></select>'+
                    '</div></div>' +
                    '<div class="form-group" id="upload_msg"> ' +
                    '<label class="col-md-4 control-label" >&nbsp;</label> ' +
                    '<div class="col-md-7"> ' +
                    'If you want to add multiple files then please zip or rar them together'+
                    '</div></div>' +
                    '<div class="form-group" id="pic_div"> ' +
                    '<label class="col-md-4 control-label" for="Risk mitigation">File:</label> ' +
                    '<div class="col-md-7"> ' +                    
                    '<input type="file" name="leak_file" id="pic">'+
                    '<input type="hidden" name="addtype" value="new">'+  
                    '</div></div>' + extra_options +
                    '</form> </div></div>',
        buttons : {
                    success: {
                        label: "Save",
                        className: "btn-success",
                        callback: function($form){

                                var risk = $("#risk").val();
                                var action = $("#needaction").val();
                                var action_description = $("#action_description").val();
                                var status = $("#risk_action").val();
                                var addtype = $("input[name=addtype]").val();
                               
                                var form_data = new FormData;

                              

                                if($("input[type='file']")[0].files[0] !=""){
                                  form_data.append('file',$("input[type='file']")[0].files[0]);
                                }

                                form_data.append('sid',sid);
                                form_data.append('risk',risk);
                                form_data.append('action',action);
                                form_data.append('action_description',action_description);
                                form_data.append('option','add');
                                form_data.append('status',status);
                                form_data.append('user_id',user_id);
                                form_data.append('addtype',addtype);

                                var chk_ary = ['risk','needaction'];

                                 
                                for(var i=0;i<chk_ary.length;i++){
                                  validation_incident(chk_ary[i]);
                                }

                                if($('.new_risk_div').find('.has-error').length > 0){
                                  return false;
                                }

                                MsLstUtils.startSpin();
                                $.ajax({
                                        url:'/sitemaster/leakriskanalysis/add',
                                        processData: false, // Important!
                                        contentType: false, // Important!
                                        type: "post",
                                        data: form_data,
                                        success : function(data){
                                          //console.log("uploaded");
                                          window.location.replace(window.location.pathname+"?lpg");
                                        },
                                        error : function(){
                                          //console.log("Not uploaded");
                                        }
                                      });
                              }
                    },
                     main: {
                                                label: "Cancel",
                                                className: "btn-default",
                                                callback: function() {
                                                  
                                                }
                            }
                  }
      };
      bootbox.dialog(options);

      
    });


      MsLstSitemasters.config.risk_mitigation_manual.on('click',function(){
        
         var id = $(this).closest('td').attr('data-id').trim();
         var sid = $("input[name=supplier_id]").val();
         var user_id = $("input[name=supplier_user_id]").val();
         var login_user_id = $("input[name=login_user_id]").val();
         var datype = '', statutype = '';
         var predefined = '' ,upload_files = '-' , action_nm='' , action_desc = '' , addtype = 'new',upload_msg='';
 
         if(user_id != login_user_id) statutype = 'disabled="disabled"';
         
          var json_item = $(MsLstSitemasters.config.leak_prev_json).filter(function(i,n){
             return n.id  === id;
          });

          if($(this).closest('td').attr('data-type').trim() == 'auto' || user_id != login_user_id) { datype = 'disabled="disabled"';   addtype = 'predefined'; }
           
        

          console.log(json_item);
           
          if(json_item[0]['leak_id'] != null){

              datype = 'disabled="disabled"';
              predefined = '<div class="form-group"> ' +
                            '<label class="col-md-4 control-label" for="businessactivity">Business Activity </label> ' +
                            '<div class="col-md-7"> ' +
                             '<input class="form-control input-md" type=text disabled=disabled value="'+MsLstSitemasters.config.business_activity[parseInt(json_item[0]['site_leak_risk_analysis']['activity_id'])]+'">' +
                            '</div>
                            </div>';

                 /*Action Name*/           
                 var div_action = '<div id="s2id_autogen1" class="select2-container select2-container_risk select2-container-multi form-control"><ul class="select2-choices">';
                 var div_action_li = '<li class="select2-search-choice"><div class="label label-primary">'+json_item[0]['action_name']+'</div></li>'; 

       

                 div_action = div_action+div_action_li+'</ul></div>';  

                 /*Action Description*/
                  var div_action_des = '<div id="s2id_autogen1" class="select2-container select2-container_risk  select2-container-multi form-control"><ul class="select2-choices">';
                  var div_action_des_li = '<li class="select2-search-choice"><div class="action_des_alert action_des-info">'+json_item[0]['action_description']+'</div></li>'; 

 

                 div_action_des = div_action_des+div_action_des_li+'</ul></div>'; 


                 action_nm = div_action;
                 action_desc = div_action_des;
                 addtype = 'predefined';
                 var detail_comment_description_txt = (json_item[0]['detail_comment_description'])? json_item[0]['detail_comment_description']:'';
                 action_desc+="<textarea id='action_comment_detail' name='action_comment_detail' placeholder='Detailed description on how the action is completed' class='form-control custom-control' rows='3' cols='3' style='resize:none' "+statutype+" >"+detail_comment_description_txt+"</textarea>";
            }else{
                action_nm = '<input id="needaction" name="needaction" type="text" placeholder="Need Action" value="'+json_item[0]['action_name']+'" class="form-control input-md"  '+datype+' >';
                action_desc = '<textarea id="action_description" name="action_description" placeholder="Description" class="form-control custom-control" rows="3" cols="3" style="resize:none" '+datype+'>'+json_item[0]['action_description']+'</textarea>';
            }

            var normal_usr_risk_status = '', normal_usr_upload_option = '' , normal_usr_upload_msg='';

             if(user_id == login_user_id){
                  normal_usr_risk_status = '<select name="risk_action" id="risk_action" class="form-control" ><option value="Not Started" >Not Started</option><option value="In Progress" >In Progress</option><option value="Completed">Completed</option></select>';
                  normal_usr_upload_option = '<input type="file" name="file" id="pic">';
                  normal_usr_upload_msg = '<div class="form-group field-success" id="upload_msg"> ' +
                          '<label class="col-md-4 control-label" >&nbsp;</label> ' +
                          '<div class="col-md-7"> ' +
                          'If you want to add multiple files then please zip or rar them together'+
                          '</div></div>';
            }else {
                  normal_usr_risk_status = '<input id="risk_action" name="risk_action" type="text" placeholder="Status" value="'+json_item[0]['status']+'" class="form-control input-md"  '+datype+' >';
               
            }

               
            

            if(json_item[0]['file_name'] != null){
              upload_files = '<a href="/sitemaster/download/'+id+'/'+sid+'/site_leak_prevention">'+json_item[0]['file_description']+"</a>";
            }
            
         var  role = $("input[name='role']").val();
         var options = {
              title : 'Edit Risk',
              message: '<div class="row">  ' +
                          '<div class="col-md-12"> ' + 
                          '<form class="form-horizontal" method="get" enctype="multipart/form-data"> ' + predefined +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="risk">Risk</label> ' +
                          '<div class="col-md-7"> ' +
                          '<input id="risk" name="risk" type="type"  placeholder="Risk"  value="'+json_item[0]['risk']+'" class="form-control input-md"  '+datype+' > ' +
                          '</div></div>' +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Action">Action</label> ' +
                          '<div class="col-md-7"> '
                          +action_nm+
                          action_desc+
                          '</div></div>' +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Action">Status</label> ' +
                          '<div class="col-md-7"> ' +
                          normal_usr_risk_status +
                          '</div></div>' +
                          normal_usr_upload_msg +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Risk mitigation">File:</label> ' +
                          '<div class="col-md-7"> ' +                    
                          normal_usr_upload_option+ upload_files +
                          '<input type="hidden" name="addtype" value="'+addtype+'">'+  
                          '</div></div>' +                          
                          '</form> </div></div>',
              buttons : {
                           
                           main: {
                                                label: "Cancel",
                                                className: "btn-default",
                                                callback: function() {
                                                  
                                                }
                                 }
                        }

            };

            var owneruser = {
                  buttons : {
                     success: {
                              label: "Update",
                              className: "btn-success",
                              callback: function($form){
                                var risk = $("#risk").val();
                                var action = $("#needaction").val();
                                var action_description = $("#action_description").val();
                                var action_comment_detail = ($("#action_comment_detail").val())? $("#action_comment_detail").val() :'' ;
                                var status = $("#risk_action").val();
                                var addtype = $("input[name=addtype]").val();
                                var form_data = new FormData;

                                if($("input[type='file']").length){
                                  form_data.append('file',$("input[type='file']")[0].files[0]);
                                }

                                form_data.append('id',id);
                                form_data.append('risk',risk);
                                form_data.append('action',action);
                                form_data.append('action_description',action_description);
                                form_data.append('option','edit');
                                form_data.append('status',status);
                                form_data.append('user_id',user_id);
                                form_data.append('addtype',addtype);
                                form_data.append('action_comment_detail',action_comment_detail);

                                
                                MsLstUtils.startSpin();
                                $.ajax({
                                        url:'/sitemaster/leakriskanalysis/edit',
                                        processData: false, // Important!
                                        contentType: false, // Important!
                                        type: "post",
                                        data: form_data,
                                        success : function(data){
                                         // console.log(form_data);
                                          bootbox.alert("Selected risk is updated successfully!",function(){
                                              window.location.replace(window.location.pathname+"?lpg");
                                           });
                                         
                                        },
                                        error : function(){
                                          console.log("Not uploaded");
                                        }
                                      });

                              }
                          },
                       main: {
                                                label: "Cancel",
                                                className: "btn-default",
                                                callback: function() {
                                                  
                                                }
                                 }
                  }
            };

            if(user_id == login_user_id){  
             $.extend(options,owneruser);
            }

            var verification_done = '',risk_status_supservisor = '', supervisor_upload_option = '';

            if(json_item[0]['verified_date'] != null){
              verification_done = '<div class="form-group"> ' +
                          '<div class="col-md-2">&nbsp;</div> '+
                          '<label class="col-md-10 control-label" for="Risk mitigation">Modified on: '+json_item[0]['verified_date']+' UTC by '+json_item[0]['user']['first_name']+" "+json_item[0]['user']['last_name']+' </label> ' +
                          '</div>';
                }            


 
            if(user_id == login_user_id){
                  risk_status_supservisor = '<select name="risk_action" id="risk_action" class="form-control" ><option value="Not Started" >Not Started</option><option value="In Progress" >In Progress</option><option value="Completed">Completed</option></select>';
                  supervisor_upload_option = '<input type="file" name="file" id="pic">';
                  upload_msg = '<div class="form-group field-success" id="upload_msg"> ' +
                          '<label class="col-md-4 control-label" >&nbsp;</label> ' +
                          '<div class="col-md-7"> ' +
                          'If you want to add multiple files then please zip or rar them together'+
                          '</div></div>';
            }else {
                  risk_status_supservisor = '<input id="risk_action" name="risk_action" type="text" placeholder="Status" value="'+json_item[0]['status']+'" class="form-control input-md"  '+datype+' >';
               
            }

            var PMoptions = {
              title : 'Edit Risk',
              message: '<div class="row">  ' +
                          '<div class="col-md-12"> ' +
                          '<form class="form-horizontal"> ' + predefined +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="risk">Risk</label> ' +
                          '<div class="col-md-7"> ' +
                          '<input id="risk" name="risk" type="text" placeholder="Risk" value="'+json_item[0]['risk']+'" class="form-control input-md" '+datype+'> ' +
                          '</div></div>' +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Action">Action</label> ' +
                          '<div class="col-md-7"> '
                          +action_nm+
                          action_desc+
                          '</div></div>' +
                          '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Action">Status</label> ' +
                          '<div class="col-md-7"> ' +
                          risk_status_supservisor +
                          '</div></div>' +
                          '<div class="form-group"> ' +
                            '<label class="col-md-4 control-label" for="Risk mitigation">Verification:</label> ' +
                            '<div class="col-md-7"> ' +                    
                            '<select name="verified_action" id="verified_action" class="form-control"><option value="n/a">Not verified </option><option value="yes">Completed</option><option value="no">Needs improvement</option></select>'+
                          '</div></div>' +
                          upload_msg +
                           '<div class="form-group"> ' +
                          '<label class="col-md-4 control-label" for="Risk mitigation">File:</label> ' +
                          '<div class="col-md-7"> ' +                    
                          supervisor_upload_option + upload_files +
                          '<input type="hidden" name="addtype" value="'+addtype+'">'+  
                          '</div></div>' + 
                          verification_done+
                          '</form> </div></div>',
              buttons : {
                          success: {
                              label: "Update",
                              className: "btn-success",
                              callback: function($form){
                                var risk = $("#risk").val();
                                var action = $("#needaction").val();
                                var verified = $("#verified_action").val();
                                var addtype = $("input[name=addtype]").val();
                                var status = $("#risk_action").val();
                                var action_comment_detail = ($("#action_comment_detail").val())? $("#action_comment_detail").val() :'' ;
                                var action_description = $("#action_description").val(); 

                                var form_data = new FormData;
                                if($("input[type='file']").length){
                                 form_data.append('file',$("input[type='file']")[0].files[0]);
                                }
                                form_data.append('id',id);
                                form_data.append('risk',risk);
                                form_data.append('action',action);
                                form_data.append('action_description',action_description);
                                form_data.append('option','edit');
                                form_data.append('status',status);
                                form_data.append('user_id',user_id);
                                form_data.append('addtype',addtype);
                                form_data.append('verified',verified);
                                form_data.append('action_comment_detail',action_comment_detail);


                                MsLstUtils.startSpin();
                           
                                  $.ajax({
                                        url:'/sitemaster/leakriskanalysis/edit',
                                        processData: false, // Important!
                                        contentType: false, // Important!
                                        type: "post",
                                        data: form_data,
                                        success : function(data){
                                           bootbox.alert("Selected risk is updated successfully!",function(){
                                              window.location.replace(window.location.pathname+"?lpg");
                                           });
                                        },
                                        error : function(){
                                          console.log("Not uploaded");
                                        }
                                      });
                              }
                          },
                          main: {
                                                label: "Cancel",
                                                className: "btn-default",
                                                callback: function() {
                                                  
                                                }
                                 }
                        }
            }; 

            if(role == 'PM') {
              options = PMoptions;
            } 

            bootbox.dialog(options);

            if(role == 'PM') {
                $("#verified_action option[value='"+json_item[0]['verified_status']+"']").attr('selected','selected');
                if(user_id == login_user_id){
                   $("#risk_action option[value='"+json_item[0]['status']+"']").attr('selected','selected');
                }
            }else{
                $("#risk_action option[value='"+json_item[0]['status']+"']").attr('selected','selected');
            }
      });


      function BootboxContent(){
        var frm_str = '<div class="row incident_history_div">  ' +
                                '<div class="col-md-12"> ' +
                                '<form class="form-horizontal" method="post" > ' +
                                '<div class="form-group" id="title_div"> ' +
                                '<label class="col-md-4 control-label" for="Title">Title</label> ' +
                                '<div class="col-md-7"> ' +
                                '<input id="title" name="title" type="text" placeholder="Title" class="form-control input-md"> ' +
                                '</div></div>' +
                                '<div class="form-group" id="incident_date_div"> ' +
                                '<label class="col-md-4 control-label" for="Date">Date</label> ' +
                                '<div class="col-md-7"> ' +
                                '<input id="incident_date" name="incident_date" type="text" placeholder="Date" class="form-control input-md"> ' +
                                '</div></div>' +
                                '<div class="form-group"  id="type_div"> ' +
                                '<label class="col-md-4 control-label" for="Type">Type</label> ' +
                                '<div class="col-md-7"> ' +
                                '<select name="type" id="type" class="form-control"><option value="a">A</option><option value="b">B</option><option value="c">C</option><option value="d">D</option></select>' +
                                '</div></div>' +
                                '<div class="form-group" id="root_cause_div"> ' +
                                '<label class="col-md-4 control-label" for="Root Cause">Root Cause</label> ' +
                                '<div class="col-md-7"> ' +
                                '<textarea id="root_cause" name="root_cause" placeholder="Root Cause" class="form-control" rows="3" cols="2" style="resize:none"></textarea>' +
                                '</div></div>' +
                                '<div class="form-group" id="corrective_action_title_div"> ' +
                                '<label class="col-md-4 control-label" for="Risk mitigation">Corrective Action:</label> ' +
                                '<div class="col-md-7"> ' +
                                '<input id="corrective_action_title" name="corrective_action_title" type="text" placeholder="Title" class="form-control input-md"> ' +
                                '<textarea id="corrective_action_description" name="corrective_action_description" placeholder="Description" class="form-control custom-control" rows="3" cols="3" style="resize:none"></textarea>'+
                                '</div></div>' +
                                '<div class="form-group" id="supplier_contact_div"> ' +
                                '<label class="col-md-4 control-label" for="Need Action">Supplier Contact</label> ' +
                                '<div class="col-md-7" >' +
                                '<input id="supplier_contact" name="supplier_contact" type="text" placeholder="Supplier Contact" class="form-control input-md"> ' +
                                '</div></div>'+
                                '<div class="form-group" id="deadline_date_div"> ' +
                                '<label class="col-md-4 control-label" for="Need Action">Deadline Date</label> ' +
                                '<div class="col-md-7">' +
                                '<input id="deadline_date" name="deadline_date" type="text" placeholder="Deadline Date" class="form-control input-md"> ' +
                                '<input type="hidden" name="addtype" value="predefined">'+
                                '</div></div>'+
                                '</form> </div></div>';

    
              return frm_str;
      }



      MsLstSitemasters.config.addnewincident.on('click',function(){


          var  sid =  $("input[name='supplier_id']").val();
          var options = {
                       title : 'Leak incident report',
                       message: BootboxContent,
                      buttons : {
                                  success: {
                                      label: "Save",
                                      className: "btn-success",
                                      callback: function($form){
                                            var title  = $("#title").val();
                                            var incident_date = $("#incident_date").val();
                                            var type  =  $("#type").val();
                                            var root_cause =  $("#root_cause").val();
                                            var corrective_action_title =  $("#corrective_action_title").val();
                                            var corrective_action_description =  $("#corrective_action_description").val();
                                            var deadline_date =  $("#deadline_date").val();
                                            var supplier_contact = $("#supplier_contact").val();
                                            var addtype =  $("input[name=addtype]").val();

                                            var chk_ary = ['incident_date','title','type','root_cause','corrective_action_title','supplier_contact','deadline_date']

                                            for(var i=0;i<chk_ary.length;i++){
                                              validation_incident(chk_ary[i]);
                                            }


                                            if($('.incident_history_div').find('.has-error').length > 0){
                                                 return false;
                                            } 

                                            MsLstUtils.startSpin();
                                            $.post('/sitemaster/leakincidenthistory',{sid:sid,option:'add',title:title,incident_date:incident_date,type:type,root_cause:root_cause,corrective_action_title:corrective_action_title,corrective_action_description:corrective_action_description,deadline_date:deadline_date,supplier_contact:supplier_contact,addtype:addtype})
                                              .done(function(data){
                                                window.location.replace(window.location.pathname+"?lpg");
                                              });
                                  },
                                   main: {
                                                label: "Cancel",
                                                className: "btn-default",
                                                callback: function() {
                                                  
                                                }
                                          }
                                  }

                                }
      };
       $(".incident_history_div input").attr('disabled','disabled');
      
        bootbox.dialog(options);

        $("#incident_date").daterangepicker({ singleDatePicker: true,
                                                             format: 'YYYY-MM-DD',
                                                             maxDate: new Date(),
                                                             startDate : new Date(),
                                                          });

        $("#deadline_date").daterangepicker({ singleDatePicker: true,
                                                             format: 'YYYY-MM-DD',
                                                             startDate : new Date(),
                                                             minDate :  new Date(),
                                                          });


          $('input#deadline_date,input#incident_date').keydown(function(e) {
             e.preventDefault();
             return false;
          });



        
      });

       function validation_incident(id){

          if($("#"+id).val().trim() == null || $("#"+id).val().trim() == ""){
              $("#"+id).attr('placeholder', 'Please enter '+id.replace(/_/g,' ')); 
              $("#"+id+"_div").addClass('has-error');
          }else{
             $("#"+id+"_div").removeClass('has-error');
          }
        } 

        MsLstSitemasters.config.incident_history.live('click',function(){
          
          var user_id = $("input[name=supplier_user_id]").val();
          var login_user_id = $("input[name=login_user_id]").val();
          var str = String($(this).closest('tr').attr('data-id'));

          var asi = $(MsLstSitemasters.config.inc_hist_json).filter(function(i,n){
               return n.id === str;
          });
          
            for (var i=0;i<asi.length;i++){
                var title = (asi[i].title != "" || asi[i].title != undefined) ? asi[i].title : "" ;
                var incident_date = asi[i].incident_date ? asi[i].incident_date : "" ;
                var incident_type = asi[i].incident_type ? asi[i].incident_type : "" ;
                var root_cause = asi[i].root_cause ? asi[i].root_cause : "" ;
                var corrective_action_title = asi[i].corrective_action_title ? asi[i].corrective_action_title : "" ;
                var corrective_action_action = asi[i].corrective_action_description ? asi[i].corrective_action_description : "" ;
                var action_status = asi[i].status ? asi[i].status : "" ;
                var supplier_contact = asi[i].supplier_contact ? asi[i].supplier_contact : "" ;
                var deadline_date = asi[i].deadline_date ? asi[i].deadline_date : "" ;
                var modified_date =asi[i].created_at ? asi[i].created_at : asi[i].updated_at;
                var created_by = $("input[name=supplier_user_name]").val();
            }

                    var options = {
                             title : 'Edit Leak Incident Report',
                             message: '<div class="row incident_history_div">  ' +
                                      '<div class="col-md-12">  ' +
                                      '<form class="form-horizontal"> ' +
                                      '<div class="form-group" id="title_div"> ' +
                                      '<label class="col-md-4 control-label" for="Title">Title</label> ' +
                                      '<div class="col-md-7"> ' +
                                      '<input id="title" name="title" type="text" placeholder="Title" value="'+title+'" class="form-control input-md"> ' +
                                      '</div></div>' +
                                      '<div class="form-group" id="incident_date_div"> ' +
                                      '<label class="col-md-4 control-label" for="Date">Date</label> ' +
                                      '<div class="col-md-7"> ' +
                                      '<input id="incident_date" name="incident_date" type="text" placeholder="Date" value="'+incident_date+'" class="form-control input-md"> ' +
                                      '</div></div>' +
                                      '<div class="form-group" id="incident_type_div"> ' +
                                      '<label class="col-md-4 control-label" for="Type">Type</label> ' +
                                      '<div class="col-md-7"> ' +
                                      '<select name="incident_type" id="incident_type" class="form-control"><option value="a">A</option><option value="b">B</option><option value="c">C</option><option value="d">D</option></select>' +
                                      '</div></div>' +
                                      '<div class="form-group" id="root_cause_div"> ' +
                                      '<label class="col-md-4 control-label" for="Root Cause">Root Cause</label> ' +
                                      '<div class="col-md-7"> ' +
                                      '<textarea id="root_cause" name="root_cause" placeholder="Root Cause" class="form-control" rows="3" cols="2" style="resize:none">"'+root_cause.replace(/"/g,"")+'"</textarea>' +
                                      '</div></div>' +
                                      '<div class="form-group" id="corrective_action_title_div"> ' +
                                      '<label class="col-md-4 control-label" for="Risk mitigation">Corrective Action:</label> ' +
                                      '<div class="col-md-7"> ' +
                                      '<input id="corrective_action_title" name="corrective_action_title" value="'+corrective_action_title+'" type="text" placeholder="Title" class="form-control input-md"> ' +
                                      '<textarea id="corrective_action_action" name="corrective_action_action" placeholder="Description" class="form-control custom-control" rows="3" cols="3" style="resize:none">'+corrective_action_action+'</textarea>'+
                                      '</div></div>' +
                                      '<div class="form-group" id="supplier_contact_div"> ' +
                                      '<label class="col-md-4 control-label" for="Need Action">Action Status:</label> ' +
                                      '<div class="col-md-7">' +
                                      '<input id="action_status" name="action_status" type="text"  value="'+action_status+'" placeholder="Supplier Contact" class="form-control input-md" disabled="disabled"> ' +
                                      '</div></div>'+
                                      '<div class="form-group" id="supplier_contact_div"> ' +
                                      '<label class="col-md-4 control-label" for="Need Action">Supplier Contact</label> ' +
                                      '<div class="col-md-7">' +
                                      '<input id="supplier_contact" name="supplier_contact" type="text" value="'+supplier_contact+'" placeholder="Supplier Contact" class="form-control input-md"> ' +
                                      '</div></div>'+
                                      '<div class="form-group" id="deadline_date_div"> ' +
                                      '<label class="col-md-4 control-label" for="Need Action">Deadline Date</label> ' +
                                      '<div class="col-md-7">' +
                                      '<input id="deadline_date" name="deadline_date" type="text" placeholder="Deadline Date" value="'+deadline_date+'" class="form-control input-md"> ' +
                                      '<input type="hidden" name="addtype" value="predefined">'+
                                      '</div></div>'+
                                      '<div class="form-group"> ' +
                                        '<label class="col-md-9 control-label" for="Risk mitigation">Modified on: '+modified_date+' by '+created_by+' </label> ' +
                                       '</div>' +
                                      '</form> </div></div>',
                            buttons : {
                                        success: {
                                            label: "Update",
                                            className: "btn-success",
                                            callback : function(){
                                                          var title  = $("#title").val();
                                                          var incident_date = $("#incident_date").val();
                                                          var type  =  $("#incident_type").val();
                                                          var root_cause =  $("#root_cause").val();
                                                          var corrective_action_title =  $("#corrective_action_title").val();
                                                          var corrective_action_description =  $("#corrective_action_action").val();
                                                          var supplier_contact = $("#supplier_contact").val();
                                                          var deadline_date =  $("#deadline_date").val();
                                                          var addtype =  $("input[name=addtype]").val();
        
                                                          var chk_ary = ['incident_date','title','incident_type','root_cause','corrective_action_title','supplier_contact','deadline_date']

                                                          for(var i=0;i<chk_ary.length;i++){
                                                            validation_incident(chk_ary[i]);
                                                          } 

                                                         if($('.incident_history_div').find('.has-error').length > 0){
                                                               return false;
                                                          }

                                                          
                                                            MsLstUtils.startSpin();
                                                            $.post('/sitemaster/leakincidenthistory',{sid:str,option:'edit',title:title,incident_date:incident_date,type:incident_type,root_cause:root_cause,corrective_action_title:corrective_action_title,corrective_action_description:corrective_action_description,deadline_date:deadline_date,user_id:user_id,supplier_contact:supplier_contact,addtype:addtype})
                                                            .done(function(data){
                                                               window.location.replace(window.location.pathname+"?lpg");
                                                            });
                                                          
                                            }
                                        },
                                        main: {
                                                label: "Cancel",
                                                className: "btn-default",
                                                callback: function() {
                                                  
                                                }
                                              }
                                      }
                    };
                    bootbox.dialog(options);

                     $("#incident_date").daterangepicker({ singleDatePicker: true,
                                                             format: 'YYYY-MM-DD',
                                                             maxDate: new Date(),
                                                             startDate : incident_date,
                                                          });

                     $("#deadline_date").daterangepicker({ singleDatePicker: true,
                                                             format: 'YYYY-MM-DD',
                                                             startDate : new Date(),
                                                             minDate :  new Date(),
                                                          });
                    if(user_id != login_user_id){
                      $(".incident_history_div input,.incident_history_div select,.incident_history_div textarea").attr('disabled','disabled');
                    }

                      $('input#deadline_date,input#incident_date').keydown(function(e) {
                           e.preventDefault();
                           return false;
                       });

        });


   /*Deleting Incident History*/
   MsLstSitemasters.config.incident_history_remove.live('click',function(){
        var incident_detail = {
                                incident_id : $(this).closest('tr').attr('data-id'),
                                supplier_user_id : $("input[name=supplier_user_id]").val(),
                                supplier_id : $("input[name=supplier_id]").val(),
                                login_user_id : $("input[name=login_user_id]").val()
                              };

          if(incident_detail.login_user_id == incident_detail.supplier_user_id){

                bootbox.confirm("Are you sure want to delete this incident?",function(ok){
                  if(ok){
                     $.post('/sitemaster/leakincidenthistory',{inc:incident_detail,option:'delete'})
                                                   .done(function(data){
                                                      if(data == 'done'){
                                                         
                                                         bootbox.dialog({
                                                          message: "Selected Incident is deleted successfully!",
                                                          title : "Delete Incident",
                                                          buttons: {
                                                           success:{
                                                              label:"OK",
                                                              class:"btn-success",
                                                              callback: function(){
                                                                window.location.replace(window.location.pathname+"?lpg");
                                                              }
                                                          }
                                                         }
                                                       });
                                                      }
                                                  });
                  }
                });
           }else{
                bootbox.alert("Cannot delete you do not have permission to delete this incident!");
           }
   });

  /*Deleting Manual Risk*/
  MsLstSitemasters.config.manual_risk_delete.live('click',function(){
    var risk_detail = {
                        leak_id : $(this).closest('td').attr('data-id'),
                        supplier_user_id : $("input[name=supplier_user_id]").val(),
                        supplier_id : $("input[name=supplier_id]").val(),
                        login_user_id : $("input[name=login_user_id]").val(),
                        option : 'delete'
                      };
          if(risk_detail.login_user_id == risk_detail.supplier_user_id){
              bootbox.confirm("Are you sure want to delete this Manual Risk?",function(ok){
                if(ok){
                        $.ajax({
                                        type: 'POST',
                                        url: '/sitemaster/leakriskanalysis',
                                        data: risk_detail,
                                        beforeSend:function(){
                                             MsLstUtils.startSpin();
                                        },
                                        success:function(data){
                                          $('select.selectpicker').selectpicker('refresh');
                                          bootbox.alert("Selected Manual risk is deleted successfully!",function(){
                                              window.location.replace(window.location.pathname+"?lpg");
                                           });
                                        }
                       });
                }
              });
          }else{
               bootbox.alert("Cannot delete you do not have permission to delete this Risk!");
          }

  });

     
    $("#save_leak_analysis").hide();

    if($("input[name=busines_show]").val() == '2'){
       $("#busines_activity").hide();
    }else{
      $("#save_leak_analysis").show();
    }

    MsLstSitemasters.config.addassests.on('click',function(){
        var i = 1; 
        if($("#busines_activity").is(':visible')){
          if($(".activty-count").length > 0){
               i = parseInt($(".activty-count").last().html().replace("#",""))+1;
          }

          var activty = '<div class="row activty-row" id="activty-row'+i+'">
                                      <div class="col-sm-1 activity-cols">
                                      <span class="form-control activty-count">'+i+'</span>
                                                                            </div>
                                                                            <div class="col-lg-3">
                                                                              <div class="form-group"> 
                                                                                    <select class="form-control bus_activity_sel selectpicker" id="bus_activity_sel'+i+'" name="activity'+i+'">
                                                                                        <option value=""> Select Business Activity</option>
                                                                                        <option value="1">Device and accessory manufacturing</option>
                                                                                        <option value="2">Consumer & UX studies</option>
                                                                                        <option value="3">Creative agencies</option>
                                                                                        <option value="4">Appearance model making</option>
                                                                                        <option value="5">Component Manufacturing</option>
                                                                                        <option value="6">Print & Packaging</option>
                                                                                        <option value="7">R&D</option>
                                                                                    </select>
                                                                              </div>
                                                                            </div>
                                                                            <div class="col-lg-3">
                                                                              <div class="form-group">
                                                                                    <select class="form-control  bus_assests_sel selectpicker" id="bus_assests_sel'+i+'" name="assets'+i+'" multiple="multiple" title=" Select Assets" >
                                                                                         <option value="" data-hidden="true"></option>                                                                                     
                                                                                    </select>
                                                                              </div>
                                                                            </div>
                                                                            <div class="col-lg-3">
                                                                              <div class="form-group">
                                                                                    <select class="form-control  bus_supp_lob selectpicker" id="bus_supp_lob'+i+'" name="supp_lob'+i+'" multiple="multiple" title="Select Supported lines of business" >
                                                                                         <option value="" data-hidden="true"></option>                                                                                     
                                                                                    </select>
                                                                              </div>
                                                                            </div>
                                                                           <div class="col-lg-1">
                                                                                    <span class="glyphicon glyphicon-remove business_remove"   id="business_remove'+i+'" alt="'+i+'" aria-hidden="true"></span>
                                                                           </div>
                                                                       </div>';
            if(i <= 7){
               MsLstSitemasters.config.busines_activity.append(activty);
            }else{
                   bootbox.alert("Note:Maximum limit allowed upto 7.", function() {
                  
                   });
            }

            $('.selectpicker').selectpicker('refresh');
            $(".leak_risk_activity_assets").hide();

        }else{
          $("#busines_activity").show();
          $(".leak_risk_activity_assets").hide();
        }
          $("#save_leak_analysis").show(); 

          
         if($("select[name='activity"+i+"']").val() != '')  $("select[name='activity"+i+"']").trigger('change');


     });

    

   

    $("#save_leak_analysis").on('click',function(){

        var i = parseInt($(".activty-count").last().html().replace("#",""));
        var businesAct = [];
        var Assets = [];
        var risk_analys_new = {};
        var risk_analys_exist = {};
        var oldid = null;

          for(var j=1; j<=i;j++){

              if($("select[name=activity"+j+"]").val().trim() !=''){


                if($("#activty-row"+j+"").attr('data-id') == undefined){
                  risk_analys_new[j]  =  {busines : $("select[name=activity"+j+"]").val(), assets : $("select[name=assets"+j+"]").val() ,lob: $("select[name=supp_lob"+j+"]").val() };
                }else{
                  oldid = $("#activty-row"+j+"").attr('data-id');
                  risk_analys_exist[oldid]  =  {busines : $("select[name=activity"+j+"]").val(), assets : $("select[name=assets"+j+"]").val() ,lob: $("select[name=supp_lob"+j+"]").val() };
                }

              }
              if($("select[name=assets"+j+"]").val() == null){
                  
                 bootbox.alert("Please select the assets from predefined list!",function(){
                                             $("select[name=assets"+j+"]").select2('open').select2('focus');
                                              $('select.selectpicker').selectpicker('refresh');
                                           });

                  return false;
              }
          }
          var id = $("input[name=supplier_id]").val();
          var info  = {risk_analys_new : JSON.stringify(risk_analys_new), risk_analys_exist : JSON.stringify(risk_analys_exist), option : 'exist_analysis', ids : id} ;

              $.ajax({
                                        type: 'POST',
                                        url: '/sitemaster/leakriskanalysis',
                                        data: info,
                                        beforeSend:function(){
                                             MsLstUtils.startSpin();
                                        },
                                        success:function(data){
                                          //console.log(data);
                                          $('select.selectpicker').selectpicker('refresh');
                                          bootbox.alert("Selected business activities and assets are updated successfully",function(){
                                          	 window.location.replace(window.location.pathname+"?lpg");
                                          });
                                        }
                    });
      });

    $(".business_remove").live('click',function(){
            var i =1 , j=1 , b =1 , a= 1 , r=1 , sv_bt = false , slob=1;
            var sid = $("input[name=supplier_id]").val();

            $(".activty-row").each(function(){
               if($(this).attr('data-id') != '' && $(".activty-count").length == 1) {
                bootbox.confirm("Are you sure want to delete the business activity and assests",function(results){
                    if(results == true){
                        $("#activty-row1").remove();
                        $.ajax({
                                type: 'POST',
                                url: '/sitemaster/leakriskanalysis',
                                data: 'id='+sid+'&option=delete_all',
                                beforeSend:function(){
                                     MsLstUtils.startSpin();
                                },
                                success:function(data){
                                  $('select.selectpicker').selectpicker('refresh');
                                  bootbox.alert("Selected business activity and assets are deleted successfully",function(){
                                      window.location.replace(window.location.pathname+"?lpg");
                                   });
                                }
                         });
                    }else{
                       //alert(results);
                    }
                });
               }
            });

            if($("#activty-row1").attr('data-id') != '' && $(".activty-count").length > 1) {

                    $("#activty-row"+$(this).attr('alt')).remove();

                    $(".activty-count").each(function(){
                       $(this).html(i);
                       i++;
                    });

                    $(".activty-row").each(function(){
                       $(this).attr('id','activty-row'+j);
                       j++;
                    });

                    $('.business_remove').each(function(){
                        $(this).attr('alt',r);
                        $(this).attr('id','business_remove'+r);
                       r++;
                    });
         
                    if($(".activty-count").length == 0 ){
                      $("#save_leak_analysis").hide();
                    }

                   $("select[name^=activity]").each(function(){
                      $(this).attr('id',"bus_activity_sel"+b);
                      $(this).attr('name',"activity"+b);
                      b++;
                      $('select.selectpicker').selectpicker('refresh');
                    }); 

                   $("select[name^=assets]").each(function(){
                      $(this).attr('id',"bus_assests_sel"+a);
                      $(this).attr('name',"assets"+a);
                      a++;
                      $('select.selectpicker').selectpicker('refresh');
                    }); 

                    $("select[name^=supp_lob]").each(function(){
                      $(this).attr('id',"bus_supp_lob"+slob);
                      $(this).attr('name',"supp_lob"+slob);
                      slob++;
                      $('select.selectpicker').selectpicker('refresh');
                    }); 
             }
    });

    $("select[name^='activity']").live('change',function(){
        var activ = JSON.parse(JSON.stringify(MsLstSitemasters.config.business_assets));
        var assets = '' , s_lob= '', assets_grp = null;
        var nm = $(this).attr('name');
        var id = nm.replace('activity','');
        var lob_act = JSON.parse(JSON.stringify(MsLstSitemasters.config.business_lob));
        
        $("select[name=assets"+id+"]").empty();
        
        if($(this).val().trim() != '') {
             $.each(activ[$(this).val()],function(i,n){
                assets_grp = $('<optgroup></optgroup').attr('label',i);
                assets = '';
               $.each(n,function(i_id,n_val){
                 
                  assets+= "<option value='"+i_id+"'>"+n_val+"</option>"
                  $('select[name=assets'+id+']').select2("data", { id: i_id, text: n_val },true);
               });

                assets_grp  = assets_grp.append(assets);
                $("select[name=assets"+id+"]").append(assets_grp);
                $('select.selectpicker').selectpicker('refresh');
             });

             $.each(lob_act,function(i_lob,n_lob){
                      s_lob+="<option value='"+i_lob+"'>"+n_lob+"</option>";
             });

             console.log(s_lob);

             $("select[name=supp_lob"+id+"]").append(s_lob);
             $('select.selectpicker').selectpicker('refresh');

       
        }else{
           $('select.selectpicker').selectpicker('refresh');
        }
         
    });

    $("select[name=deter_overall_status]").live('change',function(){
        var sid = $("input[name=supplier_id]").val();
        var status = $(this).val();
        bootbox.confirm("Please confirm your Determined Overall Status?",function(ok){
            if(ok){
                    $.ajax({
                            type : 'POST',
                            url: '/sitemaster/leakpreventionstatus',
                            data: 'sid='+sid+'&option=deter_overall_status&status='+status,
                            beforeSend:function(){
                              MsLstUtils.startSpin();
                            },
                            success:function(data){
                              bootbox.alert("Overall Status is changed successfully!",function(){
                                MsLstUtils.stopSpin(); 
                              });
                            }
                    });
             }
        });
        
    });

      $(".lp_correctiv_action_edit").live('click',function(){
          var detail = {
                              ca_id:  $(this).closest('tr').attr('data-id'),
                       };

          var select_ca =  MsLstSitemasters.config.lp_corrective_actions[detail.ca_id];
          var access_name = MsLstSitemasters.config.access_name.lp_access_name;
          var divtag = '';
          var pm_comments = (select_ca['pm_comments']) ? select_ca['pm_comments'] : "" ;
          var assement_user_comments = (select_ca['assement_user_comments']) ? select_ca['assement_user_comments'] : "" ;
          console.log(select_ca);

          if(select_ca['due_date_extension'] != null){

                 divtag+= '<div class="form-group" id="supplier_comments_div"> ' +
                                          '<label class="col-md-4 control-label" >Extended due date</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<input id="due_date_extension" name="due_date_extension" type="text" placeholder="Extended due date" class="form-control input-md" value='+select_ca['due_date_extension']+' disabled> ' +                                          
                          '</div></div>';

          }

          if(access_name == 'pm_plus_user' || access_name == 'supplier_user' || access_name == 'admin'  ){

                 divtag+= '<div class="form-group" id="supplier_comments_div"> ' +
                                          '<label class="col-md-4 control-label" >Supplier Comments</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<select name="request_closure" id="request_closure" class="form-control" ><option value="">-- Select closure option --</option><option value="completed">Completed - Request Closure</option><option value="declined">Declined - Request Closure</option><option value="inprogress">In Progress – Request Due Date Extension</option><option value="mitigated">Mitigated – Request Closure</option></select>'+
                                          '<textarea id="assement_user_comments" name="assement_user_comments" class="form-control input-md" >'+assement_user_comments+'</textarea>'+
                                          '</div></div>';

          }else{
             divtag+= '<div class="form-group" id="supplier_comments_div"> ' +
                                          '<label class="col-md-4 control-label" >Supplier Comments</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<select name="request_closure" id="request_closure" class="form-control" disabled><option value="">-- Select closure option --</option><option value="completed">Completed - Request Closure</option><option value="declined">Declined - Request Closure</option><option value="inprogress">In Progress – Request Due Date Extension</option><option value="mitigated">Mitigated – Request Closure</option></select>'+
                                          '<textarea id="assement_user_comments" name="assement_user_comments" class="form-control input-md" disabled >'+assement_user_comments+'</textarea>'+
                                          '</div></div>';

          }


          if(select_ca['due_date_extension'] == null && select_ca['assessment_request_closure'] == 'inprogress' ){
             
                     if(access_name == 'pm_plus_user' ||  access_name == 'pm_user' ||  access_name == 'admin'){
                
                        divtag+= '<div class="form-group" id="due_date_extension_div">
                                      <label class="col-md-4 control-label">Due Date Extension</label>
                                             <div class="col-md-7">
                                              <select name="days_past_due" id="days_past_due" class="form-control"><option value="15">15 Days</option><option value="30">30 Days</option><option value="60">60 Days</option><option value="90">90 Days</option></select>                                            
                                             </div>
                                 </div>';
                     }
          }

          

          if(access_name == 'pm_plus_user' || access_name == 'admin' || access_name == 'pm_user'){
                   divtag+=  '<div class="form-group" id="vam_approval_div"> ' +
                                          '<label class="col-md-4 control-label" >Protection PM Approval</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<select id="pm_approval" name="pm_approval" class="form-control"><option value="">N/A</option><option value="accept">Accept</option><option value="ignore">Deny</option> </select>'+
                                          '<textarea id="pm_comments" name="pm_comments" class="form-control input-md" >'+pm_comments+' </textarea>'+
                                          '</div></div>';
          }else{
                  divtag+=  '<div class="form-group" id="vam_approval_div"> ' +
                                          '<label class="col-md-4 control-label" >Protection PM Approval</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<select id="pm_approval" name="pm_approval" class="form-control" disabled><option value="">N/A</option><option value="accept">Accept</option><option value="ignore">Deny</option> </select>'+
                                          '<textarea id="pm_comments" name="pm_comments"class="form-control input-md"  disabled>'+pm_comments+'</textarea>'+
                                          '</div></div>';
          }


           //alert(access_name);
              var severityclassName = { urgent :'sev_urg_class' , high :'sev_hig_class' , medium:'sev_mid_class' ,low:'sev_low_class'};
              var sev_val = select_ca['severity'].toLowerCase().toString();
             

              //Popup
              var inspector_comments_txt  = (select_ca['assessment_comments']!=null)?select_ca['assessment_comments']:'';


                          var options = {
                              title : 'Update Corrective Actions',
                              message: '<div class="row new_risk_div">  ' +
                                          '<div class="col-md-12"> ' +
                                          '<form class="form-horizontal" method="post" enctype="multipart/form-data"> ' +
                                          '<div class="form-group" id="inspector_name_div"> ' +
                                          '<label class="col-md-4 control-label" >Inspector Name</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<input id="inspector_name" name="inspector_name" type="text" placeholder="Inspector Name" class="form-control input-md" value='+select_ca['user']['first_name']+' '+select_ca['user']['last_name']+'  disabled> ' +
                                          '</div></div>' +
                                          '<div class="form-group" id="text_div"> ' +
                                          '<label class="col-md-4 control-label" for="Action">Requirement Text</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<textarea id="requirement_text" name="requirement_text" class="form-control input-md" disabled >'+select_ca['requirement_text']+'</textarea>'+
                                          '</div></div>' +
                                          '<div class="form-group" id="sevirty_div"> ' +
                                          '<label class="col-md-4 control-label" >Severity</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<input id="severity" name="severity" type="text" placeholder="Severity" class="form-control input-md" value='+select_ca['severity']+'  disabled> ' +
                                          '</div></div>' +
                                          '<div class="form-group" id="inspector_comment_div"> ' +
                                          '<label class="col-md-4 control-label" >Inspector comments</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<textarea id="assessment_comments" name="assessment_comments" class="form-control input-md" disabled >'+inspector_comments_txt+'</textarea>'+
                                          '</div></div>' +
                                          '<div class="form-group" id="inital_due_date_div"> ' +
                                          '<label class="col-md-4 control-label" >Initial Due Date</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<input id="initial_due_date" name="initial_due_date" type="text" placeholder="Initial Due Date" value='+select_ca['initial_due_date']+'  class="form-control input-md" disabled> ' +
                                          '</div></div>' +
                                            divtag+                                          
                                          '</form> </div></div>',
                            buttons: {
                                        success: {
                                                    label : "Save",
                                                    className: "btn-success",
                                                    callback: function(data) {

                                                      var CAform_data = new FormData;

                                                      CAform_data.append('pm_comments',$("#pm_comments").val());
                                                      CAform_data.append('pm_approval',$("#pm_approval").val());
                                                      CAform_data.append('request_closure',$("#request_closure").val());
                                                      CAform_data.append('assessment_comments',$("#assessment_comments").val());
                                                      CAform_data.append('id',select_ca['id']);
                                                      CAform_data.append('sitemaster_id',select_ca['site_master_id']);
                                                      CAform_data.append('question_id',select_ca['question_id']);
                                                      CAform_data.append('supplier_user_id',$("input[name=supplier_user_id]").val());
                                                      CAform_data.append('days_past_due',$("select[name=days_past_due]").val());
                                                      CAform_data.append('inital_due_date',$("input[name=initial_due_date]").val());
                                                      CAform_data.append('assement_user_comments',$("#assement_user_comments").val());
                                                      
                                                      CAform_data.append('type','update');
                                                      
                                                      console.log(CAform_data);
                                                      
                                                      
                                                      $.ajax({
                                                        url:'/sitemaster/calpinspection/update',
                                                        processData: false, // Important!
                                                        contentType: false, // Important!
                                                        type: "post",
                                                        data: CAform_data,
                                                        beforeSend:function(){
                                                            console.log('progress');
                                                            MsLstUtils.startSpin();
                                                        },
                                                        success : function(data){
                                                          console.log("updated");
                                                           bootbox.dialog({
                                                                  message: data,
                                                                  buttons: {
                                                                  success: {
                                                                      label: "OK",
                                                                      className: "btn-success",
                                                                      callback: function(){
                                                                           var CAurl = window.location.href.split('?');
                                                                               window.location.replace(CAurl[0]+"?lpg");
                                                                        }
                                                                      }
                                                                  }
                                                         });
                                                           
                                                        },
                                                        error : function(){
                                                          console.log("Not updated");
                                                        }
                                                      });
                                                      
                                                    }
                                        },
                                        main: {
                                                  label: "Cancel",
                                                  className: "btn-default",
                                                  callback: function() {
                                                     
                                                  }
                                        }
                            }

                            };

                       bootbox.dialog(options);

                      $("#request_closure option[value='"+select_ca['assessment_request_closure']+"']").attr('selected','selected');
                      $("#pm_approval option[value='"+select_ca['pm_approval']+"']").attr('selected','selected');

      });

     /* End  Leak Prevention assement */
  },
  setUpPRInspection: function() {
     var res = window.location.href.split('inspection');
     MsLstUtils.createSingleDatePicker(MsLstSitemasters.config.ins_main_date,'','yes');
     
     if(res.length == 2){
          /* P+R function Start */
              /* Inspection Functionality Start */
              $("textarea[id^='comment'],a[class^=comment-link]").css('cssText','display:none;');
              
              $("select[id^='question']").on('change',function(){ 
                 if($(this).val()== 2){
                    $("#"+$(this).attr('id').replace('question','comment')).css('cssText','display:block;');
                    $('.'+$(this).attr('id').replace('question','comment-link')).css('cssText','display:block;');
                  }else{
                    $("#"+$(this).attr('id').replace('question','comment')).val('').css('cssText','display:none;');
                    $('.'+$(this).attr('id').replace('question','comment-link')).css('cssText','display:none;');
                  }
              });

               $("select[id^='question']").each(function(){
                  if($(this).val()== 2){
                      $("#"+$(this).attr('id').replace('question','comment')).css('cssText','display:block;');
                      $('.'+$(this).attr('id').replace('question','comment-link')).css('cssText','display:block;');
                  }
               });

      
               $(".site_inspection").on('click',function(e){

                  $("textarea[id^='comment']").each(function(){
                      if($(this).val().trim() == '' && $(this).attr('style') == 'display: block;'){
                          var Qid = $(this).attr('id');
                          bootbox.alert("If Non-complaint is selected then need to fill comment for this Inspection!",function(){
                            $("#"+Qid).focus().css('cssText','border-color:#ff0000;');
                          });

                          e.preventDefault();
                          return false;
                      } 
                  });
                  return true;
               });
            /* Inspection Functionality End */
         }else{ 
           /*Corrective Action */
           MsLstUtils.createDataTable(MsLstSitemasters.config.corrective_action_tb,'Corrective Actions',[], [],'','',"rtip");
          
          $(".correctiv_action_edit").live('click',function(){

              var detail = {
                              ca_id:  $(this).closest('tr').attr('data-id'),
                           };


              var select_ca =  MsLstSitemasters.config.corrective_actions[detail.ca_id];
              var access_name = MsLstSitemasters.config.access_name.pr_access_name;
              
              console.log(select_ca['supplier_comments_evidence']);

              if(select_ca['vam_comments'] == null) select_ca['vam_comments'] = '';
              if(select_ca['supplier_comments_evidence'] == null) select_ca['supplier_comments_evidence'] = '';
              
              
              var divtag = '';
               
               if(access_name == 'csm_user' || access_name == 'admin'){

               }

               if(select_ca['due_date_extension'] != null){

                 divtag+= '<div class="form-group" id="supplier_comments_div"> ' +
                                          '<label class="col-md-4 control-label" >Extended due date</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<input id="due_date_extension" name="due_date_extension" type="text" placeholder="Extended due date" class="form-control input-md" value='+select_ca['due_date_extension']+' disabled> ' +                                          
                          '</div></div>';

               }

              if(access_name == 'csm_plus_user' || access_name == 'vam_plus_user' || access_name == 'supplier_user' || access_name == 'admin'  ){

                 divtag+= '<div class="form-group" id="supplier_comments_div"> ' +
                                          '<label class="col-md-4 control-label" >Supplier Comments</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<select name="request_closure" id="request_closure" class="form-control" ><option value="">-- Select closure option --</option><option value="completed">Completed - Request Closure</option><option value="declined">Declined - Request Closure</option><option value="inprogress">In Progress – Request Due Date Extension</option><option value="mitigated">Mitigated – Request Closure</option></select>'+
                                          '<textarea id="supplier_comments" name="supplier_comments"class="form-control input-md" >'+select_ca['supplier_comments_evidence']+'</textarea>'+
                                          '</div></div>';

               }
              
               if(select_ca['due_date_extension'] == null && select_ca['supplier_request_closure'] == 'inprogress' ){
             
                     if(access_name == 'csm_plus_user' ||  access_name == 'csm_user' ||  access_name == 'admin'){
                
                        divtag+= '<div class="form-group" id="due_date_extension_div">
                                      <label class="col-md-4 control-label">Due Date Extension</label>
                                             <div class="col-md-7">
                                              <select name="days_past_due" id="days_past_due" class="form-control"><option value="15">15 Days</option><option value="30">30 Days</option><option value="60">60 Days</option><option value="90">90 Days</option></select>                                            
                                             </div>
                                 </div>';
                     }
                }


               if(access_name == 'vam_user' || access_name == 'admin' || access_name == 'vam_plus_user'){
                   divtag+=  '<div class="form-group" id="vam_approval_div"> ' +
                                          '<label class="col-md-4 control-label" >VAM Approval</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<select id="vam_approval" name="vam_approval" class="form-control"><option value="">N/A</option><option value="accept">Accept</option><option value="ignore">Deny</option> </select>'+
                                          '<textarea id="vam_comments" name="vam_comments"class="form-control input-md" >'+select_ca['vam_comments']+' </textarea>'+
                                          '</div></div>';
               }else{
                  divtag+=  '<div class="form-group" id="vam_approval_div"> ' +
                                          '<label class="col-md-4 control-label" >VAM Approval</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<select id="vam_approval" name="vam_approval" class="form-control" disabled><option value="">N/A</option><option value="accept">Accept</option><option value="ignore">Deny</option> </select>'+
                                          '<textarea id="vam_comments" name="vam_comments"class="form-control input-md"  disabled>'+select_ca['vam_comments']+'</textarea>'+
                                          '</div></div>';
               }

               
              var severityclassName = { urgent :'sev_urg_class' , high :'sev_hig_class' , medium:'sev_mid_class' ,low:'sev_low_class'};
              var sev_val = select_ca['severity'].toLowerCase().toString();
         
              //Popup
              var inspector_comments_txt  = (select_ca['inspector_comments']!=null)?select_ca['inspector_comments']:'';
             

                var options = {
                              title : 'Update Corrective Actions',
                              message: '<div class="row new_risk_div">  ' +
                                          '<div class="col-md-12"> ' +
                                          '<form class="form-horizontal" method="post" enctype="multipart/form-data"> ' +
                                          '<div class="form-group" id="inspector_name_div"> ' +
                                          '<label class="col-md-4 control-label" >Inspector Name</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<input id="inspector_name" name="inspector_name" type="text" placeholder="Inspector Name" class="form-control input-md" value='+select_ca['user']['first_name']+' '+select_ca['user']['last_name']+'  disabled> ' +
                                          '</div></div>' +
                                          '<div class="form-group" id="reference_div"> ' +
                                          '<label class="col-md-4 control-label" for="risk">P+R reference</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<input id="reference" name="reference" type="text" placeholder="P+R reference" class="form-control input-md" value='+select_ca['p_r_reference']+' disabled> ' +
                                          '</div></div>' +
                                          '<div class="form-group" id="action_div"> ' +
                                          '<label class="col-md-4 control-label" for="Action">P+R version</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<input id="version" name="version" type="text" placeholder="P+R version" class="form-control input-md" value='+select_ca['p_r_version']+'  disabled> ' +
                                          '</div></div>' +
                                          '<div class="form-group" id="text_div"> ' +
                                          '<label class="col-md-4 control-label" for="Action">P+R text</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<textarea id="inspector_comment" name="inspector_comment" class="form-control input-md" disabled >'+select_ca['p_r_text']+'</textarea>'+
                                          '</div></div>' +
                                          '<div class="form-group" id="sevirty_div"> ' +
                                          '<label class="col-md-4 control-label" >Severity</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<input id="severity" name="severity" type="text" placeholder="Severity" class="form-control input-md" value='+select_ca['severity']+'  disabled> ' +
                                          '</div></div>' +
                                          '<div class="form-group" id="inspector_comment_div"> ' +
                                          '<label class="col-md-4 control-label" >Inspector comments</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<textarea id="inspector_comment" name="inspector_comment" class="form-control input-md" disabled >'+inspector_comments_txt+'</textarea>'+
                                          '</div></div>' +
                                          '<div class="form-group" id="inital_due_date_div"> ' +
                                          '<label class="col-md-4 control-label" >Initial Due Date</label> ' +
                                          '<div class="col-md-7"> ' +
                                          '<input id="inital_due_date" name="inital_due_date" type="text" placeholder="Initial Due Date" value='+select_ca['intial_due_date']+'  class="form-control input-md" disabled> ' +
                                          '</div></div>' +
                                            divtag+                                          
                                          '</form> </div></div>',
                            buttons: {
                                        success: {
                                                    label : "Save",
                                                    className: "btn-success",
                                                    callback: function(data) {

                                                      var CAform_data = new FormData;

                                                      CAform_data.append('vam_comments',$("#vam_comments").val());
                                                      CAform_data.append('vam_approval',$("#vam_approval").val());
                                                      CAform_data.append('request_closure',$("#request_closure").val());
                                                      CAform_data.append('supplier_comments',$("#supplier_comments").val());
                                                      CAform_data.append('id',select_ca['id']);
                                                      CAform_data.append('sitemaster_id',select_ca['sitemaster_id']);
                                                      CAform_data.append('question_id',select_ca['question_id']);
                                                      CAform_data.append('supplier_user_id',$("input[name=supplier_user_id]").val());
                                                      CAform_data.append('days_past_due',$("select[name=days_past_due]").val());
                                                      CAform_data.append('inital_due_date',$("input[name=inital_due_date]").val());
                                                      
                                                      CAform_data.append('type','update');
                                                      
                                                      console.log(CAform_data);
                                                      
                                                      MsLstUtils.startSpin();
                                                      $.ajax({
                                                        url:'/sitemaster/cainspection/update',
                                                        processData: false, // Important!
                                                        contentType: false, // Important!
                                                        type: "post",
                                                        data: CAform_data,
                                                        success : function(data){
                                                          console.log("updated");
                                                           bootbox.dialog({
                                                                  message: data,
                                                                  buttons: {
                                                                  success: {
                                                                      label: "OK",
                                                                      className: "btn-success",
                                                                      callback: function(){
                                                                           var CAurl = window.location.href.split('?');
                                                                               window.location.replace(CAurl[0]+"?pr");
                                                                        }
                                                                      }
                                                                  }
                                                         });
                                                           
                                                        },
                                                        error : function(){
                                                          console.log("Not updated");
                                                        }
                                                      });
                                                      
                                                    }
                                        },
                                        main: {
                                                  label: "Cancel",
                                                  className: "btn-default",
                                                  callback: function() {
                                                     
                                                  }
                                        }
                            }

                            };

                       bootbox.dialog(options);

                       $("#request_closure option[value='"+select_ca['supplier_request_closure']+"']").attr('selected','selected');
                       $("#vam_approval option[value='"+select_ca['vam_approval']+"']").attr('selected','selected');

            
          }); 


            $("#selectInspectionID").on('change',function(){
                var CAurl = window.location.href.split('?');
                window.location.replace(CAurl[0]+"?pr&uid="+$(this).val());
            });

         }

          if($(".pr_ca_section").length > 0){

              var $table = $('table.cascroll'),
              $bodyCells = $table.find('tbody tr:first').children(),
              colWidth;
         
              // Adjust the width of thead cells when window resizes
              $(window).resize(function() {
                  // Get the tbody columns width array
                  colWidth = $bodyCells.map(function() {
                      return $(this).width();
                  }).get();
                  
                  // Set the width of thead columns
                  $table.find('thead tr').children().each(function(i, v) {
                      $(v).width(colWidth[i]);
                  });    
              }).resize(); // Trigger resize handler
          }

    /* P+R function Ends */
  }
};



/**
 * Handlers for lane create/edit and listing
 */
var MsLstLanes = {
    init: function () {
        MsLstLanes.config = {
            deleteLanes : $('#lane_del'),
		      	deleteLanesyes : $('#delete_yes'),
            createlane:$('#create_lanes'),
            pendinglane: $('#pending_lane'),
            autoroutecreate: $('#auto_route_create')
        };
        MsLstLanes.setUp();
    },
    setUp: function(){
        MsLstLanes.setUpDeleteLanes();
		MsLstLanes.setUpDeleteLanesyes();
        MsLstLanes.setUpCreateLaneOpt();
        MsLstLanes.setUpUpdatependinglane();
        MsLstLanes.setUpLanesform();
        MsLstLanes.setUpTriggerLanesForms();
    },
    setUpLanesform: function(){
        MsLstUtils.createSelect2s([
            {element: $('select[name="lsp[]"]')}
        ]);

        $('input[name="daterange"]').daterangepicker({
            format: 'YYYY-MM-DD',
            maxDate: moment().add(1, 'days'),
            showDropdowns: true,
            showWeekNumbers: true
        },
        function(start, end, label) {
            $("#lanes-list-form").trigger("submit");
            // TODO
        });

    },
    setUpTriggerLanesForms : function(){
          MsLstUtils.createDataTable($('#lanes-list'), 'audits','', '','','1',"rtip");
          $("#lanes-list-form select").on('change',function(){
                $("#lanes-list-form").trigger("submit");
          });

          $("input[name='aid']").on('blur',function(){
             $("#lanes-list-form").trigger("submit");
          });

    },
    setUpCreateLaneOpt: function(){
        MsLstLanes.config.createlane.on('click',function(){
                document.cookie = "startlanes=new;365";
                document.location.href='/lanes/create';
         });
        MsLstLanes.config.autoroutecreate.live('click',function(){
             var startlocation = $(this).attr('data-start');
             var endlocation = $(this).attr('data-end');
             var dat         = "startlocation="+startlocation+"&endlocation="+endlocation;


              bootbox.confirm("Pressing OK will create route.", function(ok) {
                        if (ok) {

                            $.ajax({
                                    type: 'POST',
                                    url: '/lanes/routecreate',
                                    data: dat,
                                    beforeSend:function(){
                                        console.log('progress');
                                        $('body').append('<span class="modal-backdrop fade in modalclass" style="text-align:center;"><img src="/css/images/ajax-loader.gif" style="padding-top:20%"></span>');
                                    },
                                    success:function(data){
                                       $('.modalclass').removeClass('modal-backdrop fade in');
                                        bootbox.dialog({
                                            message : data,
                                            title   : 'Route Creation'
                                        });
                                        //console.log(data);
                                    }
                             });

                        }
                   });

        });
    },
    setUpUpdatependinglane: function(){
        MsLstLanes.config.pendinglane.live('click',function(){
            document.location.href='/lanes/'+$(this).attr('tag');
        });
    },
    setUpDeleteLanes: function(){
         MsLstLanes.config.deleteLanes.live('click',function(){
				var data = $(this).attr('tag');
				$("#dellane").val(data);
         });
    },
	setUpDeleteLanesyes: function(){
  		  MsLstLanes.config.deleteLanesyes.on('click',function(){
				var dat = "id="+$('#dellane').val();
				$.ajax({
					type: 'POST',
					url: 'lanes/delete',
					data: dat,
					beforeSend:function(){
						console.log('progress');
						$('body').append('<span class="modal-backdrop fade in" style="text-align:center;"><img src="css/images/ajax-loader.gif" style="padding-top:20%"></span>');
					},
					success:function(data){
						document.location.href='lanes';
						console.log('success');
					}
				});
         });
    }
};

/**
 * Handlers for settings management
 */
var MsLstSettings = {
    init: function () {
        MsLstSettings.config = {
            availabilitySelect: $('select[name="availability"]'),
            tosSwitch: $("input[name='site_ask_agree_tnc']"),
            alertoption: $("input[name='site_alert_option']"),
            textareas: $('#settings-form textarea')
        };

        MsLstSettings.setUp();
    },
    setUp: function () {
        MsLstSettings.setUpSettingsTabs();
    },
    setUpSettingsTabs: function () {
        MsLstUtils.createSelect2s([
            {element: MsLstSettings.config.availabilitySelect, options: { placeholder: "Select Availability" }}
        ]);

        MsLstUtils.createBootstrapSwicth(MsLstSettings.config.alertoption, {onText: "Yes", offText: 'No', size: 'normal'});
        MsLstUtils.createBootstrapSwicth(MsLstSettings.config.tosSwitch, {onText: "Yes", offText: 'No', size: 'normal'});

   
        MsLstUtils.createSummerNote(MsLstSettings.config.textareas, {height: 200});

         $("#setting_cancel").click(function(event){
            bootbox.confirm("The Setting will not be saved. Press OK to discard",function(ok){
                if(ok){
                    window.location.href = 'settings';
                }
            });
            event.preventDefault();
        });
    }
};

/**
 * Handlers for users create/edit and listing
 */
var MsLstUsers = {
    init: function () {
        MsLstUsers.config = {
            roleSelect: $('select[name="role"]'),
            lspSelect: $('select[name="lsp"]'),
            userlevelSelect: $('select[name="user_level"]'),
            lanesSwitch: $("input[name='access_lanes']"),
            auditsSwitch: $("input[name='access_audits']"),
            incidentsSwitch: $("input[name='access_incidents']"),
			factoryincidentsSwitch: $("input[name='access_factory_incidents']"),
            suppliersSwitch: $("input[name='access_suppliers']"),
            sitemastersSwitch: $("input[name='access_sitemasters']"),
            LeakPreventionSwitch: $("input[name='access_leak_prevention']"),
            accessP_R: $("input[name='access_p_r']"),
            usersList: $('#users-list'),
        };

        MsLstUsers.setUp();
    },
    setUp: function () {
        MsLstUsers.setUpUsersForm();
        MsLstUsers.setUpUsersList();
    },
    setUpUsersForm: function () {
        MsLstUtils.createSelect2s([
            {element: MsLstUsers.config.roleSelect, options: { placeholder: " Select Role " }},
            {element: MsLstUsers.config.lspSelect, options: { placeholder: " Select Company Name " }},
            {element: MsLstUsers.config.userlevelSelect, options: { placeholder: " Select User level " }}
        ]);

        MsLstUtils.createBootstrapSwicth(MsLstUsers.config.lanesSwitch, {onText: "Yes", offText: 'No', size: 'normal'});
        MsLstUtils.createBootstrapSwicth(MsLstUsers.config.auditsSwitch, {onText: "Yes", offText: 'No', size: 'normal'});
        MsLstUtils.createBootstrapSwicth(MsLstUsers.config.incidentsSwitch, {onText: "Yes", offText: 'No', size: 'normal'});
		    MsLstUtils.createBootstrapSwicth(MsLstUsers.config.factoryincidentsSwitch, {onText: "Yes", offText: 'No', size: 'normal'});
		    MsLstUtils.createBootstrapSwicth(MsLstUsers.config.suppliersSwitch, {onText: "Yes", offText: 'No', size: 'normal'});
        MsLstUtils.createBootstrapSwicth(MsLstUsers.config.sitemastersSwitch, {onText: "Yes", offText: 'No', size: 'normal'});
        MsLstUtils.createBootstrapSwicth(MsLstUsers.config.LeakPreventionSwitch, {onText: "Yes", offText: 'No', size: 'normal'});
        MsLstUtils.createBootstrapSwicth(MsLstUsers.config.accessP_R, {onText: "Yes", offText: 'No', size: 'normal'});

        MsLstUsers.config.roleSelect.on("change", function () {
            toggleRegionRoleSelect(this.value);
        });
        
        MsLstUsers.config.lspSelect.on("change", function(){
           toggleLspSelect(this.value,'');
        });

        toggleRegionRoleSelect(MsLstUsers.config.roleSelect.val());

        function toggleRegionRoleSelect(value) {
            if (value != 'admin') {
                $('.users-regions-group, .users-lsp-group').show();
            }else {
                $('.users-regions-group, .users-lsp-group, .users-userlevel-group,.users-sm_id-group').hide();
            }
        }

        var user_lsp_val = MsLstUsers.config.lspSelect;
        var user_role_val = MsLstUsers.config.roleSelect;
        var user_level_val = MsLstUsers.config.userlevelSelect;


        toggleLspSelect(user_lsp_val.val(),user_role_val);

        function toggleLspSelect(value,role){
           if(value == 8 && role != 'admin'){
              $(".users-userlevel-group").css('cssText','display:block;');

              if($("#user_level").val() == 'vam')  $(".users-sm_id-group").css('cssText','display:block;');
              else $(".users-sm_id-group").css('cssText','display:none;');

            }else{
              $("select[name=user_level] selected").val('none');  $('select.selectpicker').selectpicker('refresh');
              $(".users-userlevel-group").css('cssText','display:none;');
               /*if(role != 'admin') $(".users-sm_id-group").css('cssText','display:block;');*/
              $(".users-sm_id-group").css('cssText','display:none;');
            }
        }

        MsLstUsers.config.userlevelSelect.on('change',function(){
          toggleUserlevelSelect(this.value,user_role_val,user_lsp_val);
        });

        toggleUserlevelSelect(user_level_val.val(),user_role_val,user_lsp_val);

        function toggleUserlevelSelect(userlevlselect,role,lsp){
             lsp = lsp.selectpicker('refresh').val();
             role = role.selectpicker('refresh').val();
            if(lsp == 8 && role != 'admin'){               
                if(userlevlselect == 'vam'){
                    $(".users-sm_id-group").css('cssText','display:block;');
                }else{
                   $(".users-sm_id-group").css('cssText','display:none;');
                }
            }else{
               /* if(role != 'admin') $(".users-sm_id-group").css('cssText','display:block;');*/
            	$(".users-sm_id-group").css('cssText','display:none;');
            }
        }

       // alert($(window).height()+"##"+$(document).height());

       $('select[name="site_master_id[]"]').bootstrapDualListbox({
            nonSelectedListLabel: 'Site List',
            selectedListLabel: 'Associated Sites',
            preserveSelectionOnMove: 'moved',
            moveOnSelect: false,
            selectorMinimalHeight:300,
            //nonSelectedFilter: 'ion ([7-9]|[1][0-2])'
       });

         $('select[name="supplier_type[]"]').on('change',function(){
              var str = $.trim($(this).val());
              var field = $(this).attr('name').replace('[]','');
               
              if(str.indexOf('Other') != -1){
                 $("#"+field+"_other_type_id").show();
               }else{
                 $("#"+field+"_other_type_id").removeClass(field+'_other_type_id');
                 $("#"+field+"_other_type_id").hide();
                 $('#'+field+'_other_type').val('');
               }
        });
    },
    setUpUsersList: function () {
        MsLstUtils.createDataTable(MsLstUsers.config.usersList, 'users', [ 6 ], [[ 0, "asc" ]],'','',"rftip");

        $('#users-list-form select').on('change', function () {
           $('#users-list-form').trigger('submit');
        });

        MsLstUtils.setUpDeleteConfirmation("Do you want to change the status of selected user?", '.user-delete-button');

        MsLstUtils.createSelect2s([
           {element: $('select[name="user_access[]"]')},
           {element: $('select[name="role[]"]')},
           {element: $('select[name="username[]"]')},
           {element: $('select[name="lspname[]"]')},
        ]);
    }
};

/**
 * Handlers for the statistics pages
 */
var MsLstStatistics = {
    init: function (settings) {
		MsLstStatistics.config = {
            auditReport :[],
            auditReportlabel :[],
            dataResults:[],
            AuditXaxais:[],
            Audityaxais:[],
            AuditfltSel:[],
            plottype   :[],
            exportxls  : $("#export_xls"),
            dataJson   : $("#data_json"),
            datachart  : $("#data_chart"),
            AuditChartJSXaxais:[],
            AuditChartJSYaxais:[]
		};
		 $.extend(MsLstStatistics.config, settings);
        		MsLstStatistics.setUp();
    },
	setUp : function(){
        MsLstStatistics.setUpSwitch();
      	MsLstStatistics.setAudit();
		    MsLstStatistics.setFilterFields();
        MsLstStatistics.setUpAuditsListing();
        MsLstStatistics.setExcel();
       //MsLstStatistics.setTriggerFilter();
	},
    setUpSwitch: function () {
        var type = MsLstUtils.getParam('type');
        var param = '?type=chart';


        if (type)
        {
            param = '?type=' + type;
        }

        $('#statistics-switch').on('change', function () {
            if (this.value == 'audits')
            {
                window.location = '/statistics/audit' + param +"&report=location";
            }
            else if(this.value == 'incidents')
            {
                window.location = '/statistics/incidents' + param+"&incident_type=logistic";
            }
            else if(this.value == 'suppliers')
            {
                window.location = '/statistics/suppliers' + param;
            }
            else if(this.value == 'sitemaster')
            {
                window.location = '/statistics/sitemaster' + param;
            }
        });
    },
    setExcel : function(){
        MsLstStatistics.config.exportxls.on('click',function(){
           /* var svg = $('#statistics-audits-chart').html().trim().split("</svg>");
            var	svgtag = svg[0]+"</svg>";
            canvg(document.getElementById('drawingArea'), svgtag);
            var canvas = document.getElementById("drawingArea");
            var img    = canvas.toDataURL("image/png");*/
            var canvas = document.getElementById("statistics-audits-chart");
            var img    = canvas.toDataURL("image/png");
            $("#data_chart").val(img);
            $("#stat_excel").trigger("submit");
                /*$.ajax({
                    type: 'GET',
                    url: '/statistics/excel',
                    data: 'data_json='+MsLstStatistics.config.dataJson.val()+'&data_chart='+img
                    }).done(function(data){
                        alert(data);
                    });*/
        });
    },
    setUpAuditsListing : function(){
        MsLstUtils.createSelect2s([
                {element: $('select[name="filters[]"]')}
                ]);
    },
	setAudit : function(){
		$('select[name="filters"]').select2({placeholder: "Choose filters"});
		$('select[name="type"],select[name="statistics-switch"], select[name="report"]').select2();

		$('input[name="daterange"]').daterangepicker({
			format: 'YYYY-MM-DD',
			maxDate: moment().add(1, 'days'),
			showDropdowns: true,
			showWeekNumbers: true
     	},
		function(start, end, label) {
            $("#flt_sel").val($('select[name="filters[]"]').val());
            $("#statistics_search").trigger("submit");
			// TODO
		});
		
				//MsLstStatistics.setFilterFields();
		$('select[name="filters[]"] ,select[name="country"] ,select[name="report"],select[name="score"] ,select[name="review"],select[name="lsp"],select[name="region"],select[name="start_month"] ,select[name="end_month"],select[name="type"]').live('change', function(){
			var all_fields = $('select[name="filters[]"] option').map(function () { return this.value });
  		    var selected_fields = $('select[name="filters[]"]').val() || [];
  		    var other_fields = $.grep(all_fields, function (e) { return $.inArray(e, selected_fields) < 0; });
			
			for (fid in other_fields) {
				$('#Statistics_first_field .'+ other_fields[fid] +'-filter , #Statistics_middle_field .'+ other_fields[fid] +'-filter , #Statistics_Second_field .'+ other_fields[fid] +'-filter').html('');
			}
			
			if($(this).attr('name') == 'filters[]')  $("#flt_sel").val($(this).val());
			else $("#flt_sel").val($('select[name="filters[]"]').val());

          //  $('body').append('<span class="modal-backdrop fade in" style="text-align:center;"><img src="/css/images/ajax-loader.gif" style="padding-top:20%"></span>');
			MsLstUtils.startSpin();
			if($(this).attr('name') == 'type'){
                var url = $(location).attr('href');
                if($(this).val() == 'map'){
                    document.location.href= '/statistics/audit?type=map&report=location';
                }else if($(this).val() == 'chart'){
                    document.location.href= '/statistics/audit?type=chart&report=location';
                }
            }else{
				$("#statistics_search").trigger("submit");
            }

		});
	
		if(MsLstStatistics.config.plottype == 'chart') {
       var targetelm = 'statistics-audits-chart';
	        if(MsLstStatistics.config.auditReport != null && MsLstStatistics.config.auditReport.length != 0) {
	        	if ($('#statistics-audits-chart').length > 0) {
              /*Chart JS*/
                  var xaxis = MsLstStatistics.config.AuditChartJSXaxais;
                  var yaxis = MsLstStatistics.config.AuditChartJSYaxais;
                  MsLstUtils.createStatisticsChartJsBarChart(targetelm,yaxis,xaxis); // Chart JS
              /*Morris JS*/
	                  /*MsLstUtils.createBarChart (
	                    'statistics-audits-chart',
	                     MsLstStatistics.config.auditReport,
	                     MsLstStatistics.config.AuditXaxais,
	                     MsLstStatistics.config.AuditYaxais,
	                     MsLstStatistics.config.AuditYaxais,
	                      true
	                    ) ; */
			      }
	        }else{
        /*Chart JS*/
                 MsLstUtils.createStatisticsChartJsEmptyChart(targetelm); // Chart JS
         /*Morris JS*/
	              /*  MsLstUtils.createBarChart (
	                    'statistics-audits-chart',
	                     '[{y:0,a:0}]',
	                     'y',
	                     ['a'],
	                     '',
	                      false
	                    ) ;*/
	        }
       }

	},
	setFilterFields: function(){
        var all_fields = $('select[name="filters[]"] option').map(function () { return this.value });
        var selected_fields = $('select[name="filters[]"]').val() || [];
        var other_fields = $.grep(all_fields, function (e) { return $.inArray(e, selected_fields) < 0; });
        var flt_optsize = $(".select2-choices li").size()-1;
        var filter_opt  = $('#filter_opt').val();
        var filter_sel  = MsLstStatistics.config.AuditfltSel.split(',');
        var dataindex   = filter_sel.indexOf('daterange');
        var seltype     = $('select[name=type]').val();
        var typpe = $("#seltype").val();
        //var regionplac  = $.inArray('region',selected_fields);
        //var countryplac = $.inArray('country',selected_fields);
	
		
		
        /*if(dateindex != -1 ){
           var preorpost = (filter_sel.length - dateindex) + 1;
           alert(preorpost);
        }*/

        /*if((regionplac >= 0 && countryplac >= 0) && (countryplac > regionplac) &&  $('select[name="region"]').val() != "" ){
            alert($.inArray('region',selected_fields)+"###"+$.inArray('country',selected_fields)+"##"+$('select[name="region"]').val());
        }*/
        
        for (fid in other_fields) {
            $('.statistics-filter-control .'+ other_fields[fid] +'-filter' ).hide();
	  		    $('.statistics-filter-control .'+ other_fields[fid] +'-filter select , .statistics-filter-control #'+ other_fields[fid] +'-filter .'+ other_fields[fid] +'-filter select').val('');
	  		    $('.statistics-filter-control .'+ other_fields[fid] +'-filter input, .statistics-filter-control #'+ other_fields[fid] +'-filter .'+ other_fields[fid] +'-filter input').val('');
  		}
		
	

        $('#Statistics_middle_field .daterange-filter').hide();
        $('#Statistics_middle_field .daterange-filter').val('');


        if(seltype == 'chart'){
      		for (fid in selected_fields) {
                if(selected_fields[fid] == 'daterange'){
                    $('#Statistics_middle_field .'+ selected_fields[fid] +'-filter').show();
                    $('.statistics-filter-control .monthrange-filter').hide();
                    $('.statistics-filter-control .monthrange-filter select').val('');
                    $('.statistics-filter-control .monthrange-filter input').val('');
    				$('#filter_opt').val('yes');
    			}else if(selected_fields[fid] == 'monthrange'){
                    $('.statistics-filter-control .daterange-filter').hide();
                    $('.statistics-filter-control .daterange-filter select').val('');
                    $('.statistics-filter-control .daterange-filter input').val('');
                }
      		}
        }

        if(filter_sel.length != 0) {
      			for(filsel in filter_sel){
          				var selOpt = filter_sel[filsel];
                          if(dataindex >= filsel || dataindex == -1){
                          	$("#Statistics_first_field").append($("#"+selOpt+'-filter').html());
          					$('#Statistics_first_field .'+selOpt+'-filter').show();
          				}else if(dataindex < filsel){
          					$("#Statistics_Second_field").append($("#"+selOpt+'-filter').html());
          					$('#Statistics_Second_field .'+selOpt+'-filter').show();
          				}

                          if(selOpt == 'daterange'){
                              $('#Statistics_middle_field .daterange-filter').show();
                          }
          		}
        }

        if(typpe == 'map')     $("#Statistics_first_field select,#Statistics_second_field select").css('width','100px');

       if(filter_sel.length > 4) {
          $("#map_canvas").css('cssText','position:absolute !important;right: 0;height: 100%; width: 100%; background-color: grey; border: solid 0px #B3B3B3; margin-bottom: 10px;');
          $(".footer-wrap").css('cssText','position : fixed !important');
        }

	}
};
/**
 * MsLstStatisticsSuppliers
 **/
 var MsLstStatisticsSuppliers = {
    init: function(){
        MsLstStatisticsSuppliers.setUp();
    },
    setUp: function(){
         MsLstStatisticsSuppliers.setUpSwitch();
         MsLstStatisticsSuppliers.SuppliersetUp();

     },
    setUpSwitch: function(){
        MsLstStatistics.setUpSwitch();
    },
    SuppliersetUp: function() {
        $('select[name="type"],select[name="statistics-switch"]').select2();
    }
 };


 /**
 * MsLstStatisticsSitemasters
 **/
 var MsLstStatisticsSitemasters = {
    init: function(){
        MsLstStatisticsSitemasters.setUp();
    },
    setUp: function(){
         MsLstStatisticsSitemasters.setUpSwitch();
         MsLstStatisticsSitemasters.SitemastersetUp();

     },
    setUpSwitch: function(){
    	MsLstStatistics.setUpSwitch();
    }
        ,
    SitemastersetUp: function() {
        $('select[name="type"],select[name="statistics-switch"]').select2();
    }
 };

/**
 * MsLstStatisticsIncidents
 **/

var MsLstStatisticsIncidents = {
    init: function(settings){
        MsLstStatisticsIncidents.config = {
          incidentReport:[],
          incidentYaxis:[],
          incidentLabel:[],
          incidentXaxis:[],
          plottype 	   :[],
          reportdis    :[],
          exportxls  : $("#export_xls"),
          dataJson   : $("#data_json"),
          datachart  : $("#data_chart"),
          IncidentChartJSXaxais : [],
          IncidentChartJSYaxais :[]
        };

        $.extend(MsLstStatisticsIncidents.config, settings);
        MsLstStatisticsIncidents.setUp();
    },
    setUp: function(){
        MsLstStatisticsIncidents.setUpSwitch();
        MsLstStatisticsIncidents.setIncidents();
        MsLstStatisticsIncidents.setFilterSelect();
        MsLstStatisticsIncidents.setFilterFields();
        MsLstStatisticsIncidents.setExcel();
    },
    setUpSwitch: function () {
        MsLstStatistics.setUpSwitch();
    },
    setExcel : function(){
        MsLstStatisticsIncidents.config.exportxls.on('click',function(){
            /*var svg = $('#statistics-incidents-chart').html().trim().split("</svg>");
            var svgtag = svg[0]+"</svg>";
            canvg(document.getElementById('drawingArea'), svgtag);
            var canvas = document.getElementById("drawingArea");
            var img    = canvas.toDataURL("image/png");*/
            var canvas = document.getElementById("statistics-incidents-chart");
            var img    = canvas.toDataURL("image/png");
            var data_typeval  = $("select[name='report']").val();
            $("#data_chart").val(img);
        //   alert($("select[name='report']").val())
            $("#data_type").val(data_typeval);
            $("#stat_excel").trigger("submit");
        });
    },
    setIncidents: function(){
       // MsLstStatisticsIncidents.setFilterFields();
        $('select[name="type"],select[name="statistics-switch"],select[name="incident_type"],select[name="report"]').select2();
        $('select[name="filters[]"], select[name="country"], select[name="status"],select[name="report"],select[name="score"] ,select[name="review"],select[name="lsp"],select[name="region"],select[name="start_month"] ,select[name="end_month"],select[name="type"],select[name="type_of_device"]').on('change', function(){
            if($(this).attr('name') == 'filters[]')  $("#flt_sel").val($(this).val());
            MsLstStatisticsIncidents.setFilterFields();
            MsLstUtils.startSpin();
           // $('body').append('<span class="modal-backdrop fade in" style="text-align:center;"><img src="/css/images/ajax-loader.gif" style="padding-top:20%"></span>');
            $("#statistics_search").trigger("submit");
        });
        $('select[name="incident_type"]').on('change', function(){
          MsLstUtils.startSpin();
          MsLstStatisticsIncidents.setFilterFields();
        });
        var targetelm = 'statistics-incidents-chart';
        if(MsLstStatisticsIncidents.config.plottype == 'chart') {

	        if(MsLstStatisticsIncidents.config.incidentReport.length != 0 && MsLstStatisticsIncidents.config.incidentReport.length != null) {
             /*Chart JS*/
                  var xaxis = MsLstStatisticsIncidents.config.IncidentChartJSXaxais;
                  var yaxis = MsLstStatisticsIncidents.config.IncidentChartJSYaxais;
                  MsLstUtils.createStatisticsChartJsBarChart(targetelm,yaxis,xaxis,$("select[name='report']").val()); // Chart JS
             /*Morris JS*/
              /*  Morris.Bar({
                  element: 'statistics-incidents-chart',
                  barSize: 50,
                  data: MsLstStatisticsIncidents.config.incidentReport,
                  hoverCallback: function(index, options, content) {
                    if(MsLstStatisticsIncidents.config.reportdis == 'value'){
                        return(content+" USD");
                     }else  return(content);
                  },
                  xkey: MsLstStatisticsIncidents.config.incidentXaxis,
                  ykeys: MsLstStatisticsIncidents.config.incidentYaxis,
                  labels: MsLstStatisticsIncidents.config.incidentLabel
                }); */

	        }else{
            /*Chart JS*/
              MsLstUtils.createStatisticsChartJsEmptyChart(targetelm); // Chart JS
            /*Morris JS*/
	              /*  MsLstUtils.createBarChart (
	                    'statistics-incidents-chart',
	                     '[{y:0,a:0}]',
	                     'y',
	                     ['a'],
	                     '',
	                      false
	                    ); */
	        }
	    }

    },
    setFilterSelect: function(){
        MsLstUtils.createSelect2s([
                {element: $('select[name="filters[]"]')}
                ]);
        $('select[name="filters"]').select2({placeholder: "Choose filters"});
        $('select[name="type"],select[name="start_month"],select[name="end_month"],select[name="report"],select[name="incident_type"],select[name="status"], select[name="category"],select[name="score"], select[name="review"], select[name="lsp"], select[name="region"], select[name="country"],select[name="type_of_device"]').live(
        	"change",function(e){
        		//$('body').append('<span class="modal-backdrop fade in" style="text-align:center;"><img src="/css/images/ajax-loader.gif" style="padding-top:20%"></span>');
            MsLstUtils.startSpin();
        		$("#statistics_search").trigger("submit");
        	});
        $('input[name="daterange"]').daterangepicker({
            format: 'YYYY-MM-DD',
            maxDate: moment().add(1, 'days'),
            showDropdowns: true,
            showWeekNumbers: true
        },
        function(start, end, label) {
            $("#statistics_search").trigger("submit");
            // TODO
        });
    },
    setFilterFields: function(){
      // Existing One
      /*  var all_fields = $('select[name="filters[]"] option').map(function () { return this.value });
        var selected_fields = $('select[name="filters[]"]').val() || [];
        var other_fields = $.grep(all_fields, function (e) { return $.inArray(e, selected_fields) < 0; });

        for (fid in other_fields) {
            $('.statistics-filter-control .'+ other_fields[fid] +'-filter').hide();
            $('.statistics-filter-control .'+ other_fields[fid] +'-filter select').val('');
            $('.statistics-filter-control .'+ other_fields[fid] +'-filter input').val('');
        }

       for (fid in selected_fields) {
                $('.statistics-filter-control .'+ selected_fields[fid] +'-filter').show();
        }*/

        // New Filter Options
        var all_fields = $('select[name="filters[]"] option').map(function() { return this.value});
        var selected_fields = $('select[name="filters[]"]').val() || [];
        var other_fields = $.grep(all_fields,function(e) { return $.inArray(e,selected_fields) < 0 ; });
        var filter_sel = MsLstStatisticsIncidents.config.incidentfltSel.split(',');
        var dataindex = filter_sel.indexOf('daterange');
        var monthdataindex = filter_sel.indexOf('monthrange');
        var typpe = $("#seltype").val();
        
        for(fid in other_fields) {
          if($.isNumeric(fid)){
             $('.statistics-filter-control .'+ other_fields[fid] +'-filter').hide();
             $('.statistics-filter-control .'+ other_fields[fid] +'-filter select').val('');
             $('.statistics-filter-control .'+ other_fields[fid] +'-filter input').val('');
          }
        }

        if(monthdataindex != -1){  
          if(typpe == 'chart'){
              $("#Statistics_middle_field .daterange-filter").hide();
          }
          $("#map-controls").removeClass('col-md-3').addClass('col-md-5');
        }

        $("#Statistics_first_field,#Statistics_second_field").empty();

        for(fsd in filter_sel){
            if($.isNumeric(fsd)){
                var selopt = filter_sel[fsd];
                if(dataindex == -1 || dataindex > fsd) {
                  $("#Statistics_first_field").append($("#"+selopt+'-filter').html());
                  $('#Statistics_first_field .'+selopt+'-filter').show();
                }else if(fsd == (dataindex-1)){
                  $("#Statistics_middle_field .daterange-filter").show();
                }else if(dataindex < fsd) {
                  $("#Statistics_second_field").append($("#"+selopt+'-filter').html());
                  $('#Statistics_second_field .'+selopt+'-filter').show();
                }
            }
        }
       if(typpe == 'map')     $("#Statistics_first_field select,#Statistics_second_field select").css('width','100px');


       if(filter_sel.length > 4) {
          $("#map_canvas").css('cssText','position:absolute !important;right: 0;height: 100%; width: 100%; background-color: grey; border: solid 0px #B3B3B3; margin-bottom: 10px;');
          $(".footer-wrap").css('cssText','position : fixed !important');
        }
    
    }
};

/**
 * The site init functionality, initializes all modules
 */
var MsLstSite = {
    init: function () {

        // Initialize site layout and helper scripts
        MsLstGlobal.init();

        // Initialize scripts for the Dashboard page
        if (MsLstUtils.isCurrentPath('dashboard')) {
              var dashbrd = [];

            if (typeof Dashboard.audits != 'undefined')  {
                 dashbrd['audits'] = Dashboard.audits;  
              }
            if (typeof Dashboard.incidents != 'undefined')  {
                dashbrd['incidents'] = Dashboard.incidents;  
                dashbrd['incidentStatus'] = Dashboard.incidentStatus;  
                dashbrd['incidentLsp'] = Dashboard.incidentLsp;
                dashbrd['incidentCategory'] = Dashboard.incidentCategory;  
             }

            if (typeof Dashboard.userStatus != 'undefined')  {
                 dashbrd['userStatus'] = Dashboard.userStatus;  
            }

            if(typeof Dashboard.inspect_audit_status != 'undefined') {
               dashbrd['inspectAuditStatus'] = Dashboard.inspect_audit_status;  
            }

             dashbrd['user_role'] = Dashboard.userrole;

            $.extend({},dashbrd);

            MsLstDashboard.init(dashbrd);
        }

        // Initialize scripts for the Audit pages
        if (MsLstUtils.isCurrentPath('audits')
            || MsLstUtils.isCurrentPath('locations')
            || MsLstUtils.isCurrentPath('routes')) {

            if (typeof Locations != 'undefined')  {
                MsLstAudits.init({
                    coordinates: Locations.coordinates,
                    mapElement: Locations.mapElement
                });
            }
            else if (typeof Routes != 'undefined')  {
                MsLstAudits.init({
                    startCoordinates: Routes.startCoordinates,
                    endCoordinates: Routes.endCoordinates,
                    mapElement: Routes.mapElement
                });
            }
            else {
                MsLstAudits.init();
            }
        }

        // Initialize scripts for the Certification pages
        if (MsLstUtils.isCurrentPath('certifications')) {
            MsLstCertifications.init();
        }

        // Initialize scripts for the Country pages
        if (MsLstUtils.isCurrentPath('countries')) {
            MsLstCountries.init();
        }




        // Initialize scripts for the Incident pages
        if (MsLstUtils.isCurrentPath('incidents')) {

            if (typeof Incidents != 'undefined')  {
                MsLstIncidents.init({
                    coordinates: Incidents.coordinates,
                    mapElement: Incidents.mapElement,
                    regions: Incidents.regions
                });
            }
            else {
                MsLstIncidents.init();
            }
        }


        //Initialize Script for the Factory Incident pages

        if(MsLstUtils.isCurrentPath('factory')){
            if(typeof FactoryIncidents != 'undefined')
            {
              MsLstFactoryIncidents.init({
                coordinates : FactoryIncidents.coordinates,
                mapElement: FactoryIncidents.mapElement,
                regions: FactoryIncidents.regions,
                country: FactoryIncidents.country,
              });
            }else
            {
               MsLstFactoryIncidents.init();
            }
        }

        // Initialize scripts for the LSP pages
        if (MsLstUtils.isCurrentPath('lsps')) {
            MsLstLsp.init();
        }

        // Initialize scripts for the Question pages
        if (MsLstUtils.isCurrentPath('questions')) {
            MsLstQuestions.init();
        }

        // Initialize scripts for the Region pages
        if (MsLstUtils.isCurrentPath('regions')) {
            MsLstRegions.init();
        }

        // Initialize script for the Suppliers page
        if(MsLstUtils.isCurrentPath('suppliers')){ 
            if (typeof Suppliers != 'undefined') {
    
                MsLstSuppliers.init({
                  regions: Suppliers.regions,
                  country: Suppliers.country,
                  coordinates: Suppliers.coordinates,
                  mapElement: Suppliers.mapElement,
                  inc_hist_json : incident_history_json,
                  leak_prev_json :incident_prevention_json,
                  business_activity : business_activity,
                  business_assets : business_assets,
                  business_risk : business_risk,
                  business_actions : business_actions,
                  leak_risk_analysis : leak_risk_analysis,
                }); 
            }else {
                MsLstSuppliers.init();
            }
        }
      // Initialize script for the Sitemasters page
        if(MsLstUtils.isCurrentPath('sitemaster')){ 
            if (typeof Sitemasters != 'undefined') {
                MsLstSitemasters.init({
                  regions: Sitemasters.regions,
                  country: Sitemasters.country,
                  coordinates: Sitemasters.coordinates,
                  mapElement: Sitemasters.mapElement,
                  inc_hist_json : incident_history_json,
                  leak_prev_json :incident_prevention_json,
                  business_activity : business_activity,
                  business_assets : business_assets,
                  business_risk : business_risk,
                  business_actions : business_actions,
                  leak_risk_analysis : leak_risk_analysis,
                  corrective_actions: corrective_actions,
                  lp_corrective_actions:lp_corrective_actions,
                  access_name : accessname,
                  business_lob : business_lob,
                }); 
            }else {
                MsLstSitemasters.init();
            }
        }

        // Initialize scripts for the Lane pages
        if (MsLstUtils.isCurrentPath('lanes')) {
			     MsLstLanes.init();
        }

        // Initialize scripts for the Settings page
        if (MsLstUtils.isCurrentPath('settings')) {
            MsLstSettings.init();
        }

        // Initialize scripts for the User pages
        if (MsLstUtils.isCurrentPath('users')) {
            MsLstUsers.init();
        }

        // Initialize scripts for the Statistics pages
        if (MsLstUtils.isCurrentPath('statistics/audit')) {
            MsLstStatistics.init({
                  auditReport: Statistics.audit_report,
                  auditReportlabel: Statistics.audit_reportlabel,
                  dataResults :  Statistics.data,
                  AuditXaxais : Statistics.auditXaxais,
                  AuditYaxais : Statistics.auditYaxais,
                  AuditfltSel : Statistics.auditfltSel,
                  plottype 	: Statistics.plottype,
                  AuditChartJSXaxais : Statistics.auditChartJSXaxais,
                  AuditChartJSYaxais : Statistics.auditChartJSYaxais
 			      });
        }else if(MsLstUtils.isCurrentPath('statistics/incidents')){
           MsLstStatisticsIncidents.init({
                incidentReport : Statistics.incident_report,
                incidentYaxis : Statistics.incidentYaxis,
                incidentLabel : Statistics.incidentlabel,
                incidentXaxis : Statistics.incidentXaxis,
                incidentfltSel : Statistics.incidentfltSel,
                plottype 	  : Statistics.plottype,
                reportdis   : Statistics.reportdis,
                IncidentChartJSXaxais : Statistics.incidentChartJSXaxais,
                IncidentChartJSYaxais :  Statistics.incidentChartJSYaxais,
            });
        }else if(MsLstUtils.isCurrentPath('statistics/suppliers')){
            MsLstStatisticsSuppliers.init({

            });
        }else if(MsLstUtils.isCurrentPath('statistics/sitemaster')){
            MsLstStatisticsSitemasters.init({

           });
        }


    }
};

/**
 * When the page is ready initialize the site
 */
$(document).ready(MsLstSite.init);
