function intializeBingMap(callback) {
	var BingMapKey = 'ArMXdeVR1BqPsylU90gGcEDpIkeTHgO8JlB_FUTZAnd5ILv2tN0grmbgmbG3yTsn';
	
       
 	callback(); 
}

 

 

 function showBingMapLocationByCoordinate(latitude, longitude, mapElementId) {
 	 var map = null;
 		if (latitude.trim() == "" || longitude.trim() == "") {
			$('#'+ mapElementId).html("<p>The search request failed</p>");
			$('#'+ mapElementId).css('background-image', 'none');
		}else{

			  map = new Microsoft.Maps.Map(document.getElementById(mapElementId),{credentials:"AgbUnrKEhOfs69x9OljXuzMN-nmEShW3rL2cP7kx4SaR-o02zvmlEOkbivQKlaK2", mapTypeId:Microsoft.Maps.MapTypeId.road});
			  var center = map.getCenter();
			  map.entities.clear();
			  var pushpin = new Microsoft.Maps.Pushpin(center, null); 
			  map.entities.push(pushpin);
			  pushpin.setLocation(new Microsoft.Maps.Location(latitude,longitude));
			  map.setView({zoom: 10,center:new Microsoft.Maps.Location(latitude,longitude)}); 
		}

 }



function showBingGPSCoordinateSelector(mapElement, targetField, defaultCoord) {
	var mapContainer = document.getElementById(mapElement);


    map = new Microsoft.Maps.Map(mapContainer,{credentials:"AgbUnrKEhOfs69x9OljXuzMN-nmEShW3rL2cP7kx4SaR-o02zvmlEOkbivQKlaK2", mapTypeId:Microsoft.Maps.MapTypeId.road});
    var center = map.getCenter();
    var pin = new Microsoft.Maps.Pushpin(center, {draggable: true}); 
    map.entities.pop(pin);

	if(targetField == 'end_coordinates')
		Microsoft.Maps.Events.addHandler(pin, 'mouseup', EndDisplayLoc);
	else if(targetField == 'start_coordinates')
		Microsoft.Maps.Events.addHandler(pin, 'mouseup', StartDisplayLoc);
	else 
		Microsoft.Maps.Events.addHandler(pin, 'mouseup', DisplayLoc); 

    map.entities.push(pin);
    pin.setLocation(new Microsoft.Maps.Location(47.673988, -122.121513));
    
    var imageMarker = null;
    return [map, imageMarker];

}


/*To Display Coordinates*/
 function DisplayLoc(e){  
   if (e.targetType == 'pushpin'){
     var pinLoc = e.target.getLocation();
     //var txtbox =document.getElementById('myField').value;
     document.getElementById('coordinates').value=+ pinLoc.latitude + ", " + pinLoc.longitude;
   }
 }


 /*To Display Coordinates*/
 function StartDisplayLoc(e){  
   if (e.targetType == 'pushpin'){
     var pinLoc = e.target.getLocation();
     //var txtbox =document.getElementById('myField').value;
     document.getElementById('start_coordinates').value=+ pinLoc.latitude + ", " + pinLoc.longitude;
   }
 }

 /*To Display Coordinates*/
 function EndDisplayLoc(e){  
   if (e.targetType == 'pushpin'){
     var pinLoc = e.target.getLocation();
     //var txtbox =document.getElementById('myField').value;
     document.getElementById('end_coordinates').value=+ pinLoc.latitude + ", " + pinLoc.longitude;
   }
 }



function showBingMapMoveCoordinate(map, marker, coordField) {
	var current_coord = $(coordField).val().trim();
	var credentials = 'ArMXdeVR1BqPsylU90gGcEDpIkeTHgO8JlB_FUTZAnd5ILv2tN0grmbgmbG3yTsn';
	
	if (current_coord && current_coord.indexOf(',') > -1) {
		var current_coord_parts = current_coord.split(',');
		if (current_coord_parts.length == 2) {
			var current_coord_lat = parseFloat(current_coord_parts[0].trim());
			var current_coord_lng = parseFloat(current_coord_parts[1].trim());
 
			if (!isNaN(current_coord_lat) && !isNaN(current_coord_lng)) {
			 
				try {
					 map.entities.clear();
					 var pushpin= new Microsoft.Maps.Pushpin(map.getCenter(), {draggable: true});
					 map.entities.pop(pushpin);

					 if(coordField == '#end_coordinates')
					 	Microsoft.Maps.Events.addHandler(pushpin, 'mouseup', EndDisplayLoc);
					 else if(coordField == '#start_coordinates')
					 	Microsoft.Maps.Events.addHandler(pushpin, 'mouseup', StartDisplayLoc);
					 else 
					 	Microsoft.Maps.Events.addHandler(pushpin, 'mouseup', DisplayLoc);

					 map.entities.push(pushpin);
					 pushpin.setLocation(new Microsoft.Maps.Location(current_coord_lat,current_coord_lng));
				}
				catch (e) {
					bootbox.alert('Please enter a valid GPS Coordinate.');
				}
				return true;
			}
			else {
				    var geocodeRequest = "http://dev.virtualearth.net/REST/v1/Locations?query=" +current_coord + "&output=json&jsonp=GeocodeCallback&key=" + credentials;
			        var script = document.createElement("script");
			        script.setAttribute("type", "text/javascript");
			        script.setAttribute("src", geocodeRequest);
			        document.body.appendChild(script);
				return true;
			}
		}
	}
	return false;
}



    /* Function to locate the location using coordinates*/
    function GeocodeCallback(result) {           
      if (result && result.resourceSets && result.resourceSets.length > 0 && result.resourceSets[0].resources &&
               result.resourceSets[0].resources.length > 0) {
        alert("Found location: " + result.resourceSets[0].resources[0].name);
        var bbox = result.resourceSets[0].resources[0].bbox;
        var viewBoundaries = Microsoft.Maps.LocationRect.fromLocations(new Microsoft.Maps.Location(bbox[0], bbox[1]), new Microsoft.Maps.Location(bbox[2], bbox[3]));
        var location = new Microsoft.Maps.Location(result.resourceSets[0].resources[0].point.coordinates[0], result.resourceSets[0].resources[0].point.coordinates[1]);
        map.setView({ center:new Microsoft.Maps.Location(result.resourceSets[0].resources[0].point.coordinates[0],result.resourceSets[0].resources[0].point.coordinates[1]),zoom:4}); 
        var pin = new Microsoft.Maps.Pushpin(location,{draggable: true});  
        map.entities.push(pin);  
       /* if(txtbox==1){
          map.entities.pop(pin);  
        }*/       
           alert(4);                    
      } else {
        	bootbox.alert('Please enter a valid GPS Coordinate.');
        	return false;
      }
    }  


	

    function showBingMapRoute(startAddress, endAddress, mapElementId){ 
    	 
      var map = null;
      var directionsManager;
      var directionsErrorEventObj;
      var directionsUpdatedEventObj; 
       var displayMessage;
 		 map = new Microsoft.Maps.Map(mapElementId, {credentials: 'ArMXdeVR1BqPsylU90gGcEDpIkeTHgO8JlB_FUTZAnd5ILv2tN0grmbgmbG3yTsn'});


          map.setView({
            mapTypeId: Microsoft.Maps.MapTypeId.road,
            zoom: 5,
            draggable:false
          });

        

          if (!directionsManager) 
          {
           Microsoft.Maps.loadModule('Microsoft.Maps.Directions', { callback:function(){
 

           			if (!directionsManager) {
                       
                       if (!directionsManager) 
                          {
                              directionsManager = new Microsoft.Maps.Directions.DirectionsManager(map);
                              displayMessage = 'Directions Module loaded\n';
                              displayMessage += 'Directions Manager loaded';
                          }
                          //alert(displayMessage);
                          directionsManager.resetDirections();
                          directionsErrorEventObj = Microsoft.Maps.Events.addHandler(directionsManager, 'directionsError', function(arg) { 
                            alert(arg.message) });
                          directionsUpdatedEventObj = Microsoft.Maps.Events.addHandler(directionsManager, 'directionsUpdated', function() { 
                            //alert('Directions updated')
                             });
                    }


	                  directionsManager.resetDirections();
	                  // Set Route Mode to driving 
	                  directionsManager.setRequestOptions({ routeMode: Microsoft.Maps.Directions.RouteMode.driving , routeDraggable: false });

	                  var seattleWaypoint = new Microsoft.Maps.Directions.Waypoint({ location: new Microsoft.Maps.Location(startAddress.navigationPosition.latitude, startAddress.navigationPosition.longitude) });
	                  directionsManager.addWaypoint(seattleWaypoint);
 						console.log(startAddress); 	console.log(endAddress);
	                  var tacomaWaypoint = new Microsoft.Maps.Directions.Waypoint({location: new Microsoft.Maps.Location(endAddress.navigationPosition.latitude,endAddress.navigationPosition.longitude) });
	                  directionsManager.addWaypoint(tacomaWaypoint);
	                  // Set the element in which the itinerary will be rendered
	                  directionsManager.setRenderOptions({ itineraryContainer: document.getElementById('directionsItinerary') });
	                  //alert('Calculating directions...');
	                  directionsManager.calculateDirections(); 

           }});
          }

    }




    function createDirectionsManager()
      { 
          var displayMessage;
          if (!directionsManager) 
          {
              directionsManager = new Microsoft.Maps.Directions.DirectionsManager(map);
              displayMessage = 'Directions Module loaded\n';
              displayMessage += 'Directions Manager loaded';
          }
          //alert(displayMessage);
          directionsManager.resetDirections();
          directionsErrorEventObj = Microsoft.Maps.Events.addHandler(directionsManager, 'directionsError', function(arg) { 
            alert(arg.message) });
          directionsUpdatedEventObj = Microsoft.Maps.Events.addHandler(directionsManager, 'directionsUpdated', function() { 
            //alert('Directions updated')
             });
      }
      
      function createDrivingRoute()
      { 

        if (!directionsManager) { createDirectionsManager(); }
        directionsManager.resetDirections();
        // Set Route Mode to driving 
        directionsManager.setRequestOptions({ routeMode: Microsoft.Maps.Directions.RouteMode.driving });
        var seattleWaypoint = new Microsoft.Maps.Directions.Waypoint({ location: new Microsoft.Maps.Location(53.88596876391287, -8.918388) });
        directionsManager.addWaypoint(seattleWaypoint);
        var tacomaWaypoint = new Microsoft.Maps.Directions.Waypoint({location: new Microsoft.Maps.Location(49.53349804968433, 19.909737) });
        directionsManager.addWaypoint(tacomaWaypoint);
        // Set the element in which the itinerary will be rendered
        directionsManager.setRenderOptions({ itineraryContainer: document.getElementById('directionsItinerary') });
        //alert('Calculating directions...');
        directionsManager.calculateDirections();
      }




function showBingMapRouteWrap(start, end, elementId) {
	var startLocation = getCoordinate(start);
	var endLocation = getCoordinate(end);
	var element = document.getElementById(elementId);
	var startNavigation = {navigationPosition: {latitude: startLocation[0], longitude: startLocation[1]}};
	var endNavigation = {navigationPosition: {latitude: endLocation[0], longitude: endLocation[1]}};


 	showBingMapRoute(
		startNavigation, 
		endNavigation, 
		element
	);
}

function isCoordinate(search){
	search = (new String(search)).split(',');
	if(search.length == 2){
		if(isNumber(search[0]) && isNumber(search[1])){
			return true;
		}
		else{
			return false;
		}
	}
	else{
		return false;
	}
}

function getCoordinate(coordinate){
	coordinate = (new String(coordinate)).split(',');
	return new Array(parseFloat(coordinate[0]), parseFloat(coordinate[1]));
}

function isNumber(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}