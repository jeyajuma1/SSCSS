function intializeMap(callback) {
	nokia.Settings.set("app_id", "KyW1GWWaS-K-XOSNl-Wa"); 
	nokia.Settings.set("app_code", "pn1eUyiFnolEPuHju8sy5g");
	//nokia.Settings.set("secureConnection", "force");
	nokia.Settings.set("serviceMode", "cit");
	(document.location.protocol == "https:") && nokia.Settings.set("secureConnection", "force");
	
	callback();
}

function checkCoordFormat(coord) {
	coord = new String(coord);
	var current_coord_parts = coord.split(',');
	if (current_coord_parts.length == 2) {
		var current_coord_lat = parseFloat(current_coord_parts[0].trim());
		var current_coord_lng = parseFloat(current_coord_parts[1].trim());
		if (!isNaN(current_coord_lat) && !isNaN(current_coord_lng)) {
			return true;
		}
		else if (coord.match(/(N|S){1}[\d\s\.]*,\s*(E|W){1}[\d\s\.]*/)) {
			return true;
		}
	}
	return false;
}

// Validate the coordinate movement
function checkCoordMovement(status) {
	if (!status) {
		bootbox.alert('Please enter a valid GPS Coordinate.');
	}
}

function showNokiaGPSCoordinateSelector(mapElement, targetField, defaultCoord) {
	var mapContainer = document.getElementById(mapElement);

    nokia.Settings.set("app_id", "KyW1GWWaS-K-XOSNl-Wa"); 
    nokia.Settings.set("app_code", "pn1eUyiFnolEPuHju8sy5g");


	defaultCoord = defaultCoord || [52.51, 13.4]
	
	var map = new nokia.maps.map.Display(mapContainer, {
			center: defaultCoord,
			zoomLevel: 11,
			components:[new nokia.maps.map.component.Behavior(),new nokia.maps.map.component.ZoomBar()]
		});

	// Create a default listener for events that will just log a message.
	var defaultHandler = function (evt) {

	    if (evt.target instanceof nokia.maps.map.Marker) {

	        //console.log(evt);

	        var inputField = document.getElementById(targetField);
	        if (evt.type = "dragend"){
	            inputField.value = evt.target.coordinate.latitude + "," + evt.target.coordinate.longitude;
	        }
	        if (evt.type = "drag"){
	            var coordinate = map.pixelToGeo(evt.displayX + evt.target.anchor.x, evt.displayY + evt.target.anchor.y);
	            inputField.value = coordinate.latitude + "," + coordinate.longitude;
	        }
	    }

	    if (evt.target instanceof nokia.maps.map.Spatial) {
	        /* Prevent other event listeners from being triggered
	         * For more details see  nokia.maps.dom.Event
	         */
	        evt.stopImmediatePropagation();
	    }
	};

	/* Adding event listeners one by one to a map object is not very
	 * efficient therefore we have created a shortcut method 
	 * to add multiple eventlisteners to an object using the "eventListener" property
	 */

	// Template with all listeners to be registered.
	var listeners = {
	    // type: [(listener, useCapture, namespaceURI)(, listener, useCapture, namespaceURI)(, ...)]
	    "dragstart": [defaultHandler, false, null],
	    "drag": [defaultHandler, false, null],
	    "dragend": [defaultHandler, false, null]
	}; 

	// Create image marker object
	var imageMarker = new nokia.maps.map.Marker(
	    defaultCoord,
	    {
	        $name: "Image Marker",
	        eventListener: listeners,
	        draggable: true
	    }
	);

	// Add event listeners to the marker
	imageMarker.addListeners(listeners);
	map.objects.add(imageMarker);

	return [map, imageMarker];
}

function showNokiaMapMoveCoordinate(map, marker, coordField) {
	var current_coord = $(coordField).val().trim();
	
	if (current_coord && current_coord.indexOf(',') > -1) {
		var current_coord_parts = current_coord.split(',');
		if (current_coord_parts.length == 2) {
			var current_coord_lat = parseFloat(current_coord_parts[0].trim());
			var current_coord_lng = parseFloat(current_coord_parts[1].trim());
			if (!isNaN(current_coord_lat) && !isNaN(current_coord_lng)) {
				try {
					var new_coord = new nokia.maps.geo.Coordinate(current_coord_lat, current_coord_lng);
					//var myContainer = new nokia.maps.map.Container();
					marker.set('coordinate', new_coord);
					map.set('center', [current_coord_lat, current_coord_lng]);
					//myContainer.objects.add(marker);
					//map.zoomTo(myContainer.getBoundingBox(), false, true);
				}
				catch (e) {
					bootbox.alert('Please enter a valid GPS Coordinate.');
				}
				return true;
			}
			else {
				nokia.places.search.manager.findPlaces({
					searchTerm : current_coord, 
					onComplete:  function (data, requestStatus, requestId) {
						if (requestStatus == "OK" && data.results.items.length > 0) { 
							var myContainer = new nokia.maps.map.Container();
							marker.set('coordinate', data.results.items[0].position);
							myContainer.objects.add(marker);
							map.zoomTo(myContainer.getBoundingBox(), false, true);
							$(coordField).val(data.results.items[0].position['latitude'] +','+ data.results.items[0].position['longitude']);
						}
						else {
							bootbox.alert('Please enter a valid GPS Coordinate.');
						}
					}
				});
				return true;
			}
		}
	}
	return false;
}


function showNokiaMapLocationByCoordinate(latitude, longitude, mapElementId){
	if (latitude.trim() == "" || longitude.trim() == "") {
		$('#'+ mapElementId).html("<p>The search request failed</p>");
		$('#'+ mapElementId).css('background-image', 'none');
	}
	else {
		var map = new nokia.maps.map.Display(document.getElementById(mapElementId), {
			zoomLevel: 13,
			components:[
				new nokia.maps.map.component.Behavior(),
				new nokia.maps.map.component.ZoomBar(),
				new nokia.maps.map.component.TypeSelector()
			]
		});

		setTimeout(function() {
			var coordinate = new nokia.maps.geo.Coordinate(parseFloat(latitude.trim()), parseFloat(longitude.trim()));
			var standardMarker = new nokia.maps.map.StandardMarker(coordinate);
			map.objects.add(standardMarker);
			map.set("center", coordinate);
		}, 500);
	}
}


function showMapRoute(startAddress, endAddress, mapElementId){
	var mapElement = document.getElementById(mapElementId);
	var searchManager = new nokia.maps.search.Manager();
	searchManager.addObserver("state", function (observedManager, key, value) {
		if (value == "finished") {
			if (observedManager.locations.length > 0) {
				var location = observedManager.locations[0];
				findNokiaMapRouteDestination(location, endAddress, mapElement);
			}
		} 
		else if (value == "failed") {
			$(mapElement).html("<p>The search request failed</p>");
			$(mapElement).css('background-image', 'none');
		}
	});
	var searchProximity  = {
		center: new nokia.maps.geo.Coordinate(52.51, 13.4),
		radius: 1200000
	};
	searchManager.set("maxResults", 1);
	if(isCoordinate(startAddress)){
		var coordinate = getCoordinate(startAddress);
		searchManager.reverseGeocode(new nokia.maps.geo.Coordinate(coordinate[0], coordinate[1]));
	}
	else{
		searchManager.search(startAddress, searchProximity);
	}
}

function findNokiaMapRouteDestination(startLocation, endAddress, mapElement){	
	var searchManager = new nokia.maps.search.Manager();
	searchManager.addObserver("state", function (observedManager, key, value) {
		if (value == "finished") {
			if (observedManager.locations.length > 0) {
				var location = observedManager.locations[0];
				showNokiaMapRouteByCoordinates(startLocation, location, mapElement);
			}
		} 
		else if (value == "failed") {
			$(mapElement).html("<p>The search request failed</p>");
			$(mapElement).css('background-image', 'none');
		}
	});
	var searchProximity  = {
		center: new nokia.maps.geo.Coordinate(52.51, 13.4),
		radius: 1200000
	};
	searchManager.set("maxResults", 1);
	if(isCoordinate(endAddress)){
		var coordinate = getCoordinate(endAddress);
		searchManager.reverseGeocode(new nokia.maps.geo.Coordinate(coordinate[0], coordinate[1]));
	}
	else{
		searchManager.search(endAddress, searchProximity);
	}
}

function showNokiaMapRouteByCoordinates(start, end, mapElement){
	var map = new nokia.maps.map.Display(mapElement, {
			center: [52.51, 13.4],
			zoomLevel: 18,
			components:[new nokia.maps.map.component.Behavior(),new nokia.maps.map.component.ZoomBar(),new nokia.maps.map.component.TypeSelector()]
		}),
		router = new nokia.maps.routing.Manager();
		
	var onRouteCalculated = function (observedRouter, key, value) {
			if (value == "finished") {
				var routes = observedRouter.getRoutes();
				var mapRoute = new nokia.maps.routing.component.RouteResultSet(routes[0]).container;
				map.objects.add(mapRoute);
				map.zoomTo(mapRoute.getBoundingBox(), false, "default");
			} else if (value == "failed") {
				$(mapElement).html("<p>The routing request failed</p>");
				$(mapElement).css('background-image', 'none');
			}
		};
		
	router.addObserver("state", onRouteCalculated);

	var waypoints = new nokia.maps.routing.WaypointParameterList();
	waypoints.addCoordinate(new nokia.maps.geo.Coordinate(start.navigationPosition.latitude, start.navigationPosition.longitude));
	waypoints.addCoordinate(new nokia.maps.geo.Coordinate(end.navigationPosition.latitude, end.navigationPosition.longitude));
	var modes = [{
		type: "shortest", 
		transportModes: ["car"],
		options: "avoidTollroad",
		trafficMode: "default"
	}];
	//map.addListener("displayready", function () {
		router.calculateRoute(waypoints, modes);
	//});
}

function showMapRouteWrap(start, end, elementId) {
	var startLocation = getCoordinate(start);
	var endLocation = getCoordinate(end);
	var element = document.getElementById(elementId);
	var startNavigation = {navigationPosition: {latitude: startLocation[0], longitude: startLocation[1]}};
	var endNavigation = {navigationPosition: {latitude: endLocation[0], longitude: endLocation[1]}};

	showNokiaMapRouteByCoordinates(
		startNavigation, 
		endNavigation, 
		element
	);
}

function isCoordinate(search){
	search = (new String(search)).split(',');
	if(search.length == 2){
		if(isNumber(search[0]) && isNumber(search[1])){
			return true;
		}
		else{
			return false;
		}
	}
	else{
		return false;
	}
}

function getCoordinate(coordinate){
	coordinate = (new String(coordinate)).split(',');
	return new Array(parseFloat(coordinate[0]), parseFloat(coordinate[1]));
}

function isNumber(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}
