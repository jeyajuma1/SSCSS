<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/', 'HomeController@getLogin');
Route::post('/', 'HomeController@postLogin');
Route::get('logout', 'HomeController@getLogout');
Route::resource('password', 'RemindersController',[
	'only' => ['index', 'store', 'show', 'update']
]);

Route::get('users/new_user_access',['as'=>'accessrequest','uses'=>'RemindersController@useraccessrequest']);
Route::post('users/new_user_access_store',['as'=>'accessrequest_store','uses'=>'RemindersController@user_access_request_store']);


if (!Auth::check()) {  
	Route::get('{redir_url}',function()
	{
		if (Auth::guest()) {
	        Session::put('redir_url', URL::full());
	        return Redirect::to('/');
	    }
	})->where('redir_url', '(.*)');
}

Route::group(['before' => ['session', 'terms']], function ()
{
	Route::get('terms', [
		'before' => 'termsForms',
		'uses' => 'HomeController@getTerms'
	]);

	Route::post('terms', [
		'before' => 'termsForms',
	    'uses' =>	'HomeController@postTerms'
	]);

	Route::get('dashboard', 'HomeController@getDashboard');
	Route::post('dashboard/options','HomeController@getIncidentTransform');
	//Route::post('dashboard/type','HomeController@getIncidentTransform');
	Route::post('alerts', 'HomeController@postAlerts');
	Route::post('oldaudit', 'HomeController@postoldaudit');
	Route::post('saveorder', 'HomeController@saveOrder');

	Route::get('audits', [
		'as' => 'audits.index',
		'uses' => 'AuditsController@getIndex'
	]);

	Route::get('audits/download/{fid}/{id}/{type}', [
		'as' => 'audits.download',
		'uses' => 'AuditsController@getDownload'
	]);

	Route::get('incidents/create/{step?}', [
		'as' => 'incidents.create',
		'uses' => 'IncidentsController@create'
	]);

	Route::patch('incidents/review/{id}/{option?}', [
		'as' => 'incidents.review',
		'uses' => 'IncidentsController@review'
	]);

	Route::patch('incidents/close/{id?}', [
		'as' => 'incidents.close',
		'uses' => 'IncidentsController@close'
	]);

	Route::post('incidents/request_closure',['as'=>'incidents.request_closure','uses'=>'IncidentsController@request_closure']);


	Route::get('incidents/export/{id?}', [
		'as' => 'incidents.export',
		'uses' => 'IncidentsController@export'
	]);

	Route::get('incidents/{id}/edit/{step?}', [
		'as' => 'incidents.edit',
		'uses' => 'IncidentsController@edit'
	]);

	Route::get('incidents/download/{fid}/{id}/{type}', [
		'as' => 'incidents.download',
		'uses' => 'IncidentsController@download'
	]);

	Route::post('incidents/newfind',[
		'as' => 'incidents.newfind',
		'uses' => 'IncidentsController@newFinding'
	]);

	Route::post('incidents/update-owners', 'IncidentsController@updateOwners');

	Route::post('incident/update-investigation-status','IncidentsController@updateInvestigationStatus');

	Route::get('incident/investigation','IncidentsController@investigationList');

	Route::get('factory/incidents/create/{step?}',[
		'as' => 'factory.incidents.create',
		'uses'=> 'FactoryIncidentsController@create'
		]);

	Route::get('factory/incidents/{id}/edit/{step?}',[
		'as' => 'factory.incidents.edit',
		'uses'=> 'FactoryIncidentsController@edit'
		]);


	Route::post('factory/incidents/create',[
		'as' => 'factory.incidents.store',
		'uses' => 'FactoryIncidentsController@store'
		]);

	Route::resource('factory/incidents','FactoryIncidentsController',[
		'except' => ['create', 'edit']
	]);

	Route::patch('factory/incidents/close/{id?}', [
		'as' => 'factory.incidents.close',
		'uses' => 'FactoryIncidentsController@close'
	]);


	Route::get('incident/investigation/{id}/edit',[
			'as'   => 'investigation.edit',
			'uses' => 'IncidentsController@investigationEdit'
			]);

	Route::get('incident/investigation/create',[
			'as'   => 'investigation.create',
			'uses' => 'IncidentsController@investigationCreate'
			]);


	Route::put('incident/investigation/{id}/edit',[
			'as'   => 'investigation.update',
			'uses' => 'IncidentsController@investigationUpdate'
			]);
	
	Route::put('incident/investigation/create',[
			'as'  => 'investigation.store',
			'uses' => 'IncidentsController@investigationStore'
			]);

	Route::resource('incidents', 'IncidentsController', [
		'except' => ['create', 'edit']
	]);


	Route::get('locations/create/{step?}', [
		'as' => 'locations.create',
		'uses' => 'LocationsController@create'
	]);

	Route::patch('locations/review/{id}/{option?}', [
		'as' => 'locations.review',
		'uses' => 'LocationsController@review'
	]);

	Route::patch('locations/status/{id}/{option?}', [
		  'as' => 'locations.status',
		  'uses' => 'LocationsController@status'
		]);

	Route::get('locations/{id}/edit/{step?}', [
		'as' => 'locations.edit',
		'uses' => 'LocationsController@edit'
	]);

	Route::get('locations/incomplete/{id}',['uses' => 'LocationsController@incomplete']);

	Route::post('locations/update-owners', 'LocationsController@updateOwners');

	Route::resource('locations', 'LocationsController', [
		'except' => ['index', 'create', 'edit']
	]);

	Route::patch('routes/review/{id}/{option?}', [
		'as' => 'routes.review',
		'uses' => 'RoutesController@review'
	]);

	Route::patch('routes/status/{id}/{option?}',[
		 'as' => 'routes.status',
		 'uses' => 'RoutesController@status'
		]);

	Route::get('routes/{id}/edit/{step?}', [
		'as' => 'routes.edit',
		'uses' => 'RoutesController@edit'
	]);

	Route::get('routes/incomplete/{id}',['uses' => 'RoutesController@incomplete']);

	Route::get('routes/create/{step?}', [
		'as' => 'routes.create',
		'uses' => 'RoutesController@create'
	]);

	Route::post('routes/update-owners', 'RoutesController@updateOwners');

	Route::resource('routes', 'RoutesController', [
		'except' => ['index', 'create', 'edit']
	]);



	//Mail checking
	/*Route::resource('lanes', 'LanesController',[
    	'except' => ['show']
    	]);
    Route::get('lanes/chckmail','LanesController@chckmail');*/
    // Mailcheck

    Route::resource('lanes', 'LanesController');
    Route::post('lanes/add', 'LanesController@add');
    Route::post('lanes/update', 'LanesController@update');
    Route::post('lanes/delete', 'LanesController@delete');
    Route::post('lanes/routecreate', 'LanesController@routecreate');
    Route::get('statistics/audit','StatisticsController@getAudit');
    Route::post('statistics/excel','StatisticsController@getExportXLS');
    Route::get('statistics/incidents','StatisticsController@getIncidents');
    Route::get('statistics/suppliers','StatisticsController@getSuppliers');
	Route::get('statistics/sitemaster','StatisticsController@getSitemasters');

	Route::get('users/usermanual','UsersController@usermanual');

	Route::resource('users', 'UsersController',[
		'except' => ['show']
	]);

	
	Route::patch('suppliers/status/{id}/{option?}', [
		  'as' => 'suppliers.status',
		  'uses' => 'SuppliersController@status'
	]);
	Route::get('suppliers/self_assessment/{id?}', [
		'as' => 'suppliers.self',
		'uses' => 'SuppliersController@assessment'
	]);
	Route::post('suppliers/self_assessment/{id?}', [
		'as' => 'suppliers.self_assessment_store',
		'uses' => 'SuppliersController@self_assessment_store'
	]);
	Route::get('suppliers/onsite_assessment/{id?}', [
		'as' => 'suppliers.onsite',
		'uses' => 'SuppliersController@assessment'
	]);

	Route::post('suppliers/onsite_assessment/{id?}', [
		'as' => 'suppliers.onsite_assessment_store',
		'uses' => 'SuppliersController@onsite_assessment_store'
	]);

	Route::post('supplier/leakriskanalysis', 'SuppliersController@Leak_Risk_Analysis');

	Route::post('/supplier/leakpreventionstatus',[
			'as' => 'supplier.leakpreventionstatus',
			'uses' =>'SuppliersController@leakPreventionStatus'
		]);
	
	Route::get('suppliers/download/{fid}/{id}/{type}', [
		'as' => 'suppliers.download',
		'uses' => 'SuppliersController@getDownload'
	]);

	Route::post('supplier/leakincidenthistory',[
			'as' => 'supplier.leakincidenthistory',
			'uses' => 'SuppliersController@leak_incident_history'
		]);

	Route::post('supplier/leakriskanalysis/edit',[
			'as' =>'supplier.leakriskanalysis.edit',
			'uses' => 'SuppliersController@Leak_Risk_Analysis'
		]);

	Route::post('supplier/leakriskanalysis/add',[
			'as' =>'supplier.leakriskanalysis.add',
			'uses' => 'SuppliersController@Leak_Risk_Analysis'
		]);

	Route::resource('suppliers','SuppliersController',[
		 'except' => ['edit']
		]);
	Route::get('suppliers/create/{step?}', [
		'as' => 'suppliers.create',
		'uses' => 'SuppliersController@create'
	]);
	Route::get('suppliers/{id}/edit/{step?}', [
		'as' => 'suppliers.edit',
		'uses' => 'SuppliersController@edit'
	]);

	Route::get('sitemaster/export/{id?}', [
		'as' => 'sitemaster.export',
		'uses' => 'SitemastersController@export'
	]);
	/*Route::post('sitemaster/import/{id?}', [
		'as' => 'sitemaster.import',
		'uses' => 'SitemastersController@import'
	]);*/
	Route::patch('sitemaster/status/{id}/{option?}', [
		  'as' => 'sitemaster.status',
		  'uses' => 'SitemastersController@status'
	]);
	Route::patch('sitemaster/pdf/{id}', [
		  'as' => 'sitemaster.pdf_report',
		  'uses' => 'SitemastersController@exportpdf'
	]);
	Route::post('sitemaster/offline_confirm', [
			'as' => 'sitemaster.offline_confirm',
			'uses' => 'SitemastersController@offlineconfirm'
	]);
	
	Route::post('sitemaster/inspections', [
			'as' => 'sitemaster.inspections',
			'uses' => 'SitemastersController@inspections'
	]);
	
	Route::get('sitemaster/self_assessment/{id?}', [
		'as' => 'sitemaster.self',
		'uses' => 'SitemastersController@assessment'
	]);
	Route::post('sitemaster/self_assessment/{id?}', [
		'as' => 'sitemaster.self_assessment_store',
		'uses' => 'SitemastersController@self_assessment_store'
	]);
	Route::get('sitemaster/onsite_assessment/{id?}', [
		'as' => 'sitemaster.onsite',
		'uses' => 'SitemastersController@assessment'
	]);
	

	Route::post('sitemaster/inspectionstore/{id}/{type?}', [
		'as' => 'sitemaster.inspectionstore',
		'uses' => 'SitemastersController@inspectionstore'
	]);

	Route::post('sitemaster/inspectionprstore/{id}/{type?}', [
		'as' => 'sitemaster.inspectionprstore',
		'uses' => 'SitemastersController@inspectionprstore'
	]);
	
	Route::post('sitemaster/inspection/{id}/{type?}', [
		'as' => 'sitemaster.inspection',
		'uses' => 'SitemastersController@inspection'
	]);

	Route::post('sitemaster/{id}/inspectionedit/{inspection_num}/edit/{step?}', [
		'as' => 'sitemaster.inspectionedit' ,
		'uses' => 'SitemastersController@inspectionedit'
	]);

	Route::put('sitemaster/{id}/inspectionupdate/{inspection_num}/save/{step?}', [
		'as' => 'sitemaster.inspectionupdate' ,
		'uses' => 'SitemastersController@inspectionupdate'
	]);

	Route::get('sitemaster/prinspection/{id}/create/{type}/{step?}', [
		'as' => 'sitemaster.prinspection' ,
		'uses' => 'SitemastersController@insepectionPR'
	]);

	Route::post('sitemaster/site_visit_schedule',[
		'as' => 'sitemaster.site_visit_schedule',
		'uses' => 'SitemastersController@Site_Visit_Schedule' ]);
	

	Route::post('sitemaster/onsite_assessment/{id?}', [
		'as' => 'sitemaster.onsite_assessment_store',
		'uses' => 'SitemastersController@onsite_assessment_store'
	]);


	Route::post('sitemaster/leakriskanalysis', 'SitemastersController@Leak_Risk_Analysis');

	Route::post('/sitemaster/leakpreventionstatus',[
			'as' => 'sitemaster.leakpreventionstatus',
			'uses' =>'SitemastersController@leakPreventionStatus'
		]);
	
	Route::get('sitemaster/download/{fid}/{id}/{type}', [
		'as' => 'sitemaster.download',
		'uses' => 'SitemastersController@getDownload'
	]);

	Route::post('sitemaster/leakincidenthistory',[
			'as' => 'sitemaster.leakincidenthistory',
			'uses' => 'SitemastersController@leak_incident_history'
		]);

	Route::post('sitemaster/leakriskanalysis/edit',[
			'as' =>'sitemaster.leakriskanalysis.edit',
			'uses' => 'SitemastersController@Leak_Risk_Analysis'
		]);

	Route::post('sitemaster/leakriskanalysis/add',[
			'as' =>'sitemaster.leakriskanalysis.add',
			'uses' => 'SitemastersController@Leak_Risk_Analysis'
		]);

	Route::post('sitemaster/cainspection/update',[
			'as' => 'sitemaster.cainspection.update',
			'uses' => 'SitemastersController@updatCAInspection'
		]);

	Route::post('sitemaster/calpinspection/update',[
			'as' => 'sitemaster.calpinspection.update',
			'uses' => 'SitemastersController@updatLPCAInspection'
		]);
	

	Route::resource('sitemaster','SitemastersController',[
		 'except' => ['edit']
		]);
	Route::get('sitemaster/create/{step?}', [
		'as' => 'sitemaster.create',
		'uses' => 'SitemastersController@create'
	]);
	Route::get('sitemaster/{id}/edit/{step?}', [
		'as' => 'sitemaster.edit',
		'uses' => 'SitemastersController@edit'
	]);
	Route::resource('profile', 'ProfileController', [
		'only' => ['edit', 'update']
	]);

	Route::resource('regions', 'RegionsController', [
		'except' => ['show']
	]);


	Route::resource('countries', 'CountriesController', [
		'except' => ['show']
	]);

	Route::resource('lsps', 'LspsController', [
		'except' => ['show']
	]);

	Route::get('questions/{id}/edit/{availability}',[
		'as' => 'questionsedit',
		'uses' => 'QuestionsController@edit'
	]);
	Route::get('questions/{id}/destroy/{availability}',[
		'as' => 'questionsdestroy',
		'uses' => 'QuestionsController@destroy'
	]);
	Route::post('questions/{id}/update/{availability}',[
		'as' => 'questionsupdate',
		'uses' => 'QuestionsController@update'
	]);

	Route::resource('questions', 'QuestionsController', [
		'except' => ['show']
	]);

	Route::resource('certifications', 'CertificationsController', [
		'only' => ['index', 'edit', 'update']
	]);

	Route::get('settings', 'SettingsController@getSettings');

	Route::put('settings', 'SettingsController@putSettings');
});

// Error Pages
/*App::error(function($exception, $code)
 {
     switch ($code)
     {
         case 403:
             return Response::view('errors.403', array(), 403);

         case 404:
             return Response::view('errors.404', array(), 404);

         case 500:
             return Response::view('errors.500', array(), 500);

         default:
             return Response::view('errors.default', array(), $code);
     }
 });*/
