<?php

Blade::extend(function($view, $compiler)
{
	// Add the datetime keyword
    $pattern = $compiler->createMatcher('datetime');
    $view = preg_replace($pattern, '$1<?php echo $2->format(\'M d, Y h:i A\'); ?>', $view);
 
    return $view;
});