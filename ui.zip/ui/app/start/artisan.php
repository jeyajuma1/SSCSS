<?php

/*
|--------------------------------------------------------------------------
| Register The Artisan Commands
|--------------------------------------------------------------------------
|
| Each available Artisan command must be registered with the console so
| that it is available to be called. We'll register every command so
| the console gets access to each of the command object instances.
|
*/

Artisan::add(new importScsIrt);

Artisan::add(new mailTrigger);

Artisan::add(new createNotification);

Artisan::add(new mailTriggerforCSM);

Artisan::add(new mailTriggerforVAM);

Artisan::add(new createIncidentNotification);

Artisan::add(new mailTriggerforCSMweekly);

Artisan::add(new mailTriggerforVAMweekly);

Artisan::add(new mailTriggerforIncident);

Artisan::add(new mailTriggerforIncidentMonthlyReport);

Artisan::add(new createincidentmonthlyreport);

