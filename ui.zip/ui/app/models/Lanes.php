<?php

class Lanes extends \Eloquent {
	protected $fillable = [];
    use SoftDeletingTrait;

    /**
     * The user relationship data for this model.
     *
     * @var object
     */
    public function location()
    {
        return $this->belongsTo('Location', 'location_id')->select('id','site','address','coordinates','tapa_needed','auditor_id','country_id','lsp_id','status');
    }


     /**
     * The user relationship data for this model.
     *
     * @var object
     */

     public function user()
     {
        return $this->belongsTo('User','user_id');
     }

     /**
     * The lsp relationship data for this model.
     *
     * @var object
     */

     public function lsp()
     {
        return $this->belongsTo('Lsp','lsp_id');
     }
	

	 

  
}