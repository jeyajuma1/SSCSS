<?php
 use MSLST\Constants\Site;
	class Supplier extends \Eloquent {
		
		protected $fillable = [
			'vendor_number',
			'vendor_name',
			'site_name',
			'address',
			'country_id',
			'region_id',
			'city',
			'postal_code',
			'coordinates',			
			'site_technology',
			'tier',
			'supplier_type',
			'supplier_role',
			'category',
			'relationship',			
			'contact_telephone_number',
			'contact_email_address',
			'user_id',
			'supplier_handle',
			'status'
		];
		use SoftDeletingTrait;

		/**
		 * The database table used by the model.
		 *
		 * @var string
		 */
		protected $table = 'suppliers';
		/**
		 * The user relationship data for this model.
		 *
		 * @var object
		 */
		public static $suppliers_basic_info_rules = [
			'vendor_number'=>'required|Regex:/^[0-9]+$/',
			'vendor_name'=>'required',
			'region'=> 'required|exists:regions,id',
			'country'=> 'required|exists:countries,id',
			'city'=>'required|alpha_spaces',
			'coordinates' => 'required|coordinates',
		];
		public static $suppliers_information_rules = [
			'category'=>'required|alpha_spaces',
			'supplier_type' => 'required'
		];
		public static $suppliers_contact_details_rules = [
			'contact_email_address'=>'required|email',
			'contact_telephone_number'=>'required|Regex:/[0-9\-\(\)\+\s]+$/',
		];
		public static $messages = [
			'vendor_name.required' => 'The Supplier name field is required',
			'vendor_number.Regex'=>'The Vendor number field may only contain Numbers.',
			'city.alpha_spaces'=>'The city field may only contain letters and spaces.',
			'contact_telephone_number.Regex'=>'The Contact number should be valid',
			'contact_telephone_number.required'=>'The Contact Number is required',
			'contact_email_address.required'=>'The Email Address is required',
		]; 


		 /**
		     * Return the incident name.
		     *
		     * @return string
		 */
	    public function getNameAttribute() 
	    {
	        return Site::SUPPLIER_PREFIX . $this->id;
	    }



		public function user()
		{
			return $this->belongsTo('User', 'user_id')->withTrashed();
		}

		/**
		 * The user relationship data for this model.
		 *
		 * @var object
		 */
		public function region() {
			return $this->belongsTo('Region','region_id');
		}

		/**
		 * The user relationship data for this model.
		 *
		 * @var object
		 */

		public function country() {
			return $this->belongsTo('Country','country_id');
		}


		/**
	     * The get date mutoators for incidents table
	     *
	     * @return array
	     */
	    public function getDates()
	    {
	        return array('created_at', 'updated_at', 'deleted_at');
	    }


		/**
		* Get the format for database stored dates.
		*
		* @return string
		*/
		public function getDateFormat()
		{
			return 'Y-m-d H:i:s.u';
		}

		/**
		 * Convert a DateTime to a storable string.
		 * SQL Server will not accept 6 digit second fragment (PHP default: see getDateFormat Y-m-d H:i:s.u)
		 * trim three digits off the value returned from the parent.
		 *
		 * @param  \DateTime|int  $value
		 * @return string
		 */
		public function fromDateTime($value)
		{
		    return substr(parent::fromDateTime($value), 0, -3);
		}

		public function supplier_log()
	    {
	        return $this->hasMany('SupplierLog');
	    }
	}