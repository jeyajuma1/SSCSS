<?php

class OfficialInvestigation extends \Eloquent {
	protected $fillable = [
        'name_of_investigation_authority',
        'investigation_file_number',
        'final_investigation_findings',
		'contact_information',
        'incident_id',
        'dq'
    ];

    use SoftDeletingTrait;

    /**
     * The incident relationship data for this model.
     *
     * @return object
     */
    public function incident()
    {
        return $this->belongsTo('Incident');
    }
}