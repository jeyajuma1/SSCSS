<?php

use MSLST\Constants\Site;

class Incident extends \Eloquent {
	protected $fillable = [
        'type',
        'category',
        'short_description',
        'location_address',
        'location_city',
        'type_of_loss',
        'type_of_other_loss',
        'type_of_device',
        'type_of_other_device',
        'facility',
        'coordinates',
        'hawb',
        'mawb',
        'originating_facility',
        'destination_facility',
        'method_of_transportation',
        'consignee',
        'customer',
        'delivery_note_number',
        'cmr',
        'location_of_reporter',
        'driver_name',
        'vehicle_details',
        'carriers_and_contractors',
        'routing',
        'airline',
        'first_findings',
        'pick_up',
        'investigation_status',
        'incident_date',
        'country_id',
        'region_id',
        'user_id',
        'review_requested',
        'dq',
        'requested_by',
        'req_for_close_at',
        'closed_by',
        'closure_state',
        'closure_comment'
    ];

    use SoftDeletingTrait;

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $basic_information_rules = [
        'type'              => 'numeric',
        'region'            => 'required|exists:regions,id',
        'country'           => 'required|exists:countries,id',
        'incident_date'     => 'required|date_format:Y-m-d',
        'location_city'     => 'required|alpha_spaces',
        'type_of_loss'    => 'required',
        'coordinates'       => 'required|coordinates',
    ];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $customer_transportation_rules = [
        'consignee'             => 'required',
        'customer'              => 'required',
        'pickup_date'           => 'required|date_format:Y-m-d',
        'location_of_reporter'  => 'required',
        'originating_facility'  => 'required|Regex:/^(?=.*[a-zA-Z]).{3,}$/',
        'destination_facility'  => 'required|Regex:/^(?=.*[a-zA-Z]).{3,}$/',
        'method_of_transportation' => 'required',
    ];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $units_investigation_rules = [
        'type_of_device'    => 'required',
        'type_of_other_device'     => 'required',
        'type_of_other_loss'    => 'alpha_spaces',
        'number_of_plts_missing'     => 'required',
        'product_description'        => 'array|required|min:0',
        'number_of_units_missing'    => 'array|required|min:0',
        'value_per_unit'             => 'array|required|min:0',
        'total_value_of_lost_units'  => 'required|numeric|min:0',
        'imei_list'                  => 'mimes:xls,xlsx|min:1|max:8192',
        'name_of_investigation_authority' => 'required',
        'investigation_file_number'  => 'required',
        'first_findings'             => 'required',
        'dq'                         => 'alpha_num'
    ]; 

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $attachments_rules = [
        //'file'      => 'array|mimes:jpeg,doc,docx,xls,xlsx,pdf,zip,rar,png,gif,jpg|min:1|max:8192'
        'imei_list'     => 'min:1|max:8192',
        'sn_list'       => 'min:1|max:8192',
        'imei_list_ext' => 'in:xls,xlsx',
        'sn_list_ext'   => 'in:xls,xlsx',
        'file'          => 'array|min:1|max:8192'
    ];

    /**
     * Return the incident name.
     *
     * @return string
     */
    public function getNameAttribute() 
    {
        return Site::INCIDENT_PREFIX . $this->id;
    }

    /**
     * The user relationship data for this model.
     *
     * @return object
     */
    public function user()
    {
        return $this->belongsTo('User')->withTrashed();
    }

    /**
     * The country relationship data for this model.
     *
     * @return object
     */
    public function country()
    {
        return $this->belongsTo('Country');
    }

    /**
     * The region relationship data for this model.
     *
     * @return object
     */
    public function region()
    {
        return $this->belongsTo('Region');
    }

    /**
     * The product relationship data for this model.
     *
     * @return object
     */
    public function product()
    {
        return $this->hasOne('Product');
    }

    /**
     * The attachment relationship data for this model.
     *
     * @return object
     */
    public function attachment()
    {
        return $this->hasMany('Attachment');
    }

    /**
     * The incident log relationship data for this model.
     *
     * @return object
     */
    public function incident_log()
    {
        return $this->hasMany('IncidentLog');
    }


    /**
    * Get the format for database stored dates.
    *
    * @return string
    */
    public function getDateFormat()
    {
        return 'Y-m-d H:i:s.u';
    }

    /**
     * Convert a DateTime to a storable string.
     * SQL Server will not accept 6 digit second fragment (PHP default: see getDateFormat Y-m-d H:i:s.u)
     * trim three digits off the value returned from the parent.
     *
     * @param  \DateTime|int  $value
     * @return string
     */
    public function fromDateTime($value)
    {
        return substr(parent::fromDateTime($value), 0, -3);
    } 

    /**
     * The official investigation relationship data for this model.
     *
     * @return object
     */
    public function official_investigation()
    {
        return $this->hasOne('OfficialInvestigation');
    }

    public function getDates()
    {
        return array('pick_up', 'incident_date', 'closed_at', 'created_at', 'updated_at', 'deleted_at');
    }

    /**
     * The Investigation Status relationship data for this model
     * 
     * @return array
     **/
    public function incident_investigation()
    {
        return $this->belongsTo('IncidentInvestigation','investigation_status');
    }
}
