<?php

class Country extends \Eloquent {
	protected $fillable = ['name', 'region_id'];

    use SoftDeletingTrait;

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $rules = [
        'name'      => 'required|unique:countries,name',
        'region' => 'required',
    ];

    /**
     * The region relationship data for this model.
     *
     * @var object
     */
    public function region()
    {
        return $this->belongsTo('Region');
    }
}