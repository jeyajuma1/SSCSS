<?php

class FactoryIncidentInvestigationDetail extends \Eloquent {
	protected $fillable = [
				'name_of_investigation_authority',
				'contact_information',
				'investigation_file_number',
				'incident_refered_to',
				'ondatetime',
				'investigation_description_and_action_taken',
				'final_investigation_findings_cause_analysis_corrective_actions',
				'current_investigation_status',
				'factory_incident_id'];

	/**
     * The Investigation Status relationship data for this model
     * 
     * @return array
     **/
    public function incident_investigation()
    {
        return $this->belongsTo('IncidentInvestigation','current_investigation_status');
    }

    /**
     * The get date mutoators for incidents table
     *
     * @return array
    */
    public function getDates()
    {
        return array( 'ondatetime', 'created_at', 'updated_at', 'deleted_at');
    }
}