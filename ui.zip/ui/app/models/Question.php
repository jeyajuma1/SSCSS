<?php

class Question extends \Eloquent {
	protected $fillable = [
        'id',
        'text',
        'order',
        'availability',
        'is_archived',
        'is_mandatory',
        'subsection',
        'reference',
        'severity',
        'version',
        'severity_text'
    ];

    use SoftDeletingTrait;

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $rules = [
        'text'           => 'required|unique:questions,text',
        'availability'   => 'required|in:',
         //'order'          => 'required|integer|min:0',
        'certifications' => 'required',
    ];

    /**
     * The certification relationship data for this model.
     *
     * @var object
     */
    public function certifications()
    {
        return $this->belongsToMany('Certification', 'question_certifications');
    }
	/**
	 * Get Dates
	 *
	 **/
	
	 public function getDates()
    {
        return array('created_at', 'updated_at', 'deleted_at');
    }
	
	
}