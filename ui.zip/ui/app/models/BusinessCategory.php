<?php

class BusinessCategory extends \Eloquent {
	protected $fillable = [];
	 use SoftDeletingTrait;
}