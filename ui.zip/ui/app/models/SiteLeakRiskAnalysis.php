<?php

class SiteLeakRiskAnalysis extends \Eloquent {
	protected $fillable = [
						   'sitemaster_id',
						   'activity_id',
						   'asset_id',
						   'lob_id'
						   ];


	use SoftDeletingTrait;

	/**
	 *
	 * return @belongs
	 **/

	public function sitemaster(){
		return $this->belongsTo('Sitemaster');
	}


	/**
	 *
	 * return @belongs
	 **/

	public function site_business_activity(){
     	return $this->belongsTo('SiteBusinessActivity','activity_id')->select('id','name');
     }
}