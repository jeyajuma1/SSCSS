<?php

class UserLog extends \Eloquent {
   

  	protected $fillable = [
        'user_id',
        'login_at',
        'created_at',
        'updated_at'
       ];

    /**
     * The user relationship data for this model.
     *
     * @var object
     */
    public function user()
    {
        return $this->belongsTo('User')->withTrashed();
    }

   
}