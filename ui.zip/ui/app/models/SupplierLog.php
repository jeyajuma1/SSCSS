<?php

class SupplierLog extends \Eloquent {
	protected $fillable = [
        'supplier_id',
        'user_id',
        'created_at',
        'updated_at'
    ];

    /**
     * The user relationship data for this model.
     *
     * @var object
     */
    public function user()
    {
        return $this->belongsTo('User')->withTrashed();
    }


     /**
     * The incident relationship data for this model.
     *
     * @var object
     */
    public function supplier()
    {
        return $this->belongsTo('Supplier');
    }

}