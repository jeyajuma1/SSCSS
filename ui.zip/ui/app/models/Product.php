<?php

class Product extends \Eloquent {
	protected $fillable = [
        'number_of_plts_missing',
        'number_of_units_missing',
        'product_description',
        'value_per_unit',
        'total_value_of_lost_units',
        'incident_id',
        'currency'
    ];

    use SoftDeletingTrait;

    /**
     * The incident relationship data for this model.
     *
     * @var object
     */
    public function incident()
    {
        return $this->belongsTo('Incident');
    }
}