<?php

use MSLST\Constants\Site;

class Certification extends \Eloquent {
	protected $fillable = [
		'name',
		'availability',
	];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
	public static $rules = [
        'name'    => 'required|unique:certifications,name',
        'availability' => 'required|in:',
    ];
	
	
	/**
	 * Get Dates
	 *
	 **/
	
	public function getDates() {
        return array('created_at', 'updated_at', 'deleted_at');
    }
}