<?php

class RouteCertification extends \Eloquent {
	protected $fillable = [
		'certificate_file',
		'filename',
		'route_id',
		'certification_id',
	];
}