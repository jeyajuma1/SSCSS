<?php

class SiteLineOfBusiness extends \Eloquent {
	protected $fillable = [];

	protected $table = 'site_line_of_business';
}