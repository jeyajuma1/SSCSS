<?php

class ImeiNumber extends \Eloquent {
	protected $fillable = [];
}