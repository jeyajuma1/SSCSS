<?php

use MSLST\Constants\Site;

class Location extends \Eloquent {
	protected $fillable = [
        'site',
        'address',
        'coordinates',
        'comment',
        'value',
        'score',
        'ctpat_number',
        'aeo_number',
        'review',
        'tapa_needed',
        'auditor_id',
        'country_id',
        'lsp_id',
        'status'
    ];

    use SoftDeletingTrait;

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $basic_details_rules = [
        'site'           => 'required',
        'address'        => 'required',
        'coordinates'    => 'required|coordinates',
        'value'          => 'numeric|min:0',
        'country'        => 'required|exists:countries,id',
    ];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $needed_certification_rules = [
        'tapa_needed'     => 'required|in:',
    ];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $actual_certification_rules = [
        'tapa'              => 'required|in:',
        'ctpat'             => 'required|in:',
        'aeo'               => 'required|in:',
        'tapa_certificate'  => 'mimes:pdf,jpg,jpeg,doc,docx|min:1|max:8192',
        'ctpat_certificate' => 'mimes:pdf,jpg,jpeg,doc,docx|min:1|max:8192',
        'aeo_certificate'   => 'mimes:pdf,jpg,jpeg,doc,docx|min:1|max:8192',
        'svi_num'           => 'Regex:/(?=.*\d)(?=.*[a-zA-Z]).{8,24}/',
        'aeo_num'           => 'Regex:/(?=.*\d)(?=.*[a-zA-Z]).{8,24}/',
    ];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $questions_rules = [
        'question'     => 'array',
    ];

    /**
     * The rules to be applied to the data.
     *
     * @var array
     */
    public static $comments_rules = [
        'comments' => 'max:500'
    ];

    /**
     * Return the location name.
     *
     * @return string
     */
    public function getNameAttribute()
    {
        return Site::LOCATION_PREFIX . $this->id;
    }

    /**
     * The user relationship data for this model.
     *
     * @var object
     */
    public function user()
    {
        return $this->belongsTo('User', 'auditor_id')->withTrashed();
    }

    /**
     * The country relationship data for this model.
     *
     * @var object
     */
    public function country()
    {
        return $this->belongsTo('Country');
    }

    /**
     * The lsp relationship data for this model.
     *
     * @var object
     */
    public function lsp()
    {
        return $this->belongsTo('Lsp');
    }

    /**
     * The question relationship data for this model.
     *
     * @var object
     */
    public function question()
    {
        return $this->belongsToMany('Question', 'location_audits')->withPivot('answer_id', 'comment', 'is_archived');
    }

    /**
     * The location certifications relationship data for this model.
     *
     * @var object
     */
    public function certification()
    {
        return $this->belongsToMany('Certification', 'location_certifications')->withPivot('id', 'certificate_file', 'filename');
    }

    /**
     * The disabled certifications relationship data for this model.
     *
     * @var object
     */
    public function disabled_certification()
    {
        return $this->hasMany('LocationCertificationDisabledGroup');
    }

    /**
     * The location logs relationship data for this model.
     *
     * @var object
     */
    public function location_log()
    {
        return $this->hasMany('LocationLog');
    }
}
