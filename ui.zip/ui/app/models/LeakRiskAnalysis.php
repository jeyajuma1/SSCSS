<?php

class LeakRiskAnalysis extends \Eloquent {
	protected $fillable = ['supplier_id','activity_id','asset_id'];

	use SoftDeletingTrait;

	/**
	 *
	 **/

	public function supplier(){
		return $this->belongsTo('Supplier');
	}


	/**
	 *
	 **/

	public function business_activity(){
     	return $this->belongsTo('BusinessActivity','activity_id')->select('id','name');
     }
}