<?php

class SiteLeakIncidentHistory extends \Eloquent {
	protected $fillable = ['sitemaster_id',
						   'title',
						   'incident_date',
						   'incident_type',
						   'root_cause',
						   'corrective_action_title',
						   'corrective_action_description',
						   'supplier_contact',
						   'deadline_date'
						   ];

	use SoftDeletingTrait;

	/**
     * The get date mutoators for incidents table
     *
     * @return array
     */
    public function getDates()
    {
        return array( 'incident_date', 'deadline_date', 'created_at', 'updated_at', 'deleted_at');
    }					  
}