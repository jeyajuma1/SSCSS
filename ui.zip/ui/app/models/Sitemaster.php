<?php
use MSLST\Constants\Site;
	class Sitemaster extends \Eloquent {
		
		protected $fillable = ['site_name',
							   'status',
							   'supplier_type',
							   'region_id', 
							   'country_id',
							   'city',
							   'country_state', 
							   'postal_code',
							   'address',
							   'coordinates',
							   'lob', 'process',
							   'parent_site',
							   'primary_stakeholder',
							   'sec_stakeholder', 
							   'channel_manager', 
							   'vam',  
							   'last_inspection_date', 
							   'corrective_actions',
							   'comments', 
							   'contact_name',
							   'contact_email', 
							   'other_contact_info',
							   'supplier_handle',
							   'user_id',
							   'next_site_visit',
							   'c_tpat_svi_number',
							   'determined_overall_status',
							   'supplier_other_type',
							   'lob_other_type',
							   'process_other_type'
							  ];
		use SoftDeletingTrait;

		/**
		 * The database table used by the model.
		 *
		 * @var string
		 */
		protected $table = 'sitemasters';

		public function user()
		{
			return $this->belongsTo('User', 'user_id')->withTrashed();
		}

		public function getNameAttribute() 
		{
			return Site::SITEMASTER_PREFIX . $this->id;
		}

		public static $sitemasters_basic_info_rules = [
								
				'site_name'=> 'required',
				'supplier_type'=> 'required',				
				'region'=> 'required|exists:regions,id',
				'country'=> 'required|exists:countries,id',
				'city'=>'required|alpha_spaces',
				'coordinates' => 'coordinates',
		];
				
		public static $sitemasters_information_rules = [
				'lob'=>'required',
				'channel_manager'=>'required|alpha_spaces',
				'primary_stakeholder'=>'alpha_spaces',
				'last_inspection_date'=>'date',
				'c_tpat_svi_number' => 'alpha_num'
		];
		public static $sitemasters_contact_details_rules = [
				'contact_email'=>'required|email',
				'contact_name'=>'required|alpha_spaces',
		];
		public static $messages = [
				'lob.required' =>'The Line of business field is required.',
				'lob.alpha_spaces' =>'The Line of business field may only contain letters and spaces.',
				'last_inspection_date.date' => 'The last inspection date does not match the format YYYY-MM-DD',
				'city.alpha_spaces'=>'The city field may only contain letters and spaces.',
				'ins_main_num_sep_buliding_at_this_site.numeric'=>'Number of separate buildings at this site must be a number.',
				'ins_main_num_buliding_ms_related_functions.numeric'=>'Number of buildings with Microsoft-related functions must be a number.',
				'ins_main_num_full_time_emp_facility.numeric'=>'Number of full-time employees at this facility must be a number.'
		];


		public static $InspectionMain_rules = [  
											 	  'ins_main_num_sep_buliding_at_this_site'=>'numeric',
											 	  'ins_main_num_buliding_ms_related_functions'=>'numeric',
											      'ins_main_num_full_time_emp_facility'=>'numeric',
											  ];
		/**
		 * The user relationship data for this model.
		 *
		 * @var object
		 */
		

		public function region() {
			return $this->belongsTo('Region','region_id');
		}

		/**
		 * The user relationship data for this model.
		 *
		 * @var object
		 */

		public function country() {
			return $this->belongsTo('Country','country_id');
		}

		/**
		 * The user relationship data for this model.
		 *
		 * @var object
		 */

		public function pr_inspection_main() {
			return $this->hasMany('SiteInspectionsAnswer')->select('id','sitemaster_id','ins_main_date','sc_scoring_rules_final_rating')->orderBy('id','desc');//->take(1);
		}



		/**
		 * The user relationship data for this model.
		 *
		 * @var object
		 */

		public function insepction_pr() {
			return $this->hasMany('SiteCorrectiveAction')->select(\DB::raw("sitemaster_id,(case when (vam_approval IS NULL and ([intial_due_date] <= getdate() or ([due_date_extension] IS NOT NULL and [due_date_extension] <=getdate()))) then 'overdue' when (vam_approval =  'accept') then 'closed' else 'open' end) as pr_status,
									count((case when (vam_approval IS NULL and ([intial_due_date] <= getdate() or ([due_date_extension] IS NOT NULL and [due_date_extension] <=getdate()))) then 'overdue' when (vam_approval =  'accept') then 'closed' else 'open' end)) as cnt_status,inspection_num"))
									->groupby(\DB::raw("(case when (vam_approval IS NULL and ([intial_due_date] <= getdate() or ([due_date_extension] IS NOT NULL and [due_date_extension] <=getdate()))) then 'overdue' when (vam_approval =  'accept') then 'closed' else 'open' end),sitemaster_id,inspection_num"))
									->orderBy('inspection_num','desc');//->take(3);
		}


		/**
		 * The user relationship data for this model.
		 *
		 * @var object
		 */

		public function pr_insepction_severity() {
			return $this->hasMany('SiteCorrectiveAction')->select(\DB::raw("p_r_severity,count(p_r_severity) as severity_cnt,sitemaster_id"))
									->groupby(\DB::raw("p_r_severity,sitemaster_id"));
								 
		}

		/**
		* Get the format for database stored dates.
		*
		* @return string
		*/
		public function getDateFormat()
		{
			return 'Y-m-d H:i:s.u';
		}

		/**
		 * Convert a DateTime to a storable string.
		 * SQL Server will not accept 6 digit second fragment (PHP default: see getDateFormat Y-m-d H:i:s.u)
		 * trim three digits off the value returned from the parent.
		 *
		 * @param  \DateTime|int  $value
		 * @return string
		 */
		public function fromDateTime($value)
		{
		    return substr(parent::fromDateTime($value), 0, -3);
		} 


		/**
	     * The get date mutoators for incidents table
	     *
	     * @return array
	     */
	    public function getDates()
	    {
	        return array('created_at', 'updated_at', 'deleted_at','last_inspection_date','next_site_visit');
	    }

	    public function sitemaster_log()
	    {
	        return $this->hasMany('SitemasterLog');
	    }

	    public function site_pr_log()
	    {
	        return $this->hasMany('SitePrLog');
	    }

	}