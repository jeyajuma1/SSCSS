<?php

class BusinessRisk extends \Eloquent {
	protected $fillable = [];
	use SoftDeletingTrait;
}