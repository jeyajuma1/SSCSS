<?php

	class BusinessActivities extends \Eloquent {
		
		
		use SoftDeletingTrait;

		/**
		 * The database table used by the model.
		 *
		 * @var string
		 */
		protected $table = 'business_activities';
		
	}