<?php

class QuestionCertification extends \Eloquent {
	protected $fillable = [];

	use SoftDeletingTrait;
}