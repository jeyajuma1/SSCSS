<?php

class BusinessActivity extends \Eloquent {
	protected $fillable = [
	'name'];
	 use SoftDeletingTrait;
}