<?php

class RouteOwner extends \Eloquent {
	protected $fillable = [
		'route_id',
		'user_id',
	];
}
