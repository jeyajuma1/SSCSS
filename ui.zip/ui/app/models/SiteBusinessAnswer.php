<?php

class SiteBusinessAnswer extends \Eloquent {
	protected $fillable = ['self_answer_id',
						   'self_comment',
						   'onsite_answer_id',
						   'onsite_comment',
						   'sitemaster_id',
						   'question_id',
						   'ms_id',
						   'self_file_name',
						   'self_file_description',
						   'self_file_type',
						   'activity_id'];
						   
    use SoftDeletingTrait;						 
}