<?php

class SiteInspectionsQuestionAnswer extends \Eloquent {
	protected $fillable = [
							'inspection_id',
							'ques_reference',
							'ques_severity',
							'ques_response',
							'ques_mitigating_control',
							'ques_issue_detail_comments',
							'ques_corrective_action',
							'user_id',
							'sitemaster_id'
						  ];
}