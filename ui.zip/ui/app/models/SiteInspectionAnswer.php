<?php

class SiteInspectionAnswer extends \Eloquent {
	protected $fillable = ['answer_id',
						   'comment',
						   'sitemaster_id',
						   'question_id',
						   'user_id',
						   'inspection_num'
						   ];
						   
    use SoftDeletingTrait;						 
}