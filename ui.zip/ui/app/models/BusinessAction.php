<?php

class BusinessAction extends \Eloquent {
	protected $fillable = [];
}