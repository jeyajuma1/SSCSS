<?php

class SiteCorrectiveAction extends \Eloquent {
	
	protected $fillable = [
	  'sitemaster_id'
      ,'p_r_reference'
      ,'p_r_version'
      ,'p_r_text'
      ,'inspector_comments'
      ,'inspector_user_id'
      ,'intial_due_date'
      ,'supplier_comments_evidence'
      ,'supplier_user_id'
      ,'due_date_extension'
      ,'days_past_due'
      ,'vam_approval'
      ,'vam_user_id'
      ,'inspection_num',
      'p_r_severity'];

    use SoftDeletingTrait;

    /**
       * The user relationship data for this model.
       *
       * @var object
       */

      public function sitemaster() {
            return $this->belongsTo('Sitemaster','sitemaster_id')->select('id','site_name','last_inspection_date','next_site_visit');
      }


    /**
       * The user relationship data for this model.
       *
       * @var object
       */

      public function siteinspectionsanswer() {
            return $this->belongsTo('SiteInspectionsAnswer','inspection_num')->select('id','ins_main_date','sitemaster_id','sc_scoring_rules_final_rating','user_id');
      }

      /**
       * The user relationship data for this model.
       *
       * @var object
       */

      public function question() {
            return $this->belongsTo('Question','p_r_reference')->select('reference','id','text','order','availability','is_archived','is_mandatory','created_at','subsection','severity_text','version');
      }

      /**
     * The database table used by the model.
     *
     * @var string
     */

    public function user()
    {
      return $this->belongsTo('User', 'inspector_user_id')->select('id','first_name','last_name','role','site_user_level')->withTrashed();
    }
    


      /**
      * Get the format for database stored dates.
      *
      * @return string
      */
      public function getDateFormat()
      {
            return 'Y-m-d H:i:s.u';
      }

      /**
       * Convert a DateTime to a storable string.
       * SQL Server will not accept 6 digit second fragment (PHP default: see getDateFormat Y-m-d H:i:s.u)
       * trim three digits off the value returned from the parent.
       *
       * @param  \DateTime|int  $value
       * @return string
       */
      public function fromDateTime($value)
      {
          return substr(parent::fromDateTime($value), 0, -3);
      }


      /**
           * The get date mutoators for incidents table
           *
           * @return array
      */
     public function getDates()
      {
              return array('created_at', 'updated_at', 'deleted_at','intial_due_date','due_date_extension');
      }

}