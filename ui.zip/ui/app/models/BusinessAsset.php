<?php

class BusinessAsset extends \Eloquent {
	protected $fillable = [];
	 use SoftDeletingTrait;
}