<?php

class UserAccessRequest extends \Eloquent {
	protected $fillable = [
	'first_name',
    'last_name', 
    'company_name', 
    'address_line1',
    'address_line2', 
    'city',
    'country',
    'email', 
    'microsoft_contact',
    'microsoft_contact_email',
    'supplier_type',
    'supplier_other_type',

	];

	public static $rules = [
        'first_name'            => 'required|alpha_spaces',
        'last_name'             => 'required|alpha_spaces',
        'email'                 => 'required|email|unique:users,email',
        'company_name'			=> 'required|alpha_spaces',
        'microsoft_contact'		=> 'required|Regex:/[0-9\-\(\)\+\s]+$/',
        'microsoft_contact_email'=> 'required|email|unique:users,email',
        'supplier_type'          => 'required'
    ];
}