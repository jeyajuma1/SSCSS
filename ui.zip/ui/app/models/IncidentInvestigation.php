<?php

class IncidentInvestigation extends \Eloquent {

	protected $fillable = [];
    use SoftDeletingTrait;

}

?>