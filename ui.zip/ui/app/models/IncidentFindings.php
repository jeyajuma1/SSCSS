<?php

class IncidentFindings extends \Eloquent {

	protected $fillable = [];
	use SoftDeletingTrait;


	/**
	  * incident Relation data for this model
	  * 
	  *
	  **/
	public   function incident(){
		return $this->belongsTo('Incident');
	}


	/**
	  * User Relation data for  this model
	  *
	  *
	  **/

	public  function user(){
		return $this->belongsTo('User')->select('first_name','last_name')->withTrashed();
	}

}

?>