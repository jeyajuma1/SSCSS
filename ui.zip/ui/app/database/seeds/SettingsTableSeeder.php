<?php

class SettingsTableSeeder extends Seeder {

	/**
	 * Auto generated seed file
	 *
	 * @return void
	 */
	public function run()
	{
		\DB::table('settings')->truncate();
        
		\DB::table('settings')->insert(array (
			0 => 
			array (
				'id' => 1,
				'name' => 'site_email',
				'value' => 'scs-notifications@microsoft.com',
				'created_at' => '2014-08-01 12:09:34',
				'updated_at' => '2014-10-14 08:21:23',
			),
			1 => 
			array (
				'id' => 2,
				'name' => 'site_email_sender',
			'value' => 'Supply Chain Security (RES/Bucharest)',
				'created_at' => '2014-08-01 12:09:34',
				'updated_at' => '2014-10-14 08:21:23',
			),
			2 => 
			array (
				'id' => 3,
				'name' => 'site_ask_agree_tnc',
				'value' => '1',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			3 => 
			array (
				'id' => 4,
				'name' => 'account_email_subject_user_create',
				'value' => 'Your Microsoft Logistic Security Tool account',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			4 => 
			array (
				'id' => 5,
				'name' => 'account_email_body_user_create',
				'value' => '<div>


<div>
Dear User,<br>
<br>
This is an automatic notification e-mail from Microsoft Logistic Security Tool.<br>
A new account in Microsoft Logistic Security Tool has been created for you.<br>
<br>
To create your login password, complete this form: %reset-url%.<br>
This link will expire in 24 hours.<br>
<br>
If you need further assistance, please don\'t hesitate to contact logistics-security@microsoft.com<br>
<br>
Best regards,<br>
Microsoft Logistics Security Team<br>
</div>

</div>',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			5 => 
			array (
				'id' => 6,
				'name' => 'account_email_subject_password_reset',
				'value' => 'Microsoft Logistic Security Tool - Password Reset',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			6 => 
			array (
				'id' => 7,
				'name' => 'account_email_body_password_reset',
				'value' => '<div>

<div>
Dear User,<br><br>This is an automatic notification e-mail from Microsoft Logistic Security Tool.<br><br>To reset your password, complete this form: %reset-url%.<br>
This link will expire in %expiration% minutes.<br><br>Best regards,<br>
Microsoft Logistics Security Team<br></div>
</div>',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			7 => 
			array (
				'id' => 8,
				'name' => 'audit_email_subject_location_create',
				'value' => 'Microsoft Logistic Security Tool Notification - Location Created',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			8 => 
			array (
				'id' => 9,
				'name' => 'audit_email_subject_location_edit',
				'value' => 'Microsoft Logistic Security Tool Notification - Location Edited',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			9 => 
			array (
				'id' => 10,
				'name' => 'audit_email_body_location',
				'value' => '<p>Dear User,</p><p>This is a notification e-mail from Microsoft Logistic Security Tool.<br></p><p>%name% from %lsp_name% has %action% an audit for %site_name%<br><br>Assessor: %name%<br>Company: %lsp_name%<br>Location: %site_name% %country% & %address%<br>Date: %timestamp%<br><br>Please login to access the Administration page of the Microsoft Logistic Security Tool.<br></p><p>Best regards,<br>
Microsoft Logistics Security Team.</p><p><br></p><p><span style="font-style: italic;"><small>* The content of this communication is classified as Microsoft Confidential and Proprietary Information. If you believe that you received a misaddressed e-mail, please return it to sender, notifying him/her of this. The content of this communication is intended solely for the use of the individual or entity to whom it is addressed and others authorized to receive it. The message or attachments may be subject to professional confidentiality, personal data protection, copyright or other legal disclosure restrictions. Microsoft does not guarantee that the integrity of this communication has been maintained, nor that this communication is free of viruses, interceptions or interference. We appreciate your assistance in preserving the confidentiality of our correspondence. Thank you.</small></span></p><p><span style="font-style: italic;"><br><small>* Read the privacy policy here.</small></span></p>',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			10 => 
			array (
				'id' => 11,
				'name' => 'audit_email_subject_route_create',
				'value' => 'Microsoft Logistic Security Tool Notification - Route Created',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			11 => 
			array (
				'id' => 12,
				'name' => 'audit_email_subject_route_edit',
				'value' => 'Microsoft Logistic Security Tool Notification - Route Edited',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			12 => 
			array (
				'id' => 13,
				'name' => 'audit_email_body_route',
				'value' => '<p>Dear User,</p><p>This is a notification e-mail from Microsoft Logistic Security Tool.<br></p><p>%name% from %lsp_name% has %action% an audit for %site_name%<br><br>Assessor: %name%<br>Start Location: %site_name_start% %country_start% & %address_start%<br>End Location: %site_name_end% %country_end% & %address_end%<br>Company: %lsp_name%<br>Date: %timestamp%<br><br>Please login to access the Administration page of the Microsoft Logistic Security Tool.<br></p><p>Best regards,<br>
Microsoft Logistics Security Team.</p><p><br></p><p><span style="font-style: italic;"><small>* The content of this communication is classified as Microsoft Confidential and Proprietary Information. If you believe that you received a misaddressed e-mail, please return it to sender, notifying him/her of this. The content of this communication is intended solely for the use of the individual or entity to whom it is addressed and others authorized to receive it. The message or attachments may be subject to professional confidentiality, personal data protection, copyright or other legal disclosure restrictions. Microsoft does not guarantee that the integrity of this communication has been maintained, nor that this communication is free of viruses, interceptions or interference. We appreciate your assistance in preserving the confidentiality of our correspondence. Thank you.</small></span></p><p><span style="font-style: italic;"><br><small>* Read the privacy policy here.</small></span></p>',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			13 => 
			array (
				'id' => 14,
				'name' => 'audit_email_subject_lane_create',
				'value' => 'Microsoft Logistic Security Tool Notification - Lane Created',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			14 => 
			array (
				'id' => 15,
				'name' => 'audit_email_subject_lane_edit',
				'value' => 'Microsoft Logistic Security Tool Notification - Lane Edited',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			15 => 
			array (
				'id' => 16,
				'name' => 'audit_email_body_lane',
				'value' => '<p>Dear User,</p><p>This is a notification e-mail from Microsoft Logistic Security Tool.<br></p><p>%name% from %lsp_name% has %action% a lane for %site_name%<br><br>Assessor: %name%<br>Start Location: %site_name_start% %country_start% & %address_start%<br>End Location: %site_name_end% %country_end% & %address_end%<br>Company: %lsp_name%<br>Date: %timestamp%<br><br>Please login to access the Administration page of the Microsoft Logistic Security Tool.<br></p><p>Best regards,<br>
Microsoft Logistics Security Team.</p><p><br></p><p><span style="font-style: italic;"><small>*
The content of this communication is classified as Microsoft 
Confidential and Proprietary Information. If you believe that you 
received a misaddressed e-mail, please return it to sender, notifying 
him/her of this. The content of this communication is intended solely 
for the use of the individual or entity to whom it is addressed and 
others authorized to receive it. The message or attachments may be 
subject to professional confidentiality, personal data protection, 
copyright or other legal disclosure restrictions. Microsoft does not 
guarantee that the integrity of this communication has been maintained, 
nor that this communication is free of viruses, interceptions or 
interference. We appreciate your assistance in preserving the 
confidentiality of our correspondence. Thank you.</small></span></p><p><span style="font-style: italic;"><br><small>* Read the privacy policy here.</small></span></p>',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			16 => 
			array (
				'id' => 17,
				'name' => 'audit_email_subject_review_request',
				'value' => 'Microsoft Logistic Security Tool - Audit - Request for Review',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			17 => 
			array (
				'id' => 18,
				'name' => 'incident_email_subject_create',
				'value' => 'Microsoft Logistic Security Tool - New %category% Incident/%incidentdate%/%creatorcompany%/%country%',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			18 => 
			array (
				'id' => 19,
				'name' => 'incident_email_body_create',
				'value' => '<p>Dear User,</p><p>This is a notification e-mail from Microsoft SCS IRT.
</p><p>A %category% incident has been registered. Please find the details below:
</p><p></p>
ID: #%incidentid%<br>
Category: %category%<br>
Registered by: %creatorname%<br>
LSP: %creatorcompany%<br>
Date: %incidentdate%<br>
Country: %country%<br>
Qty: %productquantity%<br>
<span style="color:red">Total value: %totalvalue% EUR</span><br>
Customer: %customer%<br>
Description: %description%<br><br>Please login to access the Administration page of the Microsoft Logistic Security Tool.<br><br><p>Best regards,<br>
Microsoft Logistics Security Team.</p><p><span style="font-style: italic;"><small><br></small></span></p><p><span style="font-style: italic;"><small>*
The content of this communication is classified as Microsoft 
Confidential and Proprietary Information. If you believe that you 
received a misaddressed e-mail, please return it to sender, notifying 
him/her of this. The content of this communication is intended solely 
for the use of the individual or entity to whom it is addressed and 
others authorized to receive it. The message or attachments may be 
subject to professional confidentiality, personal data protection, 
copyright or other legal disclosure restrictions. Microsoft does not 
guarantee that the integrity of this communication has been maintained, 
nor that this communication is free of viruses, interceptions or 
interference. We appreciate your assistance in preserving the 
confidentiality of our correspondence. Thank you.</small></span></p><p><span style="font-style: italic;"><br><small>* Read the privacy policy here.</small></span></p><br><br>
',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			19 => 
			array (
				'id' => 20,
				'name' => 'incident_email_subject_status_change',
				'value' => 'Microsoft Logistic Security Tool - Incident Status Changed',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			20 => 
			array (
				'id' => 21,
				'name' => 'incident_email_body_status_change',
				'value' => '<p>Dear User,</p><p>This is a notification e-mail from Microsoft SCS IRT.
</p><p>An incident\'s status was changed to %status%. Please find the details below:
</p>
ID: #%incidentid%<br>
Registered by: %creatorname%<br>
LSP: %creatorcompany%<br>
Date: %incidentdate%<br>
Country: %country%<br>
Category: %category%<br>
Qty: %productquantity%<br>
<span style="color:red">Total value: %totalvalue% EUR</span><br>
Customer: %customer%<br><br>Best regards,<br><p>
Microsoft Logistics Security Team.</p><p><span style="font-style: italic;"><small><br></small></span></p><p><span style="font-style: italic;"><small>*
The content of this communication is classified as Microsoft 
Confidential and Proprietary Information. If you believe that you 
received a misaddressed e-mail, please return it to sender, notifying 
him/her of this. The content of this communication is intended solely 
for the use of the individual or entity to whom it is addressed and 
others authorized to receive it. The message or attachments may be 
subject to professional confidentiality, personal data protection, 
copyright or other legal disclosure restrictions. Microsoft does not 
guarantee that the integrity of this communication has been maintained, 
nor that this communication is free of viruses, interceptions or 
interference. We appreciate your assistance in preserving the 
confidentiality of our correspondence. Thank you.</small></span></p><p><span style="font-style: italic;"><br><small>* Read the privacy policy here.</small></span></p><br>
',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			21 => 
			array (
				'id' => 22,
				'name' => 'incident_email_subject_edit',
				'value' => 'Microsoft Logistic Security Tool - Incident Edited',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			22 => 
			array (
				'id' => 23,
				'name' => 'incident_email_body_edit',
				'value' => '<p>Dear User,</p><p>This is a notification e-mail from Microsoft SCS IRT.</p><p>Please be informed that the following incident in %country% has been edited/updated with additional details:
</p>
ID: #%incidentid%<br>
Registered by: %creatorname%<br>
LSP: %creatorcompany%<br>
Date: %incidentdate%<br>
Country: %country%<br>
Category: %category%<br>
Qty: %productquantity%<br>
<span style="color:red">Total value: %totalvalue% EUR</span><br>
Customer: %customer%<br><br>Best regards,<br><p>
Microsoft Logistics Security Team.</p><p><span style="font-style: italic;"><small><br></small></span></p><p><span style="font-style: italic;"><small>*
The content of this communication is classified as Microsoft 
Confidential and Proprietary Information. If you believe that you 
received a misaddressed e-mail, please return it to sender, notifying 
him/her of this. The content of this communication is intended solely 
for the use of the individual or entity to whom it is addressed and 
others authorized to receive it. The message or attachments may be 
subject to professional confidentiality, personal data protection, 
copyright or other legal disclosure restrictions. Microsoft does not 
guarantee that the integrity of this communication has been maintained, 
nor that this communication is free of viruses, interceptions or 
interference. We appreciate your assistance in preserving the 
confidentiality of our correspondence. Thank you.</small></span></p><p><span style="font-style: italic;"><br><small>* Read the privacy policy here.</small></span></p><br><br>
',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:23',
			),
			23 => 
			array (
				'id' => 24,
				'name' => 'incident_email_subject_review_request',
				'value' => 'Microsoft Logistic Security Tool - Incident - Request for Review',
				'created_at' => '2014-08-01 12:09:35',
				'updated_at' => '2014-10-14 08:21:24',
			),
			24 => 
			array (
				'id' => 25,
				'name' => 'audit_email_body_review_request',
				'value' => '<div>


<div>
Dear User,<br><br>This is a notification e-mail from Microsoft Logistic Security Tool.<br>
<br>
A Microsoft administrator has requested a review of the audit: %audit-url%.<br>
Please go to the above URL and submit the necessary details.<br>
<br>
Best regards,<br>
Microsoft Logistics Security Team<br><br><p><span style="font-style: italic;"><small>* The content of this 
communication is classified as Microsoft Confidential and Proprietary 
Information. If you believe that you received a misaddressed e-mail, 
please return it to sender, notifying him/her of this. The content of 
this communication is intended solely for the use of the individual or 
entity to whom it is addressed and others authorized to receive it. The 
message or attachments may be subject to professional confidentiality, 
personal data protection, copyright or other legal disclosure 
restrictions. Microsoft does not guarantee that the integrity of this 
communication has been maintained, nor that this communication is free 
of viruses, interceptions or interference. We appreciate your assistance
in preserving the confidentiality of our correspondence. Thank you.</small></span></p><p><span style="font-style: italic;"><br><small>* Read the privacy policy here.</small></span></p><br>
</div>
</div>',
				'created_at' => '2014-10-14 08:21:23',
				'updated_at' => '2014-10-14 08:21:23',
			),
			25 => 
			array (
				'id' => 26,
				'name' => 'incident_email_body_review_request',
				'value' => '<div>


<div>
Dear User,<br><br>This is a notification e-mail from Microsoft Logistic Security Tool.<br>
<br>A Microsoft administrator has requested a review of the incident: %incident-url%.<br>
Please go to the above URL and submit the necessary details.<br>
<br>
Best regards,<br>
Microsoft Logistics Security Team<br><br><p><span style="font-style: italic;"><small>* The content of this 
communication is classified as Microsoft Confidential and Proprietary 
Information. If you believe that you received a misaddressed e-mail, 
please return it to sender, notifying him/her of this. The content of 
this communication is intended solely for the use of the individual or 
entity to whom it is addressed and others authorized to receive it. The 
message or attachments may be subject to professional confidentiality, 
personal data protection, copyright or other legal disclosure 
restrictions. Microsoft does not guarantee that the integrity of this 
communication has been maintained, nor that this communication is free 
of viruses, interceptions or interference. We appreciate your assistance
in preserving the confidentiality of our correspondence. Thank you.</small></span></p><p><span style="font-style: italic;"><br><small>* Read the privacy policy here.</small></span></p><br>
</div>
</div>',
				'created_at' => '2014-10-14 08:21:24',
				'updated_at' => '2014-10-14 08:21:24',
			),
			26 => 
			array (
				'id' => 27,
				'name' => 'incident_email_subject_reminder',
				'value' => 'Microsoft Logistic Security Tool / Incident ID #%incident-id% / Reminder',
				'created_at' => '2014-10-14 08:21:24',
				'updated_at' => '2014-10-14 08:21:24',
			),
			27 => 
			array (
				'id' => 28,
				'name' => 'incident_email_body_reminder',
				'value' => '<p>Dear User,<br><br>This is an automatic email reminder from Microsoft Logistic Security Tool.</p><p>There have been 30 days since you have recorded the incident with ID = %incident-id%.<br><br>Some information is still missing or incomplete linked to the above mentioned incident event, therefore please log in to the Microsoft Logistic Security Tool website and fill the necessary information, at your earliest convenience.<br><br>Best regards,<br>
Microsoft Logistics Security Team<br></p><p><span style="font-style: italic;"><small>* The content of this 
communication is classified as Microsoft Confidential and Proprietary 
Information. If you believe that you received a misaddressed e-mail, 
please return it to sender, notifying him/her of this. The content of 
this communication is intended solely for the use of the individual or 
entity to whom it is addressed and others authorized to receive it. The 
message or attachments may be subject to professional confidentiality, 
personal data protection, copyright or other legal disclosure 
restrictions. Microsoft does not guarantee that the integrity of this 
communication has been maintained, nor that this communication is free 
of viruses, interceptions or interference. We appreciate your assistance
in preserving the confidentiality of our correspondence. Thank you.</small></span></p><p><span style="font-style: italic;"><br><small>* Read the privacy policy here.</small></span></p>',
				'created_at' => '2014-10-14 08:21:24',
				'updated_at' => '2014-10-14 08:21:24',
			),
		));
	}

}
