<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateRoutesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('routes', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('start_site');
			$table->string('start_address');
			$table->string('start_coordinates');
			$table->string('start_carrier');
			$table->string('end_site');
			$table->string('end_address');
			$table->string('end_coordinates');
			$table->string('end_carrier');
			$table->text('comment');
			$table->float('score');
			$table->string('ctpat_number');
			$table->string('aeo_number');
			$table->boolean('review')->default(0);
			$table->integer('tapa_needed')->default(0);
			$table->integer('auditor_id')->unsigned()->index();
			$table->foreign('auditor_id')->references('id')->on('users');
			$table->integer('start_country_id')->unsigned()->index();
			$table->foreign('start_country_id')->references('id')->on('countries');
			$table->integer('end_country_id')->unsigned()->index();
			$table->foreign('end_country_id')->references('id')->on('countries');
			$table->integer('lsp_id')->unsigned()->index();
			$table->foreign('lsp_id')->references('id')->on('lsps');
			$table->enum('status',array('active','inactive'));
			$table->timestamps();
			$table->softDeletes();

			$table->engine = 'InnoDB';
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('routes');
	}

}
