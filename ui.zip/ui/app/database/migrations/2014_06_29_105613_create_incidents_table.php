<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateIncidentsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('incidents', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('type')->default('other');
			$table->string('category');
			$table->text('short_description');
			$table->string('location_address');
			$table->string('location_city');
			$table->string('facility');
			$table->string('coordinates');
			$table->text('hawb');
			$table->text('mawb');
			$table->string('originating_facility');
			$table->string('destination_facility');
			$table->string('method_of_transportation');
			$table->string('consignee');
			$table->string('customer');
			$table->string('delivery_note_number');
			$table->string('cmr');
			$table->string('party_responsible');
			$table->string('reference_of_reporting_party');
			$table->string('location_of_reporter');
			$table->string('driver_name');
			$table->string('vehicle_details');
			$table->string('carriers_and_contractors');
			$table->string('routing');
			$table->string('airline');
			$table->text('first_findings');
			$table->timestamp('pick_up');
			$table->boolean('review_requested')->default(0);
			$table->text('review_comment');
			$table->timestamp('incident_date');
			$table->integer('country_id')->unsigned()->index();
			$table->foreign('country_id')->references('id')->on('countries');
			$table->integer('region_id')->unsigned()->index();
			$table->foreign('region_id')->references('id')->on('regions');
			$table->integer('user_id')->unsigned()->index();
			$table->foreign('user_id')->references('id')->on('users');
			$table->timestamp('closed_at')->nullable()->default(null);
			$table->timestamps();
			$table->softDeletes();

			$table->engine = 'InnoDB';
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('incidents');
	}

}
