<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateAttachmentsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('attachments', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('attachment_type');
			$table->string('file_name');
			$table->text('file_description');
			$table->string('file_type');
			$table->text('description');
			$table->integer('incident_id')->unsigned()->index();
			$table->foreign('incident_id')->references('id')->on('incidents')->onDelete('cascade');
			$table->softDeletes();
			$table->timestamps();

			$table->engine = 'InnoDB';
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('attachments');
	}

}
