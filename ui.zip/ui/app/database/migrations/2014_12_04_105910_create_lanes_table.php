<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateLanesTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('lanes', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('name');
			$table->integer('waypoints');
			$table->enum('end', ['yes','no']);
			$table->integer('user_id')->unsigned()->index();
			$table->integer('lsp_id')->unsigned()->index();
			$table->timestamp('updated_at');
			$table->foreign('lsp_id')->references('id')->on('lsps');
			$table->foreign('user_id')->references('id')->on('users');
			$table->softDeletes();
			
			$table->engine = 'InnoDB';
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('lanes');
	}

}
