<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateUsersTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('users', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('first_name');
			$table->string('last_name');
			$table->string('title');
			$table->string('email');
			$table->string('password');
			$table->string('role')->default('user');
			$table->boolean('first_login')->default(1);
			$table->boolean('terms_accepted')->default(0);
			$table->boolean('notification_audit_create')->default(0);
			$table->boolean('notification_audit_edit')->default(0);
			$table->boolean('access_lanes')->default(0);
			$table->boolean('access_audits')->default(0);
			$table->boolean('access_incidents')->default(0);
			$table->boolean('notification_major')->default(0);
			$table->boolean('notification_medium')->default(0);
			$table->boolean('notification_minor')->default(0);
			$table->boolean('notification_status')->default(0);
			$table->boolean('notification_edit')->default(0);
			$table->rememberToken();
			$table->string('dashboard');
			$table->integer('lsp_id')->unsigned()->index();
			$table->foreign('lsp_id')->references('id')->on('lsps');
			$table->timestamp('last_login_at')->nullable()->default(null);
			$table->timestamp('password_updated_at')->nullable()->default(null);
			$table->timestamps();
			$table->softDeletes();

			$table->engine = 'InnoDB';
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('users');
	}

}
