<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateRouteCertificationsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('route_certifications', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('certificate_file');
			$table->string('filename')->nullable()->default(null);			
			$table->integer('route_id')->unsigned()->index();
			$table->foreign('route_id')->references('id')->on('routes')->onDelete('cascade');
			$table->integer('certification_id')->unsigned()->index();
			$table->foreign('certification_id')->references('id')->on('certifications');
			$table->timestamps();

			$table->engine = 'InnoDB';
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('route_certifications');
	}

}
