<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateOfficialInvestigationsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('official_investigations', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('name_of_investigation_authority');
			$table->string('investigation_file_number');
			$table->text('final_investigation_findings');
			$table->text('contact_information');
			$table->string('root_cause_analysis');
			$table->string('long_term_corrective_actions');
			$table->integer('incident_id')->unsigned()->index();
			$table->foreign('incident_id')->references('id')->on('incidents')->onDelete('cascade');
			$table->softDeletes();
			$table->timestamps();

			$table->engine = 'InnoDB';
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('official_investigations');
	}

}
