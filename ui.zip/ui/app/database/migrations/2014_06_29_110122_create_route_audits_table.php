<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateRouteAuditsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('route_audits', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('answer_id');
			$table->text('comment');
			$table->boolean('is_archived')->default(0);
			$table->integer('route_id')->unsigned()->index();
			$table->foreign('route_id')->references('id')->on('routes')->onDelete('cascade');
			$table->integer('question_id')->unsigned()->index();
			$table->foreign('question_id')->references('id')->on('questions');
			$table->timestamps();

			$table->engine = 'InnoDB';
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('route_audits');
	}

}
