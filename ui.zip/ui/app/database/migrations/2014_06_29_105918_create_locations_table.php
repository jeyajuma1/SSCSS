<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateLocationsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('locations', function(Blueprint $table)
		{
			$table->increments('id');
			$table->string('site');
			$table->string('address');
			$table->string('coordinates');
			$table->text('comment');
			$table->float('value');
			$table->float('score');
			$table->string('ctpat_number');
			$table->string('aeo_number');
			$table->boolean('review')->default(0);
			$table->integer('tapa_needed')->default(0);
			$table->integer('auditor_id')->unsigned()->index();
			$table->foreign('auditor_id')->references('id')->on('users');
			$table->integer('country_id')->unsigned()->index();
			$table->foreign('country_id')->references('id')->on('countries');
			$table->integer('lsp_id')->unsigned()->index();
			$table->foreign('lsp_id')->references('id')->on('lsps');
			$table->enum('status',array('active','inactive'));
			$table->timestamps();
			$table->softDeletes();

			$table->engine = 'InnoDB';
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('locations');
	}

}
