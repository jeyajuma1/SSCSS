<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateProductsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('products', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('number_of_plts_missing');
			$table->string('number_of_units_missing');
			$table->string('product_description');
			$table->string('value_per_unit');
			$table->integer('currency');
			$table->decimal('total_value_of_lost_units', 12, 2);
			$table->string('status');
			$table->timestamp('pick_up_date');
			$table->integer('incident_id')->unsigned()->index();
			$table->foreign('incident_id')->references('id')->on('incidents')->onDelete('cascade');
			$table->softDeletes();
			$table->timestamps();

			$table->engine = 'InnoDB';
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('products');
	}

}
