<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;

class CreateLaneLocationsTable extends Migration {

	/**
	 * Run the migrations.
	 *
	 * @return void
	 */
	public function up()
	{
		Schema::create('lane_locations', function(Blueprint $table)
		{
			$table->increments('id');
			$table->integer('lane_id')->unsigned()->index();
			$table->foreign('lane_id')->references('id')->on('lanes')->onDelete('cascade');
			$table->integer('position');
			$table->string('transport');
			$table->integer('location_id')->unsigned()->index();
			$table->foreign('location_id')->references('id')->on('locations')->onDelete('cascade');
		    $table->softDeletes();
			
			$table->engine = 'InnoDB';
		});
	}


	/**
	 * Reverse the migrations.
	 *
	 * @return void
	 */
	public function down()
	{
		Schema::drop('lane_locations');
	}

}
