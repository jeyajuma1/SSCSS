<?php

// Register all custom validators
Validator::resolver(function($translator, $data, $rules, $messages)
{
    return new \MSLST\Helpers\Validator($translator, $data, $rules, $messages);
});
