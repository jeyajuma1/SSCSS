<?php

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;

class importScsIrt extends Command {

	/**
	 * The console command name.
	 *
	 * @var string
	 */
	protected $name = 'scsirt:import';

	/**
	 * The console command description.
	 *
	 * @var string
	 */
	protected $description = 'Imports the SCS Tool and SCS IRT databases into MSLST system.';

	/**
	 * Create a new command instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		parent::__construct();
	}

	/**
	 * Execute the console command.
	 *
	 * @return mixed
	 */
	public function fire()
	{
		$scsdb = DB::connection('scstool');
		$irtdb = DB::connection('scsirt');

		if (!$scsdb || !$irtdb)
		{
			$this->error("Please configure the connections 'scstool' and 'scsirt'.");
		}
		else
		{
			$this->printResult($this->importDB($scsdb, $irtdb));
		}
	}

    /**
     * Provide user feedback, based on success or not.
     *
     * @param  object $scsdb
     * @param  object $irtdb
     * @return boolean
     */
	protected function importDB($scsdb, $irtdb)
	{
		return true;
	}

    /**
     * Provide user feedback, based on success or not.
     *
     * @param  boolean $successful
     * @return void
     */
    protected function printResult($successful)
    {
        if ($successful)
        {
            return $this->info("Successfully imported the databases.");
        }

        $this->error("Could not import the databases.");
    }
}
