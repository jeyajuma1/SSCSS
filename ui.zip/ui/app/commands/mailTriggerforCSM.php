<?php

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use MSLST\Helpers\Emails as Emails;
 
class mailTriggerforCSM extends Command {


		/**
         * The console command name.
         *
         * @var string
         */
        protected $name = 'SndMail:trggerforcsm';

        /**
         * The console command description.
         *
         * @var string
         */
        protected $description = 'Triggering the send mail option Limit Cross 30 While creating/Updating the Incident/Audits';


        /**
         * Create a new command instance.
         *
         * @return void
         */
        public function __construct()
        {
                parent::__construct();
        }


        /**
         * Execute the console command.
         *
         * @return mixed
         */
        public function fire()
        {
        	$path =  storage_path().'/camailtrigger/csm/';
			$files1 = scandir($path,0);

			if(count($files1) >=3 ){ 
    			$content = File::get($path.$files1[2]);
	    		$mail_trig = json_decode($content,true);
                $type='csm';
    			Emails::sendNotification($mail_trig['body'],$mail_trig,$type);
    		
                echo "Mail Trigger Successfully";
                file::delete($path.$files1[2]);
            }else{

            }
        }

       

}

?>