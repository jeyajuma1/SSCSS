<?php

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;
use Symfony\Component\Console\Input\InputArgument;
use MSLST\Helpers\Emails as Emails;
 
class createNotification extends Command {


		/**
         * The console command name.
         *
         * @var string
         */
        protected $name = 'SndMail:filecreatetrgger';

        /**
         * The console command description.
         *
         * @var string
         */
       // protected $description = 'Triggering for creating files the send mail option Limit Cross 30 While creating/Updating the Incident/Audits';


        /**
         * Create a new command instance.
         *
         * @return void
         */
        public function __construct()
        {
                parent::__construct();
        }


        /**
         * Execute the console command.
         *
         * @return mixed
         */
        public function fire()
        {
        	
    			Emails::createNotification();
    		
               
        }

       

}

?>