<?php

class RegionsController extends \BaseController {

    /**
     * Instantiate a new RegionsController instance.
     */
	public function __construct()
	{
		$this->beforeFilter(function ($route){
			if (!Auth::user()->isAdmin())
			{
				App::abort(404);
			}
		});
	}

	/**
	 * Display a listing of the resource.
	 * GET /regions
	 *
	 * @return Response
	 */
	public function index()
	{
		$regions = Region::all();

		return View::make('regions.index')
				->with('regions', $regions);
	}

	/**
	 * Show the form for creating a new resource.
	 * GET /regions/create
	 *
	 * @return Response
	 */
	public function create()
	{
		return View::make('regions.create');
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /regions
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make(Input::all(), Region::$rules);

		if ($validator->passes())
		{
		    $region = Region::create([
				'name' => Input::get('name'),
		    ]);

			return Redirect::route('regions.index')
					->with('success', 'Region created Successfully.');
		}
		else
		{
			return Redirect::back()
				    ->withInput()
				    ->withErrors($validator->messages());
		}
	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /regions/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$region = Region::findOrFail($id);

		return View::make('regions.edit')
				->with('region', $region);
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /regions/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$rules = Region::$rules;
		$rules['name'] .= ','. $id;
		$validator = Validator::make(Input::all(), $rules);

		if ($validator->passes())
		{
			$region = Region::findOrFail($id);
			$region->name = Input::get('name');
			$region->save();

			return Redirect::route('regions.index')
					->with('success', 'Region updated Successfully.');
		}
		else
		{
			return Redirect::back()
				    ->withInput()
				    ->withErrors($validator->messages());
		}
	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /regions/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$region = Region::findOrFail($id);
		$region->delete();

		return Redirect::route('regions.index')
				->with('success', 'Region deleted Successfully.');
	}

}