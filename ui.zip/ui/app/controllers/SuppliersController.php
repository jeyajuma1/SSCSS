<?php
use MSLST\Helpers\Lists;
use MSLST\Helpers\Suppliers;
use MSLST\Helpers\Coordinate;
use MSLST\Helpers\Common;
use MSLST\Helpers\Emails;
class SuppliersController extends \BaseController {



	/**
	 * Instanite for Suppliercontroller Instance
	 *
	 **/
	public function __construct()
	{
		App::abort(403);
		if (!Auth::User()->access_suppliers == 1) App::abort(403);
	}


	/**
	  *
      * Leak Risk Attachment path
	**/

	public static $leak_attachment_path = 'files/suppliers/leak_risk';

	/**
	 * Display a listing of the Suppliers.
	 * GET /Suppliers
	 *
	 * @return Response
	 */
	public function index()
	{
		if (!Auth::User()->isAdmin() && !Auth::User()->access_suppliers) App::abort(403);

		$usrregion =  [];
		if (!Auth::User()->isAdmin() && !Auth::User()->isManager()) {
			 $usrregion = Lists::getUserRegion(Auth::User()->id);
		}
		
		$vendor_name = Suppliers::getVendornameList();
		$category = Suppliers::getCategoryList();
		$users = Lists::getAuditorsList();
		$regions = Lists::getRegionsList($usrregion);
		$countries = Lists::getCountriesList();
		$RequestData = Input::all();
		
		$suppliers = Suppliers::getFilteredSuppliers($RequestData);
		if(!empty($RequestData['region'])){
			$regions_country[]  =  $RequestData['region'];
			$countries =  Lists::getCountriesList($regions_country[0]);
		}


	return View::make('suppliers.index')
				->with('users', $users)
				->with('vendor_name', $vendor_name)
				->with('category', $category)
				->with('regions', $regions)
				->with('countries', $countries)
				->with('suppliers', $suppliers);		   
	}
	
	public function create($step = 0) {
		if (!Auth::User()->isAdmin() && !Auth::User()->access_suppliers) App::abort(403);
			
		switch(intval($step))
		{
			case 0:
				$data = Suppliers::getSupplierStepData('basic_information');
				return self::basic_information_form($data);
			case 1:
				$data = Suppliers::getSupplierStepData('supplier_information');
				return self::supplier_information_form($data);
			case 2:
				$data = Suppliers::getSupplierStepData('supplier_contact_details');
				return self::supplier_contact_details_form($data);
			case 3:
				$data = Session::get('suppliers');
				return self::summary_list($data);
		}
	}
	
	public static function basic_information_form($data, $edit = false) {

		$usrregion = UserRegion::select('region_id')
							   ->where('user_id',\Auth::user()->id)
				  			   ->Lists('region_id');
							   
		if(\Auth::User()->isAdmin())	$usrregion = '';
		  
		$regions = Lists::getRegionsList($usrregion);
		$regions_json = json_encode(Lists::getRegionCountriesList($usrregion));

		return View::make('suppliers.basic_information')
				->with('regions', $regions)
				->with('countries', [])
				->with('regions_json', $regions_json)
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show supplier Information .
	 *
	 * @return Response
	 */
	public static function supplier_information_form($data, $edit = false)
	{
		return View::make('suppliers.supplier_information')
				->with('edit', $edit)
				->with('data', $data);
	}
	public static function supplier_contact_details_form($data, $edit = false)
	{
		return View::make('suppliers.supplier_contact_details')
				->with('edit', $edit)
				->with('data', $data);
	}
	public static function summary_list($data)
	{
		$country  = Lists::getCountriesname($data['basic_information']->country);
		$region = Lists::getRegionsname($data['basic_information']->region);
		$coordinates = Coordinate::convertToWGS84($data['basic_information']->coordinates);
		return View::make('suppliers.summary')
					->with('country',$country)
					->with('region',$region)
					->with('coordinates', $coordinates)
					->with('data',$data);
	}

	public function show($id)
	{	
		$supplier = Supplier::with(['region','user','country','supplier_log'])->findOrFail($id);
		$leak_risk_analysis = LeakRiskAnalysis::with('supplier','business_activity')->select('id','supplier_id','activity_id','asset_id')->where('supplier_id',$id)->get()->all();
		$leak_prevention = LeakPreventionAssessment::with(['supplier','leak_risk_analysis','business_risk','user'])
												   ->select('id','supplier_id','leak_id','risk_id','risk','action_name','action_description','status','status_date','file_name','file_description','verified_by','verified_status','verified_date','inc_id','sort')
												   ->where('supplier_id',$id)
												   ->orderBy('sort')
												   ->get();
		$business_activity = BusinessActivity::select('id','name')->lists('name','id');
		$business_assets = Lists::getBusinessAssets($business_activity);
		$business_risk = Lists::getBusinessRisk($business_assets['assetsId']);
		$business_actions = Lists::getBusinessAction($business_risk['riskId']);
		$leak_incident_history = LeakIncidentHistory::where('supplier_id',$id)->orderBy('created_at')->get();

		$questions=BusinessQuestion::with('categories')->get();$data=Lists::getBusinessQuestionsList($id);
		$questions['activities_id']=$data['activities_id'];
		
		$activities=Lists::getActivitiesList();
		$assessment_data =[];
		foreach($activities as $activity_key => $activity_value){
            if(in_array($activity_key,$questions['activities_id']))
            {
            	$assessment_data[$activity_key]=BusinessAnswer::select('self_answer_id','self_comment','onsite_answer_id','onsite_comment','supplier_id'
            		,'question_id','ms_id','activity_id')->where(['supplier_id'=>$id,'activity_id'=>$activity_key])->get();
            }

        }
        $assessment_status='None';
		$assessment_score='0%';
		if($supplier['self_assessment_score'] != 0)
		{
			$assessment_status = 'SA only';
			$assessment_score = ceil($supplier['self_assessment_score']).'%';
		}
		if($supplier['onsite_assessment_score'] != 0)
		{	if($supplier['self_assessment_score']  != 0)
			{
				$assessment_status ='SA'.' + '.'OSA';
				$assessment_score.=' + '.ceil($supplier['onsite_assessment_score']).'%';
				
			}
			else{
			$assessment_status = 'OSA only';
			$assessment_score = ceil($supplier['onsite_assessment_score']).'%';
			}
		}
		
		//print "<pre>";print_r($leak_prevention);exit;

		$supplier->assessment_status=$assessment_status;
		$supplier->assessment_score=$assessment_score;
		$categories=Lists::getCategoryList();
		$answers = Lists::getAnswersList();
		$coordinates = Coordinate::convertToWGS84($supplier->coordinates);

		return View::make('suppliers.show')
					->with('leak_risk_analysis',$leak_risk_analysis)
					->with('business_assets',$business_assets)
					->with('business_risk',$business_risk)
					->with('business_actions',$business_actions)
					->with('coordinates', $coordinates)
					->with('supplier',$supplier)
					->with('assessment_data',$assessment_data)
					->with('activities',$activities)
					->with('leak_prevention',$leak_prevention)
					->with('business_activities',$business_activity)
					->with('categories',$categories)
					->with('answers', $answers)
					->with('questions',$questions)
					->with('leak_incident_history',$leak_incident_history);
			
	}

	public function edit($id, $step = 0)
	{
		if (!Auth::User()->access_suppliers) App::abort(403);

		switch(intval($step))
		{
			case 0:
				$data = Suppliers::getSupplierEditData($id, 'basic_information');
				return self::basic_information_form($data, true);
			case 1:
				$data = Suppliers::getSupplierEditData($id, 'supplier_information');
				return self::supplier_information_form($data, true);
			case 2:
				$data = Suppliers::getSupplierEditData($id, 'supplier_contact_details');
				return self::supplier_contact_details_form($data, true);
			
		}
		
	}


	public function update($id)
	{
		if (!Common::canAccessEdit($id, 'supplier')) App::abort(403);


		switch(intval(Input::get('step')))
		{
			case 0:
				$validator = Validator::make(Input::all(), Supplier::$suppliers_basic_info_rules, Supplier::$messages);
				$step = 'basic_information';
				break;
			case 1:
				$validator = Validator::make(Input::all(), Supplier::$suppliers_information_rules, Supplier::$messages);
				$step = 'supplier_information';
				break;
			case 2:
				$validator = Validator::make(Input::all(), Supplier::$suppliers_contact_details_rules, Supplier::$messages);
				$step = 'supplier_contact_details';
				break;
			
		}
		if(!empty($validator))
		{
			if ($validator->passes())
			{
				$array = Input::all();
				if(!Input::has('supplier_handle') && intval(Input::get('step')) == 1) {
			    	$array['supplier_handle'] = 0;
			    	Input::get('supplier_handle',0);
			    }
				Suppliers::setSupplierEditData($id,$step,$array);
				return Redirect::route('suppliers.show', $id)
						->with('success', 'Supplier updated successfully.');
			}
			else
			{
				return Redirect::back()
						->withInput()
						->withErrors($validator->messages());

			}
		}
		else
		{
			Suppliers::setSupplierEditData($id,$step, Input::all());
					return Redirect::route('suppliers.show', $id)
							->with('success', 'Supplier updated successfully.');
		}
		
	}

	
	public function assessment($id)
	{
		$supplier = Supplier::with(['region','user','country'])->findOrFail($id);


		$assessment_type='none';
		if(strstr(Request::Server('REQUEST_URI'),'self') && $supplier->user_id == Auth::User()->id)
			$assessment_type='self';
		if(strstr(Request::Server('REQUEST_URI'),'onsite') && Auth::user()->isManager())
			$assessment_type='onsite';
		
		$categories=Lists::getCategoryList();
		$activities=Lists::getActivitiesList();
		$questions=Lists::getBusinessQuestionsList($id);
		$answers = ['' => ''] + Lists::getAnswersList();
		$assessment_data =[];
		foreach($activities as $activity_key => $activity_value){
            if(in_array($activity_key,$questions['activities_id']))
            {
            	$assessment_data[$activity_key]=Suppliers::get_assessment_data($id,$activity_key);
            }

        }
                     
       return View::make('suppliers.assessment')
							->with('supplier',$supplier)
							->with('categories',$categories)
							->with('assessment_type',$assessment_type)
							->with('assessment_data',$assessment_data)
							->with('activities',$activities)
							->with('answers', $answers)
							->with('questions',$questions);
				
	}
	
	/**
	 * Store information
	 *
	 **/ 
	public function store() {
		if (!Auth::User()->isAdmin() && ! Auth::User()->access_suppliers) App::abort(403);

		switch(intval(Input::get('step')))
		{
			case 0:
				$validator = Validator::make(Input::all(), Supplier::$suppliers_basic_info_rules ,Supplier::$messages);
				$step = 'basic_information';
				$next = 'suppliers/create/1';
				break;
			case 1:
				$validator = Validator::make(Input::all(), Supplier::$suppliers_information_rules, Supplier::$messages);				$step = 'supplier_information';
				$next = 'suppliers/create/2';
				break;
			case 2:
				$validator =Validator::make(Input::all(), Supplier::$suppliers_contact_details_rules,Supplier::$messages);
				$step = 'supplier_contact_details';
				$next = 'suppliers/create/3';
				break;
			case 3:
				Suppliers::saveSupplierData();
				return Redirect::to('suppliers')
								->with('success', "Supplier created successfully.");
		}
		if(!empty($validator))
		{
			if ($validator->passes())
			{	
				$array = Input::all();
			    if(!Input::has('supplier_handle') && intval(Input::get('step')) == 1) {
			    	$array['supplier_handle'] = 0;
			    	Input::get('supplier_handle',0);
			    }
			    
				$data = Suppliers::setSupplierStepData($step, $array);
				return Redirect::to($next);
			}
			else
			{
				return Redirect::back()
						->withInput()
						->withErrors($validator->messages());
			}
		}
		else
		{
			$data = Suppliers::setSupplierStepData($step, Input::all());
				return Redirect::to($next);
		}
		
	}


	/**
	 * @params
	 *
	 * @ return $results
	 **/

	public function Leak_Risk_Analysis($id = null){
		$data = Input::all();
		$params = [];


		switch ($data['option']) {
					case  'add':
							$params = self::arrangeArrayLeakPrevention($data,'leak');
							$params['supplier_id'] = $data['sid'];
							$params['sort'] = 2;
							LeakPreventionAssessment::create($params);
					    break;
					case 'edit':
							/*if(\Auth::user()->isManager() && !empty($data['verified'])) {
								$params['verified_by'] =  Auth::user()->id;
								$params['verified_status'] =  $data['verified'];
	      						$params['verified_date'] = new \Carbon\Carbon;
	      					}else if(\Auth::user()->id == $data['user_id']) {
								$params['risk'] =  $data['risk'];
								$params['action'] =  $data['action'];
								$params['status'] =  $data['status'];
								$params['status_date'] =  new \Carbon\Carbon;
	      					}*/

	      				 $params = self::arrangeArrayLeakPrevention($data,'leak');
						 LeakPreventionAssessment::where('id',$data['id'])->update($params);	
						break;
					case 'exist_analysis':

						$id = $data['ids'];
						$exist = json_decode($data['risk_analys_exist']);
						$new = json_decode($data['risk_analys_new']);

						/*Updating existing Risk*/
						if(!empty((array)$exist )) { 
						    
						    $undelete_id = [];
						 	$exist_arry = [];

						 	foreach ($exist as $rk => $rv) {
						 		    LeakRiskAnalysis::where('supplier_id',$id)
						 		    				->where('id',$rk)
						 		    				->update([
						 		    						   'activity_id' => $rv->busines,
															   'asset_id' => json_encode($rv->assets)
														    ]);
						 		    $exist_arry['asset_id'][] = $rv->assets;
									$exist_arry['activity_id'][] = $rv->busines;
									$exist_arry['LeakRiskAnalysis_id'][] = $rk;

						 		    $undelete_id[] =  $rk;
						 	}
						 	$exist_arry['supplier_id'] = $data['ids'];


						 	/*Delete Leak Risk id from undeleted id */
						 	if(!empty($undelete_id)){
						 		LeakRiskAnalysis::whereNotIn('id',$undelete_id)
						 						->where('supplier_id',$id)
						 						->delete();

						 		LeakPreventionAssessment::whereNotIn('leak_id',$undelete_id)
						 						->where('supplier_id',$id)
						 						->delete();
						 	}
							
							Suppliers::SaveActionPlan($exist_arry,'exist');
						}

 
						/* Creating New Leak Risk */
						if(!empty((array)$new)) {  
 
							 $arry = [];

							 foreach($new as $rk=>$rv){
									  	$risk = LeakRiskAnalysis::create([
									  	 						 'supplier_id' => $id,
									  	 						 'activity_id' => $rv->busines,
																 'asset_id' => json_encode($rv->assets)
																 ]);
									  	$arry['asset_id'][] = $rv->assets;
									  	$arry['activity_id'][] = $rv->busines;
									  	$arry['LeakRiskAnalysis_id'][] = $risk->id;
						     }

						     $arry['supplier_id'] = $data['ids'];
						   
						     Suppliers::SaveActionPlan($arry,'new');
						 }

						 break;
					case 'delete_all':
							LeakRiskAnalysis::where('supplier_id',$data['id'])->delete(); // Soft delete the old create id
							LeakPreventionAssessment::where('supplier_id',$data['id'])->whereNotNull('leak_id')->delete(); // Soft delete the old create id
							//BusinessAnswer::where('supplier_id',$data['id'])->delete();
						 break;
					case 'delete':
 							LeakPreventionAssessment::where('supplier_id',$data['supplier_id'])->where('id',$data['leak_id'])->delete();
 		 				 break;
					default:
						 
						break;
		}		
		 
		/*for($i=1; $i<count($bus);$i++){
			$params['data'][] = [$bus[$i],$Asset[$i],'Not Started','-','-','-','-','-'];
			 
	     }
		$path =   public_path().'/js/leak_risk_analysis/'.$data['id'].'.txt';
		$params['className'][] = 'clickable-row risk_mitigation_manual';
		$content = json_encode($params);
		\File::put($path,$content);
		return $path;*/
		//print "<pre>"; print_r($business_id);   exit;

	}

	/**
	 * @params
	 *
	 * @ return $results
	 **/

	public static function arrangeArrayLeakPrevention($data,$type=null){
		$params = [];
		 
		switch($type){
			case 'leak':
						if(\Auth::user()->isManager() && !empty($data['verified'])) {
												$params['verified_by'] =  Auth::user()->id;
												$params['verified_status'] =  $data['verified'];
					      						$params['verified_date'] = new \Carbon\Carbon;
					    }

					    if(\Auth::user()->id == $data['user_id']) {
					    			if($data['addtype'] == 'new'){
												$params['risk'] =  $data['risk'];
												$params['action_name'] =  $data['action'];
												$params['action_description'] =  $data['action_description'];
									}
												$params['status'] =  $data['status'];
												$params['status_date'] =  new \Carbon\Carbon;
					    }

					    if(Input::hasFile('file')){
					    	$file  		  =	$data['file'];
					    	$Originalname = $file->getClientOriginalName();
					    	$newname 	  = sha1(time().openssl_random_pseudo_bytes(10));
					    	$mimetype     = $file->getMimeType();
					    	$path 		  = storage_path().'/'.self::$leak_attachment_path;
					    	$file->move($path,$newname);

							$params['file_name'] =  $path.'/'.$newname;
							$params['file_description'] = $Originalname;
							$params['file_type'] =  $mimetype;
							 
					    }

						break;
			case 'incident':
						//if($data['addtype'] != 'predefined'){
			 			   $params['risk']                = $data['title'];
						   $params['action_name']         = $data['corrective_action_title'];
					 	   $params['action_description']  = $data['corrective_action_description'];
					 	//}
						  // $params['inc_id']      = $data['sid'];
						break;
		 }

	    return $params;
	}


	/**
	 *
	 * @params
	 *
	 * @return $results
	**/
	public function leak_incident_history(){

		$data = Input::all();
		$params = [];

		//print "<pre>"; print_r($data);exit;

		switch ($data['option']) {
			case 'add': 
					/*Insert in leak History */	
				    $leak_inc = LeakIncidentHistory::create([
				    			'supplier_id'=> $data['sid'],
								'title' => $data['title'],
								'incident_date' => new \Carbon\Carbon($data['incident_date']),
								'incident_type'=> $data['type'],
								'root_cause' => $data['root_cause'],
								'corrective_action_title' => $data['corrective_action_title'],
								'corrective_action_description' => $data['corrective_action_description'],
								'supplier_contact' => $data['supplier_contact'],
								'deadline_date' => new \Carbon\Carbon($data['deadline_date']),
								]); 
					/*Insert in leak Prevention Assement*/			
				    $params['risk']   = $data['title'];
				    $params['action_name'] = $data['corrective_action_title'];
				    $params['action_description'] = $data['corrective_action_description'];
				    $params['supplier_id'] = $data['sid'];
				    $params['status'] = 'Not Started';
				    $params['sort'] = 3;
				    $params['inc_id'] = $leak_inc->id;
				    LeakPreventionAssessment::create($params);
				break;
			case 'edit': 

						 $params_history = self::arrangeArrayLeakIncident($data);

						 LeakIncidentHistory::where('id',$data['sid'])->update($params_history);

						 $params_leak = self::arrangeArrayLeakPrevention($data,'incident');

						 LeakPreventionAssessment::where('inc_id',$data['sid'])->update($params_leak);
						  
			    break;
			    case 'delete':	

 					if($data['inc']['login_user_id'] == $data['inc']['supplier_user_id']){
	
							LeakIncidentHistory::where('id',$data['inc']['incident_id'])->where('supplier_id',$data['inc']['supplier_id'])->delete();
				 
				 			LeakPreventionAssessment::where('inc_id',$data['inc']['incident_id'])->where('supplier_id',$data['inc']['supplier_id'])->delete();
				 	
 		 					return 'done';
 		 			}else{
 	
 		 					return 'false';
 	
 		 			}
		  		 break;

			default:
					# code...
				break;
		}
	}

	/**
	 * @params
	 *
	 * @ return $results
	 **/

	public static function arrangeArrayLeakIncident($data){
		$params = [];


			    if(\Auth::user()->id == $data['user_id']) {
								$params['title'] =  $data['title'];
								$params['incident_date'] = new \Carbon\Carbon($data['incident_date']);
	      						$params['incident_type'] = $data['type'];
	     						$params['root_cause'] =  $data['root_cause'];
								$params['corrective_action_title'] =  $data['corrective_action_title'];
								$params['corrective_action_description'] =  $data['corrective_action_description'];
								$params['supplier_contact'] =  $data['supplier_contact'];
								$params['deadline_date'] =  new \Carbon\Carbon($data['deadline_date']);
	    		}
 
 

	    return $params;
	}

	/**
	 * @params post
	 *
	 **/
	static public function leakPreventionStatus(){
		$data = Input::all();
		if(!empty($data['sid']) && !empty($data['sumary'])){
			$params['leak_prevention_summary'] = $data['sumary'];
			Supplier::where('id',$data['sid'])->update($params);
		}
	}


	/**
	 * Download the audit attachment.
	 * GET /audits/download
	 *
	 * @return Response
	 */
	public function getDownload($fid, $id, $type)
	{
		return Common::downloadFile($fid, $id, $type);
	}

	/*
	*
	*Storing Self-Assessment Data
	*/
	public static function self_assessment_store($id)
	{ 
		$answers = array_keys(Lists::getAnswersList());
		$data = Suppliers::setselfassessment($id,Input::all());
		return Redirect::route('suppliers.show', $id)
				->with('success', 'Supplier Self-Assessment updated successfully.');
	}

	/*
	*
	*Storing Onsite-Assessment Data
	*/
	public static function onsite_assessment_store($id)
	{ 
		$answers = array_keys(Lists::getAnswersList());
		$ms_id=Auth::User()->id;
		$data = Suppliers::setonsiteassessment($id,Input::all(),$ms_id);
		return Redirect::route('suppliers.show', $id)
				->with('success', 'Supplier Onsite-Assessment updated successfully.');
	}

	/**
	*Toggle review status of the specified resource.
	* PATCH /suppliers/status/{id}
	*
	**/
	public function status($id,$option='inactive')
	{
		//echo $id."$$".$option; 
	
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager() && !Auth::User()->isUser() && !Auth::User()->isSupervisor()) App::abort(403);
	
		$supplier = Supplier::findOrFail($id);

		$supplier->status = $option;

		$supplier->save();

		 return Redirect::route('suppliers.show', [$id])
				->with('success', 'Supplier status changed to <b>'.ucfirst($option).'</b>.');

	}


}