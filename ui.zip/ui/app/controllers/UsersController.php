<?php

use MSLST\Constants\Site;
use MSLST\Helpers\Lists;
use MSLST\Helpers\Emails;
use MSLST\Helpers\Users;
use MSLST\Helpers\Suppliers;

class UsersController extends \BaseController {

    /**
     * Instantiate a new UsersController instance.
     */
	public function __construct()
	{
		$this->beforeFilter(function ($route){
			if (!Auth::User()->isAdmin() 
				&& !Auth::User()->isSupervisor() 
				&& !Auth::User()->isManager())
			{
				App::abort(403);
			}
		});
	}

	/**
	 * Display a listing of the resource.
	 * GET /users
	 *
	 * @return Response
	 */
	public function index()
	{
		$RequestData = Input::all();
		$users = Users::getFilteredUsers($RequestData);
		$username = Lists::getAuditorsList();
		$lspname = Lists::getLspsList();
		// 
		return View::make('users.index')
				->with('users', $users)
				->with('lspname', $lspname)
				->with('username', $username);
	}

	/**
	 * Show the form for creating a new resource.
	 * GET /users/create
	 *
	 * @return Response
	 */
	public function create()
	{
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager()) App::abort(403);

		$regions = Lists::getRegionsList();
		$lsps = Lists::getLspsList();

		$sm_id = Sitemaster::select('id',\DB::raw("concat(site_name,' [#',id,']') as site_name"))->lists('site_name','id'); // Site Master name with ID


		return View::make('users.create')
				->with('user_roles', ['' => ''] + Site::$USER_ROLES)
				->with('regions', $regions)
				->with('lsps', ['' => ''] + $lsps)
				->with('sm_id',$sm_id);
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /users
	 *
	 * @return Response
	 */
	public function store()
	{
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager()) App::abort(403);

		$validator = Validator::make(Input::all(), User::$rules);
		
		$validator->sometimes('lsp', 'required', function($input){
			return ($input->role != 'admin');	
		});
		
		$validator->sometimes('region', 'required', function($input){
			return ($input->role != 'admin');	
		});

		if ($validator->passes())
		{
			$get = Input::get();

			if($get['user_level'] == 'csm' || $get['user_level'] =='protection_pm'){
				$get['site_master_id'] = [];
			}
			 
		 
		    $user = User::create([
				'first_name' => Input::get('first_name'),
				'last_name' => Input::get('last_name'),
				'email' => Input::get('email'),
				'title' => htmlentities(Input::get('title')),
				'role' => Input::get('role'),
				'site_user_level' => Input::get('user_level'),
				'notification_audit_create' => $this->getProfilevalue($get,'notification_audit_create'),
				'notification_audit_edit' => $this->getProfilevalue($get,'notification_audit_edit'),
				'access_suppliers' =>  $this->getProfilevalue($get,'access_suppliers'),
				'access_sitemasters' =>  $this->getProfilevalue($get,'access_sitemasters'),
				'access_lanes' => $this->getProfilevalue($get,'access_lanes'),
				'access_audits' => $this->getProfilevalue($get,'access_audits'), 
				'access_incidents' => $this->getProfilevalue($get,'access_incidents'),
				'access_factory_incidents' => $this->getProfilevalue($get,'access_factory_incidents'),
				'access_factory_incidents' => $this->getProfilevalue($get,'access_leak_prevention'),
				'access_p_r' => $this->getProfilevalue($get,'access_p_r'),
				'notification_major' => $this->getProfilevalue($get,'notification_major'),
				'notification_medium' => $this->getProfilevalue($get,'notification_medium'),
				'notification_minor' => $this->getProfilevalue($get,'notification_minor'),
				'notification_status' => $this->getProfilevalue($get,'notification_status'), 
				'notification_edit' => $this->getProfilevalue($get,'notification_edit'),
				'notification_factory_create' => $this->getProfilevalue($get,'notification_factory_create'),
			    'notification_factory_edit' => $this->getProfilevalue($get,'notification_factory_edit'),
				'lsp_id' => Input::get('role') != 'admin' ? intval(Input::get('lsp')) : Site::HIGHEST_LEVEL_COMPANY,
				'user_vam_site_id' =>  (isset($get['site_master_id']))  ? json_encode($get['site_master_id']) : '',
		    ]);
 
			if (Input::get('region'))
			{
				$user->regions()->attach(Input::get('region'));
			}

			// Get the settings
			$subject = \Setting::where('name', 'account_email_subject_user_create')->first()->value;
			$body = \Setting::where('name', 'account_email_body_user_create')->first()->value;

		    View::composer('emails.layout', function($view) use ($body) {
		        $view->with([
		            'body'  => $body,
		        ]);
		    });

			// Send the new account mail with the password reset link.
			Password::remind(Input::only('email'), function($message) use ($subject) {
				$message->subject($subject);
			});

			return Redirect::route('users.index')
					->with('success', 'User added successfully.');
		}
		else
		{
			return Redirect::back()
				    ->withInput()
				    ->withErrors($validator->messages());
		}
	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /users/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		if (!\Auth::User()->isAdmin() ) App::abort(403);

		$regions = Lists::getRegionsList();
		$lsps = Lists::getLspsList();
		$sm_id = Sitemaster::select('id',\DB::raw("concat(site_name,' [#',id,']') as site_name"))->lists('site_name','id'); // Site Master name with ID

		$user = User::withTrashed()->findOrFail($id);
		//print "<pre>"; print_r($sm_id); exit;
		return View::make('users.edit')
				->with('user_roles', ['' => ''] + Site::$USER_ROLES)
				->with('regions', $regions)
				->with('lsps', ['' => ''] + $lsps)
				->with('user', $user)
				->with('sm_id',$sm_id);
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /users/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager()) App::abort(403);

		$rules = User::$rules;
		$rules['email'] .= ','. $id;
		$validator = Validator::make(Input::all(), $rules);
		
		$validator->sometimes('lsp', 'required', function($input){
			return ($input->role != 'admin');	
		});
		
		$validator->sometimes('region', 'required', function($input){
			return ($input->role != 'admin');	
		});


		if ($validator->passes())
		{
			if(Input::get('role') == 'admin'){
				Input::merge(['lsp'=>Site::HIGHEST_LEVEL_COMPANY,'user_level'=>'none','region'=>'']);
			}

			$get = Input::get();

			if($get['user_level'] == 'csm' || $get['user_level'] =='protection_pm'){
				$get['site_master_id'] = [];
			}

  			$user = User::withTrashed()->findOrFail($id);
			$user->first_name = Input::get('first_name');
			$user->last_name = Input::get('last_name');
			$user->email = Input::get('email');
			$user->title = htmlentities(Input::get('title'));
			$user->role = Input::get('role');
			$user->site_user_level  =  (Input::get('lsp') == Site::HIGHEST_LEVEL_COMPANY) ? Input::get('user_level') : 'none';
			$user->notification_audit_create = $this->getProfilevalue($get,'notification_audit_create');
			$user->notification_audit_edit =  $this->getProfilevalue($get,'notification_audit_edit');
			$user->access_suppliers =  $this->getProfilevalue($get,'access_suppliers');
			$user->access_sitemasters = $this->getProfilevalue($get,'access_sitemasters');
			$user->access_lanes =  $this->getProfilevalue($get,'access_lanes'); 
			$user->access_audits =  $this->getProfilevalue($get,'access_audits'); 
			$user->access_incidents =  $this->getProfilevalue($get,'access_incidents'); 
			$user->access_factory_incidents =  $this->getProfilevalue($get,'access_factory_incidents'); 
			$user->access_leak_prevention = $this->getProfilevalue($get,'access_leak_prevention');
			$user->access_p_r = $this->getProfilevalue($get,'access_p_r'); ;
			$user->notification_major =  $this->getProfilevalue($get,'notification_major'); 
			$user->notification_medium =  $this->getProfilevalue($get,'notification_medium'); 
			$user->notification_minor =  $this->getProfilevalue($get,'notification_minor'); 
			$user->notification_status =  $this->getProfilevalue($get,'notification_status'); 
			$user->notification_edit =  $this->getProfilevalue($get,'notification_edit'); 
			$user->notification_factory_create =  $this->getProfilevalue($get,'notification_factory_create');
			$user->notification_factory_edit =  $this->getProfilevalue($get,'notification_factory_edit');
			$user->lsp_id = Input::get('role') != 'admin' ? intval(Input::get('lsp')) : Site::HIGHEST_LEVEL_COMPANY;
			$user->user_vam_site_id = (isset($get['site_master_id']))  ? json_encode($get['site_master_id']) : '';
			$user->updated_at = new \Carbon\Carbon();
			$user->save();
			
			if($user->role != 'admin') $user->regions()->sync(Input::get('region'));


			return Redirect::route('users.index')
					->with('success', 'User updated successfully.');
		}
		else
		{
			return Redirect::back()
				    ->withInput()
				    ->withErrors($validator->messages());
		}
	}


	/**
	 * Fetch the specified resource from Input.
	 *
	 * @param  array  $array , string  $field
	 * @return Response
	 */

	public function getProfilevalue($array,$field){
				return isset($array[$field]) ? intval($array[$field]) : 0;
	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /users/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager()) App::abort(403);
		
		$user = User::find($id);

		if ($user)
		{
			$user->delete();

			return Redirect::route('users.index')
					->with('success', 'Selected user has been disabled.');
		}
		else
		{
			$user = User::withTrashed()->findOrFail($id);

			$user->restore();

			return Redirect::route('users.index')
					->with('success', 'Selected user has been restored.');
		}
	}

}