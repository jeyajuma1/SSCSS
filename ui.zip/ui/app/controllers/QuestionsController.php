<?php

use MSLST\Constants\Site;
use MSLST\Helpers\Lists;
use MSLST\Helpers\Questions;

class QuestionsController extends \BaseController {

    /**
     * Instantiate a new QuestionsController instance.
     */
	public function __construct()
	{
		$this->beforeFilter(function ($route){
			if (!Auth::user()->isAdmin())
			{
				App::abort(404);
			}
		});

		$this->certification_groups = Site::$CERTIFICATION_GROUPS;
		$this->availabilities = Site::$CERTIFICATION_AVAILABILITIES;
		$this->severities = Site::$QUESTIONS_SEVERITY;
	}

	/**
	 * Display a listing of the resource.
	 * GET /questions
	 *
	 * @return Response
	 */
	public function index()
	{

		$questions = Questions::getFilteredQuestions(Input::all());

		// The certifications list
		$certifications = Certification::get()->lists('name', 'id');
		$supplier_categories=Lists::getCategoryList();
		$hideColumns = Questions::getHiddenColumns(Input::all());
		
		return View::make('questions.index')
				->with('certifications', $certifications)
				->with('supplier_categories', $supplier_categories)
				->with('certification_groups', $this->certification_groups)
				->with('availabilities', $this->availabilities)
				->with('severities', $this->severities)
				->with('questions', $questions)
				->with('hideColumns', $hideColumns);
	}

	/**
	 * Show the form for creating a new resource.
	 * GET /questions/create
	 *
	 * @return Response
	 */
	public function create()
	{
		$certifications = Lists::getCertificationsList();
		$categories=Lists::getCategoryList();
		$activities=Site::$SUPPLIER_ACTIVITIES;
		
		return View::make('questions.create')
				->with('certification_groups', $this->certification_groups)
				->with('availabilities', ['' => ''] + $this->availabilities)
				->with('categories', $categories)
				->with('activities', $activities)
				->with('severities', ['' => ''] + $this->severities)
				->with('certifications', $certifications);
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /questions
	 *
	 * @return Response
	 */
	public function store()
	{ 
		
		if(intval(Input::get('availability'))==5)
			$rules = BusinessQuestion::$rules;
		if(intval(Input::get('availability'))<=4)
			$rules = Question::$rules;
			$rules['availability'] .= implode(',', array_keys($this->availabilities));
			$validator = Validator::make(Input::all(), $rules);
		
		if ($validator->passes())
		{
			if(intval(Input::get('availability'))==5)
				{
					$question = BusinessQuestion::create([
						'name' => Input::get('text'),
						// 'order' => intval(Input::get('order')),
						'order' => 1,
						'availability' => intval(Input::get('availability')),
						'category' => intval(Input::get('category')),
						'activities' => '["'.implode('","', Input::get('activities')).'"]'
						]);
				}
			else{
					$question = Question::create([
						'text' => Input::get('text'),
						// 'order' => intval(Input::get('order')),
						'order' => 1,
						'availability' => intval(Input::get('availability')),
						'is_archived' => intval(Input::get('archived')),
						'is_mandatory' => intval(Input::get('mandatory')),
						'subsection' => (intval(Input::get('availability') == 4))  ? Input::get('subsection') : null,
						'reference' => (intval(Input::get('availability') == 4))  ? Input::get('reference') : null,
						'severity' => (intval(Input::get('availability') == 4))  ? intval(Input::get('severity')) : null,
						'version' => (intval(Input::get('availability') == 4))  ? Input::get('version') : null,
					]);

					$question->certifications()->attach(Input::get('certifications'));
			}
			return Redirect::route('questions.index')
					->with('success', 'Question added successfully.');
		}
		else
		{
			return Redirect::back()
				    ->withInput()
				    ->withErrors($validator->messages());
		}
	}


	/**
	 * Show the form for editing the specified resource.
	 * GET /questions/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id,$availability)
	{
		if($availability<5)
			$question = Question::with('certifications')->findOrFail($id);
		else
			{
				$question=BusinessQuestion::with('categories')->findOrFail($id);
				$question['text']=$question['name'];
				$data=explode(',',str_replace(array('["','"]','""','"'),'',$question['activities']));
				$question['activities']=$data;
			}
		
		$certifications = Lists::getCertificationsList();
		$activities=Site::$SUPPLIER_ACTIVITIES;
		$categories=Lists::getCategoryList();
		$availability=[];
		if($question->availability==1||$question->availability==2||$question->availability==3)
			$availability=array_slice($this->availabilities, 0, 3, true);
		elseif($question->availability==4)
		{
			$availability=array_slice($this->availabilities, 3, 1, true);
			if(!isset($question['certifications']) || empty($question['certifications'][0]))$question['certifications'][0]=null;
		}
		elseif($question->availability==5)
			$availability=array_slice($this->availabilities, 4, 1, true);
		
		return View::make('questions.edit')
				->with('question', $question)
				->with('activities', $activities)
				->with('categories', $categories)
				->with('certification_groups', $this->certification_groups)
				->with('availabilities',['' => ''] + $this->availabilities)
				->with('availability',$availability)
				->with('severities', ['' => ''] + $this->severities)
				->with('certifications', $certifications);
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /questions/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id,$availability)
	{	
		if($availability<5)
		{
			$rules = Question::$rules;
			$rules['text'] .= ','. $id;
			$rules['availability'] .= implode(',', array_keys($this->availabilities));
		}
		else
		{	$rules = BusinessQuestion::$rules;
			$rules['text'] .= ','. $id;
			$rules['availability'] .= implode(',', array_keys($this->availabilities));
		}

		$validator = Validator::make(Input::all(), $rules);
		$passes = $validator->passes();
		$messages = $validator->messages();

		if($availability<5)
		{
			if (Questions::isQuestionAssigned($id))
			{
				$passes = false;
				$messages->add('text', 'Cannot edit, an supplier has already answered this Question.');
			}
			if ($passes)
			{
				$question = Question::findOrFail($id);
				$question->text = Input::get('text');
				// $question->order = intval(Input::get('order'));
				$question->order = 1;
				$question->availability = intval(Input::get('availability'));
				$question->is_archived = intval(Input::get('archived'));
				$question->is_mandatory = intval(Input::get('mandatory'));
				$question->subsection = (intval(Input::get('availability') == 4))  ? Input::get('subsection') : null;
				$question->reference = (intval(Input::get('availability') == 4))  ? Input::get('reference') : null;
				$question->severity = (intval(Input::get('availability') == 4))  ? intval(Input::get('severity')) : null;
				$question->version = (intval(Input::get('availability') == 4))  ? Input::get('version') : null;
				$question->save();

				$question->certifications()->sync(Input::get('certifications'));

				return Redirect::route('questions.index')
						->with('success', 'Question updated successfully.');
			}
			else
			{	
				return Redirect::back()
					    ->withInput()
					    ->withErrors($messages);
			}
		}
		else
		{	 
			if (Questions::isSupplierQuestionAssigned($id))
			{
				$passes = false;
				$messages->add('text', 'Cannot edit, an supplier has already answered this Question.');
			}

			if ($passes)
			{
				$question = BusinessQuestion::findOrFail($id);
				$question->name = Input::get('text');
				// $question->order = intval(Input::get('order'));
				$question->order = 1;
				$question->availability = intval(Input::get('availability'));
				$question->activities='["'.implode('","', Input::get('activities')).'"]';
				$question->save();
				return Redirect::route('questions.index')
						->with('success', 'Question updated successfully.');
			}
			else
			{	
				return Redirect::back()
					    ->withInput()
					    ->withErrors($messages);
			}
		}

		
	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /questions/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id,$availability)
	{
		if($availability!=5)
		{
			if (!Questions::isQuestionAssigned($id))
			{
				$question = Question::findOrFail($id);
				$question->delete();

				return Redirect::route('questions.index')
						->with('success', 'Question deleted successfully.');
			}
		}	
		else
		{ 
			if(!Questions::isSupplierQuestionAssigned($id)) {
				$question = BusinessQuestion::findOrFail($id);
				$question->delete();
				return Redirect::route('questions.index')
						->with('success', 'Question deleted successfully.');
			}
			

		}
		return Redirect::back()
			    ->with('error', 'Cannot delete this question. It has been answered already.');
	}

	

}