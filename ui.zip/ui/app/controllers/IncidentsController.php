<?php
use MSLST\Helpers\Lists;
use MSLST\Helpers\Incidents;
use MSLST\Helpers\Coordinate;
use MSLST\Helpers\Factoryincidents;
use MSLST\Helpers\Common;
use MSLST\Helpers\Emails;

class IncidentsController extends \BaseController {

	/**
	 * Display a listing of the resource.
	 * GET /incidents
	 *
	 * @return Response
	 */
	public function index() {
		 //self::Imie_UpdateAttachmentInfo(); exit;


		if (!Auth::User()->isAdmin() && !Auth::User()->access_incidents) App::abort(403);

		$usrregion =  [];
		if (!Auth::User()->isAdmin() && !Auth::User()->isManager() ) {
			 $usrregion = Lists::getUserRegion(Auth::User()->id);
		}

		$RequestData = Input::all();
 
		/* Checking date Filter Option */ 
		if(isset($RequestData['daterange'])){
			$daterange = preg_split('/ - /',$RequestData['daterange']);
			if(count($daterange) == 1) {
				$RequestData['daterange'] = '';
				Input::merge(array('daterange'=>''));
			}
		}

		$users = Lists::getAuditorsList();
		$customers = Lists::getCustomersList();
		$lsps = Lists::getLspsList();
		$regions = Lists::getRegionsList($usrregion);
		$countries = Lists::getCountriesList();
		$investigation = Lists::getInvestigation();
		

		if(isset($RequestData['type']) && $RequestData['type'] == 'factory')
			$incidents = Factoryincidents::getFilteredIncidents($RequestData);
		else
			$incidents = Incidents::getFilteredIncidents($RequestData);

		if(!empty($RequestData['region'])){
			$regions_country[]  =  $RequestData['region'];
			$countries =  Lists::getCountriesList($regions_country[0]);
		}

		return View::make('incidents.index')
				->with('users', $users)
				->with('customers', $customers)
				->with('lsps', $lsps)
				->with('regions', $regions)
				->with('countries', $countries)
				->with('investigation',$investigation)
				->with('incidents', $incidents);
	}

	/**
	 * Show the form for creating a new resource.
	 * GET /incidents/create
	 *
	 * @return Response
	 */
	public function create($step = 0) {
		if (!Auth::User()->isAdmin() && ! Auth::User()->access_incidents) App::abort(403);

		switch(intval($step))
		{
			case 0:
				$data = Incidents::getIncidentStepData('basic_information');
				return self::basic_information_form($data);
			case 1:
				$data = Incidents::getIncidentStepData('customer_transportation');
				return self::customer_transportation_form($data);
			case 2:
				$data = Incidents::getIncidentStepData('units_investigation');
				return self::units_investigation_form($data);
			case 3:
				$data = Incidents::getIncidentStepData('attachments');
				return self::attachments_form($data);
			case 4:
				$data = Session::get('incidents');
				return self::summary_list($data);
		}
	}

	/**
	 * Show basic information form for incidents.
	 *
	 * @return Response
	 */
	public static function basic_information_form($data, $edit = false) {

		$usrregion = UserRegion::select('region_id')
							   ->where('user_id',\Auth::user()->id)
				  			   ->Lists('region_id');

		if(Auth::User()->isAdmin())  $usrregion = '';
		
		$regions = Lists::getRegionsList($usrregion);

		$regions_json = json_encode(Lists::getRegionCountriesList($usrregion));

		return View::make('incidents.basic_information')
				->with('regions', $regions)
				->with('countries', [])
				->with('regions_json', $regions_json)
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show customer/transportation form for incidents.
	 *
	 * @return Response
	 */
	public static function customer_transportation_form($data, $edit = false) {
		return View::make('incidents.customer_transportation')
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show units/investigation form for incidents.
	 *
	 * @return Response
	 */
	public static function units_investigation_form($data, $edit = false)
	{
		return View::make('incidents.units_investigation')
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show attachments form for incidents.
	 *
	 * @return Response
	 */
	public static function attachments_form($data, $edit = false) {
		return View::make('incidents.attachments')
				->with('edit', $edit)
				->with('data', $data);
	}

	/**
	 * Show Current Create Summary Location
	 *
	 *@return Response
	 */
	public static function summary_list($data) {
		$category = Incidents::getIncidentCategory($data['units_investigation']->total_value_of_lost_units);
		
		$country  = Lists::getCountriesname($data['basic_information']->country);
		
		return View::make('incidents.summary')
					->with('category',$category)
					->with('country',$country)
					->with('data',$data);
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /incidents
	 *
	 * @return Response
	 */
	public function store() {
		if (!Auth::User()->isAdmin() && ! Auth::User()->access_incidents) App::abort(403);
		
		switch(intval(Input::get('step')))
		{
			case 0:
				$validator = Validator::make(Input::all(), Incident::$basic_information_rules);
				$step = 'basic_information';
				$next = 'incidents/create/1';
				break;
			case 1:
				$validator = Validator::make(Input::all(), Incident::$customer_transportation_rules);
				$step = 'customer_transportation';
				$next = 'incidents/create/2';
				break;
			case 2:
				$Newvalidators=Input::all();
				if($Newvalidators['type_of_device']['0']=='Proto Device') {
					$validatorvar=Incident::$units_investigation_rules;
 					$getarray = array_where($Newvalidators, function($key, $value){
			    			 if($key == 'product_description' || $key == 'number_of_units_missing'  ){
			    			 	return array_filter($value);
			    			 }else{
			    			 	 return $key = $value;
			    			 }
					});
					unset($validatorvar['number_of_plts_missing']);unset($validatorvar['value_per_unit']);unset($validatorvar['total_value_of_lost_units']);unset($validatorvar['type_of_other_device']);
				}
				elseif($Newvalidators['type_of_device']['0']=='Other') {
				$validatorvar=Incident::$units_investigation_rules;
				$getarray =  $Newvalidators;
				}
				else
				{
					$validatorvar=Incident::$units_investigation_rules;
					$getarray =  $Newvalidators;
					unset($validatorvar['type_of_other_device']);
				}

				$validator = Validator::make($getarray,$validatorvar);
				
				$step = 'units_investigation';
				$next = 'incidents/create/3';
				break;
			case 3:
				$validator = Validator::make(Input::all(), Incident::$attachments_rules);
				$step = 'attachments';
				$next = 'incidents/create/4';
			    break;
			case 4:
				Incidents::saveIncidentData();

				return Redirect::to('incidents')
								->with('success', "Incident created successfully.");
		}

		if ($validator->passes())
		{ 
			$data = Incidents::setIncidentStepData($step, Input::all());
			return Redirect::to($next);
		}
		else
		{
			return Redirect::back()
					->withInput()
					->withErrors($validator->messages());

		}
	}

	/**
	 * Display the specified resource.
	 * GET /incidents/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		if (! Common::canAccess($id, 'incident')) App::abort(403);

		$incident = Incident::with('user', 'country', 'region', 'product', 'attachment', 'incident_log', 'official_investigation','incident_investigation')->findOrFail($id);

		$products = Incidents::getDecodedProducts($incident->product);
		$coordinates = Coordinate::convertToWGS84($incident->coordinates);
		$imei_list = Incidents::getImeiList($incident->attachment);
		$sn_list = Incidents::getSnList($incident->attachment);
		
		$has_attachments = Incidents::hasAttachments($incident->attachment);
		$status = Common::getDateStatus($incident->closed_at, 'Closed', 'Open');
		
		if(!empty($incident->user->lsp->id)){
			$users = ['' => ''] + Lists::getLspUsersList($incident->user->lsp->id, $incident->user->id, $incident->region->id);
		}else{
			$users = [];
		}
		$owners = IncidentOwner::where('incident_id', $incident->id)->lists('user_id');

		$findings = IncidentFindings::with('user')->where('incident_id',$id)->get()->all();

		$InvestigationStus = [];
		if(\Auth::User()->isManager() || \Auth::User()->isAdmin() || ($incident->user_id == \Auth::User()->id) ){
			$InvestigationStus = IncidentInvestigation::select('name','id')->get()->lists('name','id'); 
		}

		$incident->closure_state = strtolower(trim($incident->closure_state));
		 
		return View::make('incidents.show')
				->with('products', $products)
				->with('incident', $incident)
				->with('imei_list', $imei_list)
				->with('sn_list', $sn_list)
				->with('status', $status)
				->with('has_attachments', $has_attachments)
				->with('coordinates', $coordinates)
				->with('findings',$findings)
				->with('InvestigationStus',$InvestigationStus)
				->with('users', $users)
				->with('owners', $owners);
	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /incidents/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id, $step = 0)
	{
		if (! Common::canAccess($id, 'incident')) App::abort(403);

		switch(intval($step))
		{
			case 0:
				$data = Incidents::getIncidentEditData($id, 'basic_information');
				return self::basic_information_form($data, true);
			case 1:
				$data = Incidents::getIncidentEditData($id, 'customer_transportation');
				return self::customer_transportation_form($data, true);
			case 2:
				$data = Incidents::getIncidentEditData($id, 'units_investigation');
				return self::units_investigation_form($data, true);
			case 3:
				$data = Incidents::getIncidentEditData($id, 'attachments');
				return self::attachments_form($data, true);
		}
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /incidents/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		if (! Common::canAccess($id, 'incident')) App::abort(403);

		switch(intval(Input::get('step')))
		{
			case 0:
				$validator = Validator::make(Input::all(), Incident::$basic_information_rules);
				$step = 'basic_information';
				break;
			case 1:
				$validator = Validator::make(Input::all(), Incident::$customer_transportation_rules);
				$step = 'customer_transportation';
				break;
			case 2:
				$Newvalidators=Input::all();
				if($Newvalidators['type_of_device']['0']=='Proto Device') {
					$validatorvar=Incident::$units_investigation_rules;
 					$getarray = array_where($Newvalidators, function($key, $value){
			    			 if($key == 'product_description' || $key == 'number_of_units_missing'  ){
			    			 	return array_filter($value);
			    			 }else{
			    			 	 return $key = $value;
			    			 }
					});
					unset($validatorvar['number_of_plts_missing']);unset($validatorvar['value_per_unit']);unset($validatorvar['total_value_of_lost_units']);unset($validatorvar['type_of_other_device']);
				}
				
				elseif($Newvalidators['type_of_device']['0']=='Other')
				{
				$validatorvar=Incident::$units_investigation_rules;
				$getarray =  $Newvalidators;
				}
				else
				{
					$validatorvar=Incident::$units_investigation_rules;
					$getarray =  $Newvalidators;
					unset($validatorvar['type_of_other_device']);
				}

				$validator = Validator::make($getarray,$validatorvar); 
				$step = 'units_investigation';
				break;
			case 3:
			    $attach = Input::all();
				if(!empty((array)Input::file('imei_list'))) $attach['imei_list_ext'] = Input::file('imei_list')->getClientOriginalExtension(); 
			    if(!empty((array)Input::file('sn_list')))   $attach['sn_list_ext']   = Input::file('sn_list')->getClientOriginalExtension();

				$validator = Validator::make($attach, Incident::$attachments_rules);
				$step = 'attachments';
		}

		if ($validator->passes())
		{  
			Incidents::setIncidentEditData($id, $step, Input::all());
			return Redirect::route('incidents.show', $id)
					->with('success', 'Incident updated successfully.');
		}
		else
		{
			return Redirect::back()
					->withInput()
					->withErrors($validator->messages());

		}
	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /incidents/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		if (! Common::canAccess($id, 'incident')) App::abort(403);

		$incident = Incident::findOrFail($id);
		$incident->delete();

		return Redirect::route('incidents.index')
				->with('success', 'Incident deleted successfully.');
	}

	/**
	 * Toggle review status of the specified resource.
	 * PATCH /incidents/review/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function review($id,$option)
	{
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager()) App::abort(403);

		$incident = Incident::findOrFail($id);

		$incidentlogArray = array('incident_id'=>$incident->id,'user_id'=>\Auth::User()->id);

		if($option == 'clear')
		{
			$incident->review_requested = 0;
			$incidentlogArray['cleared_at'] = date('Y-m-d h:i:s');

			Emails::sendIncidentCleared($incident);
			$msg = 'Review request has been cleared.';
		}
		else
		{
			$incident->review_requested = 1;
			$incidentlogArray['requested_at'] = date('Y-m-d h:i:s');

			Emails::sendIncidentReview($incident, Input::get('review_message'));
			$msg = 'Review has been requested.';
		}

		$incident->save();
		IncidentLog::insert($incidentlogArray);

		return Redirect::route('incidents.show', [$id])
				->with('success', $msg);
	}

	/**
	 * Toggle closed of the specified resource.
	 * PATCH /incidents/close/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function close($id)
	{
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager()) App::abort(403);

		$incident = Incident::findOrFail($id);

		if ($incident->closed_at)
		{
			$incident->closed_at = NULL;
			$message = "Incident re-opened successfully.";

			Emails::sendIncidentStatus($incident, 'open');
		}
		else
		{
			 /* Close incident Attachment And descricption */
			 $data = Input::all();
			 if(!empty($data['attachment']) )  Incidents::closeAttachment(Input::all(),$id);

			$incident->closed_at = new \Carbon\Carbon;
			$message = "Incident closed successfully.";


			Emails::sendIncidentStatus($incident, 'closed');
		}

		$incident->save();

		return Redirect::route('incidents.show', [$id])
				->with('success', $message);
	}

	/**
	 * Request Incident Close
	 * Get /incident/request_close
	 *
	 *
	 * @params int $id
	 * @return Response
	 **/
	
	public function request_closure(){

		$input = Input::get();
		$user_id = Auth::user()->id;
		$date_now = new \Carbon\Carbon;
		$data = []; $log = [];

		$log = ['incident_id' => $input['id'],'user_id' => $user_id,'created_at' => Null,'updated_at'=> Null];

		switch($input['state']){
			case "request":
						$data = ['request_closure_comment' =>$input['comments'],'closure_state'=>'Requested'];
						$log =  $log + ['closure_requested_at'  => $date_now];
			break;
			case "close":
						$data = ['closed_at'=>$date_now,'closure_comment'=>$input['closure_comments'],'closure_state'=>'Accept'];
						$log =  $log + ['closure_accepted_at'  => $date_now];
						$message = "Incident closed successfully.";
			break;
			case "deny":
						$data = ['closure_comment'=>$input['closure_comments'],'closure_state'=>'Deny'];
						$log =  $log + ['closure_denied_at'  => $date_now];	
						$message = "Incident denied successfully.";
			break;
			case "open":
						$data = ['closure_state'=>'Re open','closed_at'=>null];
						$log =  $log + ['closure_re_open_at'  => $date_now];
						$message = "Incident re-opened successfully.";
			break;
		}

		$result = Incidents::IncidentClosureRequest($input['id'],$data);
						
        Incidents::IncidentHistoryLog($log);
        
        $incident = Incident::findOrFail($input['id']);
        
        Emails::sendIncidentStatus($incident, $input['state']);
        
        if($input['state'] == 'close' || $input['state'] == 'deny' || $input['state'] == 'open'){
        	return Redirect::route('incidents.show',  $input['id'])->with('success', $message);
        }else{
			return $result;
        }
	}



	/**
	 * Request Incident Close
	 * Get /incident/request_close/{id}
	 *
	 *
	 * @params int $id
	 * @return Response
	 **/

	public function request_close(){
		$input_id = Input::get('id');

		$result   = \Incident::where('id',$input_id)
						     ->update(['requested_by'=>Auth::user()->id,
									   'req_for_close_at'=>new \Carbon\Carbon,
									   'closure_state'=>'requested']);

		return $result;
	}


	/**
	 * Export the specified resource.
	 * GET /incidents/export/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function export($id)
	{
		if (! Common::canAccess($id, 'incident')) App::abort(403);

		$incident = Incident::findOrFail($id);

		return Incidents::incidentExportXLS($id);
	}

	/**
	 * Download the audit attachment.
	 * GET /audits/download
	 *
	 * @return Response
	 */
	public function download($fid, $id, $type)
	{
		return Common::downloadFile($fid, $id, $type);
	}

	/**
	 * Add new Findings
	 * POST /incidents/addnewfind
	 * @return Response
	 **/
	public function newFinding()
	{

		$data = Input::all();


		switch($data['options'])
		{
			case 'add':
					IncidentFindings::insert(
							array('findings'=>$data['newfindings'],
								   'incident_id' =>$data['Incid'],
								   'user_id'=>\Auth::user()->id,
								   'created_at'=>date('Y-m-d H:i:s'))
							);
			break;
			case 'update':
				$affectedrows = IncidentFindings::where('id',$data['Incid'])
												->update(array('findings'=>$data['newfindings']));
			break;
			case 'delete':
				$affectedrows = IncidentFindings::where('id',$data['Incid'])
												->delete();
			break;
		}

		return 'sucess';

	}

	/**
	 * Update owners for the incident.
	 * POST /incidents/update-owners
	 *
	 * @return Response
	 */
	public function updateOwners()
	{
		if (! \Auth::User()->isAdmin()
				&& ! \Auth::User()->isSupervisor()
				&& ! \Auth::User()->isManager()) App::abort(403);

		$data = Input::get('owners');
		$incident_id = intval(Input::get('id'));

		//@TODO: Check if the users belongs to same lsp

		if ($incident_id)
		{
			$affected = IncidentOwner::where('incident_id', $incident_id)
							->delete();
			if ($data)
			{
				foreach($data as $user_id)
				{
					IncidentOwner::create([
							'incident_id' => $incident_id,
							'user_id' => $user_id,
						]);
				}
			}
		}
	}


	/**
	 * Update Investigation status to Incident
	 * Post /incident/updateInvestigationStatus
	 * 
	 * return Response
	 **/
	public function updateInvestigationStatus()
	{
		$inves_id =Input::get('inves_id');
		$inc_id   =Input::get('inc_id');

		$userid = Incident::select('user_id')->where('id','=',$inc_id)->lists('user_id');

		if(!\Auth::User()->isManager() && !\Auth::User()->isAdmin() && ($userid[0] != \Auth::User()->id )) App::abort(403);
		

		$mytime = Carbon\Carbon::now();
		 
		$affected_rows = Incident::where('id','=',$inc_id)->update(array('investigation_status'=>$inves_id));

		$IncidentlogArray = ['incident_id'=>$inc_id,'user_id'=>\Auth::user()->id,'updated_at'=>$mytime->toDateTimeString()];

        IncidentLog::insert($IncidentlogArray);
		// dd(DB::getQuerylog());
		return $affected_rows;
	}


	/**
	 * List Investigation 
	 * Resourcse /incident/Investigation
	 * 
	 * return Response
	 **/
	public function investigationList()
	{
		$inves_all = IncidentInvestigation::get()->all();

		
		return View::make('incidents.investigation.index')
					->with('inves_lst',$inves_all);
	}

	/**
	 * Edit Investigation 
	 * Patch /incident/Investigation
	 * 
	 * return Response
	 **/
	public function investigationEdit($id)
	{

		$inves_id = IncidentInvestigation::select('id','name')->where('id',$id)->get()->all();
		return View::make('incidents.investigation.edit')
					->with('inves_lst',$inves_id[0]);

	}

	/**
	 * Update Investigation 
	 * Put /incident/Investigation
	 * 
	 * return Response
	 **/
	public function investigationUpdate($id)
	{

		$affected_rows = IncidentInvestigation::where('id',$id)->update(array('name'=>Input::get('name')));

		return Redirect::to('incident/investigation')
					->with('success', 'Investigation updated Successfully.');

	}

	/**
	 * Create Investigation 
	 * Get /incident/investigation/create
	 * 
	 * return Response
	 **/
	public function investigationCreate()
	{
		return View::make('incidents.investigation.create');
	}


	/**
	 * Store Investigation 
	 * Put /incident/investigation/create
	 * 
	 * return Response
	 **/
	public function investigationStore()
	{
		$created_at = Carbon\Carbon::now();
		if(!IncidentInvestigation::where('name',Input::get('name'))->exists()){

				IncidentInvestigation::insert(
							 array(
								   'name' => Input::get('name'),
								   'created_at' =>$created_at->toDateTimeString()
								  )
						);
		}else{
			return Redirect::to('incident/investigation/create')
					->with('success', 'Investigation alreardy Exist!');
		}

		return Redirect::to('incident/investigation')
					->with('success', 'Investigation Created Successfully.');
	}



	/**
	 *
	 *
	 *
	 **/
	public function Imie_UpdateAttachmentInfo(){
		/*$directory = storage_path().'/files/incidents/imei/';
		$files = File::allFiles($directory);*/

			$attac_arry =	Attachment::select('file_name','id','incident_id')->where('attachment_type','imeiList')
					   				  ->get()->toArray();

		    print "<pre>"; print_r($attac_arry); exit;				 		    

			foreach ($attac_arry as $file)
			{

			   
				 /**/\Excel::selectSheetsByIndex(range(0,1))->load((string)$file['file_name'], function($reader) use($file)  { 

					 	$file =  (string)$file;
                            $reader->noHeading();
                                  $attachment_info = $reader->each(function($sheet)  {
                                    return str_replace('null','',json_encode($sheet));
							       });
                                  /* Updating [attachment_info] field  in Attachment table */
											/* $imi =  Attachment::where('attachment_type','imeiList')	
											 		   		  ->whereRaw("file_name like '%".substr((preg_replace('/imei/','',explode('/', $file)[3])),1)."'")
															  ->update(['attachment_info'=>$attachment_info]);*/
												$imi =  Attachment::where('attachment_type','imeiList')	
																	->where('id',$file['id'])
																	->where('incident_id',$file['incident_id'])
															  		->update(['attachment_info'=>$attachment_info]);
										 
                                 
                              
                          });

 				 /* Found values in Attachment table 
				 $imi =  Attachment::select('id')
				 				   ->where('attachment_type','imeiList')	
				 		   		   ->whereRaw("file_name like '%".substr((preg_replace('/imei/','',explode('/', (string)$file)[3])),1)."'")
				 		           ->lists('id');
				 		    
				 		   if(isset($imi) && !empty($imi) ) {
				 		   	  print "<pre>"; print_r($imi); echo  (string)$file."-------->".substr((preg_replace('/imei/','',explode('/', (string)$file)[3])),1)."<br/>";
				 		   }*/
 				 		   
				    
			}

		 
          
	}
}
