<?php
use MSLST\Helpers\Lanes;
use MSLST\Helpers\Lists;
use MSLST\Helpers\Coordinate;
use MSLST\Helpers\Locations;

error_reporting(E_ALL ^ E_NOTICE);
class LanesController extends \BaseController {

	/**
	 * Instanite for Usercontroller Instance
	 *
	 **/
	public function __construct()
	{
		//if (!Auth::User()->isAdmin() && !Auth::User()->access_lanes ) App::abort(403);
		if (!Auth::User()->isAdmin() ) App::abort(403);
	}

	/**
	 * Display a listing of the lanes.
	 * GET /Lanes
	 *
	 * @return Response
	 */
	public function index()
	{
		$result        = [];
		$RequestData   = Input::all();
	   // $lanes         = Lanes::getLanesList($RequestData);
	    $lanes         = Lanes::getlanesdata($RequestData);
	    $lsps 	       = Lists::getLspsList();
	    $back 		   = '';

		/*Checking Lanes list Empty or not*/
 		if(isset($lanes[0]) && $lanes[0] == 'reset') { $back = $lanes[0]; goto resetlink;}

		
		if(count($lanes) != 0 ){
			foreach($lanes as $lane){
				//$lspname = Lists::getlspname($lane->lane->lsp_id);
				//$totalnodes = ($lane->lane->waypoints)+2;
				$result[$lane->lspname."-".$lane->laneid][$lane->position] = $lane;
		    }
		}else{
			  $result = false;
		}

		resetlink:

		Session::put('startlanes', ''); // Creating Session show lanes in same order
		Session::put('LaneID','');
		
		/*Rendering to view lanes index blade template page */
		return View::make('lanes.index')
				   ->with('lsps',$lsps)
				   ->with('lanes',$result)
				   ->with('back',$back);
	}
	
	/**
	 * Show the form for creating a new lanes.
	 * GET /lanes/create
	 *
	 * @ return Response
	 */
	public function create(){

		$startlane 	  = Session::get('startlanes') ?: 'new';
		$LaneID    	  =	Session::get('LaneID') ?: '';
		$Locationlist = [];
		$Countrylist  = [];
		$location_res = [];
		$Locationlist['locationlst'] = [];
		$Locationlist['lanlst'] = [];


		if(!empty($LaneID) && isset($LaneID)){

			/*Getting Location and Lanes List */
			$Locationlist = Lanes::getAuditLocationLst($startlane,'');

			if(!empty($Locationlist['lanelst']) && isset($Locationlist['lanelst'])){ 
				foreach ($Locationlist['lanelst'] as $key => $value) {
					$Locationlist['lanlst'][$value->position] = $Locationlist['lanelst'][$key];
				}
			}

	        // Step 2
			/* Getting Location */
		 	$location_res = lanes::getLocationAudit();

			/*Getting Countries List */
			$Countrylist = Lists::getCountriesList();
	    }
		
		/*Rendering to view  lanes create blade template page */
		return View::make('lanes.create')
				   ->with('Locationlist',$Locationlist['locationlst'])
				   ->with('lanelist',$Locationlist['lanlst'])
				   ->with('Countrylist',$Countrylist)
				   ->with('startlane',$startlane)
				   ->with('location_audit',json_encode($location_res))
				   ->with('laneID',$LaneID);
	}

	/**
	 * creating a new lanes.
	 * GET /lanes/addlane
	 *
	 * @ return Response
	 */
	public function add(){
	   /*All Input Request Assigning to $objArr Array */
		$data = Input::all();

		if(($data['steps'] == 2 || $data['steps'] == 3) ){

			list($laneid,$waypoints) = explode('-',Session::get('LaneID')); 

		  if(empty($data['position'])){
			$totalnodes   = $waypoints + 2;
			$positionData = Lanes::getPositionDetail($laneid);


			if(count($positionData) != $totalnodes ){
				$posArry  = range(1,$totalnodes);
				$remPos	  = array_diff($posArry,$positionData);
				$nextPos  = array_shift($remPos);
				$data['position'] = $nextPos;
			}
		  }
		}

		switch ($data['steps']) {
			case '1':	/* Adding waypoints */
					Lanes::addwaypoint($data);
					Session::put('startlanes', 'exist'); // Creating startlanes Session  value for show lanes in same order
					$laststep = 'no';
					break;
			case '2':
					if($data['existingLocation'] != '' && $data['process'] == '') $data['process'] = 'exist';

					$data['process'] = ($data['process']!="") ? $data['process'] : "new";

					switch($data['process']){
				
						case 'new':

								$validator = validator::make(Input::all(),Lanes::$basic_details_fields);

								if ($validator->fails())
								{
									return Redirect::back()
									               ->withInput()
									               ->withErrors($validator->messages());
								}

								$RequestData['site'] = $data['site'];
								$RequestData['address']  = $data['address'];
								$RequestData['country']  = $data['country'];
								$RequestData['coordinates'] = Coordinate::convertToWGS84($data['coordinates']);
								$RequestData['position']    = $data['position'];
								$RequestData['transport']   = $data['transport'];
								$audit = 'new';
							break;
						case 'exist':
						case 'map':
						default:
								$RequestData['location'] = $data['existingLocation'];
								$RequestData['position'] = $data['position'];
								$RequestData['transport'] = $data['transport'];
								$audit = 'exist';
							break;
					}


					/* Adding Location and forming Lanes */
					Lanes::addNodesLanes($RequestData,Auth::user(),$audit);

					Session::put('startlanes', ''); // Deleting startlanes Session  value for show lanes in same order
					Session::put('startlanes', 'exist'); // Creating startlanes Session  value for show lanes in same order
					 $laststep = 'no';
					break;
			  case '3':
			  		 $laststep = 'yes';
			  		if(!empty($data['final']) && isset($data['final'])){
			  			/*Create Route Automatically*/
			  			/*$auditId = explode('-',$data['all_location_id']);
			  			foreach($auditId as $key=>$val){
			  				if(end($auditId) != $val){
			  					$result['startlocation'] = $auditId[$key];
			  					$result['endlocation'] = $auditId[$key+1];
			  					$this->routecreate($result);
			  				}
			  			}*/
			  			/* End Create Route Automatically*/

			  			Lanes::updateLaneFinal($laneid);
			  			$data['success'] = 'sucess';
			  		 }
			  		break;
			default:
				# code...
				break;
		}

		if(!empty($data['success'])){
			return Redirect::to('lanes')->with('success', 'Node created successfully'); 	/*Redirect to lanes index blade template page */
		}else if(empty($data['success'])){
		     return Redirect::to('lanes/create')->with('laststep',$laststep)->with('steps',$data['steps']); 	/*Redirect to lanes create blade template page */
		}
	}
	
	
	/**
	 * Delete a lanes.
	 * DEL /lanes/delete
	 *
	 * @ return Response
	 */
	public function delete(){
	   /*All Input Request Assigning to $objArr Array */
		$RequestData = Input::all();

		list($lsp,$id) = explode('-', $RequestData['id']);
		
		/* Delete one complete lanes*/
		$result = Lanes::Deletelane($id);
		if($result == 1)Session::flash('success', 'Lanes deleted successfully');
		else Session::flash('success', 'Lanes deleted successfully');
	}


	/**
	 * By Clicking transport icons in final step of creation Lanes , the route will create automatically
	 *
	 **/

	public function routecreate($RequestData = Null){
		/*All Input Request Assigning to $objArr Array */
		if(empty($RequestData)){
			$RequestData = Input::all();
		 }
		$route  	 = [];


		$start = Locations::getLocationInvidualDetail($RequestData['startlocation'],'start');
		$end  = Locations::getLocationInvidualDetail($RequestData['endlocation'],'end');

		/*Checking Existing Route whether if same already created */
		$routechk = Routes::select('id')
						  ->where('start_site',$start[0]->startsite)
						  ->where('end_site',$end[0]->endsite)
						  ->lists('id');

	
		if(empty($routechk)){
			$route['start_site'] 		= $start[0]->startsite;
			$route['start_address'] 	= $start[0]->startaddress;
			$route['start_coordinates'] = Coordinate::convertToWGS84($start[0]->startcoordinates);
			$route['start_country_id']  = $start[0]->startcountry_id;
			$route['end_site'] 			= $end[0]->endsite;
			$route['end_address'] 		= $end[0]->endaddress;
			$route['end_coordinates'] 	= Coordinate::convertToWGS84($end[0]->endcoordinates);
			$route['end_country_id'] 	= $end[0]->endcountry_id;
			$route['auditor_id'] 		= Auth::user()->id;
			$route['lsp_id'] 			= Auth::user()->lsp_id;
			$route['created_at'] 		= date('Y-m-d H:i:s');

			$routId = Routes::insertGetId($route);
			
			$value = "Route created successfully "; 
			 
		 }else{
		 	$value = "Already exist";
		 }
 
 		return $value;
	}

	/**
	 * Update the pending lanes
	 * 
	 *
	**/
	public function show($id){


		$startlane = null;

		$chklane = Lanes::checkInValidLane($id);

		
		/* For map plot in Location */
		$location_result = lanes::getLocationAudit();


		/*Getting Location and Lanes List */
		$Locationlist = Lanes::getAuditLocationLst($startlane,$id);

		foreach($Locationlist['lanelst'] as $ky=>$lan){
			 $lanelist[$lan->position] = $lan;
		}
		
		/*Getting Countries List */
		$Countrylist = Lists::getCountriesList();
		
		/*Rendering to view  lanes create blade template page */
		return View::make('lanes.update')
				   ->with('Locationlist',$Locationlist['locationlst'])
				   ->with('lanelist',$lanelist)
				   ->with('lane_id',$id)
				   ->with('chklane',$chklane)
				   ->with('location_audit',json_encode($location_result))
				   ->with('Countrylist',$Countrylist);
	}



	/**
	 * updating a exiting lanes.
	 * GET /lanes/update
	 *
	 * @ return Response
	 */
	public function update(){
	   /*All Input Request Assigning to $objArr Array */
		$data = Input::all();

		if(($data['steps'] == 2 || $data['steps'] == 3) ){

		 	if(empty($data['position'])){
				$totalnodes   = $data['waypoints'];
				$positionData = Lanes::getPositionDetail($data['laneid']);
			
				if(count($positionData) != $totalnodes ){
					$posArry  = range(1,$totalnodes);
					$remPos	  = array_diff($posArry,$positionData);
					$nextPos  = array_shift($remPos);
					$data['position'] = $nextPos;
				}
		  	}
		}

		switch ($data['steps']) {
			case '2':
					$data['process'] = ($data['process']!="") ? $data['process'] : "new";
					switch($data['process']){
				
						case 'new':

								$validator = validator::make(Input::all(),Lanes::$basic_details_fields);

								if ($validator->fails())
								{
									return Redirect::back()
									               ->withInput()
									               ->withErrors($validator->messages());
								}

								$RequestData['site'] = $data['site'];
								$RequestData['address']  = $data['address'];
								$RequestData['country']  = $data['country'];
								$RequestData['coordinates'] = Coordinate::convertToWGS84($data['coordinates']);
								$RequestData['position']    = $data['position'];
								$RequestData['transport']   = $data['transport'];
								$RequestData['laneid']    = $data['laneid'];
								$audit = 'new';
							break;
						case 'exist':
						case 'map':
						default:
								$RequestData['location']  = $data['existingLocation'];
								$RequestData['position']  = $data['position'];
								$RequestData['transport'] = $data['transport'];
								$RequestData['laneid']    = $data['laneid'];
								$audit = 'exist';
							break;
					}

					/* Adding Location and forming Lanes */
					Lanes::addNodesLanes($RequestData,Auth::user(),$audit);

					Session::put('startlanes', ''); // Deleting startlanes Session  value for show lanes in same order
					Session::put('startlanes', 'exist'); // Creating startlanes Session  value for show lanes in same order
					 $laststep = 'no';
					break;
			  case '3':
			  		 $laststep = 'yes';
			  		 $laneid   = $data['laneid'];
			  		if(!empty($data['final']) && isset($data['final'])){
			  			Lanes::updateLaneFinal($laneid);
			  			$data['success'] = 'sucess';
			  		 }
			  		break;
			default:
				# code...
				break;
		}
		/* Adding Location and forming Lanes */
	//	Lanes::UpdateLane($objArr,Auth::user(),null,$objArr['id']);
		
		if(!empty($data['success'])){
			return Redirect::to('lanes')->with('success', 'Node successfully Updated'); 	/*Redirect to lanes index blade template page */
		}else if(empty($data['success'])){
			/*Redirect to lanes create blade template page */
			return Redirect::to('lanes/'.$data['laneid'])->with('laststep',$laststep)->with('steps',$data['steps']);
		}
	}


	/**
	 * Checking Mail configuration
	 *
	 **/
	/*public function chckmail(){
			Mail::send('emails.layout', array('key' => 'value'), function($message)
			{
				$message->to('jeyaprabhu.palanisamy@cmcltd.com', 'John Smith')->subject('Welcome!');
			});
			exit;
	}*/



	
}