<?php

use MSLST\Helpers\Common;
use MSLST\Helpers\Emails;

class RemindersController extends Controller {

	/**
	 * Display the password reminder view.
	 *
	 * @return Response
	 */
	public function index()
	{
		return View::make('password.remind');
	}

	/**
	 * Handle a POST request to remind a user of their password.
	 *
	 * @return Response
	 */
	public function store()
	{
		// Get the settings
		$subject = \Setting::where('name', 'account_email_subject_password_reset')->first()->value;
		$body = \Setting::where('name', 'account_email_body_password_reset')->first()->value;

		$body = str_replace('%expiration%', (Config::get('auth.reminder.expire', 1440)/60), $body);

	    View::composer('emails.layout', function($view) use ($body) {
	        $view->with([
	            'body'  => $body,
	        ]);
	    });

		switch ($response = Password::remind(Input::only('email'), function($message) use ($subject) {
				$message->subject($subject);
		}))
		{
			case Password::INVALID_USER:
				return Redirect::back()->with('error', Lang::get($response));

			case Password::REMINDER_SENT:
				return Redirect::to('/')->with('success', Lang::get($response));
		}
	}

	/**
	 * Display the password reset view for the given token.
	 *
	 * @param  string  $token
	 * @return Response
	 */
	public function show($token = null)
	{
		if (is_null($token)) App::abort(404);

		return View::make('password.reset')->with('token', $token);
	}

	/**
	 * Handle a POST request to reset a user's password.
	 *
	 * @return Response
	 */
	public function update()
	{
		$credentials = Input::only(
			'email', 'password', 'password_confirmation', 'token'
		);

		$has_psswrd = false;
		$response = Common::checkPasswordPolicy($credentials['password']);

		if (! $response)
		{
			// If this is new account password set, extend time expiration to 24hrs
			$has_psswrd = \MSLST\Helpers\Common::hasPassword(Request::segment(2));

			if (! $has_psswrd)
			{
				Config::set('auth.reminder.expire', 1440);
			}

			// Reset the password
			$response = Password::reset($credentials, function($user, $password)
			{
				$user->password = Hash::make($password);
				$user->password_updated_at = new \Carbon\Carbon();
				$user->save();
			});
		}

		// Switch success message, if this is for new account
		if (! $has_psswrd)
		{
			$message = 'New password created successfully.';
		}
		else
		{
			$message = 'New password updated successfully.';
		}

		switch ($response)
		{
			case Password::INVALID_PASSWORD:
			case Password::INVALID_TOKEN:
			case Password::INVALID_USER:
			case Common::PASSWORD_NOT_COMPLEX:
				return Redirect::back()->withInput()->with('error', Lang::get($response));

			case Password::PASSWORD_RESET:
				return Redirect::to('/')->with('success', $message);
		}
	}
		public function useraccessrequest()
	{	$data=null;
		return View::make('password.access_request')
					->with('data',$data);
	}

	public function user_access_request_store()
	{	
		$subject = \Setting::where('name', 'new_user_access_request_email_subject')->first()->value;
		$body = \Setting::where('name', 'new_user_access_request_email_body')->first()->value;
		
		 
		$data=Input::all();

		if(isset($data['supplier_other_type']) && !empty($data['supplier_other_type'])){
			 array_push($data['supplier_type'] ,$data['supplier_other_type']);
		}

		$validator = Validator::make($data,UserAccessRequest::$rules);
	
			if (count($validator->messages())==0)
			{   
				$new_user_request=\UserAccessRequest::Create(['first_name'=>$data['first_name'],
												    'last_name'=>$data['last_name'], 
												    'company_name'=>$data['company_name'], 
												    'address_line1'=>$data['addressline1'],
												    'address_line2'=>$data['addressline2'], 	
												    'city'=>$data['city'],
												    'country'=>$data['country'],
												    'email'=>$data['email'], 
												    'microsoft_contact'=>$data['microsoft_contact'],
												    'microsoft_contact_email'=>$data['microsoft_contact_email'],
												    'supplier_type'=>json_encode($data['supplier_type']),
												    'supplier_other_type'=>''
    												]);
					 
					$tokens=[
						'%username%'=>$new_user_request->first_name.''.$new_user_request->last_name, 
						'%company_name%'=>$new_user_request->company_name, 
						'%address%'=>$new_user_request->address_line1.''.$new_user_request->address_line2, 
						'%country%'=>$new_user_request->country, 
						'%city%'=>$new_user_request->city, 
						'%email%'=>$new_user_request->email, 
						'%microsoft_contact%'=>$new_user_request->microsoft_contact, 
						'%microsoft_contact_email%'=>$new_user_request->microsoft_contact_email, 
						'%supplier_type%'=>implode(', ',json_decode($new_user_request->supplier_type))
					];
					 
					$body = str_replace(array_keys($tokens), array_values($tokens), $body);
					$users=["mscss@microsoft.com"=>'MSCSS Microsoft',"sccg@microsoft.com"=>'SCCG Microsoft'];
					$params = [
						'to' => $users,
						'subject' => $subject,
						'body' =>$body,
					];
					 
					Emails::sendNotification($body, $params);
					
					$path =  storage_path().'/mail_trigger/'.'NewAccessRequest(RequestId-'.$new_user_request->id.')generated.txt';
					 
					$content = json_encode($params);
					\File::put($path,$content);
				return Redirect::back()
								->with('success', 'New User Access Request Sent successfully.');
			}
			else
			{	 
				return Redirect::back()
						->withInput()
						->withErrors($validator->messages());
			}
		
		

	}

}
