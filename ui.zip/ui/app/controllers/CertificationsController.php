<?php

use MSLST\Constants\Site;
use MSLST\Helpers\Certifications;

class CertificationsController extends \BaseController {

    /**
     * Instantiate a new CertificationsController instance.
     */
	public function __construct()
	{
		$this->beforeFilter(function ($route){
			if (!Auth::user()->isAdmin())
			{
				App::abort(404);
			}
		});

		$this->certification_groups = ['' => ''] + Site::$CERTIFICATION_GROUPS;
		$this->availabilities = ['' => ''] + Site::$CERTIFICATION_AVAILABILITIES;
	}

	/**
	 * Display a listing of the resource.
	 * GET /certifications
	 *
	 * @return Response
	 */
	public function index()
	{
		$certifications = Certification::all();

		return View::make('certifications.index')
				->with('certification_groups', $this->certification_groups)
				->with('certification_availabilities', $this->availabilities)		
				->with('certifications', $certifications);
	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /certifications/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$certification = Certification::findOrFail($id);

		return View::make('certifications.edit')
				->with('certification', $certification)
				->with('certification_group', $this->certification_groups[$certification->certification_group_id])
				->with('certification_availabilities', $this->availabilities);		
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /certifications/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$certification = Certification::findOrFail($id);
		
		$rules = Certification::$rules;
		$rules['name'] .= ','. $id;
		$rules['availability'] .= implode(',', array_keys($this->availabilities));
		$validator = Validator::make(Input::all(), $rules);
		$passes = $validator->passes();
		$messages = $validator->messages();

		if (Certifications::isCertificationAssigned($id) && 
			($certification->availability != Input::get('availability')))
		{
			$passes = false;
			$messages->add('text', 'Cannot change availability, this certification is already mapped to questions.');
		}

		if ($passes)
		{
			$certification->name = Input::get('name');
			$certification->availability = Input::get('availability');
			$certification->save();

			return Redirect::route('certifications.index')
					->with('success', 'Certification updated successfully.');
		}
		else
		{
			return Redirect::back()
				    ->withInput()
				    ->withErrors($messages);
		}
	}
}