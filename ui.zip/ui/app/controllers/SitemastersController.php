<?php
use MSLST\Helpers\Lists;
use MSLST\Helpers\Coordinate;
use MSLST\Helpers\Sitemasters;
use MSLST\Helpers\Common;
use MSLST\Helpers\Questions;
use MSLST\Helpers\Emails;
use Carbon\Carbon;
use Knp\Snappy\Pdf;
class SitemastersController extends \BaseController {

	/**
	 * Instanite for SitemastersController Instance
	 *
	 **/
	public function __construct()
	{
		//self::excelimport();

		if (!Auth::User()->access_sitemasters == 1) App::abort(403);
	}


	/**
	  *
      * Leak Risk Attachment path
	**/

	public static $leak_attachment_path = 'files/sitemasters/leak_risk';
	
	
	/**
	 *
	 * inspection path
	 **/
	
	public static $pr_files_path = 'files/sitemasters/inspection_temp';


	/**
	  *
      * P+R Insepection Severity
	**/

	public static $PR_Severity = [1=>'Urgent',2=>'High',3=>'Medium',4=>'Low','ClassName'=>['Urgent'=>'sev_urg_class','High'=>'sev_hig_class','Medium'=>'sev_mid_class','Low'=>'sev_low_class']];


	/**
	 * Display a listing of the Sitemasters.
	 * GET /Sitemasters
	 *
	 * @return Response
	 */
	public function index() {	
 		 //ini_set('max_execution_time', 4500);
 		//self::excelimport_LeakPreventionQuestion();

 		//self::excelimport();

		if (!Auth::User()->access_sitemasters) App::abort(403);

		//$supplier_type = Lists::getSiteMasterSplyType();
		$channel_manager = Lists::getSiteMasterChangeManager();

		$usrregion =  [];
		if (!Auth::User()->isAdmin() && !Auth::User()->isManager() ) {
			 $usrregion = Lists::getUserRegion(Auth::User()->id);
		}
		$supplier_type=\MSLST_Site::$SUPPLIER_TYPE;				
		$users = Lists::getAuditorsList();			
		$regions = Lists::getRegionsList($usrregion);
		$countries = Lists::getCountriesList();
		$RequestData = Input::all();
		$sitemasters = Sitemasters::getFilteredSitemasters($RequestData);

		if(!empty($RequestData['region'])){
			$regions_country[]  =  $RequestData['region'];
			$countries =  Lists::getCountriesList($regions_country[0]);
		}
		$result = Sitemaster::with(['region','user','country'])->get();

		 return View::make('sitemasters.index')
					->with('users', $users)
					->with('channel_manager', $channel_manager)
					->with('supplier_type', $supplier_type)
					->with('regions', $regions)
					->with('countries', $countries)
					->with('sitemasters', $sitemasters);
					 
	}
	
	public function create($step = 0) {
		if (!Auth::User()->isAdmin() && !Auth::User()->access_sitemasters) App::abort(403);
			
		switch(intval($step))
		{
			case 0:
				$data = Sitemasters::getSitemasterStepData('basic_information');
				return self::basic_information_form($data);
			case 1:
				$data = Sitemasters::getSitemasterStepData('site_information');
				return self::site_information_form($data);
			case 2:
				$data = Sitemasters::getSitemasterStepData('contact_information');
				return self::contact_information_form($data);
			case 3:
				$data = Session::get('sitemasters');
				return self::summary_list($data);
		}
	}
	
	public static function basic_information_form($data, $edit = false) {
		$usrregion = UserRegion::select('region_id')
							   ->where('user_id',\Auth::user()->id)
				  			   ->Lists('region_id');
		$supplier_type=\MSLST_Site::$SUPPLIER_TYPE;					   
		if(\Auth::User()->isAdmin())	$usrregion = '';
		
		$regions = Lists::getRegionsList($usrregion);
		$regions_json = json_encode(Lists::getRegionCountriesList($usrregion));
		return View::make('sitemasters.basic_information')
				->with('regions', $regions)
				->with('countries', [])
				->with('regions_json', $regions_json)
				->with('edit', $edit)
				->with('supplier_type',$supplier_type)
				->with('data', $data);
	}

	/**
	 * Show Sites Information .
	 *
	 * @return Response
	*/
	public static function site_information_form($data, $edit = false)
	{	
		$lineofbusiness = \MSLST_Site::$LINE_OF_BUSINESS;
		$process = \MSLST_Site::$SITE_PROCESS;
		
		return View::make('sitemasters.site_information')
				->with('edit', $edit)
				->with('lineofbusiness',$lineofbusiness)
				->with('process',$process)
				->with('data', $data);
	}
	public static function contact_information_form($data, $edit = false)
	{
		return View::make('sitemasters.contact_information')
				->with('edit', $edit)
				->with('data', $data);
	}
	public static function summary_list($data)
	{
		$country  = Lists::getCountriesname($data['basic_information']->country);
		$region = Lists::getRegionsname($data['basic_information']->region);
		$coordinates = Coordinate::convertToWGS84($data['basic_information']->coordinates);
		return View::make('sitemasters.summary')
					->with('country',$country)
					->with('region',$region)
					->with('coordinates', $coordinates)
					->with('data',$data);
	}

	public function show($id){	

 
		$id = intval($id);
		$sitemaster = Sitemaster::with(['region','user','country','sitemaster_log'])->findOrFail($id);
		
		$user_association = Sitemasters::GetAssociatedUser($id);
		
		/* Some Basic CA details*/
			$basic_ca = $this->basic_detail($id);

		/*Start Leak Prevention*/
			$lk_data = $this->leak_prevention_assessments($id,$sitemaster);   /*End Leak Prevention*/
	    /*Start P_R Inspection*/
	   		$pr_data = $this->pr_insepection($id);/*End P_R Inspection*/
 
 	 
		$coordinates = Coordinate::convertToWGS84($sitemaster->coordinates);

		return View::make('sitemasters.show')
					->with('coordinates', $coordinates)
					->with('sitemaster',$sitemaster)
					->with('basic_ca',$basic_ca)
					->with('user_assoc',$user_association)
					->with('leak_risk_analysis',$lk_data['leak_risk_analysis'])
					->with('business_assets',$lk_data['business_assets'])
					->with('business_risk',$lk_data['business_risk'])
					->with('business_lob',$lk_data['business_lob'])
					->with('business_actions',$lk_data['business_actions'])
					->with('assessment_data',$lk_data['assessment_data'])
					->with('activities',$lk_data['business_activity'])
					->with('leak_prevention',$lk_data['leak_prevention'])
					->with('business_activities',$lk_data['business_activity'])
					->with('categories',$lk_data['categories'])
					->with('answers', $lk_data['answers'])
					->with('questions',$lk_data['questions'])
					->with('leak_incident_history',$lk_data['leak_incident_history'])
					->with('lp_corrective_action' ,$lk_data['lp_corrective_action'])
					->with('CA', $pr_data['CA'])
					->with('insp_main_data', (count($pr_data['inspction_main']))?$pr_data['inspction_main'][0]: '')
					->with('prlogs', $pr_data['prlogs'])
					->with('PR_Severity',self::$PR_Severity)
					->with('list_inspector',$pr_data['list_inspector']);
			
	}


	/**
	 *  basic wizard detail
	 *
	 *
	 **/

	public function basic_detail($sid){

		$ca = Sitemasters::getPrCADetail($sid);

		return $ca;
	}


	/**
	 * Leak Prevention Assesments Module
	 * Input as SiteMaster data($sitemaster) and  id ($id)
	 * 
	 * Output returns as $results with leak_risk_analysis, leak_prevention ,leak_incident_history ,  questions ,categories & answers
	 **/


	private function leak_prevention_assessments($id,$sitemaster){
		$result = [];
		$result['leak_risk_analysis'] = SiteLeakRiskAnalysis::with('sitemaster','site_business_activity')->select('id','sitemaster_id','activity_id','asset_id','lob_id')->where('sitemaster_id',$id)->get()->all();
		$result['leak_prevention']    = SiteLeakPreventionAssessment::with(['sitemaster','site_leak_risk_analysis','site_business_risk','user'])
												   ->select('id','sitemaster_id','leak_id','risk_id','risk','action_id','action_name','action_description','status','status_date','file_name','file_description','verified_by','verified_status','verified_date','inc_id','sort','detail_comment_description')
												   ->where('sitemaster_id',$id)
												   ->orderBy('sort')
												   ->orderBy('action_id')
												   ->get();
		$result['business_activity'] = SiteBusinessActivity::select('id','name')->lists('name','id');
		$result['business_assets']   = Lists::getBusinessAssets($result['business_activity'],'SiteBusinessAsset');
		$result['business_lob']      = Sitemasters::getBusinessLob();
		$result['business_risk']     = Lists::getBusinessRisk($result['business_assets']['assetsId'],'SiteBusinessRisk');
		$result['business_actions']  = Lists::getBusinessAction($result['business_risk']['riskId'],'SiteBusinessAction');

		$result['lp_corrective_action'] = Sitemasters::getLPCorrectiveAction($id);

		//$leak_incident_history = SiteLeakIncidentHistory::where('sitemaster_id',$id)->orderBy('created_at')->get();

		$result['leak_incident_history'] = SiteLeakIncidentHistory::select(Sitemasters::$select_leak_incident_history)
														->leftJoin('site_leak_prevention_assessments','site_leak_incident_histories.id','=','site_leak_prevention_assessments.inc_id')
														->where('site_leak_incident_histories.sitemaster_id',$id)->orderBy('site_leak_incident_histories.created_at')->get();
												       
		$result['questions']=SiteBusinessQuestion::with('categories')->get();

		foreach ($result['questions'] as  $ques_val) {
			 $result['question'][$ques_val['id']] = $ques_val;
		}
		$result['questions'] = null;
		$result['questions']  = $result['question'];

		$data=Lists::getBusinessQuestionsList($id,'Site');
		$results['questions']['activities_id']=$data['activities_id'];
		 
		$assessment_data =[];
		$activity_key=0;
    	$assessment_data[$activity_key]=SiteBusinessAnswer::select('self_answer_id','self_comment','onsite_answer_id','onsite_comment','sitemaster_id'
    		,'question_id','ms_id','activity_id')->where(['sitemaster_id'=>$id,'activity_id'=>$activity_key])->get();
        $assessment_status='None';
		$assessment_score='0%';
		if($sitemaster['self_assessment_score'] != 0)
		{
			$assessment_status = 'SA only';
			$assessment_score = ceil($sitemaster['self_assessment_score']).'%';
		}
		if($sitemaster['onsite_assessment_score'] != 0)
		{	if($sitemaster['self_assessment_score']  != 0)
			{
				$assessment_status ='SA'.' + '.'OSA';
				$assessment_score.=' + '.ceil($sitemaster['onsite_assessment_score']).'%';
				
			}
			else{
			$assessment_status = 'OSA only';
			$assessment_score = ceil($sitemaster['onsite_assessment_score']).'%';
			}
		}
		
		$result['assessment_data'] = $assessment_data;

		$sitemaster->assessment_status=$assessment_status;
		$sitemaster->assessment_score=$assessment_score;
		$result['categories']=Lists::getCategoryList();
		$result['answers'] = Lists::getAnswersList();


		return $result;

	}

	/**
	 * P+R Inspection Module
	 * Input as SiteMaster id => $id
	 * 
	 * Output returns as $results with List of inpection , corrective Action and Logs
	 **/


	private function pr_insepection($id){

		$results = [];
		$results['inspction_main']  = [];
		$results['CA'] = [];
		$results['prlogs'] = [];

		$results['list_inspector'] = Sitemasters::ListInsepector($id);

		if( isset($results['list_inspector']) && !empty($results['list_inspector'])){
			$results['inspction_main'] = Sitemasters::SiteInspectionMain($id,Input::get('uid'));


			$results['CA'] = Sitemasters::SiteCA($id,Input::get('uid'),(count($results['inspction_main']))?$results['inspction_main'][0]['id']:'');

			$results['prlogs'] =SitePrLog::with('user','sitemaster')->where('sitemaster_id',$id)->orderby('updated_at','DESC')->get();
		}

		return $results;
	}

	

	public function edit($id, $step = 0)
	{
		if (!Auth::User()->access_sitemasters) App::abort(403);

		switch(intval($step))
		{
			case 0:
				$data = Sitemasters::getSitemasterEditData($id, 'basic_information');
				return self::basic_information_form($data, true);
			case 1:
				$data = Sitemasters::getSitemasterEditData($id, 'site_information');
				return self::site_information_form($data, true);
			case 2:
				$data = Sitemasters::getSitemasterEditData($id, 'contact_information');
				return self::contact_information_form($data, true);
			
		}
		
	}


	public function update($id)
	{
		if (!Auth::User()->access_sitemasters) App::abort(403);
		
		switch(intval(Input::get('step')))
		{
			case 0:
				$validator = Validator::make(Input::all(), Sitemaster::$sitemasters_basic_info_rules, Sitemaster::$messages);
				$step = 'basic_information';
				break;
			case 1:
				$validator = Validator::make(Input::all(), Sitemaster::$sitemasters_information_rules, Sitemaster::$messages);
				$step = 'site_information';
				break;
			case 2:
				$validator =Validator::make(Input::all(), Sitemaster::$sitemasters_contact_details_rules, Sitemaster::$messages);
				$step = 'contact_information';
				break;
			
		}
		if(!empty($validator))
		{
			if ($validator->passes())
			{	$array = Input::all();
				if(!Input::has('supplier_handle') && intval(Input::get('step')) == 1) {
			    	$array['supplier_handle'] = 0;
			    	Input::get('supplier_handle',0);
			    }
				
				Sitemasters::setSitemasterEditData($id,$step, $array);
				return Redirect::route('sitemaster.show', $id)
						->with('success', 'Site updated successfully.');
			}
			else
			{
				return Redirect::back()
						->withInput()
						->withErrors($validator->messages());

			}
		}
		else
		{	
			Sitemasters::setSitemasterEditData($id,$step, Input::all());
				return Redirect::route('sitemaster.show', $id)
						->with('success', 'Site updated successfully.');
		
		}
	}
	
	/**
	 * Checking Mail configuration
	 *
	 **/
 
	public function store() {
		if (!Auth::User()->isAdmin() && ! Auth::User()->access_sitemasters) App::abort(403);

		switch(intval(Input::get('step')))
		{
			case 0:
				$validator = Validator::make(Input::all(), Sitemaster::$sitemasters_basic_info_rules, Sitemaster::$messages);
				$step = 'basic_information';
				$next = 'sitemaster/create/1';
				break;
			case 1:
				$validator = Validator::make(Input::all(), Sitemaster::$sitemasters_information_rules, Sitemaster::$messages);
				$step = 'site_information';
				$next = 'sitemaster/create/2';
				break;
			case 2:
				$validator =Validator::make(Input::all(), Sitemaster::$sitemasters_contact_details_rules, Sitemaster::$messages);
				$step = 'contact_information';
				$next = 'sitemaster/create/3';
				break;
			case 3:
				Sitemasters::saveSitemasterData();
				return Redirect::to('sitemaster')
								->with('success', "Site created successfully.");
		}
		if(!empty($validator))
		{
			if ($validator->passes())
			{   
				$array = Input::all();
			    if(!Input::has('supplier_handle') && intval(Input::get('step')) == 1) {
			    	$array['supplier_handle'] = 0;
			    	Input::get('supplier_handle',0);
			    }
				$data = Sitemasters::setSitemasterStepData($step, $array);
				return Redirect::to($next);
			}
			else
			{
				return Redirect::back()
						->withInput()
						->withErrors($validator->messages());
			}
		}
		else
		{ 
			$data = Sitemasters::setSitemasterStepData($step, Input::all());
			return Redirect::to($next);
		}
	}


	/**
	 *  Leak Prevention
	 *
	 **/


	/**
	 * @params
	 *
	 * @ return $results
	 **/

	public function Leak_Risk_Analysis($id = null){
		$data = Input::all();
		$params = [];

		


		switch ($data['option']) {
					case  'add':
							$params = self::arrangeArrayLeakPrevention($data,'leak');
							$params['sitemaster_id'] = $data['sid'];
							$params['sort'] = 2;
							SiteLeakPreventionAssessment::create($params);
					    break;
					case 'edit':
 
	      				 $params = self::arrangeArrayLeakPrevention($data,'leak');
						 SiteLeakPreventionAssessment::where('id',$data['id'])->update($params);	
						
						break;
					case 'exist_analysis':

						$id = $data['ids'];
						$exist = json_decode($data['risk_analys_exist']);
						$new = json_decode($data['risk_analys_new']);

						/*Updating existing Risk*/
						if(!empty((array)$exist )) { 
						    
						    $undelete_id = [];
						 	$exist_arry = [];

						 	foreach ($exist as $rk => $rv) {
						 		    SiteLeakRiskAnalysis::where('sitemaster_id',$id)
						 		    				->where('id',$rk)
						 		    				->update([
						 		    						   'activity_id' => $rv->busines,
															   'asset_id' => json_encode($rv->assets),
															   'lob_id' => json_encode($rv->lob)
														    ]);
						 		    $exist_arry['asset_id'][] = $rv->assets;
									$exist_arry['activity_id'][] = $rv->busines;
									$exist_arry['lob_id'][] = $rv->lob;
									$exist_arry['LeakRiskAnalysis_id'][] = $rk;

						 		    $undelete_id[] =  $rk;
						 	}
						 	$exist_arry['sitemaster_id'] = $data['ids'];


						 	/*Delete Leak Risk id from undeleted id */
						 	if(!empty($undelete_id)){
						 		SiteLeakRiskAnalysis::whereNotIn('id',$undelete_id)
						 						->where('sitemaster_id',$id)
						 						->delete();

						 		SiteLeakPreventionAssessment::whereNotIn('leak_id',$undelete_id)
						 						->where('sitemaster_id',$id)
						 						->delete();
						 	}
							
							Sitemasters::SaveActionPlan($exist_arry,'exist');
						}

 
						/* Creating New Leak Risk */
						if(!empty((array)$new)) {  
 				 
							 $arry = [];

							 foreach($new as $rk=>$rv){
									  	$risk = SiteLeakRiskAnalysis::create([
									  	 						 'sitemaster_id' => $id,
									  	 						 'activity_id' => $rv->busines,
																 'asset_id' => json_encode($rv->assets),
																 'lob_id' => json_encode($rv->lob)
																 ]);
									  	$arry['asset_id'][] = $rv->assets;
									  	$arry['activity_id'][] = $rv->busines;
									  	$arry['lob_id'][] = $rv->lob;
									  	$arry['LeakRiskAnalysis_id'][] = $risk->id;
						     }

						     $arry['sitemaster_id'] = $data['ids'];
						   
						     Sitemasters::SaveActionPlan($arry,'new');
						 }

						 break;
					case 'delete_all':
							SiteLeakRiskAnalysis::where('sitemaster_id',$data['id'])->delete(); // Soft delete the old create id
							SiteLeakPreventionAssessment::where('sitemaster_id',$data['id'])->whereNotNull('leak_id')->delete(); // Soft delete the old create id
							SiteLpCorrectiveAction::where('site_master_id',$data['id'])->delete(); // Soft delete the old create id
							//BusinessAnswer::where('sitemaster_id',$data['id'])->delete();
						 break;
					case 'delete':
 							SiteLeakPreventionAssessment::where('sitemaster_id',$data['supplier_id'])->where('id',$data['leak_id'])->delete();
 		 				 break;
					default:
						 
						break;
		}		
		 
		 

	}

	/**
	 * @params
	 *
	 * @ return $results
	 **/

	public static function arrangeArrayLeakPrevention($data,$type=null){
		$params = [];
		 
		switch($type){
			case 'leak':
						if(\Auth::user()->isManager() && !empty($data['verified'])) {
									if( $data['verified'] == 'yes' || $data['verified'] == 'no'){
												$params['verified_by'] =  Auth::user()->id;
												$params['verified_status'] =  $data['verified'];
					      						$params['verified_date'] = new \Carbon\Carbon;
					      			}
					    }

					    if(\Auth::user()->id == $data['user_id']) {
					    			if($data['addtype'] == 'new'){
												$params['risk'] =  $data['risk'];
												$params['action_name'] =  $data['action'];
												$params['action_description'] =  $data['action_description'];
									}
									if($data['status'] != 'Not Started') {
												$params['status_date'] =  new \Carbon\Carbon;
									}
									$params['status'] =  $data['status'];
									if(!empty($data['action_comment_detail'])){
										$params['detail_comment_description'] =  $data['action_comment_detail'];
									}else{
										$params['detail_comment_description'] = '';
									}
					    }


					    if(Input::hasFile('file')){
					    	$file  		  =	$data['file'];
					    	$Originalname = $file->getClientOriginalName();
					    	$newname 	  = sha1(time().openssl_random_pseudo_bytes(10));
					    	$mimetype     = $file->getMimeType();
					    	$path 		  = storage_path().'/'.self::$leak_attachment_path;
					    	$file->move($path,$newname);

							$params['file_name'] =  $path.'/'.$newname;
							$params['file_description'] = $Originalname;
							$params['file_type'] =  $mimetype;
							 
					    }

						break;
			case 'incident':
						//if($data['addtype'] != 'predefined'){
			 			   $params['risk']                = $data['title'];
						   $params['action_name']         = $data['corrective_action_title'];
					 	   $params['action_description']  = $data['corrective_action_description'];
					 	//}
						  // $params['inc_id']      = $data['sid'];
						break;
		 }

	    return $params;
	}


	/**
	 *
	 * @params
	 *
	 * @return $results
	**/
	public function leak_incident_history(){

		$data = Input::all();
		$params = [];

		switch ($data['option']) {
			case 'add': 
					/*Insert in leak History */	
				    $leak_inc = SiteLeakIncidentHistory::create([
				    			'sitemaster_id'=> $data['sid'],
								'title' => $data['title'],
								'incident_date' => new \Carbon\Carbon($data['incident_date']),
								'incident_type'=> $data['type'],
								'root_cause' => $data['root_cause'],
								'corrective_action_title' => $data['corrective_action_title'],
								'corrective_action_description' => $data['corrective_action_description'],
								'supplier_contact' => $data['supplier_contact'],
								'deadline_date' => new \Carbon\Carbon($data['deadline_date']),
								]); 
					/*Insert in leak Prevention Assement*/			
				    $params['risk']   = $data['title'];
				    $params['action_name'] = $data['corrective_action_title'];
				    $params['action_description'] = $data['corrective_action_description'];
				    $params['sitemaster_id'] = $data['sid'];
				    $params['status'] = 'Not Started';
				    $params['sort'] = 3;
				    $params['inc_id'] = $leak_inc->id;
				    SiteLeakPreventionAssessment::create($params);
				break;
			case 'edit': 

						 $params_history = self::arrangeArrayLeakIncident($data);

						 SiteLeakIncidentHistory::where('id',$data['sid'])->update($params_history);

						 $params_leak = self::arrangeArrayLeakPrevention($data,'incident');

						 SiteLeakPreventionAssessment::where('inc_id',$data['sid'])->update($params_leak);
						  
			    break;
			    case 'delete':	

 					if($data['inc']['login_user_id'] == $data['inc']['supplier_user_id']){
	
							SiteLeakIncidentHistory::where('id',$data['inc']['incident_id'])->where('sitemaster_id',$data['inc']['supplier_id'])->delete();
				 
				 			SiteLeakPreventionAssessment::where('inc_id',$data['inc']['incident_id'])->where('sitemaster_id',$data['inc']['supplier_id'])->delete();
				 	
 		 					return 'done';
 		 			}else{
 	
 		 					return 'false';
 	
 		 			}
		  		 break;

			default:
					# code...
				break;
		}
	}

	/**
	 * @params
	 *
	 * @ return $results
	 **/

	public static function arrangeArrayLeakIncident($data){
		$params = [];


			    if(\Auth::user()->id == $data['user_id']) {
								$params['title'] =  $data['title'];
								$params['incident_date'] = new \Carbon\Carbon($data['incident_date']);
	      						$params['incident_type'] = $data['type'];
	     						$params['root_cause'] =  $data['root_cause'];
								$params['corrective_action_title'] =  $data['corrective_action_title'];
								$params['corrective_action_description'] =  $data['corrective_action_description'];
								$params['supplier_contact'] =  $data['supplier_contact'];
								$params['deadline_date'] =  new \Carbon\Carbon($data['deadline_date']);
	    		}
 
 

	    return $params;
	}

	/**
	 * @params post
	 *
	 **/
	static public function leakPreventionStatus(){
		$data = Input::all();
		$params = [];

		!empty($data['option']) ? $data['option'] : $data['option'] = 'save';

		switch ($data['option']) {
			case 'deter_overall_status':
					$params['determined_overall_status'] = $data['status'];	
				break;
			default:
				if(!empty($data['sid']) && !empty($data['sumary'])){
					$params['leak_prevention_summary'] = $data['sumary'];
				}
			break;
		}
		
		Sitemaster::where('id',$data['sid'])->update($params);

	}


	/**
	 * Download the sitemaster attachment.
	 * GET /sitemaster/download
	 *
	 * @return Response
	 */
	public function getDownload($fid, $id, $type)
	{
		return Common::downloadFile($fid, $id, $type);
	}

	/**
	 * Download the audit attachment.
	 * GET /sitemaster/self_assessment|onsite_assessment
	 *
	 * @return Response
	 */

	public function assessment($id)
	{
		$sitemaster = Sitemaster::with(['region','user','country'])->findOrFail($id);


		$assessment_type='none';
		if(strstr(Request::Server('REQUEST_URI'),'self') && $sitemaster->user_id == Auth::User()->id)
			$assessment_type='self';
		else if(strstr(Request::Server('REQUEST_URI'),'onsite') && (\Auth::user()->site_user_level== 'protection_pm' && $sitemaster->user_id != Auth::User()->id))
			$assessment_type='onsite';
		else 
			App::abort(403);
		
		$categories=Lists::getCategoryList('SiteBusinessCategory');
		$activities=Lists::getActivitiesList('SiteBusinessActivity');
		$questions=Lists::getBusinessQuestionsList($id,'Site');
		$answers = ['' => ''] + Lists::getAnswersList();
		 
		$assessment_data =[];
		$activity_key=0;
		$assessment_data[$activity_key]=Sitemasters::get_assessment_data($id,$activity_key);
                     
       return View::make('sitemasters.assessment')
							->with('sitemaster',$sitemaster)
							->with('categories',$categories)
							->with('assessment_type',$assessment_type)
							->with('assessment_data',$assessment_data)
							->with('activities',$activities)
							->with('answers', $answers)
							->with('questions',$questions);
				
	}
	
	public function inspection($id,$type)
	{  

		if(Request::method() == 'POST') {
				$sitemaster = Sitemaster::with(['region','user','country'])->findOrFail($id);
				$questions  = Question::with('certifications')->where('availability',4)->get();
				$inspection_method = Input::all();

				$data = null;
				
				
				$answers = [ '-1' =>'Not Answered','0' => 'N/A','1'=>'Compliant','2'=>'Not compliant'];

				if($inspection_method['inspection_type'] != 'new'){
					
					if($type=='online'){  

						$data =Sitemasters::get_inspection_data($id,$inspection_method['inspection_num']);
					}else{
						
						 
						if(!empty($_FILES['inspection']['name'])){
							  $allowed_filetypes = array('.xls','.xlsx','.ods'); // These will be the types of file that will pass the validation.
						      $filename = $_FILES['inspection']['name']; // Get the name of the file (including file extension).
							  $ext = substr($filename, strpos($filename,'.'), strlen($filename)-1); // Get the extension from the filename.
							  if(in_array($ext, $allowed_filetypes) && !empty($_FILES['inspection']['name']))
							  {	
						      		$excelFilename=storage_path().'\/files\/sitemasters\/inspection_temp\/'.\Auth::user()->id.'_'.$id.'_'.$filename;
									$uploadmessage=move_uploaded_file($_FILES['inspection']['tmp_name'],$excelFilename);

									 if($uploadmessage)
									 {
										$objReader = PHPExcel_IOFactory::createReader('Excel2007');
										$objPHPExcel = PHPExcel_IOFactory::load($excelFilename);
										 
										//Itrating through all the sheets in the excel workbook and storing the array data
										foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
										    $arrayData[$worksheet->getTitle()] = $worksheet->toArray();
										}
										
										$offlinedata=[];
										$offlinedata['id']=$id;
										 
										if(!empty($arrayData['Inspection'])){
											foreach($arrayData['Inspection'] as $inspection)
											{	
												if($inspection[0]=='id')
													continue;
												
												if($inspection[2]=='Not Answered')
													$offlinedata['answer_id'][$inspection[0]]='-1';
												elseif($inspection[2]==null||$inspection[2]=='N/A')
													$offlinedata['answer_id'][$inspection[0]]='0';
												elseif($inspection[2]=='Compliant')
													$offlinedata['answer_id'][$inspection[0]]=1;
												elseif($inspection[2]=='Not Compliant')
													$offlinedata['answer_id'][$inspection[0]]=2;

												if($offlinedata['answer_id'][$inspection[0]]==2)
												$offlinedata['comment'][$inspection[0]]=$inspection[3];

												$offlinedata['sitemaster_id'][$inspection[0]]=$id;

												$offlinedata['question_id'][$inspection[0]]=$inspection[0];
											}

											$data=(object)$offlinedata;

											if(!empty($data))
												unlink($excelFilename);

											if(Session::has('no-file'))Session::forget('no-file');
										}else{
											Session::flash('no-file', 'Incorrect Format: For exact file format please click on "Export as XLS" button.');
											$data=null;
										}

									}	
								}else{
									Session::flash('no-file', 'Please upload only file types as .xls/.xlsx/.ods format.');
									$data=null;
							  	}
							 }else{

							 		Session::flash('no-file', 'Please select the file before upload.');
									$data =Sitemasters::get_inspection_data($id,$inspection_method['inspection_num']);
							 }
					}
				}

		       return View::make('sitemasters.inspection')
									->with('sitemaster',$sitemaster)
									->with('answers', $answers)
									->with('data', $data)
									->with('type',$type)
									->with('questions',$questions);
	 }else{
	 		return Redirect::to('sitemaster/'. $id.'?pr');
	 }
				
	}

	/**
	  * online Inspection
	  *
	  *
	  **/

	public function insepectionPR($id,$type,$step){
 		if ((!Auth::User()->isAdmin() && Auth::User()->site_user_level !='csm' )) App::abort(403);
			
		switch(intval($step))
		{
			case 1:
				$data = Sitemasters::getPRInspectionStepData('InspectionMain');
				return self::inspection_main_form($id,$data);
			case 2:
				$data = Sitemasters::getPRInspectionStepData('InspectionQuestion');
				return self::inspection_question_form($id,$data);
			case 3:
				$data = Sitemasters::getPRInspectionStepData('InspectionSummary');
				return self::inspection_summary_form($id,$data);
			case 4:
				return self::onlinesummaryconfirm($id);

		}


 

	}

	/**
	 * Show Inspection Main
	 *
	 * @return Response
	*/
	public static function inspection_main_form($id,$data, $edit = false)
	{	
		$data->{"id"}=$id; 
		
		return View::make('sitemasters.prinspection_main')
				   ->with('data', $data)
				   ->with('edit', $edit);
	}


	/**
	 * Show Inspection Main
	 *
	 * @return Response
	*/
	public static function inspection_question_form($id,$data,$edit = false)
	{
		$sitemaster = Sitemaster::with(['region','user','country'])->findOrFail($id);
		$questions  = Question::with('certifications')->where('availability',4)->get();
		
		if(!$edit)
		{	
			$data = new \stdClass;
			$data->{"id"}=$id;
		}

		$PR_Severity = ['Urgent'=>'box-danger','High'=>'box-warning','Medium'=>'box-info','Low'=>'box-success'];	
		 //print "<pre>";print_r($data);print $edit;exit;
		$answers = [ '' =>'Not Answered','0' => 'N/A','1'=>'Compliant','2'=>'Not compliant'];

	 
		
		return View::make('sitemasters.prinspection_question')
					->with('sitemaster',$sitemaster)
					->with('answers', $answers)
					->with('PR_Severity',$PR_Severity)
					->with('questions',$questions)
				    ->with('data', $data)
				    ->with('edit', $edit);
	}



	/**
	 * Show Inspection Main
	 *
	 * @return Response
	*/
	public static function inspection_summary_form($id,$data,$edit = false)
	{	
	 
		$data->{"id"}=$id;
		return View::make('sitemasters.prinspection_summary')
				   ->with('data', $data)
				   ->with('edit', $edit);
	}

	/*
	*
	*Storing Self-Assessment Data
	*/
	public static function self_assessment_store($id)
	{ 
		$answers = array_keys(Lists::getAnswersList());
		$data = Sitemasters::setselfassessment($id,Input::all());
		return Redirect::to('sitemaster/'. $id.'?lpg')
				->with('success', 'Sitemaster Self-Assessment updated successfully.');
	}

	/*
	*
	*Storing Onsite-Assessment Data
	*/
	public static function onsite_assessment_store($id)
	{ 
		$answers = array_keys(Lists::getAnswersList());
		$ms_id=Auth::User()->id;
		$data = Sitemasters::setonsiteassessment($id,Input::all(),$ms_id);
		return Redirect::to('sitemaster/'. $id.'?lpg')
				->with('success', 'Sitemaster Onsite-Assessment updated successfully.');
	}

	/**
	*Toggle review status of the specified resource.
	* PATCH /suppliers/status/{id}
	*
	**/
	public function status($id,$option='inactive')
	{
		
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager() && !Auth::User()->isUser() && !Auth::User()->isSupervisor()) App::abort(403);
	
		$sitemaster = Sitemaster::findOrFail($id);

		$sitemaster->status = $option;

		$sitemaster->save();

		 return Redirect::route('sitemaster.show', [$id])
				->with('success', 'Sitemaster status changed to <b>'.ucfirst($option).'</b>.');

	}

	public function export($id,$data)
	{
		
		return Sitemasters::inspectionExportXLS($id);
	}

	public static function inspectionstore($id,$type)
	{ 
		$input_data = Input::all();
		$data = Sitemasters::setsiteinspection($id,$input_data,$type);
		return Redirect::to('sitemaster/'. $id.'?pr&uid='.Auth::user()->id.'_'.$input_data['inspection_num'])
				->with('success', 'Sitemaster '.ucfirst($type).'-Inspection updated successfully.');
	}


	/**
	 * Updating CA
	 *  
	 **/

	public function updatCAInspection(){
		$data = Input::all();
		$update_arr = [];



		switch ($data['type']) {
			case 'update':

					$log_data='';
					if(\Auth::user()->site_user_level == 'vam' || \Auth::User()->isAdmin()){
						$update_arr['vam_comments'] = $data['vam_comments'];
						$update_arr['vam_approval'] = $data['vam_approval'];
						$update_arr['vam_user_id'] = \Auth::user()->id;
						if(!empty($data['vam_comments']))$log_data='VAM Comments ';
						if(!empty($data['vam_comments']))$log_data.=', VAM approval ';
					}
					if(\Auth::user()->id ==   $data['supplier_user_id'] || \Auth::User()->isAdmin()){
						$update_arr['supplier_request_closure'] = $data['request_closure'];
						$update_arr['supplier_comments_evidence'] = $data['supplier_comments'];
						$update_arr['supplier_user_id'] = \Auth::user()->id;
						if(!empty($data['supplier_request_closure']))$log_data='Due date extension requested';
						if(!empty($data['supplier_comments_evidence']))$log_data.=', Supplier Comments updated';
					}

					if(\Auth::user()->site_user_level == 'csm' || \Auth::User()->isAdmin()){
						
						if($data['days_past_due'] != 'undefined'){
							$update_arr['days_past_due'] = $data['days_past_due'];

							if($update_arr['days_past_due'] == 15) $dat_ext_days = 21;
							if($update_arr['days_past_due'] == 30) $dat_ext_days = 40;
							if($update_arr['days_past_due'] == 60) $dat_ext_days = 80;
							if($update_arr['days_past_due'] == 90) $dat_ext_days = 108;

							$dat_now  = new \Carbon\Carbon('now');
							$dat_exten = new \Carbon\Carbon($dat_ext_days.' days');
		               		$res_date = Sitemasters::calculateweekends($dat_now,$dat_exten);
		               		$res_date = $res_date+$update_arr['days_past_due'];
		               		$due_date  = $res_date.' days';
		               		 
		            		$dt = Carbon::parse($due_date); // Check for weekends
		               		if($dt->dayOfWeek === Carbon::SATURDAY) {
		               			    $res_date = $res_date+2;
   									$due_date  = $res_date.' days';
							}else if($dt->dayOfWeek === Carbon::SUNDAY) {
									 $res_date = $res_date+1;
   									 $due_date  = $res_date.' days';
							}

							 

							$update_arr['due_date_extension'] = Carbon::parse($due_date);
							if(!empty($data['due_date_extension']))$log_data='Due date extended';
						}

					}
					 
					if(!empty($update_arr)) {
						$log_data.='updated for CA #'.$data['id'];
						SiteCorrectiveAction::where('sitemaster_id',$data['sitemaster_id'])->where('id',$data['id'])->update($update_arr);
						$prlogArray = ['sitemaster_id' => $data['sitemaster_id'],'user_id' => \Auth::User()->id,'updated_at'=> \Carbon\Carbon::parse('now'),'type'=>$log_data];
						SitePrLog::insert($prlogArray);

						$msg = "CA details updated successfully!";
						 
						/* Email Notification */

						if(!empty($data['supplier_request_closure'])  && $update_arr['supplier_request_closure'] != 'inprogress') 
							Emails::sendDueDateExtensionRequest($data,'progress');
						else
							Emails::sendDueDateExtensionRequest($data,'inprogress');/**/



					}else{

						$msg = "There is no update";
					}

				break;
			
			default:
				break;
		}

		return $msg;
	}


	/**
	 * Update the Next site visit Schedule
	 **
	 */
	 public function Site_Visit_Schedule(){

	 	$result = Sitemaster::where('id',Input::get('id'))
	 					->update(['next_site_visit'=>Input::get('next_visit_date')]);
	 	return $result;
	 }


	 /**
	  *
	  *
	  *
	  */
	 private static function excelimport(){
			//selectSheetsByIndex(1)
	 		Excel::selectSheetsByIndex(range(2,8))->load('/test_import/SCS Inspection Guide FY17.xlsx', function($reader) { //P&R Inspection.xlsx
 
	 		   $reader->noHeading();	 			
			   $results = $reader->all()->toArray();
			   $sheetarray = [];
			   $categoryarray = [];
			   $catvalue = '';
			  foreach ($results as $ky => $sheetvalue){
			  	foreach(array_slice($sheetvalue,7) as $categoryvalue){
			  		if(empty($categoryvalue[0])) $categoryvalue[0] = $catvalue;
			  		$categoryarray['Sheet'.$ky][] = array_slice($categoryvalue,0,9);
			  		if(isset($categoryvalue[0]) && !empty($categoryvalue[0])) $catvalue = $categoryvalue[0];
			  	}
			  }

			  $reader->each(function($sheet){
			  	$sheet = (array)$sheet;
			  	$question_data = array_slice(array_values(array_slice($sheet,1))[0],2);
			  	foreach ($question_data as $key => $value) {
			  				$question[$key]['sub_section'] = $question_data[$key][0]?:$sub_section;
			  				$question[$key]['pr_reference'] = $question_data[$key][1];
					  		$question[$key]['pr_text'] = $question_data[$key][2];
					  		$question[$key]['pr_severity'] = $question_data[$key][3];

					  		if(!empty($question_data[$key][0])) $sub_section = $question_data[$key][0];

					  		Question::create([
									'text' => $question[$key]['pr_text'],
									// 'order' => intval(Input::get('order')),
									'order' => 1,
									'availability' => '4',
									'is_archived' =>'0',
									'is_mandatory' => '1',
									'subsection' => $question[$key]['sub_section'],
									'reference' => $question[$key]['pr_reference'],
									'severity_text' => $question[$key]['pr_severity'],
									'version' =>'v10',
							]);
			  		}	

			  		
			  	 
			  });
			  
			}, 'UTF-8');
				echo "P+R Inspection successfully";
			exit;

	 }


	  /**
	  *
	  *
	  *
	  */
	 private static function excelimport_LeakPreventionQuestion(){
			//selectSheetsByIndex(1)
	 		Excel::selectSheetsByIndex(range(1,2))->load('/test_import/LP questionnaire for SCSS 18th May 2016 V2.ods', function($reader) { //P&R Inspection.xlsx
 
	 		   $reader->noHeading();	 			
			   $results = $reader->all()->toArray();
			   $sheetarray = [];
			   $categoryarray = [];
			   $catvalue = '';
			 

			  $reader->each(function($sheet){
			  	$sheet = array_values(array_slice((array)$sheet,1));
			     foreach($sheet[0]  as $lk_ky=>$lk_val){
			     	if($lk_ky == 0) continue;
			     	 
						$leak_question['order'] = $lk_val[0];
						$leak_question['name']  = $lk_val[3]; 
						$leak_question['availability'] = '';
						$leak_question['category']   = $lk_val[2]; 
						$leak_question['activities'] = '["'.str_replace(' ','","',trim($lk_val[1])).'"]';  
						$leak_question['category_id'] = $lk_val[4];  
						$leak_question['activity_id'] = '["'.str_replace(' ','","',trim($lk_val[1])).'"]';
						$leak_question['severity_text'] = $lk_val[5];  
						 SiteBusinessQuestion::create($leak_question);
			     	 
			     }

			     //print "<pre>"; print_r($leak_question); 
			  		echo "Leak prevention Question is Added successfully";exit;
			  	 	 
			  });
			  
			}, 'UTF-8');

			

	 }







	 /**
	  *
	  *
	  *
	  */
	 public function exportpdf($id){

		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager() && !Auth::User()->isUser() && !Auth::User()->isSupervisor()) App::abort(403);
	
 		$id = intval($id);
		$sitemaster = Sitemaster::with(['region','user','country','sitemaster_log'])->findOrFail($id);

		/*Start Leak Prevention*/
			$lk_data = $this->leak_prevention_assessments($id,$sitemaster);   /*End Leak Prevention*/
	    /*Start P_R Inspection*/
	   		$pr_data = $this->pr_insepection($id);/*End P_R Inspection*/


		$coordinates = Coordinate::convertToWGS84($sitemaster->coordinates);

	    $data = ['sitemaster'=>$sitemaster,
				'leak_risk_analysis'=>$lk_data['leak_risk_analysis'],
				'business_assets'=>$lk_data['business_assets'],
				'business_risk'=>$lk_data['business_risk'],
				'business_actions'=>$lk_data['business_actions'],
				'assessment_data'=>$lk_data['assessment_data'],
				'activities'=>$lk_data['business_activity'],
				'leak_prevention'=>$lk_data['leak_prevention'],
				'business_activities'=>$lk_data['business_activity'],
				'categories'=>$lk_data['categories'],
				'answers'=>$lk_data['answers'],
				'questions'=>$lk_data['questions'],
				'leak_incident_history'=>$lk_data['leak_incident_history'],
	   			'lp_corrective_action' => $lk_data['lp_corrective_action'],
	   			'CA'=>$pr_data['CA'],
				'prlogs'=> $pr_data['prlogs'],
				'PR_Severity'=>self::$PR_Severity,
				'list_inspector'=>$pr_data['list_inspector'],
				'coordinates' => $coordinates
				];

	    $pdf = \App::make('dompdf'); $pdf->loadView('sitemasters.pdf_report', $data); return $pdf->download('sitmaster_'.$id.'.pdf');

	}
	
	
	
	/**
	 * offline Inspection
	 *
	 */
	
	public function offlineconfirm(){
	
		$data = Input::all();
		if(!empty($data['addtype'])){

			$sitname_data = Sitemaster::find($data['sid']);
			Session::put('Main_Site_Name' ,$sitname_data->site_name);
			self::inspection_method($data);

		}else {

			$errormsg = [];
			$shetSitename = strtolower(trim(Session::get('Site_Name'))) ?: "";
			$MainSitname = strtolower(trim(Session::get('Main_Site_Name'))) ?: "";
			if( $shetSitename !=  $MainSitname){
				if(empty($shetSitename)) {
					$errormsg[] = "Please fill Supplier Name in the sheet";
				}else 	$errormsg[] = "Supplier Name is differ from your inspection sheet(<b>".Session::get('Site_Name')."</b>) and in the site(<b>".Session::get('Main_Site_Name')."</b>)";
			}
			$errormsg = array_merge($errormsg, Session::get('insp_main_error')?:[],Session::get('summary_main_error') );
			 
			return View::make('sitemasters.offline_summary_confirm')
			->with('insp_main_data', Session::get('insp_main_data'))
			->with('ques_ans_data',Session::get('ques_ans_data'))
			->with('summary_main_data',Session::get('summary_main_data'))
			->with('errormsg',$errormsg);
		}
			
	}


	public function onlinesummaryconfirm($id)
	{	
		$data = new \stdClass;
		$data->{"id"}=$id;
		$sitemaster_data = Session::get('sitemasters_inspection');
		//print "<pre>";print_r($sitemaster_data);exit;
		$insp_main_data = (array) $sitemaster_data['InspectionMain'];
		$ques_ans_data = (array) $sitemaster_data['InspectionQuestion'];
		$summary_main_data = (array) $sitemaster_data['InspectionSummary'];
		$edit=null;

		$insp_main_data['ins_main_name_alias_access']=json_encode($insp_main_data['ins_main_name_alias_access']);
		$insp_main_data['ins_main_inspectors']=json_encode($insp_main_data['ins_main_inspectors']);
		$summary_main_data['summ_people_interview_during_inspec']=json_encode($summary_main_data['summ_people_interview_during_inspec']);
		
		return View::make('sitemasters.offline_summary_confirm')
			->with('insp_main_data', $insp_main_data)
			->with('ques_ans_data',$ques_ans_data)
			->with('edit',$edit)
			->with('summary_main_data',$summary_main_data)
			->with('data', $data);
	}
	
 
	
	/**
	 *
	 *
	 */
	
	public static function inspection_method($data){
		$errormsg = '';
	
		switch ($data['addtype']) {
			case 'summary':
	
				$file = $data['file'];
				$original_name = $file->getClientOriginalName();
				$mime_type = $file->getMimeType();
				$newname = $file->getClientOriginalName(); //echo date('ymdhim');exit;
				$path = storage_path() .'/'.self::$pr_files_path.'/'.\Auth::User()->id;
				$file->move($path, $newname);

			 
				Excel::selectSheetsByIndex(range(0,9))->load($path.'/'.$original_name, function($reader) {
	
					$reader->noHeading();
					$reader->calculate(true);
					$inspector  = [];
	
	
	
					$reader->each(function($sheet){
						$sheet = (array)$sheet ;
						$ques_ans_data = [];
						$summary_main_data = [];
						$data  = [];
						$summary_main_error = [];
						$insp_main_error = [];
						foreach ($sheet as $key => $rows) {
	
							switch($rows){
								case "Inspection Main":
									$inspection_main = array_values(array_slice($sheet,1));
									foreach ($inspection_main as $key => $value) {
											
										$value = array_slice($value, 1);
											
										$inspector = [0 => ['firm'=>$value[1][7],'name'=>$value[1][8]],
												1 => ['firm'=>$value[2][7],'name'=>$value[2][8]],
												2 => ['firm'=>$value[3][7],'name'=>$value[3][8]],
												3 => ['firm'=>$value[4][7],'name'=>$value[4][8]],
												4 => ['firm'=>$value[5][7],'name'=>$value[5][8]]
										];
										$name_alias_access = [0 => ['name'=>$value[17][11],'alias'=>$value[17][13],'access' => $value[17][14]],
												1 => ['name'=>$value[18][11],'alias'=>$value[18][13],'access' => $value[18][14]],
												2 => ['name'=>$value[19][11],'alias'=>$value[19][13],'access' => $value[19][14]],
												3 => ['name'=>$value[20][11],'alias'=>$value[20][13],'access' => $value[20][14]],
												4 => ['name'=>$value[21][11],'alias'=>$value[21][13],'access' => $value[21][14]],
												5 => ['name'=>$value[22][11],'alias'=>$value[22][13],'access' => $value[22][14]],
												6 => ['name'=>$value[23][11],'alias'=>$value[23][13],'access' => $value[23][14]],
												7 => ['name'=>$value[24][11],'alias'=>$value[24][13],'access' => $value[24][14]],
												8 => ['name'=>$value[25][11],'alias'=>$value[25][13],'access' => $value[25][14]],
												9 => ['name'=>$value[26][11],'alias'=>$value[26][13],'access' => $value[26][14]],
												10 => ['name'=>$value[27][11],'alias'=>$value[27][13],'access' => $value[27][14]],
										];
											
										$insp_main_data['ins_main_date'] =  $value[0][2];
										$insp_main_data['ins_main_num_sep_buliding_at_this_site'] = $value[9][4];
										$insp_main_data['ins_main_num_buliding_ms_related_functions'] = $value[11][4];
										$insp_main_data['ins_main_inspectors'] = json_encode($inspector);
										$insp_main_data['ins_main_comments'] = $value[17][7];
										$insp_main_data['ins_main_num_full_time_emp_facility'] = $value[10][14];
										$insp_main_data['ins_main_supp_subcontract_handling_ms_product_ip'] = $value[12][14];
										$insp_main_data['ins_main_emp_ms_system_account'] =  $value[14][14];
										$insp_main_data['ins_main_name_alias_access'] =json_encode($name_alias_access);
										$Site_Name = $value[2][2];
	
	
										if(empty(trim($value[0][2]))) //ins_main_date
										{
											$insp_main_error[] = "Date is Missing in Inspection Main sheet";
										}
										if(empty(trim($value[9][4]))) //ins_main_num_sep_buliding_at_this_site
										{
											$insp_main_error[] = "Number of separate buildings at this site is Missing in Inspection Main sheet";
										}
										if(empty(trim($value[11][4]))) // ins_main_num_buliding_ms_related_functions
										{
											$insp_main_error[] = "Number of buildings With MS-related functions in Inspection Main sheet";
										}
										if(empty(trim($value[10][14]))) // ins_main_num_full_time_emp_facility
										{
											$insp_main_error[] = "Number of full-time employees at this facility in Inspection Main sheet";
										}
										if(empty(trim($value[12][14]))) //  ins_main_supp_subcontract_handling_ms_product_ip
										{
											$insp_main_error[] = "Supplier Subcontractor(s) Handling MS product or IP in Inspection Main sheet";
										}
										if(empty(trim($value[14][14]))) //  ins_main_emp_ms_system_account
										{
											$insp_main_error[] = "Employees with MS System Accounts in Inspection Main sheet";
										}
	
	
											
									}
									Session::put('insp_main_data', $insp_main_data);
									Session::put('insp_main_error', $insp_main_error);
									Session::put('Site_Name',$Site_Name);
									 
									break;
									//case "I":
								case "1":
								case "2":
								case "3":
								case "4":
								case "5":
								case "6":
								case "7":
									$question_data = array_slice(array_values(array_slice($sheet,1))[0],2);
	
									foreach ($question_data as $ky => $value) {
										if(isset($value[1]) && !empty($value[1])){
											$ques_ans_data[$rows][$value[1]]['ques_reference'] = $value[1];
											$ques_ans_data[$rows][$value[1]]['ques_text'] = $value[2];
											$ques_ans_data[$rows][$value[1]]['ques_severity'] = $value[3];
											$ques_ans_data[$rows][$value[1]]['ques_response'] = $value[4];
											$ques_ans_data[$rows][$value[1]]['ques_mitigating_control'] = $value[5];
											$ques_ans_data[$rows][$value[1]]['ques_issue_detail_comments'] = $value[6];
											$ques_ans_data[$rows][$value[1]]['ques_corrective_action'] = $value[7];
											//$ques_ans_data[$rows][$value[1]]['subsection'] = $value[0];
											$ques_ans_data[$rows][$value[1]]['user_id'] = \Auth::User()->id;
	
	
										}
									}
	
									Session::put('ques_ans_data'.$rows, $ques_ans_data);
									break;
								case "Summary":
	
									$summary_data = array_values(array_slice($sheet,1))[0];
	
									$people_interview = [0  => ['name'=>$summary_data[37][9],'title'=>$summary_data[37][13]],
											1  => ['name'=>$summary_data[38][9],'title'=>$summary_data[38][13]],
											2  => ['name'=>$summary_data[39][9],'title'=>$summary_data[39][13]],
											3  => ['name'=>$summary_data[40][9],'title'=>$summary_data[40][13]],
											4  => ['name'=>$summary_data[41][9],'title'=>$summary_data[41][13]],
											5  => ['name'=>$summary_data[42][9],'title'=>$summary_data[42][13]],
											6  => ['name'=>$summary_data[43][9],'title'=>$summary_data[43][13]],
											7  => ['name'=>$summary_data[44][9],'title'=>$summary_data[44][13]],
											8  => ['name'=>$summary_data[45][9],'title'=>$summary_data[45][13]],
											9  => ['name'=>$summary_data[46][9],'title'=>$summary_data[46][13]],
											10 => ['name'=>$summary_data[47][9],'title'=>$summary_data[47][13]],
											11 => ['name'=>$summary_data[48][9],'title'=>$summary_data[48][13]],
											12 => ['name'=>$summary_data[49][9],'title'=>$summary_data[49][13]],
											13 => ['name'=>$summary_data[50][9],'title'=>$summary_data[50][13]],
											14 => ['name'=>$summary_data[51][9],'title'=>$summary_data[51][13]],
											15 => ['name'=>$summary_data[52][9],'title'=>$summary_data[52][13]],
									];
									$summary_main_data['summ_company_background'] = $summary_data[15][1];
									$summary_main_data['summ_overview_inspection_work'] = $summary_data[15][9];
									$summary_main_data['summ_facility_site_desc'] = $summary_data[37][1];
									$summary_main_data['summ_people_interview_during_inspec'] = json_encode($people_interview);
	
									$summary_main_data['sc_pr_req_excepted'] =  $summary_data[8][2];
									$summary_main_data['sc_pr_req_required'] = $summary_data[8][3];
									$summary_main_data['sc_pr_req_accumulated'] = $summary_data[8][4];
									$summary_main_data['sc_pr_req_percent'] = $summary_data[8][5];
									$summary_main_data['sc_pr_score_excepted'] = $summary_data[9][2];
									$summary_main_data['sc_pr_score_required'] = $summary_data[9][3];
									$summary_main_data['sc_pr_score_accumulated'] = $summary_data[9][4];
									$summary_main_data['sc_pr_score_percent'] = $summary_data[9][5];
									$summary_main_data['sc_calulated_score'] = $summary_data[8][6];
									$summary_main_data['sc_scoring_rules_final_rating'] = $summary_data[8][15];
	
									if(empty(trim($summary_data[8][15]))) //  ins_main_emp_ms_system_account
									{
										$summary_main_error[] = "Final Rating is missing in Summary sheet";
									}
									if(trim($summary_data[8][3]) == 0)
									{
										$summary_main_error[] = "Please response any Question in sheet";
									}
	
									Session::put('summary_main_data', $summary_main_data);
									Session::put('summary_main_error', $summary_main_error);
									break;
							}
						}
	
					});
	
				}, 'UTF-8');
	
					break;
			case "confirm":
				$confirm_data = Session::get('summary_main_data') + Session::get('insp_main_data');

				$errormsg     = [];
				$sheetSitename = strtolower(trim(Session::get('Site_Name'))) ?: "";
			    $MainSitname = strtolower(trim(Session::get('Main_Site_Name'))) ?: "";

				if($sheetSitename != $MainSitname){
					$errormsg[] = "Supplier Name is differ from sheet and in the Site";
				}

				$error_data   = Session::get('summary_main_error') + Session::get('insp_main_error') + $errormsg;

				if(empty($error_data)){
	
					$confirm_data['user_id'] = \Auth::User()->id;
					$confirm_data['sitemaster_id'] = $data['sid'];
	
					$inspections =  SiteInspectionsAnswer::create($confirm_data);
	
					$confirm_ques_data = array_values(Session::get('ques_ans_data1')[1] + Session::get('ques_ans_data2')[2] + Session::get('ques_ans_data3')[3]+Session::get('ques_ans_data4')[4]+Session::get('ques_ans_data5')[5]+Session::get('ques_ans_data6')[6]+Session::get('ques_ans_data7')[7]);
	
					foreach ($confirm_ques_data as $key => $value) {
						/*$ques_data[$key]['ques_reference'] =  $value['ques_reference'];
						$ques_data[$key]['ques_severity'] =  $value['ques_severity'];
						$ques_data[$key]['ques_response'] =   $value['ques_response'];
						$ques_data[$key]['ques_mitigating_control'] =  $value['ques_mitigating_control'];
						$ques_data[$key]['ques_issue_detail_comments'] =  $value['ques_issue_detail_comments'];
						$ques_data[$key]['ques_corrective_action'] = $value['ques_corrective_action'];
						$ques_data[$key]['user_id'] =  $value['user_id'];
						$ques_data[$key]['inspection_id'] =  $inspections->id;*/

						\SiteInspectionsQuestionAnswer::create([
							'ques_reference' =>  $value['ques_reference'],
							'ques_severity' =>  $value['ques_severity'],
							'ques_response' =>    $value['ques_response'],
							'ques_mitigating_control' =>  $value['ques_mitigating_control'],
							'ques_issue_detail_comments' =>   $value['ques_issue_detail_comments'],
							'ques_corrective_action' =>$value['ques_corrective_action'],
							'user_id' =>  $value['user_id'],
							'inspection_id' =>  $inspections->id,
							'sitemaster_id' =>  $data['sid']
						]);
	
						if($value['ques_response'] == 'Does not Meet Requirement') {
							$ca_data[$key]['sitemaster_id'] =  $data['sid'];
							$ca_data[$key]['p_r_reference'] =  $value['ques_reference'];
							$ca_data[$key]['p_r_version'] =  'v10';
							$ca_data[$key]['p_r_text'] =  $value['ques_text'];
							$ca_data[$key]['inspector_comments'] =  $value['ques_issue_detail_comments'];
							$ca_data[$key]['inspector_user_id'] =  $value['user_id'];
							$ca_data[$key]['intial_due_date'] =  Carbon::parse(self::due_date_calculation($value['ques_severity']));
							$ca_data[$key]['inspection_num'] =  $inspections->id;
							$ca_data[$key]['p_r_severity']  = $value['ques_severity'];
						}
	
					}
	
					//	SiteInspectionsQuestionAnswer::insert(array_values($ques_data));
	
					 SiteCorrectiveAction::insert(array_values($ca_data));
					//print "<pre>"; print_r($sit_ca); 
					 Sitemaster::where('id',$data['sid'])->update(['last_inspection_num'=> $inspections->id]);
					echo "1"; exit;
				}else{
					echo "0"; exit;
				}
				break;
		}
	
	}
	
	/**
	 * due_date_calculation
	 * 
	 **/
	
	public static function due_date_calculation($severity){
	
		$due_date = 'now';
		$dat_now  = new \Carbon\Carbon('now');
		$severity = ucfirst(strtolower(trim($severity)));
		if($severity == 'Urgent'){
			$dat_exten = new \Carbon\Carbon('9 days');
			$res_date = Sitemasters::calculateweekends($dat_now,$dat_exten);
			$res_date = $res_date+7;
			$due_date  = $res_date.' days'; // Urgent
		}
	
		if($severity  == 'High'){
			$dat_exten = new \Carbon\Carbon('21 days');
			$res_date = Sitemasters::calculateweekends($dat_now,$dat_exten);
			$res_date = $res_date+15;
			$due_date  = $res_date.' days'; // High
		}
		if($severity  == 'Medium'){
			$dat_exten = new \Carbon\Carbon('40 days');
			$res_date = Sitemasters::calculateweekends($dat_now,$dat_exten);
			$res_date = $res_date+30;
			$due_date  = $res_date.' days'; // medium
		}
		if($severity == 'Low') {
			$dat_exten = new \Carbon\Carbon('80 days');
			$res_date = Sitemasters::calculateweekends($dat_now,$dat_exten);
			$res_date = $res_date+60;
			$due_date  = $res_date.' days'; // low
		}
	
	
		$dt = Carbon::parse($due_date); // Check for weekends
		if($dt->dayOfWeek === Carbon::SATURDAY) {
			$res_date = $res_date+2;
			$due_date  = $res_date.' days';
		}else if($dt->dayOfWeek === Carbon::SUNDAY) {
			$res_date = $res_date+1;
			$due_date  = $res_date.' days';
		}
	
		return $due_date;
	}
	
	/**
	 *  Inspection
	 *
	 **/
	public function inspections(){
		$data = Input::all();
	
		switch(Input::get('type')){
			case "delete":
				$ids = explode('_', Input::get('id'));
				Sitemasters::deleteInspection($ids[1]);
				break;
	
		}
	
	}



	/**
	 * Updating CA
	 *  
	 **/

	public function updatLPCAInspection(){
		$data = Input::all();
		$update_arr = [];

		switch ($data['type']) {
			case 'update':

					$log_data='';
					if(\Auth::user()->site_user_level == 'protection_pm' || \Auth::User()->isAdmin()){
						$update_arr['pm_comments'] = $data['pm_comments'];
						$update_arr['pm_approval'] = $data['pm_approval'];
						$update_arr['pm_user_id'] = \Auth::user()->id;
						if(!empty($data['pm_comments']))$log_data='PM Comments ';
						if(!empty($data['pm_comments']))$log_data.=', PM approval ';
					}
					if(\Auth::user()->id ==   $data['supplier_user_id'] || \Auth::User()->isAdmin()){
						$update_arr['assessment_request_closure'] = $data['request_closure'];
						$update_arr['assement_user_comments'] = $data['assement_user_comments'];
						$update_arr['assement_user_id'] = \Auth::user()->id;
						if(!empty($data['assessment_request_closure']))$log_data='Due date extension requested';
						if(!empty($data['assement_user_comments']))$log_data.=', Supplier Comments updated';
					}

					if(\Auth::user()->site_user_level == 'protection_pm' || \Auth::User()->isAdmin()){
						
						if($data['days_past_due'] != 'undefined'){
							$update_arr['days_past_due'] = $data['days_past_due'];

							if($update_arr['days_past_due'] == 15) $dat_ext_days = 21;
							if($update_arr['days_past_due'] == 30) $dat_ext_days = 40;
							if($update_arr['days_past_due'] == 60) $dat_ext_days = 80;
							if($update_arr['days_past_due'] == 90) $dat_ext_days = 108;

							$dat_now  = new \Carbon\Carbon('now');
							$dat_exten = new \Carbon\Carbon($dat_ext_days.' days');
		               		$res_date = Sitemasters::calculateweekends($dat_now,$dat_exten);
		               		$res_date = $res_date+$update_arr['days_past_due'];
		               		$due_date  = $res_date.' days';
		               		 
		            		$dt = Carbon::parse($due_date); // Check for weekends
		               		if($dt->dayOfWeek === Carbon::SATURDAY) {
		               			    $res_date = $res_date+2;
   									$due_date  = $res_date.' days';
							}else if($dt->dayOfWeek === Carbon::SUNDAY) {
									 $res_date = $res_date+1;
   									 $due_date  = $res_date.' days';
							}

							 

							$update_arr['due_date_extension'] = Carbon::parse($due_date);
							if(!empty($data['due_date_extension']))$log_data='Due date extended';
						}

					}
					 
					if(!empty($update_arr)) {
						 


						$log_data.='updated for LP CA #'.$data['id'];
						SiteLpCorrectiveAction::where('site_master_id',$data['sitemaster_id'])->where('id',$data['id'])->update($update_arr);
						$prlogArray = ['sitemaster_id' => $data['sitemaster_id'],'user_id' => \Auth::User()->id,'updated_at'=> \Carbon\Carbon::parse('now'),'type'=>$log_data];
						SitePrLog::insert($prlogArray);

						$msg = "CA details updated successfully!";
						 
						/* Email Notification */

						/*if(!empty($data['request_closure'])  && $update_arr['supplier_request_closure'] != 'inprogress') 
							Emails::sendDueDateExtensionRequest($data,'progress');
						else
							Emails::sendDueDateExtensionRequest($data,'inprogress');*/



					}else{

						$msg = "There is no update";
					}

				break;
			
			default:
				break;
		}

		return $msg;
	}

	public function inspectionprstore($id,$type) {
		if (!Auth::User()->isAdmin() && ! Auth::User()->access_sitemasters) App::abort(403);

		switch(intval(Input::get('step')))
		{
			case 1:
				$validator = Validator::make(Input::all(), Sitemaster::$InspectionMain_rules, Sitemaster::$messages);
				$step = 'InspectionMain';
				$next = 'sitemaster/prinspection/'.$id.'/create/online/2';
				break;
			case 2:
				//$validator = Validator::make(Input::all(), Sitemaster::$sitemasters_information_rules, Sitemaster::$messages);
				$step = 'InspectionQuestion';
				$next = 'sitemaster/prinspection/'.$id.'/create/online/3';
				break;
			case 3:
				$step = 'InspectionSummary';
				$next = 'sitemaster/prinspection/'.$id.'/create/online/4';
				break;
			case 4:
				$inspection_num = Sitemasters::saveInspectionData($id);
				return Redirect::to('sitemaster/'. $id.'?pr&uid='.Auth::user()->id.'_'.$inspection_num)
								->with('success', "Site P+R Inspection created successfully.");
		}
		if(!empty($validator))
		{
			if ($validator->passes())
			{   
				$data = Sitemasters::setPRInspectionStepData($step, Input::all());
				return Redirect::to($next);
			}
			else
			{	//print_r($validator->messages());exit;
				return Redirect::back()
						->withInput()
						->withErrors($validator->messages());
			}
		}
		else
		{    
			//print "<pre>";print_r(Input::all());exit;
			$data = Sitemasters::setPRInspectionStepData($step, Input::all());
			return Redirect::to($next);
		}
	}


	public function inspectionedit($id,$inspection_num,$step)
	{  
		if (!Auth::User()->access_sitemasters) App::abort(403);

		switch(intval($step))
		{
			case 1:
				$data = Sitemasters::getSitemasterInspectionEditData($id,$inspection_num, 'InspectionMain');
				return self::inspection_main_form($id,$data, true);
			case 2:
				$data = Sitemasters::getSitemasterInspectionEditData($id,$inspection_num, 'InspectionQuestion');
				return self::inspection_question_form($id,$data, true);
			case 3:
				$data = Sitemasters::getSitemasterInspectionEditData($id,$inspection_num, 'InspectionSummary');
				return self::inspection_summary_form($id,$data, true);
		}
		
	}



	public function inspectionupdate($id,$inspection_num,$step)
	{
		//print "<pre>";print_r(Input::all());exit;
		if (!Auth::User()->access_sitemasters) App::abort(403);
		
		switch(intval(Input::get('step')))
		{
			case 1:
				$validator = Validator::make(Input::all(), Sitemaster::$InspectionMain_rules,Sitemaster::$messages);
				$step = 'InspectionMain';
				break;
			case 2:
				//$validator = Validator::make(Input::all(), Sitemaster::$sitemasters_information_rules, Sitemaster::$messages);
				$step = 'InspectionQuestion';
				break;
			case 3:
				//$validator =Validator::make(Input::all(), Sitemaster::$sitemasters_contact_details_rules, Sitemaster::$messages);
				$step = 'InspectionSummary';
				break;
			
		}
		if(!empty($validator))
		{
			if ($validator->passes())
			{	
				$array = Input::all();
				Sitemasters::setSitemasterInspectionEditData($id,$inspection_num,$step, $array);
				return Redirect::to('sitemaster/'. $id.'?pr&uid='.Auth::user()->id.'_'.$inspection_num)
						->with('success', 'Site P+R Inspection updated successfully.');
			}
			else
			{
				return Redirect::back()
						->withInput()
						->withErrors($validator->messages());

			}
		}
		else
		{	
			Sitemasters::setSitemasterInspectionEditData($id,$inspection_num,$step, Input::all());
				
				return Redirect::to('sitemaster/'. $id.'?pr&uid='.Auth::user()->id.'_'.$inspection_num)
						->with('success', 'Site P+R Inspection updated successfully.');
		
		}
	}
	 



}