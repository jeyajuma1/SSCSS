<?php

use MSLST\Constants\Dashboard as Dashboard;


class HomeController extends BaseController {

	/**
	 * Display the login view.
	 *
	 * @return Response
	 */
	public function getLogin()
	{
		if (Auth::check())
		{
		 	if(!empty(Session::get('redir_url'))) 
				 $url = Session::get('redir_url');  
			else 
			 	$url = 'dashboard';

			return Redirect::to($url);
		}

		return View::make('home.login');
	}

	/**
	 * Handle the login POST request.
	 *
	 * @return Response
	 */
	public function postLogin()
	{
		$user = User::withTrashed()->where('email', Input::get('email'))->first();

		if ($user && $user->deleted_at)
		{
			$message = 'This user account has been disabled. Please contact <a href="mailto:mscss@microsoft.com">mscss@microsoft.com</a>';
		}
		else
		{
			$message = 'Invalid login credentials.';

			if (Auth::attempt(['email' => Input::get('email'), 'password' => Input::get('password')]))
			{
				$user = Auth::User();
				$user->last_login_at = new \Carbon\Carbon();
				$user->save();
				
				//User Log Storage
				\UserLog::Create([
					'user_id' => \Auth::User()->id,
					'login_at' => new \Carbon\Carbon()
				]);

				
				$setting = Setting::select('value','name')->lists('value','name');

				Session::put('settings_site_alert_option', $setting['site_alert_option']); 
				Session::put('settings_site_alert_message', $setting['site_alert_message']);
				
				return Redirect::intended('/');
			}
		}

		return Redirect::to('/')
            ->withInput()
            ->with('error', $message);

	}

	/**
	 * Display the terms and conditions view.
	 *
	 * @return Response
	 */
	public function getTerms()
	{
		return View::make('home.terms');
	}

	/**
	 * Handle the terms and conditions form POST request.
	 *
	 * @return Response
	 */
	public function postTerms()
	{
		$validator = Validator::make(
			Input::all(),
			['agree' => ['required']],
			['required' => 'You must accept the privacy policy to proceed.']
		);

		if ($validator->passes())
		{
			$user = Auth::User();
			$user->terms_accepted = 1;
			$user->save();

			return Redirect::to('/');
		}
		else
		{
			return Redirect::back()
				    ->withInput()
				    ->withErrors($validator->messages());
		}
	}

	/**
	 * Show the dashboard
	 *
	 * @return Response
	 */
	public function getDashboard()
	{
		$audits = MSLST_Dashboard::getJSFormattedAudits(Dashboard::AREA_CHART_AUDITS_COUNT);
		$incidents = MSLST_Dashboard::getJSFormattedIncidents(Dashboard::AREA_CHART_INCIDENTS_COUNT);
		$incident_status = MSLST_Dashboard::getJSFormattedIncidentStatus();
		$incident_category = MSLST_Dashboard::getJSFormattedIncidentCategory();
		$inspect_audit_status = MSLST_Dashboard::getJsFormatedInspectAudits();

		$site_inspec_notification = MSLST_Dashboard::getJsFormatInspectionData() ;// VAM Approval status and CSM Request Status

		$incident_lsp = MSLST_Dashboard::getJSFormattedIncidentsLsp();

		$site_pr_inspection = MSLST_Dashboard::getInspectionData() ;

 

		$user_status = (!Auth::User()->isUser()) ? MSLST_Dashboard::getJSFormatteduserStatus() : '[]';

 
		$recent_users = MSLST_Dashboard::getFormattedRecentUsers(
			Dashboard::RECENT_USERS_DISPLAY_COUNT,
			Dashboard::RECENT_USERS_DATE_FORMAT
		);

		$alerts = MSLST_Dashboard::getFormattedRecentAuditsIncidents(
			Dashboard::ALERTS_DISPLAY_COUNT,
			Dashboard::ALERTS_DATE_FORMAT
		);

		$oldaudits = MSLST_Dashboard::getJSFormatedOldAudits(Dashboard::OLD_AUDIT_DISPLAY_COUNT);


		$order = Auth::User()->dashboard;
		$left_order = Dashboard::$LEFT_ORDER;
		$right_order = Dashboard::$RIGHT_ORDER;

		if ($order)
		{
			$order = unserialize($order);

			if (isset($order['left']) && !empty($order['left']))
			{
				$left_order = $order['left'];
			}

			if (isset($order['right']) && !empty($order['right']))
			{
				$right_order = $order['right'];
			}
		}

		 //print "<pre>"; print_r(json_decode($incidents)->fy_date);  exit;


		return View::make('home.dashboard')
			->with('audits', $audits)
			->with('incidents', $incidents)
			->with('incident_status', $incident_status)
			->with('incident_category', $incident_category)
			->with('user_status', $user_status)			
			->with('recent_users', $recent_users)
			->with('oldaudits',$oldaudits)
			->with('inspect_audit_status',$inspect_audit_status)
			->with('incident_lsp',$incident_lsp)
			->with('site_inspec_notification',$site_inspec_notification)
			->with('site_ca_summary',$site_pr_inspection)
			->with('alerts', $alerts)
			->with('left_order', $left_order)
			->with('right_order', $right_order);
	}

	/**
	 * Returns alerts, AJAX callback
	 *
	 * @return string
	 */
	public function postAlerts()
	{
		//if (!Auth::user()->isAdmin()) App::abort(404);

		$offset = intval(Input::get('offset'));
		$response = 'No More Alerts.';

		if ($offset > 0)
		{
			$alerts = MSLST_Dashboard::getFormattedRecentAuditsIncidents(
				Dashboard::ALERTS_DISPLAY_COUNT,
				Dashboard::ALERTS_DATE_FORMAT,
				$offset * Dashboard::ALERTS_DISPLAY_COUNT
			);

			$response = '';
			foreach ($alerts as $alert)
			{
				/*$response .= "
                    <a href='{$alert['url']}' class='list-group-item'>
                        <i class='fa {$alert['icon']} fa-fw'></i> <small>{$alert['text']}</small>
                        <span class='pull-right text-muted small'><em>{$alert['date']}</em>
                        </span>
                    </a>
				";*/

				$response .="<div class='timeline-item'> 
								<div class='row'>
								<a href='{$alert['url']}'>
									<div class='col-xs-3 date'>
										<i class='fa fa-file-text'></i>
										{$alert['date']}
									</div>
							<div class='col-xs-7 content'>
							<p class='m-b-xs' style=' text-transform: capitalize;'><strong>{$alert['type'] }</strong><br/>
                                    {$alert['text']}</p>
                                  </div>
                                  </a>
								</div>
							</div>

				";
			}
		}

		return $response;
	}
	/**
	 * Logout the user and redirect to landing page
	 *
	 * @return Response
	 */
	public function getLogout()
	{

		Session::flush();
    	Auth::logout();
    	Session::flush();
		 
    	return Redirect::to('/');
	}

	/**
	* Change the date Option
	*
	**/

	public function getIncidentTransform(){

		$data = Input::All();
		$data['fy'] = '';

		if(!empty($data['fy_audit'])){

			if(!empty($data['fy_start']))	$data['fy'] = [$data['fy_start'], $data['fy_end']];

			$results = MSLST_Dashboard::getJSFormattedAudits(12,$data['fy_audit'],$data['fy']);

		}elseif(!empty($data['auditdate'])){

			list($num,$option) = explode("#",$data['auditdate']);
			switch($option){
				case 'month':
					$results = MSLST_Dashboard::getJSFormattedAudits($num);
					break;
				case 'year':
					$results = MSLST_Dashboard::getJSFormattedAudits(12);
					break;
			}

		}else if(!empty($data['fy_incident'])){
			
			if(!empty($data['fy_start']))	$data['fy'] = [$data['fy_start'], $data['fy_end']];

			$results = MSLST_Dashboard::getJSFormattedIncidents(12,$data['incidenttype'],$data['fy_incident'],$data['fy']);
		
		}else if(!empty($data['incidentdate']) && !empty($data['incidenttype'])  ){

			list($num,$option) = explode("#",$data['incidentdate']);
			switch($option){
				case 'month':
					$results = MSLST_Dashboard::getJSFormattedIncidents($num,$data['incidenttype']);
					break;
				case 'year':
					$results = MSLST_Dashboard::getJSFormattedIncidents(12,$data['incidenttype']);
					break;
			}

		}else if(!empty($data['incidenttype_lsp'])){

			$results = MSLST_Dashboard::getJSFormattedIncidentsLsp($data['incidenttype_lsp'],$data['fy_incident_lsp']);

		}else if(!empty($data['fy_incident_status'])){

			$results = MSLST_Dashboard::getJSFormattedIncidentStatus($data['fy_incident_status']);

		}elseif(!empty($data['fy_incident_category'])){

			$results = MSLST_Dashboard::getJSFormattedIncidentCategory($data['fy_incident_category']);
		}

		return $results;
	}

	/**
	 * Return oldaudits, Ajax Callback
	 *
	 * @var String
	 **/

	public function postoldaudit(){

		$data = Input::all();

		if(!empty($data['audit']) && isset($data['audit'])){
			MSLST_Dashboard::changeOldAuditStatus($data['audit']);
		}

		$oldaudits = MSLST_Dashboard::getJSFormatedOldAudits(Dashboard::OLD_AUDIT_DISPLAY_COUNT);

		$html     = '';

		foreach($oldaudits  as $audits){

			$html.=  '<div class="list-group-item">
                            <input type="checkbox" name="audits[]" id="audits-'.$audits['type'].'-'.$audits['id'].'" class="oldaudits" >
                            <a href="'.$audits['url'].'">
                                <i class="fa fa-location-arrow fa-fw"></i> <small>'.$audits['text'].'</small>
                                <span class="pull-right text-muted small"><em>'.$audits['days'].' days ago</em>
                                </span>
                            </a>
                        </div>';
		}

		return $html;
	}

	public function saveOrder()
	{
		$data = Input::all();

		if (isset($data['left']) && isset($data['right']))
		{
			$user = Auth::User();
			$user->dashboard = serialize($data);
			$user->save();
		}
	}

}
