<?php

class PasswordReminder extends \Eloquent {
	protected $fillable = [];
}