<?php
use MSLST\Helpers\Lists;
use MSLST\Helpers\Factoryincidents;
use MSLST\Helpers\Common;
use MSLST\Helpers\Coordinate;

class FactoryIncidentsController extends \BaseController {

	/**
	 * Instanite for Usercontroller Instance
	 *
	 **/
	public function __construct()
	{
		//if (!Auth::User()->isAdmin() && !Auth::User()->access_lanes ) App::abort(403);
		if (!Auth::User()->isAdmin() && !Auth::User()->access_factory_incidents) App::abort(403);
	}

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		//
	}


	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */
	public function create($step = 0)
	{
		switch($step)
		{
			case 0:
				$data = Factoryincidents::getFactoryIncidentStepData('basic_information');
				return self::basic_information_form($data);
			break;
			case 1:
				$data = Factoryincidents::getFactoryIncidentStepData('incident_details');
				return self::incident_details_form($data);
			break;
			case 2:
				$data = Factoryincidents::getFactoryIncidentStepData('investigation_attachments');
				return self::investigation_attachments_form($data);
			break;
			case 3:
				$data = Session::get('factoryincident');
				return self::summary_incident($data);
			break;
		}
	}


	/**
	 *
	 *
	 *
	 **/
	public function basic_information_form($data,$edit=false){

		$usrregion = UserRegion::select('region_id')
							   ->where('user_id',\Auth::user()->id)
				  			   ->Lists('region_id');

		$regions = Lists::getRegionsList($usrregion);
		$regions_json = json_encode(Lists::getRegionCountriesList($usrregion));


		return View::make('incidents.factory.basic_information')
				->with('regions',$regions)
				->with('countries', [])
				->with('regions_json',$regions_json)
				->with('edit',$edit)
				->with('data', $data);
	}

	/**
	 *
	 *
	 **/
	public function incident_details_form($data,$edit=false){

		 return View::make('incidents.factory.incident_details')
		 			->with('edit',$edit)
					->with('data', $data);
	}


	/**
	 *
	 *
	 **/

	public function investigation_attachments_form($data,$edit=false){

		$InvestigationStus = IncidentInvestigation::select('name','id')->get()->lists('name','id'); 

		return View::make('incidents.factory.investigation_attachments')
				   ->with('edit',$edit)
				   ->with('InvestigationStus',$InvestigationStus)
				   ->with('data',$data);
	}


	/**
	 *  Summary of Factory Incident
	 *
	 **/

	public function summary_incident($data) {

		$country  = Lists::getCountriesname($data['basic_information']->country);
		$region  = Lists::getRegionsname($data['basic_information']->region);

		$InvestigationStus = IncidentInvestigation::find($data['investigation_attachments']->current_investigation_status);
		return View::make('incidents.factory.summary_incident')
					->with('data',$data)
					->with('country',$country)
					->with('region',$region)
					->with('InvestigationStus',$InvestigationStus);
	}

	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	public function store()
	{
		switch(intval(Input::get('step'))){
			case 0:
					//$validator = validator::make(Input::all(),FactoryIncident::$basic_information_rules) ;
					$validator = validator::make(Input::all(),FactoryIncident::$basic_information_rules ,FactoryIncident::$messages ) ;
					$step = 'basic_information';
					$next = 'factory/incidents/create/1';
			break;
			case 1:
					$validator = validator::make(Input::all(),FactoryIncident::$incident_detail_rules,FactoryIncident::$messages);
					$step = 'incident_details';
			 		$next = 'factory/incidents/create/2';
			break;
			case 2:
				   //$validator = validator::make(Input::all(),FactoryIncident::$investigation_attachment_rules);
				   $validator = validator::make(Input::all(),FactoryIncident::$investigation_attachment_rules,FactoryIncident::$messages);
				   $step = 'investigation_attachments';
				   $next = 'factory/incidents/create/3';
			break;
			case 3:
					Factoryincidents::SaveFactoryIncident();

					return Redirect::to('incidents?type=factory')
								->with('success', "Factory Incident created successfully.");
			break;
		}


		if ($validator->fails()) {
			return Redirect::back()
					->withInput()
					->withErrors($validator->messages());
        }else{
				Factoryincidents::setFactoryIncidentStepData($step,Input::all());
				return Redirect::to($next);
        }

	}


	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		if (!Common::canAccess($id, 'factoryincident')) App::abort(403);
		$incident = FactoryIncident::with('region','country','user','product','investigation','attachment','incidentlog')->findOrFail($id);
		$products = Factoryincidents::getDecodedProducts($incident->product);
		$coordinates = Coordinate::convertToWGS84($incident->coordinates);

		$has_attachments = Factoryincidents::hasAttachments($incident->attachment);
		$status = Common::getDateStatus($incident->closed_at, 'Closed', 'Open');
		$InvestigationStus = IncidentInvestigation::find($incident->investigation->current_investigation_status);
		$incident->{'investigation'}->{'investigationname'} = $InvestigationStus->name;
	
		return View::make('incidents.factory.show')
				   ->with('incidents',$incident)
				   ->with('products',$products)
				   ->with('status',$status)
				   ->with('has_attachments',$has_attachments)
				   ->with('coordinates',$coordinates);
	}


	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id,$step=0)
	{
		if (! Common::canAccess($id, 'factoryincident')) App::abort(403);

		switch($step)
		{
			case 0:
				$data = Factoryincidents::getFactoryIncidentEditData($id,'basic_information');
				return self::basic_information_form($data,true);
			break;
			case 1:
				$data = Factoryincidents::getFactoryIncidentEditData($id,'incident_details');
				return self::incident_details_form($data,true);
			break;
			case 2:
				$data = Factoryincidents::getFactoryIncidentEditData($id,'investigation_attachments');
				return self::investigation_attachments_form($data,true);
			break;
		}
	}


	/**
	 * Update the specified resource in storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		if (! Common::canAccess($id, 'factoryincident')) App::abort(403);

		switch(intval(Input::get('step'))){
			case 0:
					$validator = validator::make(Input::all(),FactoryIncident::$basic_information_rules ,FactoryIncident::$messages ) ;
					$step = 'basic_information';
			break;
			case 1:
					$validator = validator::make(Input::all(),FactoryIncident::$incident_detail_rules,FactoryIncident::$messages);
			 		$step = 'incident_details';
			break;
			case 2:
				    $validator = validator::make(Input::all(),FactoryIncident::$investigation_attachment_rules,FactoryIncident::$messages);
				    $step = 'investigation_attachments';
			break;
		}
		
		if ($validator->passes())
		{
			Factoryincidents::setIncidentEditData($id, $step, Input::all());
			return Redirect::route('factory.incidents.show', $id)
					->with('success', 'Factory Incident updated successfully.');
		}
		else
		{
			return Redirect::back()
					->withInput()
					->withErrors($validator->messages());

		}
	}


	/**
	 * Remove the specified resource from storage.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		if (! Common::canAccess($id, 'factoryincident')) App::abort(403);

		$incident = FactoryIncident::findOrFail($id);
		$incident->delete();

		return Redirect::route('incidents.index',['type'=>'factory'])
				->with('success', 'Factory Incident deleted successfully.');
	}



	/**
	 * Toggle closed of the specified resource.
	 * PATCH /incidents/close/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function close($id)
	{
		if (!\Auth::User()->isAdmin() && !\Auth::User()->isManager()) App::abort(403);

		$incident = FactoryIncident::findOrFail($id);

		if ($incident->closed_at)
		{
			$incident->closed_at = NULL;
			$message = "Factory Incident re-opened successfully.";

			//Emails::sendIncidentStatus($incident, 'open');
		}
		else
		{
			 /* Close incident Attachment And descricption */
			 $data = Input::all();
			//if(!empty($data['attachment']) )  FactoryIncident::closeAttachment(Input::all(),$id);

			$incident->closed_at = new \Carbon\Carbon;
			$message = "Factory Incident closed successfully.";


			//Emails::sendIncidentStatus($incident, 'closed');
		}

		$incident->save();

		return Redirect::route('factory.incidents.show', [$id])
				->with('success', $message);
	}


}
