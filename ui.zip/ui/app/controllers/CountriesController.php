<?php

use MSLST\Helpers\Lists;

class CountriesController extends \BaseController {

    /**
     * Instantiate a new CountriesController instance.
     */
	public function __construct()
	{
		$this->beforeFilter(function ($route){
			if (!Auth::user()->isAdmin())
			{
				App::abort(404);
			}
		});
	}

	/**
	 * Display a listing of the resource.
	 * GET /countries
	 *
	 * @return Response
	 */
	public function index()
	{
		$countries = Country::where('region_id','<>','')->get()->all();

		return View::make('countries.index')
				->with('countries', $countries);
	}

	/**
	 * Show the form for creating a new resource.
	 * GET /countries/create
	 *
	 * @return Response
	 */
	public function create()
	{
		$regions = Lists::getRegionsList();

		return View::make('countries.create')
				->with('regions', ['' => ''] + $regions);
	}

	/**
	 * Store a newly created resource in storage.
	 * POST /countries
	 *
	 * @return Response
	 */
	public function store()
	{
		$validator = Validator::make(Input::all(), Country::$rules);

		if ($validator->passes())
		{
		    $region = Country::create([
				'name' => Input::get('name'),
				'region_id' => Input::get('region')
		    ]);

			return Redirect::route('countries.index')
					->with('success', 'Country created successfully.');
		}
		else
		{
			return Redirect::back()
				    ->withInput()
				    ->withErrors($validator->messages());
		}

	}

	/**
	 * Show the form for editing the specified resource.
	 * GET /countries/{id}/edit
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		$regions = Lists::getRegionsList();
		$country = Country::findOrFail($id);

		return View::make('countries.edit')
				->with('regions', ['' => ''] + $regions)
				->with('country', $country);
	}

	/**
	 * Update the specified resource in storage.
	 * PUT /countries/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function update($id)
	{
		$rules = Country::$rules;
		$rules['name'] .= ','. $id;
		$validator = Validator::make(Input::all(), $rules);

		if ($validator->passes())
		{
			$country = Country::findOrFail($id);
			$country->name = Input::get('name');
			$country->region_id = Input::get('region');
			$country->save();

			return Redirect::route('countries.index')
					->with('success', 'Country updated Successfully.');
		}
		else
		{
			return Redirect::back()
				    ->withInput()
				    ->withErrors($validator->messages());
		}
	}

	/**
	 * Remove the specified resource from storage.
	 * DELETE /countries/{id}
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function destroy($id)
	{
		$country = Country::findOrFail($id);
		$country->delete();

		return Redirect::route('countries.index')
				->with('success', 'Country deleted Successfully.');
	}

}