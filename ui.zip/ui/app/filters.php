<?php

/*
|--------------------------------------------------------------------------
| Application & Route Filters
|--------------------------------------------------------------------------
|
| Below you will find the "before" and "after" events for the application
| which may be used to do any work before or after a request into your
| application. Here you may also register your custom route filters.
|
*/

App::before(function($request)
{

	//

});


App::after(function($request, $response)
{
	//
});

/*
|--------------------------------------------------------------------------
| Authentication Filters
|--------------------------------------------------------------------------
|
| The following filters are used to verify that the user of the current
| session is logged into this application. The "basic" filter easily
| integrates HTTP Basic authentication for quick, simple checking.
|
*/

Route::filter('auth', function()
{
	if (Auth::guest())
	{
		if (Request::ajax())
		{
			return Response::make('Unauthorized', 401);
		}
		else
		{
			return Redirect::guest('login');
		}
	}
});


Route::filter('auth.basic', function()
{
	return Auth::basic();
});

/*
|--------------------------------------------------------------------------
| Guest Filter
|--------------------------------------------------------------------------
|
| The "guest" filter is the counterpart of the authentication filters as
| it simply checks that the current user is not logged in. A redirect
| response will be issued if they are, which you may freely change.
|
*/

Route::filter('guest', function()
{
	if (Auth::check()) return Redirect::to('/');
});

/*
|--------------------------------------------------------------------------
| CSRF Protection Filter
|--------------------------------------------------------------------------
|
| The CSRF filter is responsible for protecting your application against
| cross-site request forgery attacks. If this special token in a user
| session does not match the one given in this request, we'll bail.
|
*/

Route::filter('csrf', function()
{
	if (Session::token() != Input::get('_token'))
	{
		throw new Illuminate\Session\TokenMismatchException;
	}
});

/*
|--------------------------------------------------------------------------
| The Session Filter
|--------------------------------------------------------------------------
|
| This filters is reposible for redirecting user to the login page  
| if the current user does not has a session.
|
*/

Route::filter('session', function()
{
	if (! Auth::User())
	{
		return Redirect::to('/');
	}
});

/*
|--------------------------------------------------------------------------
| Terms and Conditions Filter
|--------------------------------------------------------------------------
|
| This filters is reposible for redirecting user to the terms and  
| conditions page if the user has not accepted it.
|
*/

Route::filter('terms', function($route, $request)
{
	if ($route->getUri() != 'terms')
	{
		if (! Auth::User()->terms_accepted)
		{
			// Check for the ask terms and conditions setting
			$terms = \Setting::where('name', 'site_ask_agree_tnc')->first()->value;
			
			if ($terms)
			{
				return Redirect::to('terms');
			}
		}
	}
});

/*
|--------------------------------------------------------------------------
| Terms and Conditions Forms Filter
|--------------------------------------------------------------------------
|
| This filters is reposible for redirecting user back to the home page, if 
| the user tries to access terms and conditions page again after 
| it is already accepted.
|
*/

Route::filter('termsForms', function($route, $request)
{
	if (Auth::User()->terms_accepted)
	{
		return Redirect::to('/');
	}
});