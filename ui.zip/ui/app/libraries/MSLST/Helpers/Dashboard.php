<?php namespace MSLST\Helpers;
      use MSLST\Constants\Dashboard as DashConstant;

use Carbon\Carbon;

class Dashboard {
    
    /**
     * Format all audits as json array to be used with Morris.js
     *
     * @param integer $count
     * @return string
     */
    public static function getJSFormattedAudits($count = 12 ,$fy_default='',$fy_defined = '')
    {
        $user_id = \Auth::User()->id;
        $lsp_id = \Auth::User()->lsp->id;

        // Get the location list
 
         $locations = \Location::select(\DB::raw('COUNT(id) as total, convert(varchar(6) , created_at, 112) as span'));
                    

        if(!empty($fy_defined) && ($fy_defined[0] !=  $fy_defined[1]) ){
              $start = $fy_defined[0]; $end =  $fy_defined[1];
              $count =  ($fy_defined[1]  -  $fy_defined[0]) *12 ; 
        }elseif(!empty($fy_default)){
              $start =  $fy_default-1; $end =  $fy_default;
        }

        if(!empty($fy_defined) || !empty($fy_default)){
            $locations->where(\DB::raw("format(created_at,'yyyyMM')"),'>=', $start.'07');
            $locations->where(\DB::raw("format(created_at,'yyyyMM')"),'<=', $end.'06');
        } 


         $locations->orderBy(\DB::raw('convert(varchar(6) , created_at, 112)'), 'DESC')
                    ->groupBy(\DB::raw('convert(varchar(6) , created_at, 112)'));
                                 
        if(empty($fy_defined) && empty($fy_default))  $locations->limit($count);


        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $locations->where('auditor_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $locations->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }

        $locations = $locations->lists('total', 'span');

        // Get the routes list
   
         $routes = \Routes::select(\DB::raw('COUNT(id) as total, convert(varchar(6) , created_at, 112) as span'));
                        

        if(!empty($fy_defined) || !empty($fy_default)){
            $routes->where(\DB::raw("format(created_at,'yyyyMM')"),'>=', $start.'07');
            $routes->where(\DB::raw("format(created_at,'yyyyMM')"),'<=', $end.'06');
        } 


         $routes->orderBy(\DB::raw('convert(varchar(6) , created_at, 112)'), 'DESC')
                        ->groupBy(\DB::raw('convert(varchar(6) , created_at, 112)'));
                                 
        if(empty($fy_defined) && empty($fy_default))  $routes->limit($count);


        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $routes->where('auditor_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $routes->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }

        $routes = $routes->lists('total', 'span');

        // Arrange the data
        $locations_first = key($locations);
        $routes_first = key($routes);

        $year = $locations_first > $routes_first ? $locations_first : $routes_first;
        $result = [];

        // If there are audits build the result array
        if ($year)
        {
            for ($i = 0; $i < $count; $i++)
            {
                $year_part = substr($year, 0, 4);
                $month_part = substr($year, 4, 2);
                $period = $year_part . '-' . $month_part;
                $location_count = isset($locations[$year]) ? $locations[$year] : 0;
                $route_count = isset($routes[$year]) ? $routes[$year] : 0;

                /*$result[] = [
                    'period' => $period,
                    'location' => $location_count,
                    'route' => $route_count,
                ]; */

                $result['period'][]   = $period;
                $result['location'][] = $location_count;
                $result['route'][]    = $route_count;

                if ($month_part == 1) 
                {
                    $year = ($year_part-1) .''. 12;
                }
                else
                {
                    $year--;
                }
            }

            sort($result['period']);
            krsort($result['location']);
            krsort($result['route']);

            $result['location'] = array_values($result['location']);
            $result['route'] = array_values($result['route']);
        }


        return json_encode($result);
    }

    /**
     * Format all incidents as json array to be used with Morris.js
     *
     * @param integer $count
     * @return string
     */
    public static function getJSFormattedIncidents($count = 12,$type='number',$fy_default='',$fy_defined = '')
    {   
        $user_id = \Auth::User()->id;
        $lsp_id = \Auth::User()->lsp->id;


        if($type == 'value'){
       
             $incidents = \Incident::leftjoin('products as p','incidents.id','=','p.incident_id')
                                ->select(\DB::raw('convert(varchar(6) , incidents.incident_date, 112) as span,sum(p.total_value_of_lost_units) as total'));
                                 
        }
        else
        {
           $incidents = \Incident::select(\DB::raw('COUNT(id) as total, convert(varchar(6) ,incident_date, 112) as span'));
                        
        }

        if(!empty($fy_defined) && ($fy_defined[0] !=  $fy_defined[1]) ){
              $start = $fy_defined[0]; $end =  $fy_defined[1];
              $count =  ($fy_defined[1]  -  $fy_defined[0]) *12 ; 
        }elseif(!empty($fy_default)){
              $start =  $fy_default-1; $end =  $fy_default;
        }

        if(!empty($fy_defined) || !empty($fy_default)){
            $incidents->where(\DB::raw("format(incidents.incident_date,'yyyyMM')"),'>=', $start.'07');
            $incidents->where(\DB::raw("format(incidents.incident_date,'yyyyMM')"),'<=', $end.'06');
        } 


         $incidents->orderBy(\DB::raw('convert(varchar(6) ,incidents.incident_date, 112)'),'DESC')
                                ->groupBy(\DB::raw('convert(varchar(6) ,incidents.incident_date, 112)'));
                                 
        if(empty($fy_defined) && empty($fy_default))  $incidents->limit($count);

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $incidents->where('user_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
           /* $incidents->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('user_id', $user_id)
                  ->orWhereHas('user', function($q1) use ($lsp_id) {
                      $q1->where('users.lsp_id', $lsp_id);
                  });
            });*/

           $regionChk = \UserRegion::select('region_id')
                                   ->where('user_id',\Auth::User()->id)
                                   ->lists('region_id');

           $incidents->whereIn('region_id', $regionChk);

           $lspChk    = \User::select('id')
                             ->where('lsp_id',\Auth::User()->lsp->id)
                             ->lists('id');
           $incidents->whereIn('user_id', $lspChk);
        }

        $incidents = $incidents->lists('total', 'span');

        $year = key($incidents);
        $result = [];
      
         // If there are incidents build the result array
      
        if ($year)
        {

            for ($i = 0; $i < $count; $i++)
            {
                $year_part = substr($year, 0, 4);
                $month_part = substr($year, 4, 2);
                
                $period = $year_part . '-' . $month_part;
                $incident_count = isset($incidents[$year]) ? $incidents[$year] : 0;
                
              /*  $result[] = [
                    'period' => $period,
                    'incidents' => $incident_count,
                ];*/

                 $result['period'][] = $period;
                 $result['incidents'][] = $incident_count; 


                if ($month_part == 1) 
                {
                    $year = ($year_part-1) .''. 12;
                }
                else
                {
                    $year--;
                }
            }

        sort($result['period']);
        krsort($result['incidents']);

        $result['incidents'] = array_values($result['incidents']);
        }

        if(empty($fy_defined)){
          // FY Numer
          $fy_date =  \Incident::select(\DB::raw("distinct format(incident_date,'yyyy') as fy_date,concat('FY',format(incident_date,'yy')) as fy"))->lists('fy','fy_date');
          $result['fy_date'] = $fy_date;
        } 
     //print "<pre>"; print_r(\DB::getQueryLog());
        return json_encode($result);
    }

    /**
     * Format incident status as json array to be used with Morris.js
     *
     * @return string
     */
    public static function getJSFormattedIncidentStatus($fy='2016')
    {
        $user_id = \Auth::User()->id;
        $lsp_id = \Auth::User()->lsp->id;
        $start =  $fy-1; $end =  $fy;

         $incidents = \Incident::select(\DB::raw("COUNT(id) as total, (case WHEN closed_at IS NOT NULL THEN  'Closed' ELSE 'Open' END) as status"))
                               ->where(\DB::raw("format(incidents.incident_date,'yyyyMM')"),'>=', $start.'07')
                               ->where(\DB::raw("format(incidents.incident_date,'yyyyMM')"),'<=', $end.'06')
                               ->groupBy(\DB::raw("(case WHEN closed_at IS NOT NULL THEN  'Closed' ELSE 'Open' END)")); 


        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $incidents->where('user_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            /*$incidents->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('user_id', $user_id)
                  ->orWhereHas('user', function($q1) use ($lsp_id) {
                      $q1->where('users.lsp_id', $lsp_id);
                  });
            });*/
           $regionChk = \UserRegion::select('region_id')
                                   ->where('user_id',\Auth::User()->id)
                                   ->lists('region_id');

           $incidents->whereIn('region_id', $regionChk);

           $lspChk    = \User::select('id')
                             ->where('lsp_id',\Auth::User()->lsp->id)
                             ->lists('id');
           $incidents->whereIn('user_id', $lspChk);
        }

        $incidents = $incidents->lists('total', 'status');

        $result = [];

        foreach ($incidents as $status => $total)
        {
            $result[] = [
                'label' => $status,
                'value' => $total
            ];
        }

        return json_encode($result);
    }

    /**
     * Format incident category as json array to be used with Morris.js
     *
     * @return string
     */
    public static function getJSFormattedIncidentCategory($fy='2016')
    {
        $user_id = \Auth::User()->id;
        $lsp_id = \Auth::User()->lsp->id;

         $start =  $fy-1; $end =  $fy;
  

        $incidents = \Incident::select(\DB::raw('COUNT(id) as total, category'))
                             ->where(\DB::raw("format(incidents.incident_date,'yyyyMM')"),'>=', $start.'07')
                             ->where(\DB::raw("format(incidents.incident_date,'yyyyMM')"),'<=', $end.'06')
                             ->groupBy('category');

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $incidents->where('user_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            /*$incidents->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('user_id', $user_id)
                  ->orWhereHas('user', function($q1) use ($lsp_id) {
                      $q1->where('users.lsp_id', $lsp_id);
                  });
            });*/
           $regionChk = \UserRegion::select('region_id')
                                   ->where('user_id',\Auth::User()->id)
                                   ->lists('region_id');

           $incidents->whereIn('region_id', $regionChk);

           $lspChk    = \User::select('id')
                             ->where('lsp_id',\Auth::User()->lsp->id)
                             ->lists('id');
           $incidents->whereIn('user_id', $lspChk);
        }

        $incidents = $incidents->lists('total', 'category');

        $result = [];

        foreach ($incidents as $status => $total)
        {
            $result[] = [
                'label' => $status,
                'value' => $total
            ];
        }

        return json_encode($result);
    }
	
	 /**
     * Format User status as json array to be used with Morris.js
     *
     * @return string
     */
    public static function getJSFormatteduserStatus()
    {
        $user_id = \Auth::User()->id;
		$lsp_id = \Auth::User()->lsp->id;        

        $users = \User::select(\DB::raw("COUNT(id) as total,IIF(deleted_at IS NOT NULL, 'Inactive', 'Active') as status"))
                      ->groupBy(\DB::raw("IIF(deleted_at IS NOT NULL,'Inactive','Active')"))->withTrashed(); 
						
						
		if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $users->where(function ($q) use ($lsp_id) {
                $q->where('users.lsp_id', $lsp_id);
             });
            
        }
         $users = $users->lists('total', 'status'); 
        $result = [];

        foreach ($users as $status => $total)
        {
            $result[] = [
                'label' => $status,
                'value' => $total
            ];
        }
        return json_encode($result);
    }


    /**
     * Format recent users and login time as an array
     *
     * @param integer $count
     * @param string $format
     * @return array
     */
    public static function getFormattedRecentUsers($count = 10, $format = '%M %D, %Y %h:%i:%s %p')
    {
        $lsp_id = \Auth::User()->lsp->id;
 						
		$users = \UserLog::select('id', \DB::raw("id, user_id, FORMAT(login_at,'dd MMMM,yyyy hh:mm:ss tt') as login"))
						  ->orderBy('login_at', 'DESC')
						  ->WhereNotIn('user_id',DashConstant::$RESTRICTED_RECENT_USER_LIST)
                          ->limit($count);

         /* If LSP supervisor, get only owned and LSP records
        //if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        //{
        // $users->where('lsp_id', $lsp_id);
        //} */

        $users = $users->get();

        $users = $users?:[];

        return $users;
    }

    /**
     * Format recent audits and incidents and return them as an array
     *
     * @param integer $count
     * @param string $format
     * @return array
     */
    public static function getFormattedRecentAuditsIncidents($count = 10, $format = "%b %D, %h:%i %p", $index = 0)
    {
        $user_id = \Auth::User()->id;
        $lsp_id = \Auth::User()->lsp->id;

        // If there is index, fetch more items
        $limit = $index ? ($index + 1) * $count : $count;

        //MSSQL
        $formt = 'MMM dd, hh:mm tt';
        $locations = \Location::select('id', 'site', \DB::raw("FORMAT(updated_at,'".$formt."') as formatted_date,DATEDIFF(s,'19700101',updated_at) as unixtime"))
                        ->orderBy('created_at', 'DESC')
                        ->limit($limit);
        
        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $locations->where('auditor_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $locations->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }

        $locations = $locations->get();

        //MSSQL 
        $routes = \Routes::select('id', 'start_site', 'end_site', \DB::raw("FORMAT(updated_at, '". $formt ."') as formatted_date, DATEDIFF(s,'19700101',updated_at) as unixtime"))
                        ->orderBy('created_at', 'DESC')
                        ->limit($limit); 
        
        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $routes->where('auditor_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $routes->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }

        $routes = $routes->get();

        //MSSQL
         $incidents = \Incident::with('country')
                        ->select('id', 'category','country_id','location_city','facility', \DB::raw("FORMAT(created_at,'". $formt ."') as formatted_date, DATEDIFF(s,'19700101',created_at) as unixtime"))
                        ->orderBy('created_at', 'DESC')
                        ->limit($limit);           


        

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $incidents->where('user_id', $user_id);
        }

        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $incidents->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('user_id', $user_id)
                  ->orWhereHas('user', function($q1) use ($lsp_id) {
                      $q1->where('users.lsp_id', $lsp_id);
                  });
            });
        }

        $incidents = $incidents->get();

       // echo "<pre>"; print_r($incidents); exit;

        $locations_array = [];
        foreach ($locations as $location)
        {
            $locations_array[$location->unixtime] = [
                'id' => $location->id,
                'url' => route('locations.show', [$location->id]),
                'type' => 'location',
                'icon' => 'fa-location-arrow',
                'text' => 'New location at '. substr($location->site,10),
                'date' => str_replace(",",",<span>",$location->formatted_date),
            ];
        }

        $routes_array = [];
        foreach ($routes as $route)
        {
            $routes_array[$route->unixtime] = [
                'id' => $route->id,
                'url' => route('routes.show', [$route->id]),
                'type' => 'route',
                'icon' => 'fa-location-arrow',
                'text' => 'New route from '. $route->start_site .' to '. substr($route->end_site,10),
                'date' => str_replace(",",",<span>",$route->formatted_date),
             ];
        }

        $incidents_array = [];
        foreach ($incidents as $incident)
        {
            $incidents_array[$incident->unixtime] = [
                'id' => $incident->id,
                'url' => route('incidents.show', [$incident->id]),
                'type' => 'incident',
                'icon' => 'fa-exclamation',
                'text' => 'New '.$incident->category.' incident in '. $incident->country->name.' , '. $incident->location_city,
                'date' => str_replace(",",",<span>",$incident->formatted_date),
            ];
        }

        $alerts = $locations_array + $routes_array + $incidents_array;

        // If the list is not empty, take $count items and 
        // sort it by key [timestamps] in descending order
        $items = [];
        if ($alerts)
        {
            krsort($alerts);

            foreach ($alerts as $alert)
            {
                $items[] = $alert;
            }

            $items = array_slice($items, $index, $count);
        }

        return $items;
    }

    /**
     * Format old audits  and return them as an array
     *
     * @param integer $count
     * @param string $format
     * @return array
     **/

    public static function getJSFormatedOldAudits($count, $format = "%b %D, %h:%i %p", $index = 0){

        $user_id = \Auth::User()->id;
        $lsp_id  = \Auth::User()->lsp_id;

        $limit   = ($index) ? ($index+1) * $count : $count;


        /* Fetch Location Old Audits */
        $mssqlformat = 'MMM dd"th", HH:mm tt';
        // MSSQL
        $locations = \Location::select('id','site',\DB::raw("datediff(day,format(updated_at,'yyyy-MM-dd'),getdate()) as days") ,\DB::raw("format(updated_at,'".$mssqlformat."') as formatted_date,DATEDIFF(s,'19700101',updated_at) as unixtime"))
                    ->orderBy('days','DESC');

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $locations->where('auditor_id', $user_id);
        }

         // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $locations->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }

        $locations->where(\DB::raw("datediff(day,format(updated_at,'yyyy-MM-dd'),getdate())"),'>=',365);
        $locations->where('status','!=','inactive');

        $locations = $locations->get();


        /* Fetch Route Old Audits */
        $routes = \Routes::select('id','start_site','end_site',\DB::raw("datediff(day,Format(updated_at,'yyyy-MM-dd'),getdate()) as days"),\DB::raw("Format(updated_at,'".$mssqlformat."') as formatted_date,datediff(s,'19700101',updated_at) as unixtime"))
                  ->orderBy('days');

        // If user, get only owned records
        if (\Auth::User()->isUser())
        {
            $routes->where('auditor_id', $user_id);
        }


        // If LSP supervisor, get only owned and LSP records
        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $routes->where(function ($q) use ($user_id, $lsp_id) {
                $q->where('auditor_id', $user_id)
                  ->orWhere('lsp_id', $lsp_id);
            });
        }
        //mysql
       // $routes->where(\DB::raw("datediff(curdate(),date_format(updated_at,'%Y-%m-%d'))"),'>=',365);
        //mssql
        $routes->where(\DB::raw("datediff(day,FORMAT(updated_at,'yyyy-MM-dd'),getdate())"),'>=',365);

        $routes->where('status','!=','inactive');

        $routes = $routes->get();          

        $locations_array = [];

        foreach ($locations as $location)
        {
            $locations_array[$location->unixtime] = [
                'id'   => $location->id,
                'url'  => route('locations.show', [$location->id]),
                'type' => 'location',
                'icon' => 'fa-location-arrow',
                'text' => 'Location Audit created for the site '. $location->site,
                'date' => $location->formatted_date,
                'days' => $location->days,
            ];
        }

        $routes_array  = [];

        foreach($routes as $route){
            $routes_array[$route->unixtime] = [
                'id'   => $route->id,
                'url'  => route('routes.show', [$route->id]),
                'type' => 'route',
                'icon' => 'fa-location-arrow',
                'text' => 'Route Audit created for the site '. $route->start_site.' to '.$route->end_site,
                'date' => $route->formatted_date,
                'days' => $route->days,
            ];
        }

        $auidts = $locations_array + $routes_array;

        ksort($auidts);

        $item = array_slice($auidts,$index,$count);

       // print "<pre>"; print_r($locations_array); exit;

        return $item;
    }


    /**
     *  Audit Change Status inactive
     *
     *  @var String
     **/
    public static function changeOldAuditStatus($audit){

        if(!empty($audit['route']) && isset($audit['route'])){
            \Routes::whereIn('id',$audit['route'])->update(array('status'=>'inactive'));
        }

        if(!empty($audit['location']) && isset($audit['location'])){
            \Location::whereIn('id',$audit['location'])->update(array('status'=>'inactive'));
        }

    }


     
    /**
     *  Inspect Audit Status
     *
     *
     **/

    public static function getJsFormatedInspectAudits(){

            $open_site= \SiteCorrectiveAction::select(\DB::raw('count(id) as open_site'))
                                                ->whereNull('vam_approval')
                                                ->orWhere('vam_approval', '=','')
                                                ->orWhere('vam_approval', '=','ignore')
                                                ->lists('open_site');

            $closed_site = \SiteCorrectiveAction::select(\DB::raw('count(id) as closed_site'))
                                                ->where('vam_approval', '=','accept')
                                                ->lists('closed_site');

            $request_site = \SiteCorrectiveAction::select(\DB::raw('count(id) as request_site'))
                                                ->where('supplier_request_closure', '=','inprogress')
                                                ->lists('request_site');


            $results = [ 
                        ['label'=>'Closed Site','value'=> (@$closed_site[0])?:'0' ],
                        ['label'=>'Open Site','value' => (@$open_site[0])?:'0' ],
                        ['label'=>'Request Due','value'=> (@$request_site[0])?:'0']
                      ];
             
            if($closed_site[0] == 0 && $open_site[0] == 0 &&  $request_site[0] == 0){
                 $results = [];
            }
  
           return json_encode($results);

    }


    /**
     *
     *
     *
     **/

    public static function getJsFormatInspectionData(){
      
        //echo "<pre>"; print_r(\Auth::user()->site_user_level);exit;
        $user = \Auth::user();
        $sitaca = [];

        switch($user->site_user_level){
               
               case 'vam':
                     $sit_id = explode(',',preg_replace('/[^0-9\,]/', '', $user->user_vam_site_id));   
                     $sitaca =  \SiteCorrectiveAction::with('sitemaster','siteinspectionsanswer')->select(\DB::raw("count(case when vam_approval IS NOT NULL THEN 'closed' end) as closed,count(case when vam_approval is NULL Then 'open' end) as opens,sitemaster_id,inspection_num"))
                                        ->whereIn('sitemaster_id', $sit_id)
                                        ->groupBy(\DB::raw("sitemaster_id,inspection_num"));
                     $sitaca =  $sitaca->get();
               break;
               case 'csm':
                     $sitaca =  \SiteCorrectiveAction::with('sitemaster','siteinspectionsanswer')->select(\DB::raw("count(case when days_past_due IS NOT NULL THEN 'closed' end) as closed,count(case when days_past_due is NULL Then 'open' end) as opens,sitemaster_id,inspection_num"))
                                        ->where('supplier_request_closure', 'inprogress')
                                        ->groupBy(\DB::raw("sitemaster_id,inspection_num"));
                     $sitaca =  $sitaca->get();
               break;
        }

       
        //echo "<pre>"; print_r($sitaca->toArray()); exit;
        return $sitaca;
    }



    /**
     *
     *
     *
     **/
    public static function getJSFormattedIncidentsLsp($data=null,$fy='2016'){ 

        $start =  $fy-1; $end =  $fy;

       $select = "c.name as label,count(incidents.id)  as 'value'";           
        if(!empty($data)){
            if($data == 'value')
                $select= "c.name as label,SUM(p.total_value_of_lost_units) as 'value'";

        }


        $inc_lsp = \Incident::leftjoin('users as u','incidents.user_id','=','u.id')
                         ->leftjoin('lsps as c','u.lsp_id','=','c.id')
                         ->leftjoin('regions as r','incidents.region_id','=','r.id')
                         ->leftjoin('countries as l','incidents.country_id','=','l.id')
                         ->leftjoin('products as p','incidents.id','=','p.incident_id')
                          ->select(\DB::raw($select));

                        if(\Auth::user()->role !='admin')  
                             $inc_lsp->where('u.lsp_id',\Auth::user()->lsp_id);


        $inc_lsp->where(\DB::raw("format(incidents.incident_date,'yyyyMM')"),'>=', $start.'07')
                ->where(\DB::raw("format(incidents.incident_date,'yyyyMM')"),'<=', $end.'06');

        $inc_lsp->groupby(\DB::raw('c.name'));

        $results = $inc_lsp->get()->toArray();

       // print "<pre>"; print_r(\Auth::user()->lsp_id); exit;

        return json_encode($results);
    }



    /**
     *
     *
     *
     ***/
    public static function getInspectionData(){

         /* $prCA = \SiteCorrectiveAction::with('siteinspectionsanswer','sitemaster')
                                         ->select(\DB::raw("inspection_num,sitemaster_id,
                                            (case when (vam_approval =  'accept') then 'closed' else 'open' end) as status,
                                          count((case when (vam_approval =  'accept') then 'closed' else 'open' end)) as cnt_status"))
                                         ->groupby(\DB::raw("sitemaster_id,(case when (vam_approval =  'accept') then 'closed' else 'open' end),inspection_num"))
                                         ->orderby('inspection_num','sitemaster_id')
                                        ->get()->toArray();*/

            $prCA = \SiteCorrectiveAction::with('siteinspectionsanswer','sitemaster')
                                         ->select(\DB::raw("inspection_num,sitemaster_id,
                                            (case when (vam_approval IS NULL and ([intial_due_date] <= getdate() or ([due_date_extension] IS NOT NULL and [due_date_extension] <=getdate()))) then 'overdue' when (vam_approval =  'accept') then 'closed' else 'open' end) as status,
                                          count((case when (vam_approval IS NULL and ([intial_due_date] <= getdate() or ([due_date_extension] IS NOT NULL and [due_date_extension] <=getdate()))) then 'overdue' when (vam_approval =  'accept') then 'closed' else 'open' end)) as cnt_status"))
                                          ->groupby(\DB::raw("sitemaster_id,(case when (vam_approval IS NULL and ([intial_due_date] <= getdate() or ([due_date_extension] IS NOT NULL and [due_date_extension] <=getdate()))) then 'overdue' when (vam_approval =  'accept') then 'closed' else 'open' end),inspection_num"))
                                         ->orderby('inspection_num','sitemaster_id')
                                        ->get()->toArray();

                                    
 
            $ca = []; $results=[];
            foreach ($prCA as $ky => $val) {
                $ca[$val['inspection_num']][$val['status']] = $val;
            }
  
            foreach ($ca as $ky => $val) {
                    
                        $ca_val = isset($val['open'])  ? $val['open'] : (isset($val['closed']) ? $val['closed'] : $val['overdue']) ;
                        $open_ca = '';   $closed_ca = '';  $overdue_ca= '';
  
                        if(isset($val['closed']))   $closed_ca = $val['closed']['cnt_status'];
                        if (isset($val['open']))    $open_ca   = $val['open']['cnt_status'];
                        if (isset($val['overdue'])) $overdue_ca   = $val['overdue']['cnt_status'];

                        $results[$ky]['total_ca']  =  $closed_ca + $open_ca + $overdue_ca;

                        $results[$ky]['sitemaster_id'] =  $ca_val['sitemaster_id'];
                        $results[$ky]['site_name']     =  $ca_val['sitemaster']['site_name'];
                        $results[$ky]['inspection_num'] = $ca_val['inspection_num'];
                        $results[$ky]['over_due_cas']  =  isset($val['overdue']) ? $val['overdue']['cnt_status'] : 0;
                        $results[$ky]['total_open_ca'] =  isset($val['open']) ? $val['open']['cnt_status'] : 0;
                        $results[$ky]['ins_main_date'] =  $ca_val['siteinspectionsanswer']['ins_main_date'];
                        $results[$ky]['inspection_result'] =  $ca_val['siteinspectionsanswer']['sc_scoring_rules_final_rating'];
                        $results[$ky]['inspector_user_id'] =  $ca_val['siteinspectionsanswer']['user_id'];
 
            } 

          //print "<pre>";  print_r($ca);exit;
           //print_r(\DB::getQueryLog());
        return $results;
             
    }
   




}