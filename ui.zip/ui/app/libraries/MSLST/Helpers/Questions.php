<?php namespace MSLST\Helpers;

use MSLST\Constants\Site;
use Carbon\Carbon;

class Questions {


    /**
     * Hide Columns by filters
     *
     * @param $filters array     
     * @return array
     */
    public static function getHiddenColumns($filters)
    {
       
       

        if (isset($filters['category']) && !empty($filters['category']))
        {

            foreach($filters['category'] as $category)
            {

                if ($category == 4)
                    return 'show';
            }
     
        }

        if (isset($filters['certification']) && !empty($filters['certification']))
        {

            foreach($filters['certification'] as $certification)
            {

            if ($certification == 11)
                    return 'show';
            }
     
        }
       
return 'hide';      
       

    }
    
    /**
     * Get all questions by filters
     *
     * @param $filters array     
     * @return array
     */
    public static function getFilteredQuestions($filters)
    {   
        if(isset($filters['availability']) && in_array(5,$filters['availability']) )
        {
               $questions = \BusinessQuestion::with('categories');
		
        }
        else
        {
            $questions = \Question::with('certifications');

            if (isset($filters['availability']) && !empty($filters['availability']))
            {   
                $questions->where('availability', $filters['availability']);
            }
            
    		if (isset($filters['category']) && !empty($filters['category']))
    		{
    			$questions->whereHas('certifications', function ($q) use ($filters) {
    				$q->whereIn('certifications.certification_group_id', $filters['category']);
    			});
    		}

    		if (isset($filters['certification']) && !empty($filters['certification']))
    		{
    			$questions->whereHas('certifications', function ($q) use ($filters) {
    				$q->whereIn('certifications.id', $filters['certification']);
    			});
    		}

    		if (isset($filters['mandatory']) && !empty($filters['mandatory']))
    		{
    			$questions->whereIn('is_mandatory', $filters['mandatory']);
    		}
        }

		return $questions->get();
	}

    /**
     * Check if the question assigned to some audits
     *
     * @param $qid int     
     * @return boolean
     */
     public static function isQuestionAssigned($qid)
     {
     	$location_audits = \LocationAudit::where('question_id', $qid)->count();
     	$route_audits = \RouteAudit::where('question_id', $qid)->count();

     	if ($location_audits || $route_audits)
     	{
     		return true;
     	}

     	return false;
     }
     public static function isSupplierQuestionAssigned($qid)
     {
        $supplier_questions = \BusinessAnswer::where('question_id', $qid)->count();
        if ($supplier_questions)
        {   
            return true;
        }

        return false;
     }
}