<?php namespace MSLST\Helpers;

use MSLST\Constants\Site;
use MSLST\Helpers\Emails;
use Carbon\Carbon;

class Locations {
    
    /**
     * Represents location basic details fields.
     *
     * @var array
     */
    public static $basic_details_fields = [
    	'site',
    	'address',
    	'coordinates',
    	'value',
    	'country'
    ];

    /**
     * Represents location needed certification fields.
     *
     * @var array
     */
    public static $needed_certification_fields = [
    	'tapa_needed'
    ];

    /**
     * Represents location actual certification fields.
     *
     * @var array
     */
    public static $actual_certification_fields = [
        'tapa',
        'ctpat',
        'aeo',
        'svi_num',
        'aeo_num',
        'tapa_certificate',
        'ctpat_certificate',
        'aeo_certificate',
    ];

    /**
     * Represents location questions fields.
     *
     * @var array
     */
    public static $questions_fields = [
        'question',
    ];

    /**
     * Represents location comments fields.
     *
     * @var array
     */
    public static $comments_fields = [
        'comments',
    ];

    /**
     * Represents multi value fields.
     *
     * @var array
     */
    public static $multi_fields = [
    ];

    /**
     * Represents file fields.
     *
     * @var array
     */
    public static $file_fields = [
        'tapa_certificate',
        'ctpat_certificate',
        'aeo_certificate',
    ];


    /**
     * Summary Fields
     *
     *@var array
     **/
    public static $summary_fields=[
    ];


    /**
     * Represents the certificates file path.
     *
     * @var string
     */
    public static $certificates_files_path = 'files/locations';

    /**
     * Save the location data
     * along with the audit data
     */
    public static function saveLocationData()
    {
        $data = \Session::get('locations');

       

        $comments = \Input::get('comments') ? \Input::get('comments') : $data['comments']->comments ;

        $basic_details = (array) $data['basic_details'];
        $tapa_needed = $data['needed_certification']->tapa_needed;
        $actual_certification = (array) $data['actual_certification'];
        $questions = (array) $data['questions']->question;
        $question_comments = isset($data['questions']->comment) ? $data['questions']->comment : [];

        // Create the location or Update Location 
        if(!isset($data['id']))
        {
          
         $location = \Location::create([
                'site' => $basic_details['site'],
                'address' => $basic_details['address'],
                'coordinates' => $basic_details['coordinates'],
                'comment' => $comments,
                'value' => !empty($basic_details['value']) ? $basic_details['value'] : 0,
                'score' => 0,
                'ctpat_number' => $actual_certification['svi_num'],
                'aeo_number' => $actual_certification['aeo_num'],
                'review' => 0,
                'tapa_needed' => $tapa_needed,
                'auditor_id' => \Auth::User()->id,
                'country_id' => $basic_details['country'],
                'lsp_id' => \Auth::User()->lsp->id,
                'status' => 'active',
            ]);
         
        }
        else
        {
            \Location::where('id',$data['id'])
                                 ->update([
                                        'site' => $basic_details['site'],
                                        'address' => $basic_details['address'],
                                        'coordinates' => $basic_details['coordinates'],
                                        'comment' => $comments,
                                        'value' => $basic_details['value'],
                                        'score' => 0,
                                        'ctpat_number' => $actual_certification['svi_num'],
                                        'aeo_number' => $actual_certification['aeo_num'],
                                        'review' => 0,
                                        'tapa_needed' => $tapa_needed,
                                        'auditor_id' => \Auth::User()->id,
                                        'country_id' => $basic_details['country'],
                                        'lsp_id' => \Auth::User()->lsp->id,
                                        'updated_at' => date('Y-m-d H:i:s')
                                    ]);
            $location = \Location::find($data['id']);
        }

        // Save the disabled certifications and added certifications
        if ($actual_certification['tapa'] == 'na')
        {
            \LocationCertificationDisabledGroup::create([
                'certification_group_id' => Site::TAPA_GROUP,
                'location_id' => $location->id,
            ]);
        }
        elseif ($actual_certification['tapa'] != '0')
        {
            \LocationCertification::create([
                'certificate_file' => $actual_certification['tapa_certificate']['certificate_file'],
                'filename' => $actual_certification['tapa_certificate']['filename'],
                'location_id' => $location->id,
                'certification_id' => $actual_certification['tapa'],
            ]);
        }

        if ($actual_certification['ctpat'] == 'na')
        {
            \LocationCertificationDisabledGroup::create([
                'certification_group_id' => Site::C_TPAT_GROUP,
                'location_id' => $location->id,
            ]);
        }
        elseif ($actual_certification['ctpat'] != '0')
        {
            \LocationCertification::create([
                'certificate_file' => $actual_certification['ctpat_certificate']['certificate_file'],
                'filename' => $actual_certification['ctpat_certificate']['filename'],
                'location_id' => $location->id,
                'certification_id' => $actual_certification['ctpat'],
            ]);
        }

        if ($actual_certification['aeo'] == 'na')
        {
            \LocationCertificationDisabledGroup::create([
                'certification_group_id' => Site::AEO_GROUP,
                'location_id' => $location->id,
            ]);
        }
        elseif ($actual_certification['aeo'] != '0')
        {
            \LocationCertification::create([
                'certificate_file' => $actual_certification['aeo_certificate']['certificate_file'],
                'filename' => $actual_certification['aeo_certificate']['filename'],
                'location_id' => $location->id,
                'certification_id' => $actual_certification['aeo'],
            ]);
        }

        // Save the audits
        $audits = [];
        foreach ($questions as $qid => $aid)
        {
            $audit = new \stdClass;
            $audit->is_archived = 0;
            $audit->answer_id = intval($aid);
            
            \LocationAudit::create([
                'location_id' => $location->id,
                'question_id' => $qid,
                'answer_id' => $audit->answer_id,
                'comment' => isset($question_comments[$qid]) ? $question_comments[$qid] : '',
                'is_archived' => 0,
            ]);

            $audits[] = $audit;
        }

        // Calculate the score from new audits
        $location->score = self::calculateScore($location->id, $audits);
        $location->save();

         // create the edit log
        \LocationLog::create([
            'location_id' => $location->id,
            'user_id' => \Auth::User()->id,
            'created_at'=>  Carbon::parse('now')
        ]);

        // Send location create notification
        Emails::sendLocationCreateUpdate(\Location::with('user', 'country', 'lsp')->find($location->id), 'created');



        // Destroy the session data
        \Session::forget('locations');
    }

    /**
     * Get the locations step data
     *
     * @param $name string
     * @return object
     */
    public static function getLocationStepData($name)
    {
        $data = new \stdClass;
        $fields = [];

        $fields = self::${$name .'_fields'};

        if (\Session::has('locations.'. $name))
        {
            $data = (object) \Session::get('locations.'. $name);
        }
        else
        {
            foreach ($fields as $field)
            {
                if (in_array($field, self::$multi_fields))
                {
                    $data->{$field} = [''];
                }
                else
                {
                    $data->{$field} = '';
                }
            }
        }
 
        return $data;
    }

    /**
     * Set the audits step data
     *
     * @param $name string
     * @param $data array
     */
    public static function setLocationStepData($name, $step_data)
    {
        $data = new \stdClass;



        $fields = self::${$name .'_fields'};
          

        
        foreach ($fields as $field)
        {
            if (in_array($field, self::$file_fields) && \Input::file($field))
            {
                $file = \Input::file($field);
                // @TODO keep original name and mime in table
                $original_name = $file->getClientOriginalName();
                $newname = sha1(microtime(true));
                $path = storage_path() .'/'. self::$certificates_files_path;
                $file->move($path, $newname);

                $data->{$field} = [
                    'certificate_file' => $path .'/'. $newname,
                    'filename' => $original_name,
                ];
            }
            else 
            {
                if (isset($step_data[$field]))
                {
                    $data->{$field} = $step_data[$field];
                }
                else
                {
                    $data->{$field} = null;
                }
            }
        }

        \Session::set('locations.'. $name, $data);
    }

    /**
     * Get the location edit data
     *
     * @param $id number
     * @param $name string
     * @return object
     */
    public static function getLocationEditData($id, $name)
    {
        $data = new \stdClass;
        $location = \Location::find($id);

        $data->id = $id;

        $fields = self::${$name .'_fields'};

        foreach ($fields as $field)
        {
            if (isset($location->{$field}))
            {
                $data->{$field} = $location->{$field};
            }
        }

        if ($name == 'basic_details')
        {
            // There is no country_id field, it is country
            $data->country = (!empty($location->country->id)) ? $location->country->id : '';
        }
        elseif ($name == 'actual_certification')
        {
            // Reassign the SVI and AEO numbers, if any
            $data->svi_num = $location->ctpat_number;
            $data->aeo_num = $location->aeo_number;

            // Get all certifications
            $certs = self::getCurrentCertifications($id);

            $data->tapa = $certs->tapa;
            $data->ctpat = $certs->ctpat;
            $data->aeo = $certs->aeo;
        }
        elseif ($name == 'questions')
        {

            // Get all certifications
            $certs = self::getCurrentCertifications($id);

            $data->tapa_needed = $location->tapa_needed;
            $data->actual_certification = [
                'tapa' => $certs->tapa,
                'ctpat' => $certs->ctpat,
                'aeo' => $certs->aeo,
            ];

            $audits = \LocationAudit::where('location_id', $id)
                                        ->where('is_archived', 0)
                                        ->get();

            $data->answer = [];
            $data->comment = [];

            foreach($audits as $audit)
            {
                $data->answer[$audit->question->id] = $audit->answer_id ?: null;
                
                if ($audit->comment)
                {
                    $data->comment[$audit->question->id] = $audit->comment;
                }
            }
        }
        elseif ($name == 'comments')
        {
            $data->comments = $location->comment;
        }

        return $data;
    }

    /**
     * Save the locations edit data
     *
     * @param $id number
     * @param $step string     
     * @param $data array
     */
    public static function setLocationEditData($id, $step, $data)
    {
        $location = \Location::findOrFail($id);

        if ($step == 'basic_details')
        {
            $location->site = $data['site'];
            $location->address = $data['address'];
            $location->coordinates = $data['coordinates'];
            $location->value = $data['value'];
            $location->country_id = $data['country'];
            $location->save();
        }
        elseif ($step == 'actual_certification')
        {
            // Get all certifications and svi numbers
            $certs = self::getCurrentCertifications($id);

            if (isset($data['tapa']) && $data['tapa'] != 0)
            {
                if (($certs->tapa != $data['tapa']) || $data['tapa_certificate'])
                {
                    \LocationCertification::where('location_id', $id)
                                            ->where('certification_id', $certs->tapa)
                                            ->delete();

                    $file = $data['tapa_certificate'];
                    $original_name = $file->getClientOriginalName();
                    $mime_type = $file->getMimeType();
                    $newname = sha1(microtime(true));
                    $path = storage_path() .'/'. self::$certificates_files_path;
                    $file->move($path, $newname);

                    \LocationCertification::create([
                            'certificate_file' => $path .'/'. $newname,
                            'filename' => $original_name,
                            'location_id' => $id,
                            'certification_id' => $data['tapa'],
                        ]);

                    // If there is a certification change, Update the audits as well
                    $qhcs = \QuestionCertification::where('certification_id', $data['tapa'])->get();
                    foreach ($qhcs as $qhc) {
                        
                        // Remove the current audit, if any
                        $audit = \LocationAudit::where('location_id', $location->id)
                                                ->where('question_id', $qhc->question_id)
                                                ->delete();

                        // Add a new audit
                        \LocationAudit::create([
                            'location_id' => $location->id,
                            'question_id' => $qhc->question_id,
                            'answer_id' => 0,
                            'comment' => '',
                            'is_archived' => 0,
                        ]);
                    }
                }
            }

            if (isset($data['ctpat']) && $data['ctpat'] != 0)
            {
                $location->ctpat_number = $data['svi_num'];
                $location->save();

                if (($certs->ctpat != $data['ctpat']) || $data['ctpat_certificate'])
                {
                    
                 if(!empty($data['ctpat_certificate'])) {
                    
                    \LocationCertification::where('location_id', $id)
                                            ->where('certification_id', $certs->ctpat)
                                            ->delete();
                                        
                        $file = $data['ctpat_certificate'];
                        $original_name = $file->getClientOriginalName();
                        $mime_type = $file->getMimeType();
                        $newname = sha1(microtime(true));
                        $path = storage_path() .'/'. self::$certificates_files_path;
                        $file->move($path, $newname);

                        \LocationCertification::create([
                                'certificate_file' => $path .'/'. $newname,
                                'filename' => $original_name,
                                'location_id' => $id,
                                'certification_id' => $data['ctpat'],
                            ]);
                    }

                    // If there is a certification change, Update the audits as well
                    $qhcs = \QuestionCertification::where('certification_id', $data['ctpat'])->get();
                    foreach ($qhcs as $qhc) {
                        
                        // Remove the current audit, if any
                        $audit = \LocationAudit::where('location_id', $location->id)
                                                ->where('question_id', $qhc->question_id)
                                                ->delete();

                        // Add a new audit
                        \LocationAudit::create([
                            'location_id' => $location->id,
                            'question_id' => $qhc->question_id,
                            'answer_id' => 0,
                            'comment' => '',
                            'is_archived' => 0,
                        ]);
                    }
                }
            }

            if (isset($data['aeo']) && $data['aeo'] != 0)
            {
                $location->aeo_number = $data['aeo_num'];
                $location->save();

                if (($certs->aeo != $data['aeo']) || $data['aeo_certificate'])
                {
                    
                   if (!empty($data['aeo_certificate'])) {  

                    \LocationCertification::where('location_id', $id)
                                            ->where('certification_id', $certs->aeo)
                                            ->delete();

                                         
                        $file = $data['aeo_certificate'];
                        $original_name = $file->getClientOriginalName();
                        $mime_type = $file->getMimeType();
                        $newname = sha1(microtime(true));
                        $path = storage_path() .'/'. self::$certificates_files_path;
                        $file->move($path, $newname);

                        \LocationCertification::create([
                                'certificate_file' => $path .'/'. $newname,
                                'filename' => $original_name,
                                'location_id' => $id,
                                'certification_id' => $data['aeo'],
                            ]);
                    }

                    // If there is a certification change, Update the audits as well
                    $qhcs = \QuestionCertification::where('certification_id', $data['tapa'])->get();
                    foreach ($qhcs as $qhc) {
                        
                        // Remove the current audit, if any
                        $audit = \LocationAudit::where('location_id', $location->id)
                                                ->where('question_id', $qhc->question_id)
                                                ->delete();

                        // Add a new audit
                        \LocationAudit::create([
                            'location_id' => $location->id,
                            'question_id' => $qhc->question_id,
                            'answer_id' => 0,
                            'comment' => '',
                            'is_archived' => 0,
                        ]);
                    }
                }
            }

            // Update the scores too
            $location->score = self::calculateScore($location->id);
            $location->save();
        }
        elseif ($step == 'questions')
        {
            $questions = $data['question'];
            $question_comments = isset($data['comment']) ? $data['comment'] : [];

            // Delete current audits
            $audits = \LocationAudit::where('location_id', $id)
                                        ->where('is_archived', 0)
                                        ->delete();
            // Save the audits
            $audits = [];
            foreach ($questions as $qid => $aid)
            {
                $audit = new \stdClass;
                $audit->is_archived = 0;
                $audit->answer_id = intval($aid);
                
                \LocationAudit::create([
                    'location_id' => $location->id,
                    'question_id' => $qid,
                    'answer_id' => $audit->answer_id,
                    'comment' => isset($question_comments[$qid]) ? $question_comments[$qid] : '',
                    'is_archived' => 0,
                ]);

                $audits[] = $audit;
            }

            // Calculate the score from new audits
            $location->score = self::calculateScore($location->id, $audits);
            $location->save();
        }
        elseif ($step == 'comments')
        {
            $location->comment = $data['comments'];
            $location->save();
        }

        // Update the edit log
        /*\LocationLog::create([
            'location_id' => $location->id,
            'user_id' => \Auth::User()->id,
        ]);*/
        $locationlogArray = ['location_id' => $location->id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];

        \LocationLog::insert($locationlogArray);

        // Send location update notification
        Emails::sendLocationCreateUpdate(\Location::with('user', 'country', 'lsp')->find($location->id), 'updated');
    }

    /**
     * Get the current audit certifications 
     *
     * @param $id number
     * @return array
     */
    public static function getCurrentCertifications($id)
    {
        $data = new \stdClass;

        // Get all certifications as well as disabled groups
        $disabled_groups = \LocationCertificationDisabledGroup::where('location_id', $id)
                                                                ->get()
                                                                ->lists('certification_group_id');
        $certifications = \LocationCertification::where('location_id', $id)
                                                    ->get()
                                                    ->lists('certificate_file', 'certification_id');

        $tapa = array_intersect(array_keys($certifications), array_keys(Site::$TAPA_CERTIFICATIONS));
        $data->tapa = end($tapa) ?: 0;
        if ($data->tapa)
        {
            $data->tapa_certificate = $certifications[$data->tapa];
        }

        $data->ctpat = 0;
        $data->aeo = 0;

        $data->disabled_groups = $disabled_groups;
        
        if (!in_array(Site::C_TPAT_GROUP, $disabled_groups))
        {
            $ctpat = array_intersect(array_keys($certifications), array_keys(Site::$C_TPAT_CERTIFICATIONS));
            $data->ctpat = end($ctpat) ?: 0;
            if ($data->ctpat)
            {
                $data->ctpat_certificate = $certifications[$data->ctpat];
            }
        }
        else 
        {
            $data->ctpat = 'na';
        }

        if (!in_array(Site::AEO_GROUP, $disabled_groups))
        {
            $aeo = array_intersect(array_keys($certifications), array_keys(Site::$AEO_CERTIFICATIONS));
            $data->aeo = end($aeo) ?: 0;
            if ($data->aeo)
            {
                $data->aeo_certificate = $certifications[$data->aeo];
            }
        }
        else
        {
            $data->aeo = 'na';
        }

        return $data;
    }

    /**
     * Get the question list from certification selection
     *
     * @param $tapa_needed number
     * @param $certificates_actual array     
     * @param array
     */
    public static function getQuestionsList($tapa_needed, $certificates_actual) {
        $disabled_certs = array();
        if ($certificates_actual['tapa'] == 'na') {
            $disabled_certs[] = Site::TAPA_FSR_A;
            $disabled_certs[] = Site::TAPA_FSR_B;
            $disabled_certs[] = Site::TAPA_FSR_C;
        }
        if ($certificates_actual['ctpat'] == 'na') {
            $disabled_certs[] = Site::C_TPAT;
        }
        if ($certificates_actual['aeo'] == 'na') {
            $disabled_certs[] = Site::AEO_S;
            $disabled_certs[] = Site::AEO_F;
            $disabled_certs[] = Site::AEO_C;
        }

        $certifications = array();
        if ($certificates_actual['tapa'] != 'na' && $certificates_actual['tapa'] != 0) {
            $certifications[] = $certificates_actual['tapa'];
        }
        if ($certificates_actual['ctpat'] != 'na' && $certificates_actual['ctpat'] != 0) {
            $certifications[] = $certificates_actual['ctpat'];
        }
        if ($certificates_actual['aeo'] != 'na' && $certificates_actual['aeo'] != 0) {
            $certifications[] = $certificates_actual['aeo'];
        }

        $question_list = \Question::with('certifications')
                                    ->whereIn('availability', [Site::AVAILABILITY_LOCATION, Site::AVAILABILITY_LOCATION_ROUTE])
                                   // ->where('is_archived', 0)
                                    ->orderBy('order')
                                    ->get()
                                    ->all();

        $questions = array();
        $i = 0;

        foreach ($question_list as $question) {
            $question_certs = array();
            foreach ($question->certifications as $certification) {
                $question_certs[$certification->id] = $certification->name;
            }
            $questioncert_ids = array_keys($question_certs);

            $tapa_certs = array_keys(Site::$TAPA_CERTIFICATIONS);
            $c_tpat_certs = array_keys(Site::$C_TPAT_CERTIFICATIONS);
            $aeo_certs = array_keys(Site::$AEO_CERTIFICATIONS);

            // Find the question certificate category
            $is_tapa = array_intersect($tapa_certs, $questioncert_ids);
            $is_c_tpat = array_intersect($c_tpat_certs, $questioncert_ids);
            $is_aeo = array_intersect($aeo_certs, $questioncert_ids);

            $category = 0;
            if (! empty($is_tapa)) {
                $category = 'tapa';
            }
            if (! empty($is_c_tpat)) {
                $category = 'c_tpat';
            }
            if (! empty($is_aeo)) {
                $category = 'aeo';
            }

            // Set the question and its certifications
            $questions[$category][$i]['id'] = $question->id;
            $questions[$category][$i]['text'] = $question->text;
            $questions[$category][$i]['is_mandatory'] = $question->is_mandatory;
            $questions[$category][$i]['certifications'] = implode(', ', $question_certs);
            $questions[$category][$i]['display'] = 0;

            if ($category == 'c_tpat' && $certificates_actual['ctpat'] == '0') {
                $questions[$category][$i]['display'] = 1;
            }
            elseif ($category == 'aeo' && $certificates_actual['aeo'] == '0') {
                $questions[$category][$i]['display'] = 1;
            }
            elseif (self::questionToDisplay($tapa_needed, $certifications, $questioncert_ids, $disabled_certs, $question->is_mandatory)) {
                $questions[$category][$i]['display'] = 1;
            }

            $i++;
        }

        return $questions;        
    }

    public static function questionToDisplay($tapa_needed, $certifications, $questioncert_ids, $disabled_certs, $is_mandatory) {

        // list of scenarios in which the question should not display
        $dummy_session_certs = $certifications;
        if ($tapa_needed == Site::TAPA_FSR_A) {
            if (in_array(Site::TAPA_FSR_A, $certifications)) { 
                // if TAPA FSR A is selected then no question mappad to TAPA FSR A, TAPA FSR B and TAPA FSR C should be displayed
                array_push($dummy_session_certs, Site::TAPA_FSR_B, Site::TAPA_FSR_C);
            }
            if (in_array(Site::TAPA_FSR_B, $certifications)) { 
                // if TAPA FSR B is selected then no question mappad to TAPA FSR B and TAPA FSR C should be displayed
                array_push($dummy_session_certs, Site::TAPA_FSR_C);
            }
            // if TAPA FSR C is selected then no question mappad to TAPA FSR C should be displayed
        }

        if ($tapa_needed == Site::TAPA_FSR_C) {
            if (in_array(Site::TAPA_FSR_A, $certifications) 
                || in_array(Site::TAPA_FSR_B, $certifications) 
                || in_array(Site::TAPA_FSR_C, $certifications)) {
                if (in_array(Site::TAPA_FSR_A, $certifications)) { 
                    array_push($dummy_session_certs, Site::TAPA_FSR_B, Site::TAPA_FSR_C);
                }
                if (in_array(Site::TAPA_FSR_B, $certifications)) { 
                    array_push($dummy_session_certs, Site::TAPA_FSR_A, Site::TAPA_FSR_C);
                }
                if (in_array(Site::TAPA_FSR_C, $certifications)) { 
                    array_push($dummy_session_certs, Site::TAPA_FSR_A, Site::TAPA_FSR_B);
                }
            }
        }

        $result = self::questionToDisplayForLocation($tapa_needed, $certifications, $questioncert_ids, $dummy_session_certs, $disabled_certs, $is_mandatory);
        return $result;
    }    
    
    public static function questionToDisplayForLocation($tapa_needed, $certifications, $questioncert_ids, $session_cert, $disabled_certs, $is_mandatory) {

        if (in_array(Site::TAPA_FSR_A, $questioncert_ids) 
            || in_array(Site::TAPA_FSR_B, $questioncert_ids) 
            || in_array(Site::TAPA_FSR_C, $questioncert_ids)) {
            
            if($tapa_needed == Site::TAPA_FSR_A) {
                if (!in_array(Site::TAPA_FSR_A, $certifications) 
                    && !in_array(Site::TAPA_FSR_B, $certifications) 
                    && !in_array(Site::TAPA_FSR_C, $certifications)) {
                    if (in_array(Site::TAPA_FSR_A, $questioncert_ids)) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                elseif (in_array(Site::TAPA_FSR_B, $certifications)) {
                    if (!in_array(Site::TAPA_FSR_B, $questioncert_ids) 
                        && !in_array(Site::TAPA_FSR_C, $questioncert_ids)) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                elseif (in_array(Site::TAPA_FSR_C, $certifications)) {
                    if (!in_array(Site::TAPA_FSR_C, $questioncert_ids)) {
                        return true;
                    }
                    else {
                        return false;
                    }
                }
                else {
                    foreach ($questioncert_ids as $id) {
                        if (in_array($id, $session_cert) 
                            || in_array($id,$disabled_certs)) {
                            return false;
                        }
                    }
                }
            }
            elseif ($tapa_needed == Site::TAPA_FSR_C) {
                if (!in_array(Site::TAPA_FSR_A, $certifications) 
                    && !in_array(Site::TAPA_FSR_B, $certifications) 
                    && !in_array(Site::TAPA_FSR_C, $certifications)) {
                        if (in_array(Site::TAPA_FSR_C, $questioncert_ids)) {
                            return true;
                        }
                        else {
                            return false;
                        }
                }
                else {
                    foreach($questioncert_ids as $id) {
                        if (in_array($id, $session_cert) || in_array($id,$disabled_certs)) {
                            return false;
                        }
                    }
                }
            }
            else {
                foreach ($questioncert_ids as $id) {
                    if (in_array($id, $session_cert) || in_array($id,$disabled_certs)) {
                        return false;
                    }
                }
            }
        }
        else {
            foreach ($questioncert_ids as $id) {
                if (in_array($id, $session_cert) || in_array($id,$disabled_certs)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Calculate the score from the audits
     *
     * @param $location_id integer
     * @param $audits array
     * @return float
     */
    public static function calculateScore($location_id, $audits = null)
    {
        if (! $audits)
        {
            $audits = \LocationAudit::where('location_id', $location_id)->get()->all();
        }

        $score = $count = $final_score = 0;
        
        if ($audits)
        {
            foreach ($audits as $audit)
            {
                if($audit->answer_id == '1' || $audit->answer_id == '0')
                    $score += 100;
                if($audit->answer_id == '2')
                    $score += 50;
                if($audit->answer_id == '3')
                    $score += 0;
                if($audit->answer_id != '4')
                    $count++;
            }

            $final_score = $score / $count;
        }

        return $final_score;
    }

    /**
     * Geting Incdividual detail lanes for creating route automatically
     *
     */


    public static function getLocationInvidualDetail($id,$pos){

        $location = \Location::select('site as '.$pos.'site','address as '.$pos.'address','coordinates as '.$pos.'coordinates','country_id as '.$pos.'country_id')
                 ->where('id',$id)
                 ->get()
                 ->all();

        return $location;
    }
    
}