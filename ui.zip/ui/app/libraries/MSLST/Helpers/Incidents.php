<?php
namespace MSLST\Helpers;

use MSLST\Constants\Site;
use Carbon\Carbon;

class Incidents {

    /**
     * Represents basic information fields.
     *
     * @var array
     */
    public static $basic_information_fields = [
                'type',
                'plant_care',
                'short_description',
                'incident_date',
                'region',
                'country',
                'location_city',
                'facility',
                'location_address',
                'coordinates',
                'type_of_loss',
                'type_of_other_loss'
            ];

    /**
     * Represents customer transportation fields.
     *
     * @var array
     */
    public static $customer_transportation_fields = [
                'consignee',
                'customer',
                'delivery_note_number',
                'cmr',
                'pickup_date',
                'pickup_time',
                'location_of_reporter',
                'driver_name',
                'vehicle_details',
                'carriers_and_contractors',
                'routing',
                'airline',
                'hawb',
                'mawb',
                'originating_facility',
                'destination_facility',
                'method_of_transportation',
            ];

    /**
     * Represents units investigation fields.
     *
     * @var array
     */
    public static $units_investigation_fields = [
                'number_of_plts_missing',
                'product_description',
                'number_of_units_missing',
                'value_per_unit',
                'total_value_of_lost_units',
                'type_of_device',
                'type_of_other_device',
                'name_of_investigation_authority',
                'investigation_file_number',
                'first_findings',
                'final_investigation_findings',
				        'contact_information',
                'dq',
            ];

    /**
     * Represents attachment fields.
     *
     * @var array
     */
    public static $attachments_fields = [
                'attachment',
                'description',
                'imei_list',
                'sn_list',
            ];

    /**
     * Represents multi value fields.
     *
     * @var array
     */
    public static $multi_fields = [
        'product_description',
        'number_of_units_missing',
        'value_per_unit',
        'attachment',
        'description'
    ];

    /**
     * Represents file fields.
     *
     * @var array
     */
    public static $file_fields = [
        'imei_list',
		'sn_list',
        'attachment'
    ];

    /**
     * Summary Fields
     *
     *@var array
     **/
    public static $summary_fields=[
    ];

    /**
     * Represents incident IMEI files path.
     *
     * @var string
     */
    public static $imei_files_path = 'files/incidents/imei';
	
	/**
	 * Represents incident SN files path
	 *
	 * @var string
	 */
	 
	 public static $sn_files_path = 'files/incidents/sn';
	
    /**
     * Represents incident files path.
     *
     * @var string
     */
    public static $attachments_files_path = 'files/incidents';

    /**
     * Get all incidents by filters
     *
     * @param $filters array
     * @return array
     */
    public static function getFilteredIncidents($filters)
    {
		$incidents = \Incident::with('user', 'country', 'region', 'product');

		if (isset($filters['daterange']) && !empty($filters['daterange']))
		{
			list($start, $end) = explode(' - ', $filters['daterange']);

			$start = new \DateTime($start);
			$end = new \DateTime($end);

			$incidents->where(\DB::raw("FORMAT(incident_date,'yyyy-MM-dd')"), '>=', $start->format('Y-m-d'))
					  ->where(\DB::raw("FORMAT(incident_date,'yyyy-MM-dd')"), '<=', $end->format('Y-m-d'));
		}

		if (isset($filters['user']) && !empty($filters['user']))
		{
			$incidents->whereIn('user_id', $filters['user']);
		}

		if (isset($filters['customer']) && !empty($filters['customer']))
		{
			foreach ($filters['customer'] as $key=>$customer)
			{
				$filters['customer'][$key] = strtolower($customer);
            }
            $incidents->whereIn('customer' , $filters['customer']);

		}

		if (isset($filters['category']) && !empty($filters['category']))
		{
			$incidents->whereIn('category', $filters['category']);
		}

    if (isset($filters['closure']) && !empty($filters['closure']))
    {
      $incidents->whereIn('closure_state', $filters['closure']);
    }

		if (isset($filters['status']) && !empty($filters['status']))
		{
			if (count($filters['status']) == 1)
			{
				if ($filters['status'][0] == 'closed')
				{
					//$incidents->whereRaw('(closed_at is not null AND closed_at <> "0000-00-00 00:00:00")');
                    $incidents->whereRaw('(closed_at is not null)');
				}
				else
				{
					$incidents->whereRaw('(closed_at is null)');
				}
			}
		}
        if (isset($filters['type_of_device']) && !empty($filters['type_of_device']))
        {           
          //  $option = implode('|',$filters['type_of_device']);
            //   print "<pre>"; print_r($filters['type_of_device']); exit;
           $type_devce  = "REPLACE(REPLACE(REPLACE(incidents.type_of_device,'\"',''),']',''),'[','')";
           $incidents->whereIn(\DB::raw($type_devce),$filters['type_of_device']);
        }
		if (isset($filters['lsp']) && !empty($filters['lsp']))
		{
            $incidents->whereHas('user', function($q) use (&$filters) {
                $q->whereIn('lsp_id', $filters['lsp']);
                $q->withTrashed();
            });
		}

		if (isset($filters['region']) && !empty($filters['region']))
		{
			$incidents->whereIn('region_id', $filters['region']);
		}

		if (isset($filters['country']) && !empty($filters['country']))
		{
			$incidents->whereIn('country_id', $filters['country']);
		}

		if (isset($filters['review']) && !empty($filters['review']))
		{
			$incidents->whereIn('review_requested', $filters['review']);
		}

		if (isset($filters['keywords']) && !empty($filters['keywords']))
		{
			$keywords = strtolower($filters['keywords']);

			$incidents->where(function ($q) use ($keywords) {
				$q->orWhereRaw('lower(short_description) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(location_address) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(location_city) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(facility) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(hawb) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(mawb) like \'%'. $keywords .'%\'')
          		  ->orWhereRaw('lower(originating_facility) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(consignee) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(delivery_note_number) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(cmr) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(party_responsible) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(reference_of_reporting_party) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(location_of_reporter) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(driver_name) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(vehicle_details) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(carriers_and_contractors) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(routing) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(airline) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(first_findings) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(review_comment) like \'%'. $keywords .'%\'');
			});
		}

		if (isset($filters['incident_id']) && !empty($filters['incident_id']))
		{
            $incident_id = $filters['incident_id'];

            if (preg_match('/^'.Site::INCIDENT_PREFIX.'/', $incident_id))
            {
                $incident_id = ltrim($incident_id, Site::INCIDENT_PREFIX);
            }

            $incidents->where('id', intval($incident_id));
		}

        if (\Auth::User()->isUser())
        {
            $incidents->where(function ($q) {
                $owners = \IncidentOwner::select('incident_id')->where('user_id', \Auth::User()->id)->lists('incident_id');
				$q->where('incidents.user_id', \Auth::User()->id);
				
				if (! empty($owners))
				{
					$q->OrWhereIn('incidents.id', $owners);
				}
            });
        }

        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
          /* $incidents->whereHas('user', function($q) {
                $q->where('lsp_id', '=', \Auth::User()->lsp->id);
            });*/

           $regionChk = \UserRegion::select('region_id')
                                   ->where('user_id',\Auth::User()->id)
                                   ->lists('region_id');

           $incidents->whereIn('region_id', $regionChk);

           $lspChk    = \User::withTrashed()
                             ->select('id')
                             ->where('lsp_id',\Auth::User()->lsp->id)
                             ->lists('id');
           $incidents->whereIn('user_id', $lspChk);
           
        }


        if (isset($filters['imielist']) && !empty($filters['imielist'])){
            $imielist = $filters['imielist'];
              $incidents->where(function($imie) use ($imielist){
               
                $imilst = explode(',',$imielist);
                  $im_qry =  \Attachment::select('incident_id');
                   
                   foreach ($imilst as $key => $imi_value) {
                     if($key == 0)  $im_qry->WhereRaw('attachment_info like \'%'. $imi_value .'%\'');
                     else $im_qry->orWhereRaw('attachment_info like \'%'. $imi_value .'%\'');
                   }

                   $im_qry = $im_qry->lists('incident_id');

                  //if(!empty($im_qry)) 
                    $imie->whereIn('incidents.id',$im_qry);
              });
        }


		$incidents = $incidents
					->orderBy('incident_date', 'DESC')
					->get()
					->all();

		//dd(\DB::getQueryLog());

		return $incidents;
    }

    /**
     * Save the Incident along with the product
     * and investigation information
     */
    public static function saveIncidentData()
    {
        $incident_data = \Session::get('incidents');
        $attachment_data = $incident_data['attachments'] ;
		
		

        // Get the data from each steps
        $basic_information = (array) $incident_data['basic_information'];
        $customer_transportation = (array) $incident_data['customer_transportation'];
        $units_investigation = (array) $incident_data['units_investigation'];
		
	    // First create the incident
        $incident = \Incident::create([
            'type' => self::getIncidentType(
                $basic_information['type'],
                $basic_information['plant_care']
            ),
            'category' => self::getIncidentCategory(
                $units_investigation['total_value_of_lost_units']
            ),
            'short_description' => $basic_information['short_description'],
            'location_address' => $basic_information['location_address'],
            'location_city' => $basic_information['location_city'],
            'type_of_loss' => $basic_information['type_of_loss'],
            'type_of_other_loss' => $basic_information['type_of_other_loss'],
            'facility' => $basic_information['facility'],
            'coordinates' => $basic_information['coordinates'],
            'hawb' => $customer_transportation['hawb'],
            'mawb' => $customer_transportation['mawb'],
            'originating_facility' => $customer_transportation['originating_facility'],
            'destination_facility' => $customer_transportation['destination_facility'],
            'method_of_transportation' => $customer_transportation['method_of_transportation'],
            'consignee' => $customer_transportation['consignee'],
            'customer' => $customer_transportation['customer'],
            'delivery_note_number' => $customer_transportation['delivery_note_number'],
            'cmr' => $customer_transportation['cmr'],
            'location_of_reporter' => $customer_transportation['location_of_reporter'],
            'driver_name' => $customer_transportation['driver_name'],
            'vehicle_details' => $customer_transportation['vehicle_details'],
            'carriers_and_contractors' => $customer_transportation['carriers_and_contractors'],
            'routing' => $customer_transportation['routing'],
            'airline' => $customer_transportation['airline'],
            'first_findings' => $units_investigation['first_findings'],
            'type_of_device' => json_encode($units_investigation['type_of_device']),
            'type_of_other_device' =>json_encode( $units_investigation['type_of_other_device']),
            'pick_up' => self::getPickUpDate(
                $customer_transportation['pickup_date'],
                $customer_transportation['pickup_time']
            ),
            'incident_date' => self::getIncidentDateTime(
                $basic_information['incident_date']
            ),
            'investigation_status'=>1,
            'country_id' => $basic_information['country'],
            'region_id' => $basic_information['region'],
            'user_id' => \Auth::User()->id,
            'review_requested' => 0,
        ]);

        // Skip invalid products
        $product_description = [];
        $number_of_units_missing = [];
        $value_per_unit = [];
        foreach ($units_investigation['product_description'] as $i => $item)
        { 
            if (trim($units_investigation['product_description'][$i]) != ''
                && trim($units_investigation['number_of_units_missing'][$i]) != '')
            { //echo "<pre>";print_r($units_investigation['value_per_unit']);exit;
                $product_description[] = $units_investigation['product_description'][$i];
                $number_of_units_missing[] = $units_investigation['number_of_units_missing'][$i];
                $value_per_unit[] = !empty($units_investigation['value_per_unit'])?$units_investigation['value_per_unit'][$i]:'NA';
            }
        }

        // Create the product information of the incident
        \Product::create([
            'number_of_plts_missing' => !empty($units_investigation['number_of_plts_missing'])?$units_investigation['number_of_plts_missing']:0,
            'number_of_units_missing' => json_encode($number_of_units_missing),
            'product_description' => json_encode($product_description),
            'value_per_unit' => json_encode($value_per_unit),
            'total_value_of_lost_units' => !empty($units_investigation['total_value_of_lost_units'])?$units_investigation['total_value_of_lost_units']:0,
            'incident_id' => $incident->id,
            'currency' => 0
        ]);

        // Create the official investigation information of the incident
        \OfficialInvestigation::create([
            'name_of_investigation_authority' => $units_investigation['name_of_investigation_authority'],
            'investigation_file_number' => $units_investigation['investigation_file_number'],
            'final_investigation_findings' => $units_investigation['final_investigation_findings'],
			      'contact_information' => $units_investigation['contact_information'],
            'dq' => $units_investigation['dq'],
            'incident_id' => $incident->id,
        ]);
		
        // Save the IMEI List (If any)

        if(!empty($attachment_data->imei_list['file_name']))
        {

            \Attachment::create([
                'attachment_type' => $attachment_data->imei_list['type'],
                'file_name' => $attachment_data->imei_list['file_name'],
                'file_description' => $attachment_data->imei_list['file_description'],
                'file_type' => $attachment_data->imei_list['file_type'],
                'description' => $attachment_data->imei_list['description'],
                'incident_id' => $incident->id,
                'attachment_info' => $attachment_data->imei_list['attachment_info']
            ]);
        }
		
		// Save the S/N List (If any)



          if(!empty($attachment_data->sn_list['file_name']))
        {

            \Attachment::create([
                'attachment_type' => $attachment_data->sn_list['type'],
                'file_name' => $attachment_data->sn_list['file_name'],
                'file_description' => $attachment_data->sn_list['file_description'],
                'file_type' => $attachment_data->sn_list['file_type'],
                'description' => $attachment_data->sn_list['description'],
                'incident_id' => $incident->id
            ]);
        }

        // Save the final attachments
        if(!empty($attachment_data->attachment)){

            foreach($attachment_data->attachment as $ky=>$file)
            {
                  \Attachment::create([
                    'attachment_type' => 'attachment',
                    'file_name' => $file['file_name'],
                    'file_description' => $file['file_description'],
                    'file_type' => $file['file_type'],
                    'description' => $attachment_data->description[$ky],
                    'incident_id' => $incident->id
                ]);

                  $i++;
            }
        }else if(!is_object($attachment_data)){

            if(!empty($attachment_data['file'][0])){

                $i = 0;
                foreach ($attachment_data['file'] as $file)
                {
                    $original_name = $file->getClientOriginalName();
                    $mime_type = $file->getMimeType();
                    $newname = sha1(time() . openssl_random_pseudo_bytes(10));
                    $path = storage_path() .'/'. self::$attachments_files_path;
                    $file->move($path, $newname);

                    \Attachment::create([
                        'attachment_type' => 'attachment',
                        'file_name' => $path .'/'. $newname,
                        'file_description' => $original_name,
                        'file_type' => $mime_type,
                        'description' => $attachment_data['description'][$i],
                        'incident_id' => $incident->id
                    ]);

                    $i++;
                }

           }

        }


        //Incident Log Storage
        \IncidentLog::Create([
            'incident_id' => $incident->id,
            'user_id'     => \Auth::User()->id,
            'created_at'  => Carbon::parse('now'),
            ]);

        // Send incident create notification
        Emails::sendIncidentCreateUpdate($incident, 'created');

        // Destroy the session data
        \Session::forget('incidents');
    }

    /**
     * Get the incident type from the form data
     *
     * @param $type string
     * @param $plant_care string
     * @return string
     */
    public static function getIncidentType($type, $plant_care)
    {
        if (intval($plant_care))
        {
            return Site::$INCIDENT_TYPES[$type];
        }
        else
        {
            return Site::$INCIDENT_TYPES[0];
        }

    }

    /**
     * Get the incident category from form data
     *
     * @param $type float
     * @return string
     */
    public static function getIncidentCategory($value)
    {
        if ($value < Site::INCIDENT_MINOR_THRESHOLD && $value!=null)
        {
            return 'minor';
        }
        elseif ($value <=  Site::INCIDENT_MAJOR_THRESHOLD && $value!=null)
        {
            return 'medium';
        }
        
        return 'major';
    }

    /**
     * Get the incident's pickup date from the date and time
     *
     * @param $date string
     * @param $time string
     * @return string
     */
    public static function getPickUpDate($date, $time)
    {
        $pickupdate = Carbon::createFromFormat('Y-m-d H:i A', $date.' '.$time)
                    ->toDateTimeString(); 
        return  $pickupdate.".000";
    }

    /**
     * Get the incident date time string from the date
     *
     * @param $date string
     * @param $time string
     * @return string
     */
    public static function getIncidentDateTime($date)
    {
        $incidentdate = Carbon::createFromFormat('Y-m-d', $date)
                    ->toDateTimeString();

        return   $incidentdate .".000";
    }

    /**
     * Get decoded products from JSON
     *
     * @param $products object
     * @return array
     */
    public static function getDecodedProducts($products)
    {
    	$items = [];

    	if (\MSLST\Helpers\Common::isJson($products->product_description))
    	{
    		$descriptions = json_decode($products->product_description);
    		$units = json_decode($products->number_of_units_missing);
    		$value = json_decode($products->value_per_unit);
    		$count = count($descriptions);

    		for ($i = 0; $i < $count; $i++)
    		{
    			$items[$i]['description'] =  $descriptions[$i];
    			$items[$i]['units'] =  $units[$i] ?:'NA';
    			$items[$i]['value'] =  $value[$i] ?:'NA';
    		}
    	}
    	else
    	{
    		$items[] = [
    			'description' => $products->product_description,
    			'units' => $products->number_of_units_missing ?:'NA',
    			'value' => $products->value_per_unit ?:'NA',
    		];
    	}

    	return $items;
    }

    /**
     * Get IMEI list of the incidents
     *
     * @param $attachment object
     * @param $link boolean
     * @return string
     */
    public static function getImeiList($attachment, $link = true)
    {
    	$imei_list = [];
    	foreach ($attachment as $item)
    	{
    		if ($item->attachment_type == 'imeiList')
    		{
    			if ($link)
    			{
    				$imei_list[] = '<p><a href="'. route('incidents.download', [$item->id, $item->incident_id, 'imei']) .'">'. $item->file_description .'</a></p>';
    			}
    			else
    			{
    				$imei_list[] = [
    					'name' => $item->file_description,
    					'description' => $item->description,
    				];
    			}
    		}
    	}

    	if (!empty($imei_list))
    	{
    		if ($link)
    		{
    			return implode(' ', $imei_list);
    		}
    		else
    		{
    			return $imei_list;
    		}
    	}

    	return 'No IMEI list uploaded';
    }
	
	/**
     * Get S/N list of the incidents
     *
     * @param $attachment object
     * @param $link boolean
     * @return string
     */
    public static function getSnList($attachment, $link = true)
    {
    	$imei_list = [];
    	foreach ($attachment as $item)
    	{
    		if ($item->attachment_type == 'snList')
    		{
    			if ($link)
    			{
    				$sn_list[] = '<p><a href="'. route('incidents.download', [$item->id, $item->incident_id, 'sn']) .'">'. $item->file_description .'</a></p>';
    			}
    			else
    			{
    				$sn_list[] = [
    					'name' => $item->file_description,
    					'description' => $item->description,
    				];
    			}
    		}
    	}

    	if (!empty($sn_list))
    	{
    		if ($link)
    		{
    			return implode(' ', $sn_list);
    		}
    		else
    		{
    			return $sn_list;
    		}
    	}

    	return 'No S/N list uploaded';
    }

    /**
     * Check if there are attachments
     *
     * @param $attachment object
     * @return boolean
     */
    public static function hasAttachments($attachment)
    {

      $status = false;
    	foreach ($attachment as $item)
    	{
     		if ($item->attachment_type == 'attachment' || $item->attachment_type == 'closeincident' )
    		{
    			$status = true;
    			break;
    		}
    	}

    	return $status;
    }

    /**
     * Get the incidents step data
     *
     * @param $name string
     * @return object
     */
    public static function getIncidentStepData($name)
    {
        $data = new \stdClass;
        $fields = [];

        $fields = self::${$name .'_fields'};

        if (\Session::has('incidents.'. $name))
        {
            $data = (object) \Session::get('incidents.'. $name);
        }
        else
        {
            foreach ($fields as $field)
            {
                if (in_array($field, self::$multi_fields))
                {
                    $data->{$field} = [''];
                }
                else
                {
                    $data->{$field} = '';
                }
            }
        }

       
        return $data;
    }

    /**
     * Set the incidents step data
     *
     * @param $name string
     * @param $data array
     */
    public static function setIncidentStepData($name, $step_data)
    {
        $data = new \stdClass;

        $fields = self::${$name .'_fields'};


        
        foreach ($fields as $field)
        {
			
            if (in_array($field, self::$file_fields))
            {
                $file = \Input::file($field);
				

        		   if(!empty($file) ){
        			   
              			   if($field == 'imei_list' ) {
              					$type = 'imeiList';
              					$filepath = self::$imei_files_path;
              				}else if($field == 'sn_list' ){
              					$type = 'snList';
              					$filepath = self::$sn_files_path;
              				}
        				
        		            $original_name = $file->getClientOriginalName();
                        $mime_type = $file->getMimeType();
                        $newname = sha1(microtime(true));
                        $path = storage_path() .'/'. $filepath;
                        $file->move($path, $newname);

                        // File Read
                        if($field == 'imei_list')  self::UpdateAttachmentInfo($path.'/'.$newname);

                        $data->{$field} = [
                            'type' => $type,
                            'file_name' => $path .'/'. $newname,
                            'file_description' => htmlentities($original_name),
                            'file_type' => $mime_type,
                            'description' => '',
                            'attachment_info' => \Session::get('attachment_info')?str_replace('null','',\Session::get('attachment_info')):''
                        ];
        				
                    }else if($field == 'attachment'){

        			         	$step_data['file'] = array_filter($step_data['file']);

                          if(!empty($step_data['file'][0])){
                                foreach($step_data['file'] as $key=>$attachfile){
                                    $original_name = $attachfile->getClientOriginalName();
                                    $mime_type = $attachfile->getMimeType();
                                    $newname = sha1(time() . openssl_random_pseudo_bytes(10));
                                    $path = storage_path() .'/'. self::$attachments_files_path;
                                    $attachfile->move($path, $newname);

                                    $data->{$field}[$key] = [
                                    'type' => 'attachment',
                                    'file_name' => $path .'/'. $newname,
                                    'file_description' => htmlentities($original_name),
                                    'file_type' => $mime_type,
                                    'description' => '',
                                ];

                                }
                          }
                        }
            }
            else
            { 
                if($step_data['step']==2 && !isset($step_data['number_of_plts_missing'])) {
                    $step_data['number_of_plts_missing']=null;
                    $step_data['value_per_unit']=null;
                    $step_data['total_value_of_lost_units']=null;
                }
                if(!is_array($step_data[$field]))
                    $data->{$field} = htmlentities($step_data[$field]);
                else
                    $data->{$field} = $step_data[$field];
            }

        }

        \Session::set('incidents.'. $name, $data);
    }

    /**
     * Get the incidents edit data
     *
     * @param $id number
     * @param $name string
     * @return object
     */
    public static function getIncidentEditData($id, $name)
    {

        $data = new \stdClass;
        $incident = \Incident::find($id);

        $data->id = $id;

        $fields = self::${$name .'_fields'};

        foreach ($fields as $field)
        {
            if (isset($incident->{$field}))
            {
                $data->{$field} = $incident->{$field};
            }
        }

        if ($name == 'basic_information')
        {
            // Form sepcific adjustments
            // Adjust plant care values
            if ($data->type == 'other')
            {
                $data->type = '';
                $data->plant_care = '';
            }
            else
            {
                $data->plant_care = 1;
            }

            // There is no region_id field, it is region
            $data->region = $incident->region->id;

            // There is no country_id field, it is country
            $data->country = $incident->country->id;

            // Show only date
            $data->incident_date = $incident->incident_date->format('Y-m-d');
        }
        elseif ($name == 'customer_transportation')
        {
            // Split the pick up date to date and time
            list($data->pickup_date, $data->pickup_time) = explode(' ', $incident->pick_up);
        }
        elseif ($name == 'units_investigation')
        {
            // Load the device data
            $data->type_of_device = json_decode($incident->type_of_device);
            $data->type_of_other_device = json_decode($incident->type_of_other_device);

            // Load the product data
            $product = \Product::where('incident_id', $id)->firstOrFail();

            foreach ($fields as $field)
            {
                if (isset($product->{$field}))
                {
                    $data->{$field} = $product->{$field};
                }
            }

            // Load the Official investigation data
            $investigation = \OfficialInvestigation::where('incident_id', $id)->firstOrFail();

            foreach ($fields as $field)
            {
                if (isset($investigation->{$field}))
                {
                    $data->{$field} = $investigation->{$field};
                }
            }
        }
        elseif ($name == 'attachments')
        {
            $attachments = \Attachment::where('incident_id', $id)
                                        ->whereIn('attachment_type', ['attachment','snList','imeiList'])
                                        ->get();
            if ($attachments)
            {
                $data->attachment = [];
                $data->filename = [];
                $data->description = [];

                foreach ($attachments as $attachment)
                {
                   if($attachment->attachment_type == 'attachment'){
                      $data->attachment[]  = $attachment->id;
                      $data->filename[]    = $attachment->file_description;
                      $data->description[] = $attachment->description;
                    }else if($attachment->attachment_type == 'snList'){
                      $data->sn_attachment = $attachment->id;
                      $data->sn_filename    = $attachment->file_description;
                      $data->sn_description = $attachment->description;
                    }else if($attachment->attachment_type == 'imeiList'){
                      $data->imei_attachment  = $attachment->id;
                      $data->imei_filename    = $attachment->file_description;
                      $data->imei_description = $attachment->description;
                    }

                }
            }
        }

       
        return $data;
    }

    /**
     * Save the incidents edit data
     *
     * @param $id number
     * @param $step string
     * @param $data array
     */
    public static function setIncidentEditData($id, $step, $data)
    {
        $incident = \Incident::findOrFail($id);
        
        if ($step == 'basic_information')
        {
            $incident->type = self::getIncidentType(
                $data['type'],
                $data['plant_care']
            );
            $incident->short_description = $data['short_description'];
            $incident->incident_date = self::getIncidentDateTime(
                $data['incident_date']
            );
            $incident->country_id = $data['country'];
            $incident->region_id = $data['region'];
            $incident->location_city = $data['location_city'];
            $incident->type_of_loss = $data['type_of_loss'];
            $incident->type_of_other_loss = $data['type_of_other_loss'];
            $incident->facility = $data['facility'];
            $incident->location_address = $data['location_address'];
            $incident->coordinates = $data['coordinates'];
            $incident->save();
        }
        elseif ($step == 'customer_transportation')
        {
            $incident->consignee = $data['consignee'];
            $incident->customer = $data['customer'];
            $incident->delivery_note_number = $data['delivery_note_number'];
            $incident->cmr = $data['cmr'];
            $incident->pick_up = self::getPickUpDate(
                $data['pickup_date'],
                $data['pickup_time']
            );
            $incident->location_of_reporter = $data['location_of_reporter'];
            $incident->driver_name = $data['driver_name'];
            $incident->vehicle_details = $data['vehicle_details'];
            $incident->carriers_and_contractors = $data['carriers_and_contractors'];
            $incident->routing = $data['routing'];
            $incident->airline = $data['airline'];
            $incident->hawb = $data['hawb'];
            $incident->mawb = $data['mawb'];
            $incident->originating_facility = $data['originating_facility'];
            $incident->destination_facility = $data['destination_facility'];
            $incident->save();
        }
        elseif ($step == 'units_investigation')
        {
            $incident->first_findings = $data['first_findings'];
            $incident->type_of_device = json_encode($data['type_of_device']);
            $incident->type_of_other_device = json_encode($data['type_of_other_device']);
            $incident->save();

            // Skip invalid items
            $type_of_device=[];
            $type_of_other_device = [];
            $product_description = [];
            $number_of_units_missing = [];
            $value_per_unit = [];
            foreach ($data['product_description'] as $i => $item)
            {
                if (trim($data['product_description'][$i]) != ''
                    && trim($data['number_of_units_missing'][$i]) != '')
                {
                    $product_description[] = $data['product_description'][$i];
                    $number_of_units_missing[] = $data['number_of_units_missing'][$i];
                    $value_per_unit[] =!empty($data['value_per_unit'])?$data['value_per_unit'][$i]:'NA';
                }
            }

            $product = \Product::where('incident_id', $id)->firstOrFail();
            $product->number_of_plts_missing = !empty($data['number_of_plts_missing'])?$data['number_of_plts_missing']:0;
            $product->product_description = json_encode($product_description);
            $product->number_of_units_missing = json_encode($number_of_units_missing);
            $product->value_per_unit = json_encode($value_per_unit);
            $product->total_value_of_lost_units =!empty($data['total_value_of_lost_units'])?$data['total_value_of_lost_units']:0;
            $product->save();
              
            $incident->category = self::getIncidentCategory(isset($data['total_value_of_lost_units'])?$data['total_value_of_lost_units']:null);
            $incident->save();
        	
			      $investigation = \OfficialInvestigation::where('incident_id', $id)->firstOrFail();
            $investigation->name_of_investigation_authority = $data['name_of_investigation_authority'];
            $investigation->investigation_file_number = $data['investigation_file_number'];
            $investigation->final_investigation_findings = $data['final_investigation_findings'];
			      $investigation->contact_information = $data['contact_information'];
            $investigation->dq = $data['dq'];
            $investigation->save();


            
        }
        elseif ($step == 'attachments')
        {

   
            if (isset($data['imei_list']))
            {
                // Delete current imei list
                $current_imei = \Attachment::where('incident_id', $id)
                                            ->where('attachment_type', 'imeiList');
                                            
                $current_imei->delete();

                // Create new imei attachment
                $file = $data['imei_list'];
                $original_name = $file->getClientOriginalName();
                $mime_type = $file->getMimeType();
                $newname = sha1(time() . openssl_random_pseudo_bytes(10));
                $path = storage_path() .'/'. self::$imei_files_path;
                $file->move($path, $newname);

                // File Read
                self::UpdateAttachmentInfo($path.'/'.$newname);
                

                \Attachment::create([
                    'attachment_type' => 'imeiList',
                    'file_name' => $path .'/'. $newname,
                    'file_description' => $original_name,
                    'file_type' => $mime_type,
                    'description' => '',
                    'incident_id' => $incident->id,
                    'attachment_info' => \Session::get('attachment_info')?str_replace('null','',\Session::get('attachment_info')):''
                ]);

                \Session::forget('attachment_info');
                
            }

            if(isset($data['sn_list'])){
                 // Delete current sn list
               $current_sn = \Attachment::where('incident_id', $id)
                                            ->where('attachment_type', 'snList');
                                      
                $current_sn->delete();

                // Create new imei attachment
                $file = $data['sn_list'];
                $original_name = $file->getClientOriginalName();
                $mime_type = $file->getMimeType();
                $newname = sha1(time() . openssl_random_pseudo_bytes(10));
                $path = storage_path() .'/'. self::$sn_files_path;
                $file->move($path, $newname);

                \Attachment::create([
                    'attachment_type' => 'snList',
                    'file_name' => $path .'/'. $newname,
                    'file_description' => $original_name,
                    'file_type' => $mime_type,
                    'description' => '',
                    'incident_id' => $incident->id
                ]);
            }

            if(!empty($data['current_file']))
            {
                // Handle the current files
                foreach($data['current_file'] as $id => $status)
                {
                    $attachment = \Attachment::find($id);

                    if ($status)
                    {
                        $attachment->description = $data['current_description'][$id];
                        $attachment->save();
                    }
                    else
                    {
                        $attachment->delete();
                    }
                }
            }

            // Handle the new files
            foreach ($data['file'] as $i => $file)
            {
                if ($file)
                {
                    $original_name = $file->getClientOriginalName();
                    $mime_type = $file->getMimeType();
                    $newname = sha1(time() . openssl_random_pseudo_bytes(10));
                    $path = storage_path() .'/'. self::$attachments_files_path;
                    $file->move($path, $newname);

                    \Attachment::create([
                        'attachment_type' => 'attachment',
                        'file_name' => $path .'/'. $newname,
                        'file_description' => $original_name,
                        'file_type' => $mime_type,
                        'description' => $data['description'][$i],
                        'incident_id' => $incident->id
                    ]);
                }
            }
        }
          //echo Carbon::parse();  exit;
        //Incident Log Storage
        \IncidentLog::Create([
            'incident_id' => $incident->id,
            'user_id'     => \Auth::User()->id,
            'created_at'  => Null,
            'updated_at'  => Carbon::parse('now')
            ]);
      
        // Send incident update notification
        Emails::sendIncidentCreateUpdate($incident, 'updated');
    }

    /**
     * Insert Attachmentinfo for IMIE LIST
     *
     **/
    public static function UpdateAttachmentInfo($file){

        \Excel::selectSheetsByIndex(range(0,1))->load($file, function($reader) { 
                            $reader->noHeading();
                                  $attachment_info = $reader->each(function($sheet){
                                      return json_encode($sheet); 
                                  });
                                \Session::put('attachment_info', $attachment_info);        
                          });

    }

    /**
     * Get Incident  Statistics Chart Data
     *
     **/
    public static function findStatisticsGroupedByYears($filterSet = NULL, $x_axis, $z_axis , $is_value = FALSE){

       /* New Code */
    $select_fields = [];    
    $xsort = Null;
    $zsort = Null;
    $total_audit = 'Total Incidents';
    $groupby = true;
    $montsort  = false;
    $datsort  = false;

    if(count($filterSet['filters']) == 1 && in_array('daterange',$filterSet['filters']) &&  !empty($filterSet['daterange'])){
      $groupby = false;
    } 

    if(($x_axis == $total_audit || $z_axis == $total_audit)){
        if ( $is_value == FALSE) {
              $select_fields[] = "count(incidents.id) as 'Total Incidents'";
        }else{
             $select_fields[] = "SUM(p.total_value_of_lost_units) as 'Total Incidents'";
        }
    } else {
        if($is_value == FALSE ) {
           $select_fields[] = 'COUNT(incidents.id) as total';
        }else{
          $select_fields[] = 'SUM(p.total_value_of_lost_units) as total';
        }
    }

    $sorting = true;
  
    if ($x_axis == 'daterange' || $z_axis == 'daterange') {

        if(!empty($filterSet['daterange']) ){
            $filt_dat = explode(" - ",$filterSet['daterange']);
            $filterSet['start_date'] = $filt_dat[0];
            $filterSet['end_date']   = $filt_dat[1];
         }

        if(!empty($filterSet['start_date'])) $filt_start_date = date('d M Y',strtotime($filterSet['start_date']));
          
        if(!empty($filterSet['end_date']))  $filt_end_date = date('d M Y',strtotime($filterSet['end_date']));

        if(!empty($filterSet['start_date']) && !empty($filterSet['end_date'])){
             $select_fields[] = "(CASE WHEN 1 >= 1 THEN '".$filt_start_date." - ".$filt_end_date."' END) as daterange";
             $sorting = false;
        }else{
             $select_fields[] = 'FORMAT(incidents.incident_date, \'yyyy\') as daterange';
             $datsort = true;
        }

       

        if(($x_axis == 'daterange' || $z_axis == 'daterange')  && $sorting == true) $xsort = "FORMAT(incidents.incident_date, 'yyyy')"; $zsort = $xsort;  $dsort = $zsort;
    }

   if ($x_axis == 'monthrange' || $z_axis == 'monthrange') {
        $select_fields[] = 'FORMAT(incidents.incident_date, \'MMM yyyy\') as monthrange ,FORMAT(incidents.incident_date, \'yyyyMM\') as sortmonth';
        if($x_axis == 'monthrange' || $z_axis == 'monthrange' ) { $xsort = 'FORMAT(incidents.incident_date, \'MMM yyyy\')';  $msort = 'FORMAT(incidents.incident_date, \'yyyyMM\')';}
        $montsort  = true;
    }

    if ($x_axis == 'category' || $z_axis == 'category') {
          $select_fields[] = 'incidents.category as category';
          if($x_axis == 'category')  $xsort = "incidents.category";
          if($z_axis == 'category')   $zsort = "incidents.category";
    }


   if ($x_axis == 'type_of_device' || $z_axis == 'type_of_device') {       
          $type_devce  = "REPLACE(REPLACE(REPLACE(incidents.type_of_device,'\"',''),']',''),'[','')";
          $select_fields[] = $type_devce.' as type_of_device ';      
          //print_r($select_fields);exit;die;

          if($x_axis == 'type_of_device')  $xsort = $type_devce;         
          if($z_axis == 'type_of_device')   $zsort = $type_devce;         
    }

    if ($x_axis == 'status' || $z_axis == 'status') {
          $select_fields[] = 'IIF(incidents.closed_at IS NULL, \'open\', \'closed\') as status';
          if($x_axis == 'status') $xsort = "IIF(incidents.closed_at IS NULL, 'open', 'closed')";
          if($z_axis == 'status') $zsort = "IIF(incidents.closed_at IS NULL, 'open', 'closed')";
    }

    if ($x_axis == 'lsp' || $z_axis == 'lsp') {
          $select_fields[] = 'c.name as lsp';
          if($x_axis == 'lsp')  $xsort = 'c.name';
          if($z_axis == 'lsp')  $zsort = 'c.name';
         
    }

    if ($x_axis == 'region' || $z_axis == 'region') {
          $select_fields[] = 'r.name as region';
          if($x_axis == 'region') $xsort = 'r.name';
          if($z_axis == 'region') $zsort = 'r.name';
    }


    if ($x_axis == 'country' || $z_axis == 'country') {
          $select_fields[] = 'l.name as country';
          if($x_axis == 'country') $xsort = 'l.name';
          if($z_axis == 'country') $zsort = 'l.name';
    }

      $incidents = \Incident::leftjoin('users as u','incidents.user_id','=','u.id')
                         ->leftjoin('lsps as c','u.lsp_id','=','c.id')
                         ->leftjoin('regions as r','incidents.region_id','=','r.id')
                         ->leftjoin('countries as l','incidents.country_id','=','l.id')
                         ->leftjoin('products as p','incidents.id','=','p.incident_id')
                         ->select(\DB::raw(implode(',', $select_fields)));

       if (!empty($filterSet['lsp'])) {
            $incidents->where("c.id",$filterSet['lsp']);
       }

       if (!empty($filterSet['start_date'])) {
            $incidents->where(\DB::raw('FORMAT(incidents.incident_date, \'yyyy-MM-dd\')'),'>=',$filterSet['start_date']);
       }

       if (!empty($filterSet['end_date'])) {
            $incidents->where(\DB::raw('FORMAT(incidents.incident_date, \'yyyy-MM-dd\')'),'<=',$filterSet['end_date']);
       }

      if (!empty($filterSet['start_month'])) {
            $incidents->where(\DB::raw('FORMAT(incidents.incident_date, \'yyyyMM\')'),'>=',$filterSet['start_month']);
       }

       if (!empty($filterSet['end_month'])) {
            $incidents->where(\DB::raw('FORMAT(incidents.incident_date, \'yyyyMM\')'),'<=',$filterSet['end_month']);
       }

       if (!empty($filterSet['region'])) {
            $incidents->where("r.id",$filterSet['region']);
       }

        if (isset($filterSet['status']) && $filterSet['status'] === '0' ) {
            $incidents->whereNUll('incidents.closed_at');
        }

        if(isset($filterSet['status']) && $filterSet['status'] == '1')
        {
            $incidents->whereNOTNUll('incidents.closed_at');
        }


       if (!empty($filterSet['category'])) {
            $incidents->where("incidents.category",$filterSet['category']);
       }
       
       if (!empty($filterSet['type_of_device'])) {
            $type_devce  = "REPLACE(REPLACE(REPLACE(incidents.type_of_device,'\"',''),']',''),'[','')";
            $incidents->whereRaw($type_devce." = '".$filterSet['type_of_device']."'");
       }

       if (!empty($filterSet['country'])) {
            $incidents->where('l.id',$filterSet['country']);
       }

       /* Create Group By Filter */
       if($groupby  == true){
            if($z_axis != $total_audit){
                if($sorting == true) $incidents->groupby(\DB::raw($xsort),\DB::raw($zsort));
                else    $incidents->groupby(\DB::raw($zsort));
             }else{
                $incidents->groupby(\DB::raw($xsort));
            }
       }

       if($montsort == true) {
             $incidents->groupby(\DB::raw($msort));
             $incidents->orderby(\DB::raw($msort));
       }elseif($datsort == true) {
            $incidents->orderby(\DB::raw($dsort));
        }

       $results = $incidents->get();

       //echo "<pre>"; print_r($results); exit;
        return  $results;

    }

    /**
     * Get Incident  In Map Plotting Data
     *
     *@ return Array
     **/
    public static function findStatisticsMapLocations($filterSet = NULL, $regionsArray = array()) {

        $select_item[] = 'incidents.id';
        $select_item[] = 'incidents.region_id as rid';
        $select_item[] = 'e.name as company_name';
        $select_item[] = 'e.id as cid';
        $select_item[] = 'l.name as country_name';
        $select_item[] = 'incidents.coordinates as coordinates';
        $select_item[] = "CONCAT(c.first_name,' ',c.last_name) as name";
        $select_item[] = 'c.id as userid';
        $select_item[] = 'FORMAT(incidents.incident_date, \'yyyy-MM-dd\') as date';
        $select_item[] = 'p.total_value_of_lost_units as value';
        $select_item[] = 'incidents.incident_date';
        $select_item[] = 'incidents.category as category';
        $select_item[] = 'incidents.short_description as description';
        $select_item[] = 'incidents.location_city as city';

        $incidents = \DB::table('incidents')->leftJoin('users as c','incidents.user_id','=','c.id')
                              ->leftJoin('lsps as e','c.lsp_id','=','e.id')
                              ->leftJoin('regions as r','incidents.region_id','=','r.id')
                              ->leftJoin('countries as l','incidents.country_id','=','l.id')
                              ->leftJoin('products as p','incidents.id','=','p.incident_id')
                              ->select(\DB::raw(implode(',',$select_item)));




         if(!empty($filterSet['daterange'])){
            $dateRang = explode(' - ',$filterSet['daterange']);
            $filterSet['incident_start_date'] = $dateRang[0];
            $filterSet['incident_end_date'] = $dateRang[1];
         }
        if (!empty($filterSet['incident_start_date'])) {
            $startDateObj = new \DateTime($filterSet['incident_start_date']);
            $startDate = $startDateObj->format('Y-m-d');
            $incidents->where(\DB::raw("FORMAT(incidents.incident_date,'yyyy-MM-dd')"),'>=',$startDate);
        }
        if (!empty($filterSet['incident_end_date'])) {
            $endDateObj = new \DateTime($filterSet['incident_end_date']);
            $endDate = $endDateObj->format('Y-m-d');
            $incidents->where(\DB::raw("FORMAT(incidents.incident_date,'yyyy-MM-dd')"),'<=',$endDate);
        }
        if(!empty($filterSet['start_month'])){
            $incidents->where(\DB::raw("FORMAT(incidents.incident_date, 'yyyyMM')"),'>=',$filterSet['start_month']);
        }

        if(!empty($filterSet['end_month'])){
            $incidents->where(\DB::raw("FORMAT(incidents.incident_date, 'yyyyMM')"),'<=',$filterSet['end_month']);
        }
        if (!empty($filterSet['category'])) {
           $incidents->where('incidents.category','=',$filterSet['category']);
        }
        if (!empty($filterSet['type_of_device'])) {
           $type_devce  = "REPLACE(REPLACE(REPLACE(incidents.type_of_device,'\"',''),']',''),'[','')";
           $incidents->where(\DB::raw($type_devce),$filterSet['type_of_device']);
        }
        if (isset($filterSet['status']) && $filterSet['status'] === '0' ) {
            $incidents->whereNUll('incidents.closed_at');
        }
        if(isset($filterSet['status']) && $filterSet['status'] == '1')
        {
            $incidents->whereNOTNULL('incidents.closed_at');
        }
        if (!empty($filterSet['lsp'])) {
            $incidents->where('e.id','=',$filterSet['lsp']);
        }
        if (!empty($filterSet['region'])) {
            $incidents->where('r.id','=',$filterSet['region']);
        }
        if (!empty($filterSet['country'])) {
            $incidents->where('l.id','=',$filterSet['country']);
        }

        $incidents->whereNUll('incidents.deleted_at');


      $results =  $incidents->orderby('incidents.incident_date','ASC')
                  ->get();
                 
        return $results;
    }

    /**
     * Prepare the incident data
     *
     * @param $id number
     * @param array
     */
    public static function prepareIncidentData($id) {
        $incident = \Incident::with('incident_investigation')->find($id);
        $products = \Product::where('incident_id', $id)->get()->toArray();
        $investigations = \OfficialInvestigation::where('incident_id', $id)->get()->toArray();
        $incidentlog = \IncidentLog::with('user')->where('incident_id', $id)->get()->toArray();


        $incident_meta = array(
            'Incident ID' => $incident->id,
            'Created By' => $incident->user->name,
            'Created On' => $incident->created_at->format('F j, Y H:i'),
            'Incident Status' => $incident->closed_at ? 'Closed' : 'Open',
        );
        if ($incident->closed_at) {
            $incident_meta['Closed On'] = $incident->closed_at->format('F j, Y H:i');
        }
        $incident_data = array(
            array(
                'title' => NULL,
                'data' => $incident_meta
            ),
        );

     ;

        $incident_basic = array(
            'Description' => $incident->short_description,
            'Category' => ucfirst($incident->category),
            'Facility' => $incident->facility,
            'Incident Date' => $incident->incident_date->format('F j, Y'),
            'Type of loss' => ($incident->type_of_loss)?: 'Not Specfied',
            'Country' => $incident->country->name,
            'City' => $incident->location_city,
            'Address' => $incident->location_address,
            'Lsp'    => $incident->user->lsp->name,
            'GPS Coordinates' => $incident->coordinates,
        );
        $incident_data[] = array(
            'title' => 'Basic Information',
            'data' => $incident_basic
        );

        $incident_customer = array(
            'Consignee' => $incident->consignee,
            'Customer' => $incident->customer,
            'Delivery note number' => $incident->delivery_note_number,
            'CMR' => $incident->cmr,
        );
        $incident_data[] = array(
            'title' => 'Customer Details',
            'data' => $incident_customer
        );

        $incident_transport = array(
            'Pick Up from Origin (Date & Time)' => $incident->pick_up->format('F j, Y H:i'),
            'Location of The Incident\'s Reporting' => $incident->location_of_reporter,
            'Driver Name' => $incident->driver_name,
            'Transportation Vehicle\'s Details' => $incident->vehicle_details,
            'Carriers and Contractors Involved' => $incident->carriers_and_contractors,
            'Routing' => $incident->routing,
            'Airline' => $incident->airline,
            'HAWB' => $incident->hawb,
            'MAWB' => $incident->mawb,
            'Origin Facility' => $incident->originating_facility,
            'Destination Facility' => $incident->destination_facility,
            'Method Of Transportation' => $incident->method_of_transportation,
        );
        $incident_data[] = array(
            'title' => 'Transportation Details',
            'data' => $incident_transport
        );

        //@TODO: fix this to handle json
        if (is_array($products) && count($products)) {
            $product = $products[0];
            $productDescriptions = $product['product_description'];
            $numberOfUnitsMissings = $product['number_of_units_missing'];
            $valuePerUnits = $product['value_per_unit'];

            if (\MSLST\Helpers\Common::isJson($valuePerUnits)) {
                $productDescriptions = json_decode($productDescriptions);
                $numberOfUnitsMissings = json_decode($numberOfUnitsMissings);
                $valuePerUnits = json_decode($valuePerUnits);
                $count = count($valuePerUnits);
                for ($i=0; $i<$count; $i++) {
                    $product_details['Product/item Description #' . ($i + 1)] = $productDescriptions[$i];
                    $product_details['Number of Units Missing #' . ($i + 1)] = $numberOfUnitsMissings[$i];
                    $product_details['Value per Unit (USD) #' . ($i + 1)] = $valuePerUnits[$i];
                }
            }
            else {
                $product_details['Product/item Description'] = $productDescriptions;
                $product_details['Number of Units Missing'] = $numberOfUnitsMissings;
                $product_details['Value per Unit (USD)'] = $valuePerUnits;
            }

            $product_details[' '] = ' ';
            $product_details['Number of Plts/Crts Missing'] = $product['number_of_plts_missing'];
            $product_details['Total Value of lost Units (USD)'] = $product['total_value_of_lost_units'];
            $product_details['Type of Device'] = preg_replace("/\[\"(\w+)\"\]/", '${1}', $incident->type_of_device);


            $incident_data[] = array(
                'title' => 'Details of Units Missing',
                'data' => $product_details
            );
        }

        if (is_array($investigations) && count($investigations)) {
            $investigation = $investigations[0];


            $investigation_details = array(
                'The Name of The Investigation Authority' => $investigation['name_of_investigation_authority'],
                'The Investigation File Number' => $investigation['investigation_file_number'],
                'DQI Number' => $investigation['dq'],
                'Contact information for the investigating law enforcement agency' => $investigation['contact_information'],
                'First Findings, Lessons Learn, Short Term Actions, Loss Type (Pilferage, Theft, Robbery, etc.)' => $incident['first_findings'],
                'Final investigation findings, root cause analysis, long term corrective actions' => $investigation['final_investigation_findings'],
            );
            $incident_data[] = array(
                'title' => 'Official Investigation Details',
                'data' => $investigation_details
            );

        }

        if(isset($incident->incident_investigation) ){
          $investigation_details = array('investigation status' => $incident->incident_investigation->name);
           $incident_data[] = array(
                'title' => 'Current investigation status',
                'data' => $investigation_details
            );
        }

        if (!empty($incidentlog)) {
            $incident_history = array();
  


            foreach ($incidentlog as $log) {

                if( date('Y', strtotime($log['created_at']))  != 1970 && date('Y',strtotime($log['created_at'])) != -0001){
                          $incident_history[date('F j, Y H:i', strtotime($log['created_at']))." Created by"] = $log['user']['first_name'] .' '. $log['user']['last_name'];
                 }elseif( date('Y', strtotime($log['updated_at']))  != 1970 && date('Y',strtotime($log['updated_at'])) != -0001){
                          $incident_history[date('F j, Y H:i', strtotime($log['updated_at']))." Edited by"] = $log['user']['first_name'] .' '. $log['user']['last_name'];
                 }elseif( date('Y', strtotime($log['requested_at']))  != 1970 && date('Y',strtotime($log['requested_at'])) != -0001){
                          $incident_history[date('F j, Y H:i', strtotime($log['requested_at']))." Review requested by"] = $log['user']['first_name'] .' '. $log['user']['last_name'];
                 }elseif( date('Y', strtotime($log['cleared_at']))  != 1970 && date('Y',strtotime($log['cleared_at'])) != -0001){
                          $incident_history[date('F j, Y H:i', strtotime($log['cleared_at']))." Review cleared by"] = $log['user']['first_name'] .' '. $log['user']['last_name'];
                 }elseif( date('Y', strtotime($log['closure_requested_at']))  != 1970 && date('Y',strtotime($log['closure_requested_at'])) != -0001){
                          $incident_history[date('F j, Y H:i', strtotime($log['closure_requested_at']))." Incident closure requested by "] = $log['user']['first_name'] .' '. $log['user']['last_name'];
                 }elseif( date('Y', strtotime($log['closure_accepted_at']))  != 1970 && date('Y',strtotime($log['closure_accepted_at'])) != -0001){
                          $incident_history[date('F j, Y H:i', strtotime($log['closure_accepted_at']))." Closure request accepted by "] = $log['user']['first_name'] .' '. $log['user']['last_name'];
                 }elseif( date('Y', strtotime($log['closure_denied_at']))  != 1970 && date('Y',strtotime($log['closure_denied_at'])) != -0001){
                          $incident_history[date('F j, Y H:i', strtotime($log['closure_denied_at']))." Closure request denied by "] = $log['user']['first_name'] .' '. $log['user']['last_name'];
                 }elseif( date('Y', strtotime($log['closure_re_open_at']))  != 1970 && date('Y',strtotime($log['closure_re_open_at'])) != -0001){
                          $incident_history[date('F j, Y H:i', strtotime($log['closure_re_open_at']))." Closure request re-open by "] = $log['user']['first_name'] .' '. $log['user']['last_name'];
                 }

            }
            $incident_data[] = array(
                'title' => 'Edit History',
                'data' => $incident_history
            );
        }
       
     //  print "<pre>"; print_r($incident_data); exit;
        return $incident_data;
    }

    /**
     * Prepare the incident data
     *
     * @param $id number
     * @param array
     */
    public static function incidentExportXLS($id) {
        $file_type = 'Excel2007';
        $xls_file = tempnam(sys_get_temp_dir(), 'scsirt_report');
        $incident_data = self::prepareIncidentData($id);

        // Add the data to the XLS sheet
        $row_id = 1;
        $php_excel = new \PHPExcel();

        // Load the workbook
        $sheet = $php_excel->getActiveSheet();

        $sheet->setCellValue('A' . $row_id, 'Incident Report');
        $sheet->getStyle('A' . $row_id)->applyFromArray(array(
          'font' => array('bold' => true),
          'fill' => array(
                    'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                    'color' => array('rgb' => 'FACA9B')
                )
          )
        );
        $sheet->mergeCells('A' . $row_id .':D' . $row_id);
        $row_id++;

        foreach ($incident_data as $column_data) {

            $sheet->setCellValue('A' . $row_id, '');
            $row_id++;
            if ($column_data['title']) {
                $sheet->setCellValue('A' . $row_id, $column_data['title']);
                $sheet->getStyle('A' . $row_id)->applyFromArray(array(
                  'font' => array('bold' => true),
                  'fill' => array(
                            'type' => \PHPExcel_Style_Fill::FILL_SOLID,
                            'color' => array('rgb' => 'FFDAB9')
                        )
                  )
                );
                $sheet->mergeCells('A' . $row_id .':D' . $row_id);
                $row_id++;
            }

            foreach ($column_data['data'] as $key => $value) {
                $sheet->setCellValue('A' . $row_id, "$key");
                $sheet->setCellValue('B' . $row_id, "$value");
                $sheet->getStyle('B' . $row_id)->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
                $sheet->mergeCells('B' . $row_id .':D' . $row_id);
                $row_id++;
            }
        }
        $sheet->getStyle('A1:B'.$row_id)->getAlignment()->setWrapText(true);

        $sheet->getColumnDimension('A')->setWidth(35);
        $sheet->getColumnDimension('B')->setWidth(20);

        // Save the workbook
        $php_excelWriter = \PHPExcel_IOFactory::createWriter($php_excel, $file_type);
        $php_excelWriter->save($xls_file);

        // Send the file for download
        $response = \Response::make(file_get_contents($xls_file))
                        ->header('Content-Disposition', 'attachment; filename=incident_report.xlsx')
                        ->header('Content-Type', 'application/octet-stream')
                        ->header('Content-Transfer-Encoding', 'binary')
                        ->header('Accept-Ranges', 'bytes')
                        ->header('Cache-control', 'private')
                        ->header('Pragma', 'private')
                        ->header('Content-Length', filesize($xls_file));

        // Delete the file after download
        register_shutdown_function('unlink', $xls_file);

        return $response;
    }


    /**
     * Close Incident Attachements
     *
     **/
    public static function closeAttachment($data,$id){

            $file = $data['attachment'];

            $original_name = $file->getClientOriginalName();
            $mime_type = $file->getMimeType();
            $newname = sha1(time() . openssl_random_pseudo_bytes(10));
            $path = storage_path() .'/'. self::$attachments_files_path;
            $file->move($path, $newname);
           \Attachment::create([
                    'attachment_type' => 'closeincident',
                    'file_name' => $path .'/'. $newname,
                    'file_description' => $original_name,
                    'file_type' => $mime_type,
                    'description' => $data['description'],
                    'incident_id' => $id
                ]);
    }



    /**
     * Update Incident History Logs
     *
     *
     **/
    public static function IncidentHistoryLog($data){

        //Incident Log Storage
        \IncidentLog::Create($data);

    }


     /**
     * Update Incident Closure request Data Logs
     *
     *
     **/
    public static function IncidentClosureRequest($incidentid,$data){

        $results = \Incident::where('id',$incidentid)
                        ->update($data);

        return $results;
    }

}
