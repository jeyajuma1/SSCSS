<?php namespace MSLST\Helpers;

class Lists {

    /**
     * Generate the auditors list
     *
     * @return array
     */
    public static function getAuditorsList()
    {
		$auditors = \User::select('id', \DB::raw("CONCAT(first_name, ' ', last_name) as auditor"))
							->orderBy('auditor');

        if (\Auth::User()->isUser()) return [];

        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $auditors->where('lsp_id', \Auth::User()->lsp->id);
        }

        $auditors = $auditors->lists('auditor', 'id');

		return $auditors;
    }

    /**
     * Generate the lsp users list
     *
     * @return array
     */
    public static function getLspUsersList($lsp_id, $except = null, $region_id = null)
    {
        $users = \User::select('id', \DB::raw("CONCAT(first_name, ' ', last_name) as fullname"))
                            ->where('lsp_id', $lsp_id)
                            ->orderBy('fullname');

        if ($except)
        {
            $users = $users->where('id', '<>', $except);
        }

        if ($region_id)
        {
            $users = $users->whereHas('regions', function($q) use ($region_id) {
                $q->where('regions.id', $region_id);
            });
        }

        $users = $users->lists('fullname', 'id');

        return $users;
    }

    /**
     * Generate the certifications list
     *
     * @return array
     */
    public static function getCertificationsList()
    {
        $list = [];
        $certifications = \Certification::select('id', 'name', 'availability', 'certification_group_id')
                            ->orderBy('id')
                            ->get();

        foreach ($certifications as $certification)
        {
            $list[$certification->certification_group_id][$certification->id] = [
                'name' => $certification->name,
                'availability' => $certification->availability,
            ];
        }

        return $list;
    }

    /**
     * Generate the customers list
     *
     * @return array
     */
    public static function getCustomersList()
    {
        $customers = \Incident::select('customer')
                            ->distinct();

        if (\Auth::User()->isUser()) return [];

        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $customers->join('users', 'incidents.user_id', '=', 'users.id')
                      ->where('users.lsp_id', \Auth::User()->lsp->id);
        }

        $customers = $customers->lists('customer', 'customer');

        return $customers;
    }

    /**
     * Generate the LSP list
     *
     * @return array
     */
    public static function getLspsList()
    {
		$lsps = \Lsp::select('id', 'name')
				->orderBy('name');

        if (\Auth::User()->isUser()) return [];

        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
            $lsps->where('id', \Auth::User()->lsp->id);
        }

        $lsps = $lsps->lists('name', 'id');

		return $lsps;
    }

    /**
     * Generate the Lsp Value
     *
     * return value
     */
    public static function getlspname($lspid)
    {
        $lsp_name = \lsp::select('name')
                        ->where('id',$lspid)
                        ->lists('name');

        return $lsp_name[0];
    }


    public static function getUserRegion($usid){
        $regions = \UserRegion::select('region_id')
                              ->where('user_id',$usid)
                              ->lists('region_id');

        return $regions;
    }


    /**
     * Generate the Regions list
     *
     * @return array
     */
    public static function getRegionsList($regions = [])
    {
        if(!empty($regions))
        {
    		$regions = \Region::select('id', 'name')
    				->orderBy('name')
                    ->WhereIn('id',$regions)
    				->lists('name', 'id');
        }
        else
        {
            $regions = \Region::select('id', 'name')
                    ->orderBy('name')
                    ->lists('name', 'id');
        }

		return $regions;
    }

    /**
     * Generate the Countries list
     *
     * @param $regions array
     * @return array
     */
    public static function getCountriesList($regions = [])
    {

		if (!empty($regions))
		{
			$countries = \Country::select('id', 'name')
					->whereIn('region_id', $regions)
					->orderBy('name')
					->lists('name', 'id');
		}
		else
		{
			$countries = \Country::select('id', 'name')
					->orderBy('name')
					->lists('name', 'id');
		}

		return $countries;
    }

    /**
     * Generate the Region with Countries list
     *
     * @return array
     */
    public static function getRegionCountriesList()
    {
        $countries = \Country::select('id', 'name', 'region_id')
                    ->orderBy('name')
                    ->get();

        $list = [];

        foreach ($countries as $country)
        {
            $list[$country->region_id][] = [
                'id' => $country->id,
                'text' => $country->name,
            ];
        }

        return $list;
    }

    /**
     * Generate the Answers list
     *
     * @return array
     */
    public static function getAnswersList()
    {
        $answers = \Answer::select('id', 'content')
                    ->orderBy('id')
                    ->lists('content', 'id');

        return $answers;
    }


    /**
     * Get Country name
     * @return Array
     **/
    public static function getCountriesname($id)
    {
       $country = \Country::select('name','id')->where('id',$id)->lists('name','id');

       return $country;
    }
    /**
     * Get Region name
     * @return Array
     **/

     public static function getRegionsname($id)
    {
       $region = \Region::select('name','id')->where('id',$id)->lists('name','id');

       return $region;
    }


    
    /**
     *  Get Investigation 
     *
     * @return Array
     **/
    public static function getInvestigation(){
        $InvestigationStus = \IncidentInvestigation::select('name','id')->get()->lists('name','id'); 
        return $InvestigationStus;
    }


    /**
     *  Get SuppilerType 
     *
     * @return Array
     **/

    public static function getSiteMasterSplyType(){
        $Sitemaster = \Sitemaster::select ('supplier_type')
                                    ->distinct()
                                    ->where('supplier_type','!=','')
                                    ->orderBy('supplier_type')
                                    ->lists('supplier_type','supplier_type');
        return $Sitemaster;
    }

    /**
     *  Get ChangeManager From Sitemaster 
     *
     * @return Array
     **/

    public static function getSiteMasterChangeManager(){
        $Sitemaster = \Sitemaster::select ('channel_manager')
                                    ->distinct()
                                    ->where('channel_manager','!=','')
                                    ->orderBy('channel_manager')
                                    ->lists('channel_manager','channel_manager');
        return $Sitemaster;
    }

    public static function getCategoryList($table='')
    {
        $table_name='SiteBusinessCategory';
        $category = $table_name::select('name','id')->whereNull('deleted_at')->get()->lists('name','id'); 
        return $category;
    }

    public static function getActivitiesList($table='')
    {
         $table_name=($table!='')?$table:'BusinessActivity';
        $activities = $table_name::select('name','id')->get()->lists('name','id'); 
        return $activities;
    }

    public static function getBusinessQuestionsList($id,$table='')
    {   
        $table_name=(($table!='')?($table.'LeakRiskAnalysis'):'LeakRiskAnalysis');
        $table_name1=(($table!='')?($table.'BusinessQuestion'):'BusinessQuestion');
        $id_type=(($table!='')?'sitemaster_id':'supplier_id');
        $activity_id = $table_name::SELECT ('activity_id')->distinct()->where($id_type,'=',$id)->lists('activity_id');
        
        $questions = $table_name1::select('id'
          ,'name'
          ,'order'
          ,'availability'
          ,'category'
          ,'created_at'
          ,'updated_at'
          ,'deleted_at'
          ,'activities'
          ,'severity_text',
          'category_id'
          );
   


        foreach ($activity_id as $key => $value) {

           if($key!=0)
             $questions->orwhere('activities','LIKE','%"'.$value.'"%');
           else
            $questions->where('activities','LIKE','%"'.$value.'"%');
        }   
         $questions->whereNull('deleted_at');
        $questions = $questions->get()->all();
        
        $questions['activities_id']=$activity_id;
       
       return $questions;
    }



    /**
     * Business Assests List
     * @params $activity
     * 
     * return $array
     **/

    public static function getBusinessAssets($activity,$table=''){

        $table_name=($table!='')?$table:'BusinessAsset';


        $array = [];
        $assetsId = [];
        $business_assets = $table_name::select('id','activity',"name","category_name")->get();

        $ary_acty = array_keys($activity);
        foreach ($business_assets as $key => $value) {
            $act_arry = json_decode($value['activity']);
            foreach ($act_arry as $ay => $av) {
                $array[$av][$value['category_name']][$value['id']] = $value['name'];
                
                $assetsId['assetsId'][$value['id']] =$value['id'];
            }
        }

        return $array+$assetsId;
    }


    /**
     * Business Risk List
     * @params $assets
     * 
     * return $array
     **/

    public static function getBusinessRisk($assets,$table=''){
        $riskArry = [];
        $riskId = [];
         $table_name=($table!='')?$table:'BusinessRisk';
        $business_risks = $table_name::select('id','name','asset_ids')->get();

        foreach($business_risks as $brky=>$brvl){
            $asst_arry = json_decode($brvl['asset_ids']);
            foreach ($asst_arry as $rk => $rv) {
                $riskArry[$rv][$brvl['id']] = $brvl['name'];
                $riskId['riskId'][$brvl['id']] = $brvl['id'];
            }
        }
        ksort($riskArry);
         

        return $riskArry + $riskId;
    }

    public static function getBusinessAction($risk,$table=''){

        $actionArry = [];
        $actionId = [];
         $table_name=($table!='')?$table:'BusinessAction';
        $business_action = $table_name::select('id','name','risk_id','description')->get();

        foreach($business_action as $baky=>$bavl){
                $risk_arry = json_decode($bavl['risk_id']);
                foreach ($risk_arry as $aky => $ave) {
                    if($risk == 'leak_risk_plan'){
                        /*$actionArry[$ave]['action_name'][$bavl['id']] = $bavl['name'];
                         $actionArry[$ave]['action_description'][$bavl['id']] = $bavl['description'];*/
                         $actionArry[$ave][$bavl['id']]['action_id'] = $bavl['id'];
                         $actionArry[$ave][$bavl['id']]['action_name'] = $bavl['name'];
                         $actionArry[$ave][$bavl['id']]['action_description'] = $bavl['description'];
                         $actionId['actionId'][$bavl['id']] = $bavl['id'];  
                    }else{ 
                         $actionArry[$ave][$bavl['id']] = $bavl['name'];
                         $actionArry[$ave][$bavl['name']] = $bavl['description'];
                    }
                }
        }
        ksort($actionArry);
        return $actionArry + $actionId;
    }

    /**
     *
     *
     *
     **/

    public static function getFilterRisk($asset = [],$table=''){

        $table_name=($table!='')?$table:'BusinessRisk';
       $risk = $table_name::select('id','name','asset_ids')->get();
    }


    /**
     *
     *
     *
     **/

    public static function getBusinessQuestiondetail(){
        $question_list =  \SiteBusinessQuestion::select('id','name','category_id','severity_text')->get()->toArray();
        $questions_array = [];
        foreach ($question_list as $key => $value) {
            $questions_array[$value['id']] = $value;
        }
        return $questions_array;
    }

}
