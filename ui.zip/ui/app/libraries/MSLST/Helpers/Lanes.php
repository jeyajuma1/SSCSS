<?php 
namespace MSLST\Helpers;

class Lanes {


	/**
	 * Represents node location creation  basic feilds
	 *
	 **/

	public static $basic_details_fields = [
		'site'=>'required',
    	'address' => 'required',
    	'coordinates' =>'required',
    	'country' =>'required'
    ];


    /**
     * Get all Lanes 
     *
     * @param $all array
     * @return array
     */
    public static function getLanesList($filters)
    {
		
		$Lanes       = \LaneLocations::with('location','lane');
		$laneId      = [];
		$lanedata    = \Lanes::select('id');
		$Rolechk     = true;
		$laneqrychk  = false;

		if(\Auth::User()->isSupervisor() && !\Auth::User()->isManager()) {
			$Rolechk = false;
			$lanedata->where('lsp_id',\Auth::user()->lsp_id); 
			$laneqrychk  = true;
		}

		if(\Auth::User()->isUser()){
			$Rolechk = false;
			$lanedata->where('user_id',\Auth::user()->id);
			$laneqrychk  = true;
	    } 



	     /*Checking Audit ID Filters*/
	  /*  if(isset($filters['aid']) && !empty($filters['aid'])){
	    	$dataid = \LaneLocations::select('lane_id')->where('location_id',$filters['aid'])->lists('lane_id');
	    	if(!empty($dataid) && isset($dataid)) $Lanes->whereIn('lane_id',$dataid);
	    	else return ['reset'] ;
	    }*/

	    /*Checking Date Filters*/
	    if(isset($filters['daterange']) && !empty($filters['daterange'])){
	     	list($start,$end) = explode(' - ',$filters['daterange']);

	     	$startTime = new \DateTime($start);
	     	$endTime = new \DateTime($end);

	     	$lanedata->where('updated_at','>=',$startTime->format(\Lanes::getDateFormat()))
	     			 ->where('updated_at','<=',$endTime->format(\Lanes::getDateFormat()));
	    	$lanedata->whereBetween('updated_at',[$startTime->format(\Lanes::getDateFormat()) , $endTime->format(\Lanes::getDateFormat())]);
	     	$laneqrychk  = true;
        }

        
        /*Checking Lsp Filters*/
	    if(isset($filters['lsp']) && !empty($filters['lsp'])){
	     	$lanedata->whereIn('lsp_id',$filters['lsp']);
	     	$laneqrychk  = true;
	    }


	    if($laneqrychk  == true) {
	    	$laneId = $lanedata->lists('id');
	    	if(empty($laneId)) {
	    	 	$Rolechk = false;
	    	}

	    }

	    if(!empty($laneId)) {
	    	  $Lanes->whereIn('lane_id',$laneId);
	    	  $Rolechk = true;
	    }


	    if($Rolechk == true){ 
			$Lanes = $Lanes->orderBy('lane_id', 'ASC')
						   ->orderBy('position','ASC')
						   //->paginate(8);
						   ->get()
						   ->all();
		 }else{
		 	 if($laneqrychk  == true) $Lanes = ['reset'];
		 	 else 	$Lanes = [];
		 }
		//print "<pre>"; 
		//print_r($laneId); exit;
		//dd(\DB::getQueryLog());

		return $Lanes;	 
    }

    /**
     * get all lane and related location , lsps, users
     * @params 
     * @return array
     **/
    public static function getlanesdata($filters){
    	//$lane = \Lanes::with('user','lsp')->get()->all();
    	$select[] = 'll.id as nodeid';
    	$select[] = 'lanes.waypoints as waypoints';
    	$select[] = 'lanes.id as laneid';
    	$select[] = 'lanes.user_id as userid';
    	$select[] = 'lanes.lsp_id as lspid';
    	$select[] = 'll.transport as transport ';
    	$select[] = 'll.position as position ';
    	$select[] = 'll.location_id as locationid ';
    	$select[] = 'location.site as site';
    	$select[] = 'location.coordinates as coordinates';
    	$select[] = 'location.value as value';
    	$select[] = 'location.score as score';
    	$select[] = 'location.tapa_needed as location_tapaNeeded';
    	$select[] = 'lsp.name as lspname';
    	$select[] = 'lanes.[end] as laneend';
    	$select[] = 'location.address as location_address';
    	$select[] = 'location.auditor_id as auditor_id';
    	$select[] = 'location.deleted_at as location_deletedAt';
    	$select[] = 'location.created_at as location_createdAt';
    	
    	
    	
    	$lane = \Lanes::leftjoin('lane_locations as ll','lanes.id','=','ll.lane_id')
    				   ->leftjoin('locations as location','ll.location_id','=','location.id')
    				   //->leftjoin('users as u','lanes.user_id','=','u.id')
    				   ->leftjoin('lsps as lsp','lanes.lsp_id','=','lsp.id')
    				   ->select(\DB::raw(implode(',',$select)));

	    $lane = $lane->whereNotNull('ll.id');


	    /* Authorisation for Lanes */

	    if(\Auth::User()->isSupervisor() && !\Auth::User()->isManager()) {
			$lane->where('lanes.lsp_id',\Auth::user()->lsp_id); 
		}

		if(\Auth::User()->isUser()){
			$lane->where('lanes.user_id',\Auth::user()->id);
	    }

	     /*Checking Lsp Filters*/
	    if(isset($filters['lsp']) && !empty($filters['lsp'])){
	     	$lane->whereIn('lanes.lsp_id',$filters['lsp']);
	    }


	     /*Checking Date Filters*/
	    if(isset($filters['daterange']) && !empty($filters['daterange'])){
	     	list($start,$end) = explode(' - ',$filters['daterange']);

	     	$startTime = new \DateTime($start);
	     	$endTime = new \DateTime($end);

	     	$lane->where('lanes.updated_at','>=',$startTime->format(\Lanes::getDateFormat()))
	     			 ->where('lanes.updated_at','<=',$endTime->format(\Lanes::getDateFormat()));
	    	//$lanedata->whereBetween('lanes.updated_at',[$startTime->format(\Lanes::getDateFormat()) , $endTime->format(\Lanes::getDateFormat())]);
        }




    	$lane = $lane->orderBy('laneid', 'ASC')
					 ->orderBy('position','ASC')
					 ->get()
					 ->all();

    	return $lane;
    }
	
	/**
     * Get all Lanes and Location for Creating Lanes 
     *
     * @param $list array
     * @return array
     */
   public static function getAuditLocationLst($startOption,$lanid)
    {	
    	$location_except = \LaneLocations::select('location_id')->lists('location_id');

    	$locations = \Location::select('id','site');

    	//print "<pre>"; print_r(\Auth::user()->isManager()); exit;
    	if(\Auth::User()->isSupervisor() && !\Auth::User()->isManager()) $locations->where('lsp_id',\Auth::user()->lsp_id);
    	if(\Auth::User()->isUser())	 $locations->where('auditor_id',\Auth::user()->id);

    	if (!empty($location_except))
    	{
    		$locations->whereNotIn('id', $location_except);
    	}

	 	$location['locationlst'] = $locations		
									->orderBy('id')
									->lists('site','id');

		
        /*listing the Creating Lane*/
        $lane_id = null;	
        $lane    = null;
        if($startOption == "exist" ) {
    		$lane    = \Lanes::select('id')->where('end', '=','no')->orderBy('id','DESC')->first();
    	}else{
    		$lane_id = $lanid; 
    	}
    	

    	if ($lane)
    	{
    		$lane_id = $lane->id;
    	}

	    $location['lanelst'] = '';
		
		if(!empty($lane_id))
		{
			$List =	\LaneLocations::with('location','lane')
									->where('lane_id', $lane_id)
									->orderBy('position')
							        ->get()
							        ->all();
			$location['lanelst']  = $List;
		}
		
		return $location;
	}
	
	/** 
	 * Add Locations for Lane
     *
	 *@param $list
	 *return array
	**/
	public static function AddLane($objArray,$userid,$startOption){

		   if(isset($objArray['type']) != 'existing'){
				/* Insert Into Location table */
				$locatinArry = array('country_id' =>$objArray['country'] ,
									 'site' => $objArray['site'],
									 'address'=>$objArray['address'],
									 'coordinates'=>$objArray['coordinates'],
									 'auditor_id' => $userid->id,
									 'lsp_id' => $userid->lsp_id,
									 'created_at' => date('Y-m-d H:i:s')
									); 
				$location = \Location::insertGetId($locatinArry); 
			}else{
				$location = $objArray['existingLocation'];
			}

			$ChkLanes = array();
			/* Checking one full lanes is completed or not */
			if($startOption != "new" ) {
				$ChkLanes = \Lanes::select(\DB::raw('count(id) as cnt'))
							   ->where('end','no')
							    ->lists('cnt');
			}else{
				$ChkLanes[0]  = 0;
			}
						   
			/* Checking and Getting Lanes Id */			   
			switch($ChkLanes[0]){
				case 0:
					 $LaneID =  \Lanes::insertGetId(array('end'=>'no','user_id'=>\Auth::user()->id,'lsp_id'=>\Auth::user()->lsp_id));
				break;
				default:
					 $LaneID = \Lanes::select('id')
									  ->where('end','no')
									  ->orderBy('id','DESC')
									  ->lists('id');
					  $LaneID = $LaneID[0];	
					if(!empty($objArray['success'])){
							 \Lanes::where('id',$LaneID)
								   ->update(array('end'=>'yes'));
					}
				break;
			}
		  
		   /* Getting Previous Position location in the Lanes */		
			$ChkLane_loca = \LaneLocations::select('position')
							   ->where('lane_id',$LaneID)
							   ->lists('position');
					 
			if(!empty($ChkLane_loca)){
				  $pos_num = count($ChkLane_loca)+1;
			}else{
				  $pos_num = 1;
			}
		 		
			/* Adding lanes */	
			$laneArry = array('location_id'=>$location,
							  'transport'=>$objArray['transport'],
							  'lane_id'=>$LaneID,
							  'position'=>$pos_num,
							 ); 
			$LaneID =  \LaneLocations::insertGetId($laneArry);					 
	}

	/**
	  * Add each node(Location) in lanes
	  * @params $data
	  *
	  **/
	public static function addNodesLanes($RequestData,$userid,$step){

	 if(!empty(\Session::get('LaneID')))
		list($laneID,$waypoints) = explode('-',\Session::get('LaneID'));
     else
     	$laneID = $RequestData['laneid'];

		switch($step){
			case 'exist':
						 $locationlaneArry = array('location_id'=>$RequestData['location'],
							  			  		   'transport'=>$RequestData['transport'],
							  			  		   'lane_id'=>$laneID,
							  			  		   'position'=>$RequestData['position'],
							 					  );
					//print "<pre>"; print_r($RequestData); exit;
				  break;
			case 'new':
						/* Insert Into Location table */
						$locatinArry = array('country_id'  => $RequestData['country'] ,
											  'site'       => $RequestData['site'],
											  'address'    => $RequestData['address'],
											  'coordinates' => $RequestData['coordinates'],
											  'auditor_id'  => $userid->id,
											  'lsp_id'      => $userid->lsp_id,
											  'created_at'  => date('Y-m-d H:i:s')
										); 
						$location = \Location::insertGetId($locatinArry); 
						
						$locationlaneArry = array('location_id'=>$location,
							  			  		   'transport'=>$RequestData['transport'],
							  			  		   'lane_id'=>$laneID,
							  			  		   'position'=>$RequestData['position'],
							 					  );

				  break;
			default:
				   break;
		}

		$LaneID =  \LaneLocations::insertGetId($locationlaneArry);
	}

	/**
	 * Update the Lanes
	 * 
	 *
	 **/
	public static function updateLaneFinal($laneid){
			\Lanes::where('id',$laneid)
						  ->update(array('end'=>'yes'));
	}

	/**
	 * Add Way points
	 * @param $list
	 * 
	 **/

	public static function addwaypoint($data){
		 $LaneID =  \Lanes::insertGetId(array('end'=>'no','waypoints'=>$data['waypoints'],'user_id'=>\Auth::user()->id,'lsp_id'=>\Auth::user()->lsp_id));

		\Session::put('LaneID', $LaneID."-".$data['waypoints']);
	}

	/**
	 *
	 *Get Position Information
	 *@param laneid
	 *
	 **/
	public static function getPositionDetail($laneid){
		$positionData = \LaneLocations::select('position')->where('lane_id',$laneid)->lists('position');
		return $positionData;
	}


    /**
     * Update Locations for Lane
     *
	 *@param $list
	 *return array
	**/
	public static function UpdateLane($objArray,$userid,$startOption,$lane_id){

		   if(isset($objArray['type']) != 'existing'){
				/* Insert Into Location table */
				$locatinArry = array('country_id' =>$objArray['country'] ,
									 'site' => $objArray['site'],
									 'address'=>$objArray['address'],
									 'coordinates'=>$objArray['coordinates'],
									 'auditor_id' => $userid->id,
									 'lsp_id' => $userid->lsp_id,
									 'created_at' => date('Y-m-d H:i:s')
									);
				$location = \Location::insertGetId($locatinArry); 
			}else{
				$location = $objArray['existingLocation'];
			}

			if(!empty($objArray['success'])){
					\Lanes::where('id',$lane_id)
						  ->update(array('end'=>'yes'));
			}
		  
		   /* Getting Previous Position location in the Lanes */		
			$ChkLane_loca = \LaneLocations::select('position')
							   ->where('lane_id',$lane_id)
							   ->lists('position');
					 
			if(!empty($ChkLane_loca)){
				  $pos_num = count($ChkLane_loca)+1;
			}else{
				  $pos_num = 1;
			}
		 		
			/* Adding lanes */	
			$laneArry = array('location_id'=>$location,
							  'transport'=>$objArray['transport'],
							  'lane_id'=>$lane_id,
							  'position'=>$pos_num,
							 ); 
			$LaneID =  \LaneLocations::insertGetId($laneArry);		
						 
	}


	
	/**
	 * Delete Locations for Lane
     *
	 **/
	public static function Deletelane($objArr){
		$affectedRows = \Lanes::where('id',$objArr)->delete();
		return $affectedRows;
	}

	/**
	 * Check Valid lanes
	 **/

	public static function checkInValidLane($id){

		$chklan = \Lanes::select('end','id')
						->where('id',$id)
						->lists('end','id');

		//echo "<pre>"; print_r($chklan); exit;
		return $chklan;				

	}

	/**
	 *
	 * Get Location Audit List and which is not in lane
	 * @param
	 **/
	public static function getLocationAudit(){
		$location_result = \Location::select('id','site as name','coordinates',\DB::raw('(CASE WHEN score >= 80 THEN \'green\' WHEN score >= 60 THEN \'yellow\' ELSE \'red\' END) as category'),'created_at as date','score');
		$locationlane    = \LaneLocations::select('location_id')->lists('location_id');

		if(!empty($locationlane))
				$location_result->whereNotIn('id',$locationlane);

		


		if(\Auth::User()->isSupervisor() && !\Auth::User()->isManager()) $location_result->where('lsp_id',\Auth::user()->lsp_id);
    	if(\Auth::User()->isUser())	 $location_result->where('auditor_id',\Auth::user()->id);


		$location_result = $location_result->get();

		foreach ($location_result as $key => $locat_item) {
							$location_res[$key]                     = $locat_item['original'];
							$location_res[$key]['coordinates']      = Coordinate::convertToWGS84($locat_item['original']['coordinates']);
		}

		return $location_res;

	}
}