<?php namespace MSLST\Helpers;
use Carbon\Carbon;
use MSLST\Constants\Site;
class Factoryincidents {

	/**
	 * Represent basic Information Details
	 *
	 * @return array
	 **/

	public static $basic_information_fields = [
		'short_description',
		'incident_event_date',
		'region',
		'country',
		'city',
		'facility',
		'location_address',
		'coordinates',		
	];


	/**
	 * Represent Incident Details 
	 *
	 * @return array
	 **/

	public static $incident_details_fields = [
		'persons_involved',
		'loss_discovered_by',
		'location_of_incident_within_sitepremises',
		'total_value_of_loss_unit',
		'product_description',
		'part_number',
		'serial_number',
		'product_family',
		'number_of_unit_missing',
		'value_per_unit',
	];


	/**
	 * Represent Investigation and attachments
	 *
	 * @return array
	 **/

	public static $investigation_attachments_fields = [
		'name_of_investigation_authority',
		'contact_information',
		'investigation_file_number',
		'incident_refered_to',
		'on_date',
		'on_time',
		'investigation_description_and_action_taken',
		'final_investigation_findings_cause_analysis_corrective_actions',
		'current_investigation_status',
		'attachment'
	];

	/**
	 *  Represent Multiple Fields 
	 *
	 * @return array
	 **/

	public static $multiple_fields = [
		'product_description',
		'part_number',
		'serial_number',
		'product_family',
		'number_of_unit_missing',
		'value_per_unit',
	];


	/**
	 *  Represent attachement
	 *
	 **/
	public static $file_fields = [
		'attachment',
	];


    /**
     * Represent Attachment Path
     *
     **/

    public static $attachments_files_path = 'files/incident/factory';



    /**
     * Get the incident date time string from the date
     *
     * @param $date string
     * @param $time string
     * @return string
     */
    public static function getIncidentDateTime($date)
    {
        return Carbon::createFromFormat('Y-m-d', $date)
                    ->toDateTimeString();
    }


    /**
	 *  Get Filtered Factory Incident
	 *
	 * @return array
	 **/

    public static function getFilteredIncidents($filters){

    
    	$incident = \FactoryIncident::with('region','country','user','product','investigation');
    	

    	if(!empty($filters['daterange']) && isset($filters['daterange'])){
    		list($start,$end) = explode(' - ',$filters['daterange']);


    		$start = new \DateTime($start);
			$end = new \DateTime($end);

			$incident->where(\DB::raw("FORMAT(incident_event_date,'yyyy-MM-dd')"), '>=', $start->format('Y-m-d'))
					  ->where(\DB::raw("FORMAT(incident_event_date,'yyyy-MM-dd')"), '<=', $end->format('Y-m-d'));
    	}

    	if (isset($filters['status']) && !empty($filters['status']))
		{
			if (count($filters['status']) == 1)
			{
				if ($filters['status'][0] == 'closed')
				{
					//$incident->whereRaw('(closed_at is not null AND closed_at <> "0000-00-00 00:00:00")');
					$incident->whereRaw('(closed_at is not null)');
				}
				else
				{
					//$incident->whereRaw('(closed_at is null OR closed_at = "0000-00-00 00:00:00")');
					$incident->whereRaw('(closed_at is null)');
				}
			}
		}


		if (isset($filters['region']) && !empty($filters['region']))
		{
			$incident->whereIn('region_id', $filters['region']);
		}

		if (isset($filters['country']) && !empty($filters['country']))
		{
			$incident->whereIn('country_id', $filters['country']);
		}

		if (isset($filters['investigation']) && !empty($filters['investigation']))
		{
			$incident->whereHas('investigation', function($q) use(&$filters){
					$q->whereIn('current_investigation_status',$filters['investigation']);
			});
		}

		if (isset($filters['lsp']) && !empty($filters['lsp']))
		{
            $incident->whereHas('user', function($q) use (&$filters) {
                $q->whereIn('lsp_id', $filters['lsp']);
                $q->withTrashed();
            });
		}


		if (isset($filters['keywords']) && !empty($filters['keywords']))
		{
			$keywords = strtolower($filters['keywords']);

			$incident->where(function ($q) use ($keywords) {
				$q->orWhereRaw("lower(short_description) like '%". $keywords ."%'")
				  ->orWhereRaw("lower(facility) like '%". $keywords ."%'")
				  ->orWhereRaw("lower(location_address) like '%". $keywords ."%'")
				  ->orWhereRaw("lower(persons_involved) like '%". $keywords ."%'")
				  ->orWhereRaw("lower(loss_discovered_by) like '%". $keywords ."%'")
				  ->orWhereRaw("lower(location_of_incident_within_sitepremises) like '%". $keywords ."%'");
			});
		}

		if (isset($filters['incident_id']) && !empty($filters['incident_id']))
		{
            $incident_id = $filters['incident_id'];

            if (preg_match('/^'.Site::FACTORY_INCIDENT_PREFIX.'/', $incident_id))
            {
               $incident_id = ltrim($incident_id, Site::FACTORY_INCIDENT_PREFIX);
            }

            $incident->where('id', intval($incident_id));
		}


		if (isset($filters['user']) && !empty($filters['user']))
		{
			$incident->whereIn('user_id', $filters['user']);
		}


		if (\Auth::User()->isUser())
        {
            $incident->where(function ($q) {
               $q->where('user_id', \Auth::User()->id);
            });
        }

        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
           $regionChk = \UserRegion::select('region_id')
                                   ->where('user_id',\Auth::User()->id)
                                   ->lists('region_id');

           $incident->whereIn('region_id', $regionChk);

           $lspChk    = \User::select('id')
                             ->where('lsp_id',\Auth::User()->lsp->id)
                             ->lists('id');
           $incident->whereIn('user_id', $lspChk);
           
        }

		 
    	$incident = $incident->orderBy('incident_event_date', 'DESC')->get()->all();

    	return $incident;
    }

    /**
     * Get Factory Incident  Statistics Chart Data
     *
     **/
    public static function findStatisticsGroupedByYears($filterSet = NULL, $x_axis, $z_axis , $is_value = FALSE){

       /* New Code */
    $select_fields = [];    
    $xsort = Null;
    $zsort = Null;
    $total_audit = 'Total Incidents';
    $groupby = true;
    $montsort  = false;
    $datsort  = false;

    if(count($filterSet['filters']) == 1 && in_array('daterange',$filterSet['filters']) &&  !empty($filterSet['daterange'])){
      $groupby = false;
    } 

    if(($x_axis == $total_audit || $z_axis == $total_audit)){
        if ( $is_value == FALSE) {
              $select_fields[] = "count(factory_incidents.id) as 'Total Incidents'";
        }else{
             $select_fields[] = "SUM(CAST(p.total_value_of_loss_unit as decimal(12, 2))) as 'Total Incidents'";
        }
    } else {
        if($is_value == FALSE ) {
           $select_fields[] = 'COUNT(factory_incidents.id) as total';
        }else{
          $select_fields[] = 'SUM(CAST(p.total_value_of_loss_unit as decimal(12, 2))) as total';
        }
    }

    $sorting = true;
  
    if ($x_axis == 'daterange' || $z_axis == 'daterange') {

        if(!empty($filterSet['daterange']) ){
            $filt_dat = explode(" - ",$filterSet['daterange']);
            $filterSet['start_date'] = $filt_dat[0];
            $filterSet['end_date']   = $filt_dat[1];
         }

        if(!empty($filterSet['start_date'])) $filt_start_date = date('d M Y',strtotime($filterSet['start_date']));
          
        if(!empty($filterSet['end_date']))  $filt_end_date = date('d M Y',strtotime($filterSet['end_date']));

        if(!empty($filterSet['start_date']) && !empty($filterSet['end_date'])){
             $select_fields[] = "(CASE WHEN 1 >= 1 THEN '".$filt_start_date." - ".$filt_end_date."' END) as daterange";
             $sorting = false;
        }else{
             $select_fields[] = 'FORMAT(factory_incidents.incident_event_date, \'yyyy\') as daterange';
             $datsort = true;
        }

       

        if(($x_axis == 'daterange' || $z_axis == 'daterange')  && $sorting == true) $xsort = "FORMAT(factory_incidents.incident_event_date, 'yyyy')"; $zsort = $xsort;  $dsort = $zsort;
    }

   if ($x_axis == 'monthrange' || $z_axis == 'monthrange') {
        $select_fields[] = 'FORMAT(factory_incidents.incident_event_date, \'MMM yyyy\') as monthrange ,FORMAT(factory_incidents.incident_event_date, \'yyyyMM\') as sortmonth';
        if($x_axis == 'monthrange' || $z_axis == 'monthrange' ) { $xsort = 'FORMAT(factory_incidents.incident_event_date, \'MMM yyyy\')';  $msort = 'FORMAT(factory_incidents.incident_event_date, \'yyyyMM\')';}
        $montsort  = true;
    }

    if ($x_axis == 'status' || $z_axis == 'status') {
          $select_fields[] = 'IIF(factory_incidents.closed_at IS NULL, \'open\', \'closed\') as status';
          if($x_axis == 'status') $xsort = "IIF(factory_incidents.closed_at IS NULL, 'open', 'closed')";
          if($z_axis == 'status') $zsort = "IIF(factory_incidents.closed_at IS NULL, 'open', 'closed')";
    }

    if ($x_axis == 'lsp' || $z_axis == 'lsp') {
          $select_fields[] = 'c.name as lsp';
          if($x_axis == 'lsp')  $xsort = 'c.name';
          if($z_axis == 'lsp')  $zsort = 'c.name';
         
    }

    if ($x_axis == 'region' || $z_axis == 'region') {
          $select_fields[] = 'r.name as region';
          if($x_axis == 'region') $xsort = 'r.name';
          if($z_axis == 'region') $zsort = 'r.name';
    }


    if ($x_axis == 'country' || $z_axis == 'country') {
          $select_fields[] = 'l.name as country';
          if($x_axis == 'country') $xsort = 'l.name';
          if($z_axis == 'country') $zsort = 'l.name';
    }

      $incidents = \FactoryIncident::leftjoin('users as u','factory_incidents.user_id','=','u.id')
                         ->leftjoin('lsps as c','u.lsp_id','=','c.id')
                         ->leftjoin('regions as r','factory_incidents.region_id','=','r.id')
                         ->leftjoin('countries as l','factory_incidents.country_id','=','l.id')
                         ->leftjoin('product_factory_incidents as p','factory_incidents.id','=','p.factory_incident_id')
                         ->select(\DB::raw(implode(',', $select_fields)));

       if (!empty($filterSet['lsp'])) {
            $incidents->where("c.id",$filterSet['lsp']);
       }

       if (!empty($filterSet['start_date'])) {
            $incidents->where(\DB::raw('FORMAT(factory_incidents.incident_event_date, \'yyyy-MM-dd\')'),'>=',$filterSet['start_date']);
       }

       if (!empty($filterSet['end_date'])) {
            $incidents->where(\DB::raw('FORMAT(factory_incidents.incident_event_date, \'yyyy-MM-dd\')'),'<=',$filterSet['end_date']);
       }

      if (!empty($filterSet['start_month'])) {
            $incidents->where(\DB::raw('FORMAT(factory_incidents.incident_event_date, \'yyyyMM\')'),'>=',$filterSet['start_month']);
       }

       if (!empty($filterSet['end_month'])) {
            $incidents->where(\DB::raw('FORMAT(factory_incidents.incident_event_date, \'yyyyMM\')'),'<=',$filterSet['end_month']);
       }

       if (!empty($filterSet['region'])) {
            $incidents->where("r.id",$filterSet['region']);
       }

      if (isset($filterSet['status']) && $filterSet['status'] === '0' ) {
          $incidents->whereNUll('factory_incidents.closed_at');
      }

      if(isset($filterSet['status']) && $filterSet['status'] == '1')
      {
          $incidents->whereNOTNUll('factory_incidents.closed_at');
      }

      if (!empty($filterSet['country'])) {
            $incidents->where('l.id',$filterSet['country']);
      }

       /* Create Group By Filter*/ 
       if($groupby  == true){
            if($z_axis != $total_audit){
                if($sorting == true) $incidents->groupby(\DB::raw($xsort),\DB::raw($zsort));
                else    $incidents->groupby(\DB::raw($zsort));
             }else{
                $incidents->groupby(\DB::raw($xsort));
             }
       }

       if($montsort == true) {
            $incidents->groupby(\DB::raw($msort));
             $incidents->orderby(\DB::raw($msort));
       }elseif($datsort == true) {
            $incidents->orderby(\DB::raw($dsort));
        }

       $results = $incidents->get();

       //echo "<pre>"; print_r($results); exit;
        return  $results;

    }


    /**
     * Get Incident  In Map Plotting Data
     *
     *@ return Array
     **/
    public static function findStatisticsMapLocations($filterSet = NULL, $regionsArray = array()) {

        $select_item[] = 'factory_incidents.id';
        $select_item[] = 'factory_incidents.region_id as rid';
        $select_item[] = 'e.name as company_name';
        $select_item[] = 'e.id as cid';
        $select_item[] = 'l.name as country_name';
        $select_item[] = 'factory_incidents.coordinates as coordinates';
        $select_item[] = "CONCAT(c.first_name,' ',c.last_name) as name";
        $select_item[] = 'c.id as userid';
        $select_item[] = 'FORMAT(factory_incidents.incident_event_date, \'yyyy-MM-dd\') as date';
        $select_item[] = 'p.total_value_of_loss_unit as value';
        $select_item[] = 'factory_incidents.incident_event_date';
       	$select_item[] = 'factory_incidents.short_description as description';
        $select_item[] = 'factory_incidents.city as city';

        $incidents = \FactoryIncident::leftjoin('users as c','factory_incidents.user_id','=','c.id')
                              ->leftJoin('lsps as e','c.lsp_id','=','e.id')
                              ->leftJoin('regions as r','factory_incidents.region_id','=','r.id')
                              ->leftJoin('countries as l','factory_incidents.country_id','=','l.id')
                              ->leftJoin('product_factory_incidents as p','factory_incidents.id','=','p.factory_incident_id')
                              ->select(\DB::raw(implode(',',$select_item)));


		if(!empty($filterSet['daterange'])){
            $dateRang = explode(' - ',$filterSet['daterange']);
            $filterSet['incident_start_date'] = $dateRang[0];
            $filterSet['incident_end_date'] = $dateRang[1];
         }
        if (!empty($filterSet['incident_start_date'])) {
            $startDateObj = new \DateTime($filterSet['incident_start_date']);
            $startDate = $startDateObj->format('Y-m-d');
            $incidents->where(\DB::raw("FORMAT(factory_incidents.incident_event_date,'yyyy-MM-dd')"),'>=',$startDate);
        }
        if (!empty($filterSet['incident_end_date'])) {
            $endDateObj = new \DateTime($filterSet['incident_end_date']);
            $endDate = $endDateObj->format('Y-m-d');
            $incidents->where(\DB::raw("FORMAT(factory_incidents.incident_event_date,'yyyy-MM-dd')"),'<=',$endDate);
        }
        if(!empty($filterSet['start_month'])){
            $incidents->where(\DB::raw("FORMAT(factory_incidents.incident_event_date, 'yyyyMM')"),'>=',$filterSet['start_month']);
        }

        if(!empty($filterSet['end_month'])){
            $incidents->where(\DB::raw("FORMAT(factory_incidents.incident_event_date, 'yyyyMM')"),'<=',$filterSet['end_month']);
        }
        if (isset($filterSet['status']) && $filterSet['status'] === '0' ) {
            $incidents->whereNUll('factory_incidents.closed_at');
        }
        if(isset($filterSet['status']) && $filterSet['status'] == '1')
        {
            $incidents->whereNOTNULL('factory_incidents.closed_at');
        }
        if (!empty($filterSet['lsp'])) {
            $incidents->where('e.id','=',$filterSet['lsp']);
        }
        if (!empty($filterSet['region'])) {
            $incidents->where('r.id','=',$filterSet['region']);
        }
        if (!empty($filterSet['country'])) {
            $incidents->where('l.id','=',$filterSet['country']);
        }

        $incidents->whereNUll('factory_incidents.deleted_at');


      $results =  $incidents->orderby('factory_incidents.incident_event_date','ASC')
                 ->get();
                //echo count($results);exit;
        return $results;
    }


	/**
	 * Get Factory Incident Step Data
	 *
	 * @param string
	 * @return object
	 **/

	public static function getFactoryIncidentStepData($name){

		$data = new \stdclass;
		$field = [];

		$fields = self::${$name.'_fields'};

		if(\Session::has('factoryincident.'.$name)){
			$data = (object) \Session::get('factoryincident.'.$name);
		}else{
			foreach($fields as $field){

					if(in_array($field,self::$multiple_fields)){
						$data->{$field} = [''];
					}else{
						$data->{$field} = '';
					}
			}
		}


		return $data;
	}


	/**
	 * Set Factory Incident Step Data
	 *
	 * @param string , @param array
	 * @return Session
	 **/

	public static function setFactoryIncidentStepData($name,$step_data){

		$data = new \stdclass;
		$field = [];

		$fields = self::${$name.'_fields'};
 
		
		foreach($fields as $field){

				if(in_array($field,self::$file_fields)){

					$step_data['description'] = array_values(array_filter($step_data['description']));
					$step_data['attachment'] = array_values(array_filter($step_data['attachment']));

	                  if(!empty($step_data['attachment'][0])){

	                        foreach($step_data['attachment'] as $key=>$attachfile){
	                            $original_name = $attachfile->getClientOriginalName();
	                            $mime_type = $attachfile->getMimeType();
	                            $newname = sha1(time() . openssl_random_pseudo_bytes(10));
	                            $path = storage_path() .'/'. self::$attachments_files_path;
	                            $attachfile->move($path, $newname);

	                            $data->{$field}[$key] = [
	                            'type' => 'attachment',
	                            'file_name' => $path .'/'. $newname,
	                            'file_description' => $original_name,
	                            'file_type' => $mime_type,
	                            'description' => isset($step_data['description'][$key]) ? $step_data['description'][$key]: '',
	                        ];

	                        }

	                  }
				}else if(!empty($step_data[$field])){
					$data->{$field} = $step_data[$field];
				}else
					$data->{$field} = '';
			}

		

		\Session::set('factoryincident.'. $name, $data);
	}



	/**
	 *  Save Incident Data
	 *
	 * @param
	 **/
	public static function SaveFactoryIncident(){

		$data = \Session::get('factoryincident');
		$basic_information = $data['basic_information'];

		

		$incident_details  = $data['incident_details'];
		$investigation_attachments = (array) $data['investigation_attachments'];
		if(isset($investigation_attachments->attachment)) $attachment_data['attachment'] = $investigation_attachments->attachment;

		foreach($incident_details->product_description as $ky=>$val){
				$product_description[]	  = $incident_details->product_description[$ky];
				$part_number[]			  = $incident_details->part_number[$ky];
				$serial_number[]		  = $incident_details->serial_number[$ky];
				$product_family[]		  = $incident_details->product_family[$ky];
				$number_of_unit_missing[] = $incident_details->number_of_unit_missing[$ky];
				$value_per_unit[] 		  = $incident_details->value_per_unit[$ky];
		}

		
		/*Factory Incident Creation*/

		$factoryIncident = \FactoryIncident::create([
			'short_description'=>$basic_information->short_description,
			'facility'=>$basic_information->facility,
			'coordinates'=>$basic_information->coordinates,
			'persons_involved'=>$incident_details->persons_involved,
			'loss_discovered_by'=>$incident_details->loss_discovered_by,
			'location_of_incident_within_sitepremises'=>$incident_details->location_of_incident_within_sitepremises,
			'region_id'=>$basic_information->region,
			'country_id'=>$basic_information->country,
			'city' => $basic_information->city,
			'location_address' => $basic_information->location_address,
			'user_id'=>\Auth::user()->id,
			'incident_event_date'=>$basic_information->incident_event_date
			]); 

//print "<pre>"; print_r($basic_information); exit;

		/*Factory Incident Detail and Product Creation*/

		\ProductFactoryIncident::create([
			'product_description' => json_encode($product_description),
			'part_number'=> json_encode($part_number),
			'serial_number'=> json_encode($serial_number),
			'product_family'=> json_encode($product_family),
			'number_of_unit_missing'=> json_encode($number_of_unit_missing),
			'value_per_unit'=> json_encode($value_per_unit),
			'total_value_of_loss_unit'=> $incident_details->total_value_of_loss_unit,
			'factory_incident_id'=> $factoryIncident->id,
		]);

		/* Investigatio and Attachments Creation*/

		\FactoryIncidentInvestigationDetail::create([
			'name_of_investigation_authority' =>$investigation_attachments['name_of_investigation_authority'],
			'contact_information' => $investigation_attachments['contact_information'],
			'investigation_file_number' => $investigation_attachments['investigation_file_number'],
			'incident_refered_to' => $investigation_attachments['incident_refered_to'],
			'ondatetime' => self::getPickUpDate(
                $investigation_attachments['on_date'],
                $investigation_attachments['on_time']
            ),
			'investigation_description_and_action_taken' => $investigation_attachments['investigation_description_and_action_taken'],
			'final_investigation_findings_cause_analysis_corrective_actions' => $investigation_attachments['final_investigation_findings_cause_analysis_corrective_actions'],
			'current_investigation_status' => $investigation_attachments['current_investigation_status'],
			'factory_incident_id' => $factoryIncident->id
		]);


		// Save the final attachments
        if(!empty($attachment_data['attachment'])){

            foreach($attachment_data['attachment'] as $ky=>$file)
            {
                  \FactoryAttachments::create([
                    'attachment_type' => 'factory_attachment',
                    'file_name' => $file['file_name'],
                    'file_description' => $file['file_description'],
                    'file_type' => $file['file_type'],
                    'description' => $file['description'],
                    'factory_incident_id' => $factoryIncident->id
                ]);
            }
        }


          //Incident Log Storage
        \FactoryIncidentLog::Create([
            'factory_incident_id' => $factoryIncident->id,
            'user_id'     => \Auth::User()->id,
            'created_at'  =>  Carbon::parse('now')
            ]); 

          // Send incident create notification
         Emails::sendFactoryIncidentCreateUpdate($factoryIncident, 'created');

		 \Session::forget('factoryincident');
	}

	/**
     * Get decoded products from JSON
     *
     * @param $products object
     * @return array
     */
  
  public static function getDecodedProducts($products){

  	$items = [];

  	
    if (\MSLST\Helpers\Common::isJson($products->product_description))
    {
    	$product_description = json_decode($products->product_description);
    	$part_number = json_decode($products->part_number);
    	$serial_number = json_decode($products->serial_number);
    	$product_family = json_decode($products->product_family);
    	$number_of_unit_missing = json_decode($products->number_of_unit_missing);
    	$value_per_unit = json_decode($products->value_per_unit);
    	$count = count($product_description);

    	for($i=0;$i<$count;$i++){
    		$items[$i]['product_description'] = $product_description[$i];
    		$items[$i]['part_number'] = $part_number[$i];
    		$items[$i]['serial_number'] = $serial_number[$i];
    		$items[$i]['product_family'] = $product_family[$i];
    		$items[$i]['number_of_unit_missing'] = $number_of_unit_missing[$i];
    		$items[$i]['value_per_unit'] = $value_per_unit[$i];
    	}

    }else{
    	$items[] = [
    			'product_description' => $products->product_description,
    			'part_number' => $products->part_number ?:'NA',
    			'serial_number' => $products->serial_number ?:'NA',
    			'product_family' => $products->product_family ?:'NA',
    			'number_of_unit_missing' => $products->number_of_unit_missing ?:'NA',
    			'value_per_unit' => $products->value_per_unit ?:'NA',
    		];
    }

    return $items;
  }

    /**
     * Get the incident's pickup date from the date and time
     *
     * @param $date string
     * @param $time string
     * @return string
     */
    public static function getPickUpDate($date, $time)
    {
        $pickupdate = Carbon::createFromFormat('Y-m-d H:i A', $date.' '.$time)
                    ->toDateTimeString(); 
		return  $pickupdate.".000";
    }

  /**
	 * Get Factory Incident Edit Data
	 *
	 * @param string
	 * @return object
	 **/

	public static function getFactoryIncidentEditData($id,$step){

		$data = new \stdclass;
		$value = [];

		$incident = \FactoryIncident::find($id);
		$data->id = $id;

		$fields = self::${$step.'_fields'};

		

		foreach ($fields as $value){
			if(isset($incident->{$value})){
 					$data->{$value} = $incident->{$value};
 			}
 		} 

 		if($step == 'basic_information'){
 			$data->region = $incident->region->id;
 			$data->country = $incident->country->id;
 			$data->city = $incident->city;
 			$data->location_address = $incident->location_address;
 		}else if($step == 'incident_details'){

 			$product = \ProductFactoryIncident::where('factory_incident_id',$id)->firstOrFail();

 			foreach ($fields as $value){
				if(isset($product->{$value})){
	 					$data->{$value} = $product->{$value};
	 			}
 			} 
 		}else if($step == 'investigation_attachments'){

 			$investment = \FactoryIncidentInvestigationDetail::where('factory_incident_id',$id)->firstOrFail();
			list($data->on_date, $data->on_time) = explode(' ', $investment->ondatetime);
 			foreach ($fields as $value){
				if(isset($investment->{$value})){
	 					$data->{$value} = $investment->{$value};
	 			}
 			} 

 			$attachments = \FactoryAttachments::where('factory_incident_id',$id)->get();


 			if ($attachments)
            {
                $data->attachment = [];
                $data->filename = [];
                $data->description = [];

                foreach ($attachments as $attachment)
                {
                    $data->attachment[] = $attachment->id;
                    $data->filename[] = $attachment->file_description;
                    $data->description[] = $attachment->description;
                }
            }

 		
		}

		return $data;
	}


	 /**
     * Save the incidents edit data
     *
     * @param $id number
     * @param $step string
     * @param $data array
     */
    public static function setIncidentEditData($id, $step, $data)
    {
        $incident = \FactoryIncident::findOrFail($id);
       
       // echo self::getIncidentDateTime($data['incident_event_date']); exit;
         if ($step == 'basic_information')
        {
 			$incident->short_description = $data['short_description'];
			$incident->facility = $data['facility'];
			$incident->coordinates = $data['coordinates']; 
			$incident->region_id =$data['region'];
			$incident->country_id = $data['country'];
			$incident->city = $data['city'];
			$incident->location_address = $data['location_address'];
			$incident->incident_event_date = $data['incident_event_date'];
			$incident->save();
        	
        }else if($step == 'incident_details'){

        	$incident->persons_involved = $data['persons_involved'];
        	$incident->loss_discovered_by = $data['loss_discovered_by'];
        	$incident->location_of_incident_within_sitepremises = $data['location_of_incident_within_sitepremises'];
        	$incident->save();


        	// Skip invalid items
            $product_description = [];
      		$part_number = [];
			$serial_number = [];
			$product_family = [];
			$number_of_unit_missing = [];
			$value_per_unit = [];

            foreach ($data['product_description'] as $i => $item)
            {
                if (trim($data['product_description'][$i]) != ''
                    && trim($data['part_number'][$i]) != ''
                    && trim($data['serial_number'][$i]) != ''
                    && trim($data['product_family'][$i]) != ''
                    && trim($data['number_of_unit_missing'][$i]) != ''
                    && trim($data['value_per_unit'][$i]) != '')
                {
                    $product_description[] = $data['product_description'][$i];
                    $part_number[] = $data['part_number'][$i];
                    $serial_number[] = $data['serial_number'][$i];
                    $product_family[] = $data['product_family'][$i];
                    $number_of_unit_missing[] = $data['number_of_unit_missing'][$i];
                    $value_per_unit[] = $data['value_per_unit'][$i];
                }
            }
 
        	$products = \ProductFactoryIncident::where('factory_incident_id',$id)->firstOrFail();
        	$products->product_description  = json_encode($product_description);
        	$products->part_number  = json_encode($part_number);
        	$products->serial_number  = json_encode($serial_number);
        	$products->product_family  = json_encode($product_family);
        	$products->number_of_unit_missing  = json_encode($number_of_unit_missing);
        	$products->value_per_unit  = json_encode($value_per_unit);
        	$products->total_value_of_loss_unit = $data['total_value_of_loss_unit'];
        	$products->save();

        }else if($step == 'investigation_attachments'){
        	$investigation = \FactoryIncidentInvestigationDetail::where('factory_incident_id',$id)->firstOrFail();

        	$investigation->name_of_investigation_authority  = $data['name_of_investigation_authority'];
			$investigation->contact_information              = $data['contact_information'];
			$investigation->investigation_file_number = $data['investigation_file_number'];
			$investigation->incident_refered_to = $data['incident_refered_to'];
			 $investigation->ondatetime = self::getPickUpDate(
                $data['on_date'],
                $data['on_time']
            );
			$investigation->investigation_description_and_action_taken = $data['investigation_description_and_action_taken'];
			$investigation->final_investigation_findings_cause_analysis_corrective_actions = $data['final_investigation_findings_cause_analysis_corrective_actions'];
			$investigation->current_investigation_status = $data['current_investigation_status'];
			$investigation->save();

			//$data['current_file'] = array_filter($data['current_file']);


			if(!empty($data['current_file']))
            {
                // Handle the current files
                foreach($data['current_file'] as $id => $status)
                {
                    $attachment = \FactoryAttachments::find($id);

                    if ($status)
                    {
                        $attachment->description = $data['current_description'][$id];
                        $attachment->save();
                    }
                    else
                    {
                        $attachment->delete();
                    }
                }
            }

            	
           $data['description'] = array_values(array_filter($data['description']));
           $data['attachment'] = array_values(array_filter($data['attachment']));
 			//print "<pre>";print_r($data); exit;
              // Handle the new files
            foreach ($data['attachment'] as $i => $file)
            {
                if ($file)
                {
                    $original_name = $file->getClientOriginalName();
                    $mime_type = $file->getMimeType();
                    $newname = sha1(time() . openssl_random_pseudo_bytes(10));
                    $path = storage_path() .'/'. self::$attachments_files_path;
                    $file->move($path, $newname);

                    \FactoryAttachments::create([
                        'attachment_type' => 'factory_attachment',
                        'file_name' => $path .'/'. $newname,
                        'file_description' => $original_name,
                        'file_type' => $mime_type,
                        'description' => (isset($data['description'][$i])) ? ($data['description'][$i]) : "",
                        'factory_incident_id' => $incident->id
                    ]);
                }
            }

        	//echo "<pre>"; print_r($data);exit;

        }

          //Incident Log Storage
        \FactoryIncidentLog::Create([
            'factory_incident_id' => $incident->id,
            'user_id'     => \Auth::User()->id,
            'created_at'  => null,
            'updated_at'  =>  Carbon::parse('now')
            ]);


		//echo date('Y-m-d H:i:s'); exit;

           // Send incident Update notification
         Emails::sendFactoryIncidentCreateUpdate($incident, 'updated');
     }


     /**
     * Check if there are attachments
     *
     * @param $attachment object
     * @return boolean
     */
    public static function hasAttachments($attachment)
    {
    	$status = false;
    	foreach ($attachment as $item)
    	{
    		if ($item->attachment_type == 'factory_attachment')
    		{
    			$status = true;
    			break;
    		}
    	}

    	return $status;
    }

}

?>