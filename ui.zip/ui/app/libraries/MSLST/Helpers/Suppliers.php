<?php
namespace MSLST\Helpers;
use Carbon\Carbon;
	class Suppliers {
		public static $basic_information_fields = [
			'vendor_number','vendor_name','site_name','city','region','country','postal_code','address','coordinates'
		];
			
		public static $supplier_information_fields = [
			'supplier_handle','site_technology','tier','relationship','supplier_type','supplier_role','category'
		];
		public static $supplier_contact_details_fields = [
			'contact_telephone_number','contact_email_address'
		];
		public static $questions_fields = [
        'question'
    	];
    	public static $questions_answers_fields = [
       'self_answer_id','self_comment','onsite_answer_id','onsite_comment','supplier_id','question_id','ms_id','self_file_name','self_file_description','self_file_type','activity_id'
    	];

		public static function getSupplierEditData($id, $name)  {
			$data = new \stdClass;
			$supplier = \Supplier::find($id);

			$data->id = $id;
			$fields =self::${$name .'_fields'};		

			foreach ($fields as $field)
			{
				if (isset($supplier->{$field}))
				{
					$data->{$field} = $supplier->{$field};
				}
			}

			// There is no region_id field, it is region
			$data->region = $supplier->region->id;

			// There is no country_id field, it is country
			$data->country = $supplier->country->id;

			// Show only date
			//$data->incident_date = $incident->incident_date->format('Y-m-d');
		 return $data;			
		}
		
		public static function getSupplierStepData($name) {
	
			$data = new \stdClass;
			$fields = [];
			$fields = self::${$name .'_fields'};

			if (\Session::has('suppliers.'. $name))	{
			$data = (object) \Session::get('suppliers.'. $name);
			}
			else{
				foreach ($fields as $field){
				$data->{$field} = '';
				}
			}
			return $data;
		}
	
		public static function setSupplierStepData($name, $step_data) {
			$data = new \stdClass;
			$fields = self::${$name .'_fields'};
				foreach ($fields as $field)  {
					$data->{$field} = $step_data[$field];       
				}
			\Session::set('suppliers.'. $name, $data);
		}
	
		public static function getIncidentEditData($id, $name)   {

			$data = new \stdClass;
			$supplier = \Supplier::find($id);
			$data->id = $id;
			$fields = self::${$name .'_fields'};

			foreach ($fields as $field)
			{
				if (isset($supplier->{$field}))
				{
					$data->{$field} = $supplier->{$field};
				}
			}

			if ($name == 'basic_information')
			{
				// There is no region_id field, it is region
				$data->region = $supplier->region->id;

				// There is no country_id field, it is country
				$data->country = $supplier->country->id;
			}			
			return $data;
		}
		public static function getVendornameList()
		{
			$vendor_name = \Supplier::select('vendor_name')
									->distinct()
									->where('vendor_name','!=','')
									->orderBy('vendor_name')
									->lists('vendor_name','vendor_name');

			return $vendor_name;
		}
		public static function getCategoryList()
		{
			$category = \Supplier::select ('category')
									->distinct()
									->where('category','!=','')
									->orderBy('category')
									->lists('category','category');

			return $category;
		}
	
	
		/**
		 * Save the suppliers edit data
		 *
		 * @param $id number
		 * @param $step string
		 * @param $data array
		 */
		public static function setSupplierEditData($id, $step, $data)  {
			$supplier = \Supplier::findOrFail($id);

			if ($step == 'basic_information')
			{
				$supplier->vendor_number = $data['vendor_number'];
				$supplier->vendor_name = $data['vendor_name'];
				$supplier->site_name = $data['site_name'];
				$supplier->address = $data['address'];
				$supplier->country_id = $data['country'];
				$supplier->region_id = $data['region'];
				$supplier->city = $data['city'];
				$supplier->postal_code = $data['postal_code'];
				$supplier->coordinates = $data['coordinates'];				
				$supplier->save();
			}
			elseif ($step == 'supplier_information') {
				$supplier->site_technology = $data['site_technology'];
				$supplier->tier = $data['tier'];
				$supplier->supplier_type = $data['supplier_type'];
				$supplier->supplier_role = $data['supplier_role'];
				$supplier->category = $data['category'];
				$supplier->relationship = $data['relationship'];
				$supplier->supplier_handle = $data['supplier_handle'];
				$supplier->save();
			}
			elseif ($step == 'supplier_contact_details') {
				$supplier->contact_telephone_number = $data['contact_telephone_number'];
				$supplier->contact_email_address = $data['contact_email_address'];
				$supplier->save();
			}
			//Updating Supplier_log
			$supplierlogArray = ['supplier_id' => $supplier->id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SupplierLog::insert($supplierlogArray);
			// Send incident update notification
			//Emails::sendIncidentCreateUpdate($incident, 'updated');
		}	
	
	
		public static function saveSupplierData() {
			$supplier_data = \Session::get('suppliers');
        
			// Get the data from each steps
			$basic_information = (array) $supplier_data['basic_information'];
			$supplier_information = (array) $supplier_data['supplier_information'];
			$supplier_contact_details = (array) $supplier_data['supplier_contact_details'];

			
			// First create the incident
			$supplier = \Supplier::create([
				'vendor_number'=> $basic_information['vendor_number'],
				'vendor_name'=> $basic_information['vendor_name'],
				'site_name'=> $basic_information['site_name'],
				'address'=> $basic_information['address'],
				'country_id'=> $basic_information['country'],
				'region_id'=> $basic_information['region'],
				'city'=> $basic_information['city'],
				'postal_code'=> $basic_information['postal_code'],
				'coordinates'=> $basic_information['coordinates'],
				'site_technology'=> $supplier_information['site_technology'],
				'tier'=> $supplier_information['tier'],
				'supplier_type'=> $supplier_information['supplier_type'],
				'supplier_role'=> $supplier_information['supplier_role'],
				'category'=> $supplier_information['category'],
				'relationship'=> $supplier_information['relationship'],
				'supplier_handle' => $supplier_information['supplier_handle'],	
				'contact_telephone_number'=> $supplier_contact_details['contact_telephone_number'],
				'contact_email_address'=> $supplier_contact_details['contact_email_address'],
				'user_id' => \Auth::User()->id,
				'status' => 'active'
			]); 
			// Send incident create notification
			//Emails::sendIncidentCreateUpdate($supplier, 'created');

			// Destroy the session data
			\SupplierLog::create([
	            'supplier_id' => $supplier->id,
	            'user_id' => \Auth::User()->id,
	            'created_at'=>  Carbon::parse('now')
	        ]);

			// Destroy the session data
			\Session::forget('suppliers');
		}
	/**
     * Get all suppliers by filters
     *
     * @param $filters array
     * @return array
     */
    public static function getFilteredSuppliers($filters)
    {
		$suppliers = \Supplier::with('user', 'country', 'region');
		if (isset($filters['vendor_number']) && !empty($filters['vendor_number']))
		{ $vendor_number =$filters['vendor_number'];
			
			$suppliers->WhereRaw('lower(vendor_number) like \'%'. $vendor_number  .'%\'');
		}
		
		if (isset($filters['user']) && !empty($filters['user']))
		{
			$suppliers->whereIn('user_id', $filters['user']);
		}

		if (isset($filters['vendor_name']) && !empty($filters['vendor_name']))
		{
			$suppliers->whereIn('vendor_name', $filters['vendor_name']);
		}

		if (isset($filters['category']) && !empty($filters['category']))
		{
			$suppliers->whereIn('category', $filters['category']);
		}
		if (isset($filters['region']) && !empty($filters['region']))
		{
			$suppliers->whereIn('region_id', $filters['region']);
		}

		if (isset($filters['country']) && !empty($filters['country']))
		{
			$suppliers->whereIn('country_id', $filters['country']);
		}
		
		if (isset($filters['keywords']) && !empty($filters['keywords']))
		{
			$keywords = strtolower($filters['keywords']);
			$suppliers->where(function ($q) use ($keywords) {
				$q->orWhereRaw('lower(vendor_name) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(vendor_number) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(site_name) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(address) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(country_id) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(region_id) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(city) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(site_technology) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(supplier_type) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(supplier_role) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(category) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(relationship) like \'%'. $keywords .'%\'')
				  ->orWhereRaw('lower(contact_email_address) like \'%'. $keywords .'%\'');
			});
		}
		
		if (\Auth::User()->isUser())
        {
            $suppliers->where(function ($q) {
                $q->where('suppliers.user_id', \Auth::User()->id);
				
				if (! empty($owners))
				{
					$q->OrWhereIn('suppliers.id', $owners);
				}
            });
        }

        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
          $regionChk = \UserRegion::select('region_id')
                                   ->where('user_id',\Auth::User()->id)
                                   ->lists('region_id');

           $suppliers->whereIn('region_id', $regionChk);

        }
           
        

		$suppliers = $suppliers
					->orderBy('created_at', 'DESC')
					->get()
					->all();
		

		return $suppliers;
    }

    /**
     *
     *
     **/
    public static function SaveActionPlan($data,$option=null){
    	
    	$action = Lists::getBusinessAction('leak_risk_plan');

    	$leak_create = [];
    	$leak_create['supplier_id'] = $data['supplier_id'];

    	foreach($data['asset_id'] as $kar=>$kav){

	    	/*Get Risk Id*/
	    	$risk = \BusinessRisk::select('id','name');
	    	foreach ($kav as $key => $value) {
	    		if($key == 0)
	    		    $risk->where('asset_ids','like','%"'.$value.'"%');
	    		else
	    		    $risk->orwhere('asset_ids','like','%"'.$value.'"%');
	    	}
	    	$risk = $risk->lists('name','id');

         	/*Get Action Id*/
	    	/*$action = \BusinessAction::select('id','name','description');
	    	foreach ($risk as $kac => $vac) {
	    		if($key == 0)
	    			$action->where('risk_id','like','%"'.$vac->id.'"%');
	    		else
	    			$action->orwhere('risk_id','like','%"'.$vac->id.'"%');
	    	}
	    	$action = $action->get();*/
	    	if($option == 'exist'){
		    	/* Selecting Leak prevention id for existing */
		    	$select_preven_arry = \LeakPreventionAssessment::select('risk_id')
		    							->where('supplier_id',$data['supplier_id'])
		    							->where('leak_id',$data['LeakRiskAnalysis_id'][$kar])
		    							->lists('risk_id');
		        /*Deleting unselected Leak prevention from existing*/
		        $delete_id = array_diff($select_preven_arry,array_flip($risk));
		        if(!empty($delete_id)){
			       \LeakPreventionAssessment::where('supplier_id',$data['supplier_id'])
			    							->where('leak_id',$data['LeakRiskAnalysis_id'][$kar])
			    							->whereIn('risk_id',$delete_id)
			    							->delete();
			    }

		    	$risk = array_flip(array_diff(array_flip($risk), $select_preven_arry));
		    }	

		   			

	    	/*Insert in Leak Prevention Plan*/
	     	if(!empty($risk)){ 
		    	
		     	foreach($risk as $kay=>$val){

		     	//print "<pre>"; echo $kay;	print_r($action[$kay]); exit;
			     	foreach ($action[$kay] as $key => $action_value) {
			     		 
			     		switch($option){
			    			case 'new':
								$leak_create['risk'] = $val;
								$leak_create['risk_id']   = $kay;
								$leak_create['action_name']   = $action_value['action_name'];
								$leak_create['action_description']  = $action_value['action_description'];
								$leak_create['leak_id']   = $data['LeakRiskAnalysis_id'][$kar];
					    		$leak_create['status']  = 'Not Started';
					    		\LeakPreventionAssessment::create($leak_create);
				    		break;
				    		case 'exist':
				    			$leak_update['risk'] = $val;
								$leak_update['risk_id']   = $kay;
								$leak_update['action_name']   = $action_value['action_name'];
								$leak_update['action_description']  = $action_value['action_description'];
								$leak_update['supplier_id']   = $data['supplier_id'];
								$leak_update['leak_id']   = $data['LeakRiskAnalysis_id'][$kar];
					    		$leak_update['status']  = 'Not Started';

				    			//\LeakPreventionAssessment::where('supplier_id',$data['supplier_id'])
				    			//						 ->where('leak_id',$data['LeakRiskAnalysis_id'][$kar])
				    			//						 ->where('id',$select_preven_arry[$lk])
				    			//						 ->update($leak_update);
				    			\LeakPreventionAssessment::create($leak_update);
				    		break;
			    	   }

			     	}

		    		

		    	}
		    }

	    }
	    

    }
    /*
         * Storing Self-Assessment Data
         *
         */
		public static function setselfassessment($id,$data) {
			
			$activities=Lists::getActivitiesList();
			$suppliers = [];
			foreach($activities as $activitykey => $activityvalue)
			{
				
				if(isset($data[$activitykey.'question']))
				{	
					$questions = $data[$activitykey.'question'];
					$self_comments = isset($data[$activitykey.'selfcomment']) ? $data[$activitykey.'selfcomment'] : [];
					$assessment_data = Suppliers::get_assessment_data($id,$activitykey);
					// Delete current SA anseres
		            $self = \BusinessAnswer::where(['supplier_id'=>$id,'activity_id'=>$activitykey])
		                                        ->forceDelete();
		            // Save the self-assessment ansewrs 
		            foreach ($questions as $qid => $aid)
			            {
			                $self = new \stdClass;
			                $self->self_answer_id = intval($aid);
			                
			                \BusinessAnswer::create([
			                    'supplier_id' => $id,
			                    'question_id' => $qid,
			                    'self_answer_id' => $self->self_answer_id,
			                    'self_comment' => isset($self_comments[$qid]) ? $self_comments[$qid] : '',
			                    'onsite_answer_id'=>isset($assessment_data->onsite_answer_id[$qid])?$assessment_data->onsite_answer_id[$qid]:'',
			                    'onsite_comment' =>isset($assessment_data->onsite_comment[$qid]) ? $assessment_data->onsite_comment[$qid] : '',
			                    'ms_id'=>isset($assessment_data->ms_id[$qid])?$assessment_data->ms_id[$qid]:'',
			                    'activity_id' =>$activitykey

			                ]);

			                $suppliers[] = $self;
			            }
	        	}
        	}
       		//Updating Supplier_log
			$supplierlogArray = ['supplier_id' => $id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SupplierLog::insert($supplierlogArray);
            
            // Calculate the SA score             
            $supplier_tb = \Supplier::findOrFail($id);
            $supplier_tb->self_assessment_score = self::calculateScore($id, $suppliers,'self_assessment');
            $supplier_tb->save();
        }
	     /*
	     * Storing Onsite-Assessment Data
	     *
	     */
        public static function setonsiteassessment($id,$data,$ms_id) {
			$activities=Lists::getActivitiesList();
			$suppliers = [];
			foreach($activities as $activitykey => $activityvalue)
			{
				
				if(isset($data[$activitykey.'question']))
				{	
					$questions = $data[$activitykey.'question'];
					$onsite_comments = isset($data[$activitykey.'onsitecomment']) ? $data[$activitykey.'onsitecomment'] : [];
					$assessment_data = Suppliers::get_assessment_data($id,$activitykey);
					
					// Delete current OSA answers
		            $self = \BusinessAnswer::where(['supplier_id'=>$id,'activity_id'=>$activitykey])
		                                        ->forceDelete();
	                foreach ($questions as $qid => $aid)
			        {
		                $self = new \stdClass;
		                $self->onsite_answer_id = intval($aid);
		                
		                \BusinessAnswer::create([
		                	'supplier_id' => $id,
		                    'question_id' => $qid,
		                    'onsite_answer_id' => $self->onsite_answer_id,
		                    'onsite_comment' => isset($onsite_comments[$qid]) ? $onsite_comments[$qid] : '',
		                    'self_answer_id'=>isset($assessment_data->self_answer_id[$qid])?$assessment_data->self_answer_id[$qid]:0,
		                    'self_comment' =>isset($assessment_data->self_comment[$qid]) ? $assessment_data->self_comment[$qid] : '',
		                    'ms_id' => $ms_id,
		                    'self_file_name'=>isset($assessment_data->self_file_name[$qid]) ? $assessment_data->self_file_name[$qid] : '',
		                    'self_file_description'=>isset($assessment_data->self_file_description[$qid]) ? $assessment_data->self_file_description[$qid] : '',
		                    'self_file_type'=>isset($assessment_data->self_file_type[$qid]) ? $assessment_data->self_file_type[$qid] : '',
		                    'activity_id' =>$activitykey
		                   ]);

	                	$suppliers[] = $self;
	            	}
	        	}    
	    	}
        
            //Updating Supplier_log
			$supplierlogArray = ['supplier_id' => $id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SupplierLog::insert($supplierlogArray);
            // Calculate the OSA score 
            $supplier_tb = \Supplier::findOrFail($id);
            $supplier_tb->onsite_assessment_score = self::calculateScore($id, $suppliers,'onsite_assessment');
            $supplier_tb->save();
        }
        public static function get_assessment_data($id,$activitykey)
		{
			
			$data = new \stdClass;
        	$suppliers = \BusinessAnswer::where(['supplier_id'=>$id,'activity_id'=>$activitykey])
	        							->get();
			$fields = self::$questions_answers_fields;
        	foreach ($suppliers as $supplier) 
        	{	
        		$data->id = $id;
	        	foreach ($fields as $field)
		        {
		            $data->{$field}[$supplier->question_id] = $supplier->{$field};
		           
		        }
		    }
	    
			return $data;
		}

		public static function calculateScore($supplier_id, $suppliers = null,$data)
    {
        if (!$suppliers)
        {
            $suppliers = \BusinessAnswer::where('supplier_id', $supplier_id)->get()->all();
        }

        $score = $count = $final_score = 0;
        if($data=='self_assessment')
	    {    
	        if ($suppliers)
	        {
	            foreach ($suppliers as $supplier)
	            {
	                if($supplier->self_answer_id == '1')
	                    $score += 1;
	                if($supplier->self_answer_id == '2')
	                    $score += 0.5;
	                if($supplier->self_answer_id == '3')
	                    $score += 0;
	                if($supplier->self_answer_id != '4')
	                    $count++;
	            }
	        }
	    }
	    else
	    {
	    	if ($suppliers)
	        {
	            foreach ($suppliers as $supplier)
	            {
	                if($supplier->onsite_answer_id == '1')
	                    $score += 1;
	                if($supplier->onsite_answer_id == '2')
	                    $score += 0.5;
	                if($supplier->onsite_answer_id == '3')
	                    $score += 0;
	                if($supplier->onsite_answer_id != '4')
	                    $count++;
	            }
	        }
	    }
	    $final_score = ($score / $count)*100;
	        

        return $final_score;
    }


 }
?>