<?php namespace MSLST\Helpers;

use MSLST\Constants\Site;
use Carbon\Carbon;

class Routes {
    
    /**
     * Represents route basic details fields.
     *
     * @var array
     */
    public static $basic_details_fields = [
    	'start_site',
        'end_site',
    	'start_address',
        'end_address',
    	'start_coordinates',
        'end_coordinates',
    	'start_country',
        'end_country',
        'start_carrier',
        'end_carrier',
    ];

    /**
     * Represents route needed certification fields.
     *
     * @var array
     */
    public static $needed_certification_fields = [
    	'tapa_needed'
    ];

    /**
     * Represents route actual certification fields.
     *
     * @var array
     */
    public static $actual_certification_fields = [
        'tapa',
        'ctpat',
        'aeo',
        'svi_num',
        'aeo_num',
        'tapa_certificate',
        'ctpat_certificate',
        'aeo_certificate',
    ];

    /**
     * Represents route questions fields.
     *
     * @var array
     */
    public static $questions_fields = [
        'question',
        'comment',
    ];

    /**
     * Represents route comments fields.
     *
     * @var array
     */
    public static $comments_fields = [
        'comments',
    ];

    /**
     * Represents multi value fields.
     *
     * @var array
     */
    public static $multi_fields = [
    ];

    /**
     * Represents file fields.
     *
     * @var array
     */
    public static $file_fields = [
        'tapa_certificate',
        'ctpat_certificate',
        'aeo_certificate',
    ];

    /**
     * Summary Fields
     *
     *@var array
     **/
    public static $summary_fields=[
    ];

    /**
     * Represents the certificates file path.
     *
     * @var string
     */
    public static $certificates_files_path = 'files/routes';

    /**
     * Save the route data
     * along with the audit data
     */
    public static function saveRouteData()
    {

        $data = \Session::get('routes');
       

        $comments = \Input::get('comments')? \Input::get('comments') : $data['comments']->comments ;

        $basic_details = (array) $data['basic_details'];
        $tapa_needed = $data['needed_certification']->tapa_needed;
        $actual_certification = (array) $data['actual_certification'];
        $questions = (array) $data['questions']->question;
        $question_comments = isset($data['questions']->comment) ?: [];

        if(empty($data['id'])){
        // Create the route
            $route = \Routes::create([
                'start_site' => $basic_details['start_site'],
                'end_site' => $basic_details['end_site'],
                'start_address' => $basic_details['start_address'],
                'end_address' => $basic_details['end_address'],
                'start_coordinates' => $basic_details['start_coordinates'],
                'end_coordinates' => $basic_details['end_coordinates'],
                
                // @TODO to be enabled after confirmation
                // 'start_carrier' => $basic_details['start_carrier'],
                // 'end_carrier' => $basic_details['end_carrier'],
                
                // @TODO Remove this
                'start_carrier' => 'start_carrier',
                'end_carrier' => 'end_carrier',
                'comment' => $comments,
                'score' => 0,
                'ctpat_number' => $actual_certification['svi_num'],
                'aeo_number' => $actual_certification['aeo_num'],
                'review' => 0,
                'tapa_needed' => $tapa_needed,
                'auditor_id' => \Auth::User()->id,
                'start_country_id' => $basic_details['start_country'],
                'end_country_id' => $basic_details['end_country'],
                'lsp_id' => \Auth::User()->lsp->id,
                'status' => 'active'
            ]);
            
           }else{
                \Routes::where('id',$data['id'])->update([
                'start_site' => $basic_details['start_site'],
                'end_site' => $basic_details['end_site'],
                'start_address' => $basic_details['start_address'],
                'end_address' => $basic_details['end_address'],
                'start_coordinates' => $basic_details['start_coordinates'],
                'end_coordinates' => $basic_details['end_coordinates'],
                
                // @TODO to be enabled after confirmation
                // 'start_carrier' => $basic_details['start_carrier'],
                // 'end_carrier' => $basic_details['end_carrier'],
                
                // @TODO Remove this
                'start_carrier' => 'start_carrier',
                'end_carrier' => 'end_carrier',
                
                'comment' => $comments,
                'score' => 0,
                'ctpat_number' => $actual_certification['svi_num'],
                'aeo_number' => $actual_certification['aeo_num'],
                'review' => 0,
                'tapa_needed' => $tapa_needed,
                'auditor_id' => \Auth::User()->id,
                'start_country_id' => $basic_details['start_country'],
                'end_country_id' => $basic_details['end_country'],
                'lsp_id' => \Auth::User()->lsp->id,
              ]);
                $routes = \Routes::where('id',$data['id'])->get()->all();
                $route = $routes[0];
           }

          // Save the disabled certifications and added certifications
        if ($actual_certification['tapa'] == 'na')
        {
            \RouteCertificationDisabledGroup::create([
                'certification_group_id' => Site::TAPA_GROUP,
                'route_id' => $route->id,
            ]);
        }
        elseif ($actual_certification['tapa'] != '0')
        {
            \RouteCertification::create([
                'certificate_file' => $actual_certification['tapa_certificate']['certificate_file'],
                'filename' => $actual_certification['tapa_certificate']['filename'],
                'route_id' => $route->id,
                'certification_id' => $actual_certification['tapa'],
            ]);
        }

        if ($actual_certification['ctpat'] == 'na')
        {
            \RouteCertificationDisabledGroup::create([
                'certification_group_id' => Site::C_TPAT_GROUP,
                'route_id' => $route->id,
            ]);
        }
        elseif ($actual_certification['ctpat'] != '0')
        {
            \RouteCertification::create([
                'certificate_file' => $actual_certification['ctpat_certificate']['certificate_file'],
                'filename' => $actual_certification['ctpat_certificate']['filename'],
                'route_id' => $route->id,
                'certification_id' => $actual_certification['ctpat'],
            ]);
        }

        if ($actual_certification['aeo'] == 'na')
        {
            \RouteCertificationDisabledGroup::create([
                'certification_group_id' => Site::AEO_GROUP,
                'route_id' => $route->id,
            ]);
        }
        elseif ($actual_certification['aeo'] != '0')
        {
            \RouteCertification::create([
                'certificate_file' => $actual_certification['aeo_certificate']['certificate_file'],
                'filename' => $actual_certification['aeo_certificate']['filename'],
                'route_id' => $route->id,
                'certification_id' => $actual_certification['aeo'],
            ]);
        }

        // Save the audits
        $audits = [];
        foreach ($questions as $qid => $aid)
        {
            $audit = new \stdClass;
            $audit->is_archived = 0;
            $audit->answer_id = intval($aid);
            
            \RouteAudit::create([
                'route_id' => $route->id,
                'question_id' => $qid,
                'answer_id' => $audit->answer_id,
                'comment' => isset($question_comments[$qid]) ? $question_comments[$qid] : '',
                'is_archived' => 0,
            ]);

            $audits[] = $audit;
        }

        // Calculate the score from new audits
        $route->score = self::calculateScore($route->id, $audits);
        $route->save();

        \RouteLog::create([
            'route_id' => $route->id,
            'user_id' => \Auth::User()->id,
        ]);

        // Send route create notification
        Emails::sendRouteCreateUpdate(\Routes::with('user', 'start_country', 'end_country', 'lsp')->find($route->id), 'created');

        // Destroy the session data
        \Session::forget('routes');
    }

    /**
     * Get the routes step data
     *
     * @param $name string
     * @return object
     */
    public static function getRouteStepData($name)
    {
        $data = new \stdClass;
        $fields = [];

        $fields = self::${$name .'_fields'};

        if (\Session::has('routes.'. $name))
        {
            $data = (object) \Session::get('routes.'. $name);
        }
        else
        {
            foreach ($fields as $field)
            {
                if (in_array($field, self::$multi_fields))
                {
                    $data->{$field} = [''];
                }
                else
                {
                    $data->{$field} = '';
                }
            }
        }
 
        return $data;
    }

    /**
     * Set the audits step data
     *
     * @param $name string
     * @param $data array
     */
    public static function setRouteStepData($name, $step_data)
    {
        $data = new \stdClass;

        $fields = self::${$name .'_fields'};
        
        foreach ($fields as $field)
        {
            if (in_array($field, self::$file_fields) && \Input::file($field))
            {
                $file = \Input::file($field);
                // @TODO keep original name and mime in table
                $original_name = $file->getClientOriginalName();
                $newname = sha1(microtime(true));
                $path = storage_path() .'/'. self::$certificates_files_path;
                $file->move($path, $newname);

                $data->{$field} = [
                    'certificate_file' => $path .'/'. $newname,
                    'filename' => $original_name,
                ];
            }
            else 
            {
                if (isset($step_data[$field]))
                {
                    $data->{$field} = $step_data[$field];
                }
                else
                {
                    $data->{$field} = null;
                }
            }
        }

        \Session::set('routes.'. $name, $data);
    }

    /**
     * Get the route edit data
     *
     * @param $id number
     * @param $name string
     * @return object
     */
    public static function getRouteEditData($id, $name)
    {
        $data = new \stdClass;
        $route = \Routes::with('start_country', 'end_country')->findOrFail($id);

        $data->id = $id;

        $fields = self::${$name .'_fields'};

        foreach ($fields as $field)
        {
            if (isset($route->{$field}))
            {
                $data->{$field} = $route->{$field};
            }
        }

        if ($name == 'basic_details')
        {
            // There is no country_id field, it is country
            $data->start_country = $route->start_country->id;
            $data->end_country = $route->end_country->id;
        }
        elseif ($name == 'actual_certification')
        {
            // Reassign the SVI and AEO numbers, if any
            $data->svi_num = $route->ctpat_number;
            $data->aeo_num = $route->aeo_number;

            // Get all certifications
            $certs = self::getCurrentCertifications($id);

            $data->tapa = $certs->tapa;
            $data->ctpat = $certs->ctpat;
            $data->aeo = $certs->aeo;
        }
        elseif ($name == 'questions')
        {

            // Get all certifications
            $certs = self::getCurrentCertifications($id);

            $data->tapa_needed = $route->tapa_needed;
            $data->actual_certification = [
                'tapa' => $certs->tapa,
                'ctpat' => $certs->ctpat,
                'aeo' => $certs->aeo,
            ];

            $audits = \RouteAudit::where('route_id', $id)
                                        ->where('is_archived', 0)
                                        ->get();

            $data->answer = [];
            $data->comment = [];

            foreach($audits as $audit)
            {
                $data->answer[$audit->question->id] = $audit->answer_id ?: null;
                
                if ($audit->comment)
                {
                    $data->comment[$audit->question->id] = $audit->comment;
                }
            }
        }
        elseif ($name == 'comments')
        {
            $data->comments = $route->comment;
        }

        return $data;
    }

    /**
     * Save the routes edit data
     *
     * @param $id number
     * @param $step string     
     * @param $data array
     */
    public static function setRouteEditData($id, $step, $data)
    {
        $route = \Routes::findOrFail($id);

        if ($step == 'basic_details')
        {
            $route->start_site = $data['start_site'];
            $route->end_site = $data['end_site'];
            $route->start_address = $data['start_address'];
            $route->end_address = $data['end_address'];
            $route->start_coordinates = $data['start_coordinates'];
            $route->end_coordinates = $data['end_coordinates'];

            //@TODO: to be enabled
            // $route->start_carrier = $data['start_carrier'];
            // $route->end_carrier = $data['end_carrier'];
            
            //@TODO: this to be removed
            $route->start_carrier = 'start_carrier';
            $route->end_carrier = 'end_carrier';
            
            $route->start_country_id = $data['start_country'];
            $route->end_country_id = $data['end_country'];
            $route->save();
        }
        elseif ($step == 'actual_certification')
        {
            // Get all certifications 
            $certs = self::getCurrentCertifications($id);

            if (isset($data['tapa']) && $data['tapa'] != 0)
            {
                if (($certs->tapa != $data['tapa']) || $data['tapa_certificate'])
                {
                    \RouteCertification::where('route_id', $id)
                                            ->where('certification_id', $certs->tapa)
                                            ->delete();

                    $file = $data['tapa_certificate'];
                    $original_name = $file->getClientOriginalName();
                    $mime_type = $file->getMimeType();
                    $newname = sha1(microtime(true));
                    $path = storage_path() .'/'. self::$certificates_files_path;
                    $file->move($path, $newname);

                    \RouteCertification::create([
                            'certificate_file' => $path .'/'. $newname,
                            'filename' => $original_name,
                            'route_id' => $id,
                            'certification_id' => $data['tapa'],
                        ]);

                    // If there is a certification change, Update the audits as well
                    $qhcs = \QuestionCertification::where('certification_id', $data['tapa'])->get();
                    foreach ($qhcs as $qhc) {
                        
                        // Remove the current audit, if any
                        $audit = \RouteAudit::where('route_id', $route->id)
                                                ->where('question_id', $qhc->question_id)
                                                ->delete();

                        // Add a new audit
                        \RouteAudit::create([
                            'route_id' => $route->id,
                            'question_id' => $qhc->question_id,
                            'answer_id' => 0,
                            'comment' => '',
                            'is_archived' => 0,
                        ]);
                    }
                }
            }

            if (isset($data['ctpat']) && $data['ctpat'] != 0)
            {
                $route->ctpat_number = $data['svi_num'];
                $route->save();

                if (($certs->ctpat != $data['ctpat']) || $data['ctpat_certificate'])
                {

                   if(!empty($data['ctpat_certificate'])){

                        \RouteCertification::where('route_id', $id)
                                                ->where('certification_id', $certs->ctpat)
                                                ->delete();

                        $file = $data['ctpat_certificate'];
                        $original_name = $file->getClientOriginalName();
                        $mime_type = $file->getMimeType();
                        $newname = sha1(microtime(true));
                        $path = storage_path() .'/'. self::$certificates_files_path;
                        $file->move($path, $newname);

                        \RouteCertification::create([
                                'certificate_file' => $path .'/'. $newname,
                                'filename' => $original_name,
                                'route_id' => $id,
                                'certification_id' => $data['ctpat'],
                            ]);
                    }

                    // If there is a certification change, Update the audits as well
                    $qhcs = \QuestionCertification::where('certification_id', $data['ctpat'])->get();
                    foreach ($qhcs as $qhc) {
                        
                        // Remove the current audit, if any
                        $audit = \RouteAudit::where('route_id', $route->id)
                                                ->where('question_id', $qhc->question_id)
                                                ->delete();

                        // Add a new audit
                        \RouteAudit::create([
                            'route_id' => $route->id,
                            'question_id' => $qhc->question_id,
                            'answer_id' => 0,
                            'comment' => '',
                            'is_archived' => 0,
                        ]);
                    }
                }
            }

            if (isset($data['aeo']) && $data['aeo'] != 0)
            {
                $route->aeo_number = $data['aeo_num'];
                $route->save();

                if (($certs->aeo != $data['aeo']) || $data['aeo_certificate'])
                {

                    if(!empty($data['aeo_certificate'])){

                        \RouteCertification::where('route_id', $id)
                                                ->where('certification_id', $certs->aeo)
                                                ->delete();

                        $file = $data['aeo_certificate'];
                        $original_name = $file->getClientOriginalName();
                        $mime_type = $file->getMimeType();
                        $newname = sha1(microtime(true));
                        $path = storage_path() .'/'. self::$certificates_files_path;
                        $file->move($path, $newname);

                        \RouteCertification::create([
                                'certificate_file' => $path .'/'. $newname,
                                'filename' => $original_name,
                                'route_id' => $id,
                                'certification_id' => $data['aeo'],
                            ]);
                    }

                    // If there is a certification change, Update the audits as well
                    $qhcs = \QuestionCertification::where('certification_id', $data['tapa'])->get();
                    foreach ($qhcs as $qhc) {
                        
                        // Remove the current audit, if any
                        $audit = \RouteAudit::where('route_id', $route->id)
                                                ->where('question_id', $qhc->question_id)
                                                ->delete();

                        // Add a new audit
                        \RouteAudit::create([
                            'route_id' => $route->id,
                            'question_id' => $qhc->question_id,
                            'answer_id' => 0,
                            'comment' => '',
                            'is_archived' => 0,
                        ]);
                    }
                }
            }

            // Update the scores too
            $route->score = self::calculateScore($route->id);
            $route->save();
        }
        elseif ($step == 'questions')
        {
            $questions = $data['question'];
            $question_comments = isset($data['comment']) ? $data['comment'] : [];

            // Delete current audits
            $audits = \RouteAudit::where('route_id', $id)
                                        ->where('is_archived', 0)
                                        ->delete();
            // Save the audits
            $audits = [];
            foreach ($questions as $qid => $aid)
            {
                $audit = new \stdClass;
                $audit->is_archived = 0;
                $audit->answer_id = intval($aid);
                
                \RouteAudit::create([
                    'route_id' => $route->id,
                    'question_id' => $qid,
                    'answer_id' => $audit->answer_id,
                    'comment' => isset($question_comments[$qid]) ? $question_comments[$qid] : '',
                    'is_archived' => 0,
                ]);

                $audits[] = $audit;
            }

            // Calculate the score from new audits
            $route->score = self::calculateScore($route->id, $audits);
            $route->save();
        }
        elseif ($step == 'comments')
        {
            $route->comment = $data['comments'];
            $route->save();
        }

        // Send route update notification
        Emails::sendRouteCreateUpdate(\Routes::with('user', 'start_country', 'end_country', 'lsp')->find($route->id), 'updated');

        // Update the edit log
        /*\RouteLog::create([
            'route_id' => $route->id,
            'user_id' => \Auth::User()->id,
        ]);*/

        $routelogArray = ['route_id'=>$route->id,'user_id'=>\Auth::User()->id,'updated_at'=>date('Y-m-d h:i:s')];

        \RouteLog::insert($routelogArray);
    }

    /**
     * Get the current audit certifications 
     *
     * @param $id number
     * @return array
     */
    public static function getCurrentCertifications($id)
    {
        $data = new \stdClass;

        // Get all certifications as well as disabled groups
        $disabled_groups = \RouteCertificationDisabledGroup::where('route_id', $id)
                                                                ->get()
                                                                ->lists('certification_group_id');
        $certifications = \RouteCertification::where('route_id', $id)
                                                    ->get()
                                                    ->lists('certificate_file', 'certification_id');

        $tapa = array_intersect(array_keys($certifications), array_keys(Site::$TAPA_CERTIFICATIONS));
        $data->tapa = end($tapa) ?: 0;
        if ($data->tapa)
        {
            $data->tapa_certificate = $certifications[$data->tapa];
        }

        $data->ctpat = 0;
        $data->aeo = 0;

        $data->disabled_groups = $disabled_groups;
        
        if (!in_array(Site::C_TPAT_GROUP, $disabled_groups))
        {
            $ctpat = array_intersect(array_keys($certifications), array_keys(Site::$C_TPAT_CERTIFICATIONS));
            $data->ctpat = end($ctpat) ?: 0;
            if ($data->ctpat)
            {
                $data->ctpat_certificate = $certifications[$data->ctpat];
            }
        }
        else 
        {
            $data->ctpat = 'na';
        }

        if (!in_array(Site::AEO_GROUP, $disabled_groups))
        {
            $aeo = array_intersect(array_keys($certifications), array_keys(Site::$AEO_CERTIFICATIONS));
            $data->aeo = end($aeo) ?: 0;
            if ($data->aeo)
            {
                $data->aeo_certificate = $certifications[$data->aeo];
            }
        }
        else
        {
            $data->aeo = 'na';
        }

        return $data;
    }

    /**
     * Get the current audit certifications 
     *
     * @param $id number
     * @return array
     */
    public static function getQuestionsList($tapa_needed, $certificates_actual) {
        $disabled_certs = array();
        if ($certificates_actual['tapa'] == 'na') {
            $disabled_certs[] = Site::TAPA_TSR_1;
            $disabled_certs[] = Site::TAPA_TSR_2;
            $disabled_certs[] = Site::TAPA_TSR_3;
        }
        if ($certificates_actual['ctpat'] == 'na') {
            $disabled_certs[] = Site::C_TPAT;
        }
        if ($certificates_actual['aeo'] == 'na') {
            $disabled_certs[] = Site::AEO_S;
            $disabled_certs[] = Site::AEO_F;
            $disabled_certs[] = Site::AEO_C;
        }

        $certifications = array();
        if ($certificates_actual['tapa'] != 'na' && $certificates_actual['tapa'] != 0) {
            $certifications[] = $certificates_actual['tapa'];
        }
        if ($certificates_actual['ctpat'] != 'na' && $certificates_actual['ctpat'] != 0) {
            $certifications[] = $certificates_actual['ctpat'];
        }
        if ($certificates_actual['aeo'] != 'na' && $certificates_actual['aeo'] != 0) {
            $certifications[] = $certificates_actual['aeo'];
        }

        $question_list = \Question::with('certifications')
                                    ->whereIn('availability', [Site::AVAILABILITY_ROUTE, Site::AVAILABILITY_LOCATION_ROUTE])
                                    //->where('is_archived', 0)
                                    ->orderBy('order')
                                    ->get()
                                    ->all();

        $questions = array();
        $i = 0;

        foreach ($question_list as $question) {
            $question_certs = array();
            foreach ($question->certifications as $certification) {
                $question_certs[$certification->id] = $certification->name;
            }
            $questioncert_ids = array_keys($question_certs);

            $tapa_certs = array_keys(Site::$TAPA_CERTIFICATIONS);
            $c_tpat_certs = array_keys(Site::$C_TPAT_CERTIFICATIONS);
            $aeo_certs = array_keys(Site::$AEO_CERTIFICATIONS);

            // Find the question certificate category
            $is_tapa = array_intersect($tapa_certs, $questioncert_ids);
            $is_c_tpat = array_intersect($c_tpat_certs, $questioncert_ids);
            $is_aeo = array_intersect($aeo_certs, $questioncert_ids);

            $category = 0;
            if (! empty($is_tapa)) {
                $category = 'tapa';
            }
            if (! empty($is_c_tpat)) {
                $category = 'c_tpat';
            }
            if (! empty($is_aeo)) {
                $category = 'aeo';
            }

            // Set the question and its certifications
            $questions[$category][$i]['id'] = $question->id;
            $questions[$category][$i]['text'] = $question->text;
            $questions[$category][$i]['is_mandatory'] = $question->is_mandatory;
            $questions[$category][$i]['certifications'] = implode(', ', $question_certs);
            $questions[$category][$i]['display'] = 0;

            if ($category == 'c_tpat' && $certificates_actual['ctpat'] == '0') {
                $questions[$category][$i]['display'] = 1;
            }
            elseif ($category == 'aeo' && $certificates_actual['aeo'] == '0') {
                $questions[$category][$i]['display'] = 1;
            }
            elseif (self::questionToDisplay($tapa_needed, $certifications, $questioncert_ids, $disabled_certs, $question->is_mandatory)) {
                $questions[$category][$i]['display'] = 1;
            }

            $i++;
        }

        return $questions;        
    }

    public static function questionToDisplay($tapa_needed, $certifications, $questioncert_ids, $disabled_certs, $is_mandatory) {

        // list of scenarios in which the question should not display
        $dummy_session_certs = $certifications;
        if ($tapa_needed == Site::TAPA_TSR_1) { // On TAPA TSR 1 selection on first screen
            if (in_array(Site::TAPA_TSR_1, $certifications)) { // if TAPA TSR 1 is selected then no question mappad to TAPA TSR 1, TAPA TSR 2 and TAPA TSR 3 should be displayed
                array_push($dummy_session_certs, Site::TAPA_TSR_2, Site::TAPA_TSR_3);
            }
        }
        if ($tapa_needed == Site::TAPA_TSR_2) { // On TAPA TSR 2 selection on first screen
            if (in_array(Site::TAPA_TSR_1, $certifications)) { // if TAPA TSR 1 is selected then no question mappad to TAPA TSR 1, TAPA TSR 2 and TAPA TSR 3 should be displayed
                array_push($dummy_session_certs, Site::TAPA_TSR_2, Site::TAPA_TSR_3);
            }
            if (in_array(Site::TAPA_TSR_2, $certifications)) { // if TAPA TSR 2 is selected then no question mappad to TAPA TSR 1, TAPA TSR 2 and TAPA TSR 3 should be displayed
                array_push($dummy_session_certs, Site::TAPA_TSR_1, Site::TAPA_TSR_3);
            }
        }
        if ($tapa_needed == Site::TAPA_TSR_3) { // On TAPA TSR 3 selection on first screen
            if (in_array(Site::TAPA_TSR_1, $certifications)) { // if TAPA TSR 1 is selected then no question mappad to TAPA TSR 1, TAPA TSR 2 and TAPA TSR 3 should be displayed
                array_push($dummy_session_certs, Site::TAPA_TSR_2, Site::TAPA_TSR_3);
            }
            if (in_array(Site::TAPA_TSR_2, $certifications)) { // if TAPA TSR 2 is selected then no question mappad to TAPA TSR 1, TAPA TSR 2 and TAPA TSR 3 should be displayed
                array_push($dummy_session_certs, Site::TAPA_TSR_1, Site::TAPA_TSR_3);
            }
            if (in_array(Site::TAPA_TSR_3, $certifications)) { // if TAPA TSR 3 is selected then no question mappad to TAPA TSR 1, TAPA TSR 2 and TAPA TSR 3 should be displayed
                array_push($dummy_session_certs, Site::TAPA_TSR_1, Site::TAPA_TSR_2);
            }
        }

        $result = self::questionToDisplayForRoute($tapa_needed, $certifications, $questioncert_ids, $dummy_session_certs, $disabled_certs, $is_mandatory);
        return $result;
    }    
    
    public static function questionToDisplayForRoute($tapa_needed, $certifications, $questioncert_ids, $session_cert, $disabled_certs, $is_mandatory) {

        if (in_array(Site::TAPA_TSR_1, $questioncert_ids) 
            || in_array(Site::TAPA_TSR_2, $questioncert_ids) 
            || in_array(Site::TAPA_TSR_3, $questioncert_ids)) {

            // TAPA TSR 1 is selected in the first screen
            if ($tapa_needed == Site::TAPA_TSR_1) {
                // If TAPA TSR 1 is selected in step 2; then do not show questions belongs to certificates specified
                if (in_array(Site::TAPA_TSR_1, $certifications)) {
                    foreach($questioncert_ids as $id) {
                        if(in_array($id, $session_cert)) {
                            return false;
                        }
                    }
                }
                // If TAPA TSR 2 is selected in step 2; then dont show questions belongs to TAPA TSR 2 & TAPA TSR 3
                elseif (in_array(Site::TAPA_TSR_2, $certifications)) {
                    if (in_array(Site::TAPA_TSR_2, $questioncert_ids) || in_array(Site::TAPA_TSR_3, $questioncert_ids)) {
                        return false;
                    }
                }
                // If TAPA TSR 3 is selected in step 2; then dont show questions belongs to TAPA TSR 3
                elseif (in_array(Site::TAPA_TSR_3, $certifications)) {
                    if (in_array(Site::TAPA_TSR_3, $questioncert_ids)) {
                        return false;
                    }
                    // dont show questions belongs only to TAPA TSR 2
                    elseif (count($questioncert_ids) == 1 && $questioncert_ids[0] == Site::TAPA_TSR_2) {
                        return false;
                    }
                }
                // If none of the above case
                else {
                    $check_flag = false;
                    foreach ($questioncert_ids as $id) {
                        if ($id == Site::TAPA_TSR_1) {
                            $check_flag = true;
                            break ;
                        }
                    }
                    if (!$check_flag) {
                        return false;
                    }
                }
            }
            // TAPA TSR 2 is selected in the first screen
            if ($tapa_needed == Site::TAPA_TSR_2) {
                if (in_array(Site::TAPA_TSR_1, $certifications) || in_array(Site::TAPA_TSR_2, $certifications)  || in_array(Site::TAPA_TSR_3, $certifications)) {
                    foreach ($questioncert_ids as $id) {
                        if (in_array($id, $session_cert)) {
                            return false;
                        }
                    }
                    if (in_array(Site::TAPA_TSR_3,$certifications) && !in_array(Site::TAPA_TSR_2,$questioncert_ids)) {
                        return false;
                    }
                }
                else {
                    $check_flag = false;
                    foreach ($questioncert_ids as $id) {
                        if ($id == Site::TAPA_TSR_2) {
                            $check_flag = true;
                            break ;
                        }
                    }
                    if (!$check_flag) {
                        return false;
                    }
                }
            }
            if ($tapa_needed == Site::TAPA_TSR_3) { // TAPA TSR 3 is selected in the first screen
                if (in_array(Site::TAPA_TSR_1, $certifications) || in_array(Site::TAPA_TSR_2, $certifications) ||  in_array(Site::TAPA_TSR_3, $certifications)) {
                    foreach ($questioncert_ids as $id) {
                        if (in_array($id, $session_cert)) {
                            return false;
                        }
                    }
                }
                else {
                    $check_flag = false;
                    foreach ($questioncert_ids as $id) {
                        if ($id == Site::TAPA_TSR_3) {
                            $check_flag = true;
                            break ;
                        }
                    }
                    if (!$check_flag) {
                        return false;
                    }
                }
            }            

        }
        else {
            foreach ($questioncert_ids as $id) {
                if (in_array($id, $session_cert) || in_array($id,$disabled_certs)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Calculate the score from the audits
     *
     * @param $route_id integer
     * @param $audits array
     * @return float
     */
    public static function calculateScore($route_id, $audits = null)
    {
        if (! $audits)
        {
            $audits = \RouteAudit::where('route_id', $route_id)->get()->all();
        }

        $score = $count = $final_score = 0;
        
        if ($audits)
        {
            foreach ($audits as $audit)
            {
                if($audit->answer_id == '1' || $audit->answer_id == '0')
                    $score += 100;
                if($audit->answer_id == '2')
                    $score += 50;
                if($audit->answer_id == '3')
                    $score += 0;
                if($audit->answer_id != '4')
                    $count++;
            }

            $final_score = $score / $count;
        }

        return $final_score;
    }
    
}