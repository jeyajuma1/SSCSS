<?php namespace MSLST\Helpers;

class Coordinate {

	/**
	 * The view of the codeword reminder e-mail.
	 *
	 * @var string
	 */
    private static $_sm_a = 6378137.0;

	/**
	 * The view of the codeword reminder e-mail.
	 *
	 * @var string
	 */
    private static $_sm_b = 6356752.314;

	/**
	 * The GPS UTM Scale factor value.
	 *
	 * @var string
	 */
    private static $_UTMScaleFactor = 0.9996;

    /**
     * Check if the given coordinate value is a valid.
     *
     * @param string $coordinates
     * @return boolean
     */
    public static function isValidGPS($coordinates)
    {
        // Split the cordinates in to multiple parameters
        $temp = explode(',', $coordinates);
        $value = self::trimLatLon($coordinates);
        
        if (count($temp) == 2) 
        {
        	// validating 42.374335,-71.116991
            if (preg_match("/^[+-]?\d+\.\d+,[+-]?\d+\.\d+$/", $value)) 
            {
                return true;
            }
            // validating N30 17.477,W97 44.315 & N 30 17.477,W 97 44.315 
            elseif (preg_match("/^(N|S)\s?\d{1,3}+\s{1}+\d{1,3}+\.\d+,(E|W)\s?\d{1,3}+\s{1}+\d{1,3}+\.\d+$/", $value)) 
            {
                return true;
            }
            // validating N37 23 30, W122 02 37 & N 37 23 30, W 122 02 37 
            elseif (preg_match("/^(N|S)\s?\d{1,3}+\s{1}+[0-5][0-9]?+\s{1}+[0-5][0-9]?+(\.\d{1,2})?,(E|W)\s?\d{1,3}+\s{1}+[0-5][0-9]?+\s{1}+[0-5][0-9]?+(\.\d{1,2})?$/", $value)) 
            {
                return true;
            }
        }
        // validating 10N 584646 4138781
        elseif (preg_match("/^(60|[1-9]|[1-5][0-9])(N|S)+\s{1}+\d{5,7}+\s{1}+\d{5,7}$/", $value)) 
        {
            $geoposition = explode(" ", $value);
            
            if (count($geoposition) == 3) 
            {
                return true;
            } 
            else 
            {
                return false;
            }
        } 
        else 
        {
            return false;
        }
    }

    /**
     * Convert the coordinate formate for WGS84
     *
     * @param  type   $coordinates
     * @return string
     */
    public static function convertToWGS84($coordinates)
    {
        $value = self::trimLatLon($coordinates);
        
        if (preg_match("/^[+-]?\d+\.\d+,[+-]?\d+\.\d+$/", $value)) 
        {
            return $value;
        } 
        elseif (preg_match("/^(N|S)\s?\d{1,3}+\s{1}+\d{1,3}+\.\d+,(E|W)\s?\d{1,3}+\s{1}+\d{1,3}+\.\d+$/", $value)) 
        {
            $latlon = explode(',', $value);
            $lat = $latlon[0];
            $lon = $latlon[1];
            $lat_hemi = substr($lat, 0, 1);
            $lon_hemi = substr($lon, 0, 1);
            $lat_deg = trim(substr($lat, 1, strrpos($lat, ' ')));
            $lon_deg = trim(substr($lon, 1, strrpos($lon, ' ')));
            $lat_min = self::convertMinToDegrees(trim(substr($lat, strrpos($lat, ' '))));
            $lon_min = self::convertMinToDegrees(trim(substr($lon, strrpos($lon, ' '))));
            
            if ($lat_hemi == "N") 
            {
                $latitude = $lat_deg + $lat_min;
            } 
            else 
            {
                $_latitude = $lat_deg + $lat_min;
                $latitude = "-" . $_latitude;
            }
            if ($lon_hemi == "E") 
            {
                $longitude = $lon_deg + $lon_min;
            } 
            else 
            {
                $_longitude = $lon_deg + $lon_min;
                $longitude = "-" . $_longitude;
            }

            return $latitude . "," . $longitude;
        }
        elseif (preg_match("/^(N|S)\s?\d{1,3}+\s{1}+[0-5][0-9]?+\s{1}+[0-5][0-9]?+(\.\d{1,2})?,(E|W)\s?\d{1,3}+\s{1}+[0-5][0-9]?+\s{1}+[0-5][0-9]?+(\.\d{1,2})?$/", $value)) 
        {
            $latlon = explode(',', $value);
            $lat = $latlon[0];
            $lon = $latlon[1];
            $lat_hemi = substr($lat, 0, 1);
            $lon_hemi = substr($lon, 0, 1);
            $lat_deg_min = trim(substr($lat, 1, strrpos($lat, ' ')));
            $lon_deg_min = trim(substr($lon, 1, strrpos($lon, ' ')));
            $lat_deg = substr($lat_deg_min, 0, strrpos($lat_deg_min, ' '));
            $lon_deg = substr($lon_deg_min, 0, strrpos($lon_deg_min, ' '));
            $lat_min = self::convertMinToDegrees(trim(substr($lat_deg_min, strrpos($lat_deg_min, ' '))));
            $lon_min = self::convertMinToDegrees(trim(substr($lon_deg_min, strrpos($lon_deg_min, ' '))));
            $lat_sec = self::convertSecToDegrees(trim(substr($lat, strrpos($lat, ' '))));
            $lon_sec = self::convertSecToDegrees(trim(substr($lon, strrpos($lon, ' '))));
            
            if ($lat_hemi == "N") 
            {
                $latitude = $lat_deg + $lat_min + $lat_sec;
            } 
            else 
            {
                $_latitude = $lat_deg + $lat_min + $lat_sec;
                $latitude = "-" . $_latitude;
            }
            
            if ($lon_hemi == "E") 
            {
                $longitude = $lon_deg + $lon_min + $lon_sec;
            } 
            else 
            {
                $_longitude = $lon_deg + $lon_min + $lon_sec;
                $longitude = "-" . $_longitude;
            }

            return $latitude . "," . $longitude;
        } 
        elseif (preg_match("/^(60|[1-9]|[1-5][0-9])(N|S)+\s{1}+\d{5,7}+\s{1}+\d{5,7}$/", $value)) 
        {
            $geoposition = explode(" ", $value);
            
            if (count($geoposition) == 3) 
            {
                $zone = substr($geoposition[0], 0, strlen($geoposition[0]) - 1);
                $hemi = substr($geoposition[0], strlen($geoposition[0]) - 1, strlen($geoposition[0]));
                $southhemi = false;
                
                if ($hemi == 'S') 
                {
                    $southhemi = true;
                }
                
                $x = trim($geoposition[1]);
                $y = trim($geoposition[2]);
                $latlon = self::UTMXYToLatLon($x, $y, $zone, $southhemi);
                $longitude = number_format(rad2deg($latlon[1]), 6);
                $latitude = number_format(rad2deg($latlon[0]), 6);

                return $latitude . "," . $longitude;
            } 
            else 
            {
                return $value;
            }
        } 
        else 
        {
            return $value;
        }
    }

    /**
     * Trim spaces from latitude and longitude values.
     *
     * @param string $coordinates
     * @return string
     */
    public static function trimLatLon($coordinates)
    {
        $value = trim($coordinates);
        $check = strpos($value, ',');
        
        if ($check) 
        {
            $latlon = explode(',', $value);
            $lat = trim($latlon[0]);
            $lon = trim($latlon[1]);

            return $lat . "," . $lon;
        }
        else 
        {
            return $value;
        }
    }

    /**
     * Convert min to degrees.
     *
     * @param float $min
     * @return float
     */
    private static function convertMinToDegrees($min)
    {
        $deg = number_format($min / 60, 6);

        return $deg;
    }

    /**
     * Convert sec to degrees.
     *
     * @param float $min
     * @return float
     */
    private static function convertSecToDegrees($min)
    {
        $deg = number_format($min / 3600, 6);

        return $deg;
    }

    /**
     * Convert UTM x, y values to latitude and longitude values.
     *
     * @param float $x
     * @param float $y
     * @param float $zone
     * @param boolean $southhemi
     * @return array
     */
    private static function UTMXYToLatLon($x, $y, $zone, $southhemi)
    {
        $_UTMScaleFactor = 0.9996;
        $x -= 500000.0;
        $x /= $_UTMScaleFactor;
        
        // If in southern hemisphere, adjust y accordingly.
        if ($southhemi) 
        {
            $y -= 10000000.0;
        }
        
        $y /= $_UTMScaleFactor;
        $cmeridian = self::UTMCentralMeridian($zone);
        $latlon = self::MapXYToLatLon($x, $y, $cmeridian);

        return $latlon;
    }

    /**
     * Calculate central meridian from the zone value.
     *
     * @param float $zone
     * @return float
     */
    private static function UTMCentralMeridian($zone)
    {
        $cmeridian = deg2rad(-183.0 + ($zone * 6.0));

        return $cmeridian;
    }

    /**
     * Map x, y values to latitude and longitude values.
     *
     * @param float $x
     * @param float $y
     * @param float $cmeridian
     * @return array
     */
    private static function MapXYToLatLon($x, $y, $cmeridian)
    {
        
        $_sm_a = 6378137.0;

        $_sm_b = 6356752.314;

        $latlon = array();
        
        // Get the value of phif, the footpoint latitude.
        $phif = self::FootPointLatitude($y);
        
        // Precalculate ep2
        $ep2 = (pow($_sm_a, 2.0) - pow($_sm_b, 2.0))
                / pow($_sm_b, 2.0);
        
        // Precalculate cos (phif)
        $cf = cos($phif);
        
        // Precalculate nuf2
        $nuf2 = $ep2 * pow($cf, 2.0);
        
        // Precalculate Nf and initialize Nfpow
        $Nf = pow($_sm_a, 2.0) / ($_sm_b * sqrt(1 + $nuf2));
        $Nfpow = $Nf;
        
        // Precalculate tf
        $tf = tan($phif);
        $tf2 = $tf * $tf;
        $tf4 = $tf2 * $tf2;
        
        // Precalculate fractional coefficients for x**n in the equations 
        // below to simplify the expressions for latitude and longitude.
        $x1frac = 1.0 / ($Nfpow * $cf);
        $Nfpow *= $Nf;   // now equals Nf**2)
        $x2frac = $tf / (2.0 * $Nfpow);
        $Nfpow *= $Nf;   // now equals Nf**3)
        $x3frac = 1.0 / (6.0 * $Nfpow * $cf);
        $Nfpow *= $Nf;   // now equals Nf**4)
        $x4frac = $tf / (24.0 * $Nfpow);
        $Nfpow *= $Nf;   // now equals Nf**5)
        $x5frac = 1.0 / (120.0 * $Nfpow * $cf);
        $Nfpow *= $Nf;   // now equals Nf**6)
        $x6frac = $tf / (720.0 * $Nfpow);
        $Nfpow *= $Nf;   // now equals Nf**7) /
        $x7frac = 1.0 / (5040.0 * $Nfpow * $cf);
        $Nfpow *= $Nf;   // now equals Nf**8)
        $x8frac = $tf / (40320.0 * $Nfpow);
        
        // Precalculate polynomial coefficients for x**n.  
        // -- x**1 does not have a polynomial coefficient.
        $x2poly = -1.0 - $nuf2;
        $x3poly = -1.0 - 2 * $tf2 - $nuf2;
        $x4poly = 5.0 + 3.0 * $tf2 + 6.0 * $nuf2 - 6.0 * $tf2 * $nuf2
                - 3.0 * ($nuf2 * $nuf2) - 9.0 * $tf2 * ($nuf2 * $nuf2);
        $x5poly = 5.0 + 28.0 * $tf2 + 24.0 * $tf4 + 6.0 * $nuf2 + 8.0 * $tf2 * $nuf2;
        $x6poly = -61.0 - 90.0 * $tf2 - 45.0 * $tf4 - 107.0 * $nuf2
                + 162.0 * $tf2 * $nuf2;
        $x7poly = -61.0 - 662.0 * $tf2 - 1320.0 * $tf4 - 720.0 * ($tf4 * $tf2);
        $x8poly = 1385.0 + 3633.0 * $tf2 + 4095.0 * $tf4 + 1575 * ($tf4 * $tf2);
        
        // Calculate latitude
        $latlon[0] = $phif + $x2frac * $x2poly * ($x * $x)
                + $x4frac * $x4poly * pow($x, 4.0)
                + $x6frac * $x6poly * pow($x, 6.0)
                + $x8frac * $x8poly * pow($x, 8.0);
        
        // Calculate longitude
        $latlon[1] = $cmeridian + $x1frac * $x
                + $x3frac * $x3poly * pow($x, 3.0)
                + $x5frac * $x5poly * pow($x, 5.0)
                + $x7frac * $x7poly * pow($x, 7.0);

        return $latlon;
    }

    /**
     * Calculate the footpoint latitude from the y value.
     *
     * @param float $y
     * @return float
     */
    private static function FootPointLatitude($y)
    {
        $_sm_a = 6378137.0;

        $_sm_b = 6356752.314;

        // Precalculate n
        $n = ($_sm_a - $_sm_b) / ($_sm_a + $_sm_b);
        
        // Precalculate alpha
        $alpha = (($_sm_a + $_sm_b) / 2.0) * (1 + (pow($n, 2.0) / 4) + (pow($n, 4.0) / 64));
        
        // Precalculate y_
        $y_ = $y / $alpha;
        
        // Precalculate beta
        $beta = (3.0 * $n / 2.0) + (-27.0 * pow($n, 3.0) / 32.0) + (269.0 * pow($n, 5.0) / 512.0);
        
        // Precalculate gamma
        $gamma = (21.0 * pow($n, 2.0) / 16.0) + (-55.0 * pow($n, 4.0) / 32.0);
        
        // Precalculate delta
        $delta = (151.0 * pow($n, 3.0) / 96.0) + (-417.0 * pow($n, 5.0) / 128.0);
        
        // Precalculate epsilon
        $epsilon = (1097.0 * pow($n, 4.0) / 512.0);
        
        // Now calculate the sum of the series
        $result = $y_ + ($beta * sin(2.0 * $y_))
                + ($gamma * sin(4.0 * $y_))
                + ($delta * sin(6.0 * $y_))
                + ($epsilon * sin(8.0 * $y_));

        return $result;
    }

}