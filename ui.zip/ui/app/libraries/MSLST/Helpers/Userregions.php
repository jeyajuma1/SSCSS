<?php 
namespace MSLST\Helpers;

class UserRegions {
	

    /**
     * Generate the User Region list
     *
     * @return array
     */

    public static function getRegionsByUserId($UserId){


        $Userregions = \UserRegion::join('regions as r','user_regions.region_id','=','r.id')
        						  ->select('r.id','r.name')
        						  ->where('user_regions.user_id','=',$UserId)
        						  ->lists('name', 'id');
        						  


        return $Userregions;
    }
}

?>