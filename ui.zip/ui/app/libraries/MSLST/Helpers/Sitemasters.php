<?php
namespace MSLST\Helpers;


use Carbon\Carbon;
	class Sitemasters {
		public static $basic_information_fields = [
			'site_name', 'status', 'supplier_type','supplier_other_type' ,'region', 'country', 'city', 'country_state','postal_code', 'address', 'coordinates',
		];
			
		public static $site_information_fields = [
			'lob', 'lob_other_type','process','process_other_type','parent_site', 'primary_stakeholder', 'sec_stakeholder', 'channel_manager',   'last_inspection_date','c_tpat_svi_number' ,   'supplier_handle'
		];
		public static $contact_information_fields = [
			'contact_name', 'contact_email', 'other_contact_info',
		];
		public static $questions_fields = [
        'question'
    	];
    	public static $questions_answers_fields = [
       'self_answer_id','self_comment','onsite_answer_id','onsite_comment','supplier_id','question_id','ms_id','self_file_name','self_file_description','self_file_type','activity_id'
    	];

    	public static $inspection_answers_fields = [
       'answer_id','comment','sitemaster_id','question_id'
    	];

    	public static $CAselect = ['id','sitemaster_id','p_r_reference', 'p_r_version', 'p_r_text','inspector_comments', 'inspector_user_id', 'intial_due_date' ,'supplier_comments_evidence', 'supplier_user_id', 'due_date_extension','days_past_due', 'vam_approval', 'vam_user_id','vam_comments','supplier_request_closure','p_r_severity'];
    	
    	public static $InpectionMainSelect = ['id','ins_main_date','ins_main_num_sep_buliding_at_this_site','ins_main_num_buliding_ms_related_functions','ins_main_inspectors','ins_main_comments','ins_main_num_full_time_emp_facility','ins_main_supp_subcontract_handling_ms_product_ip','ins_main_emp_ms_system_account','ins_main_name_alias_access','summ_company_background','summ_overview_inspection_work','summ_facility_site_desc','summ_people_interview_during_inspec','sc_pr_req_excepted','sc_pr_req_required','sc_pr_req_accumulated','sc_pr_req_percent','sc_pr_score_excepted','sc_pr_score_required','sc_pr_score_accumulated','sc_pr_score_percent','sc_calulated_score','sc_scoring_rules_final_rating','user_id'];

 		public static $InspectionMain_fields = [  'ins_main_date',
											 	  'ins_main_num_sep_buliding_at_this_site',
											 	  'ins_main_num_buliding_ms_related_functions',
											      'ins_main_inspectors',
											      'ins_main_comments',
											      'ins_main_num_full_time_emp_facility',
											      'ins_main_supp_subcontract_handling_ms_product_ip',
											      'ins_main_emp_ms_system_account',
											      'inspection_num',
											      'ins_main_name_alias_access'];

		public static $InspectionQuestion_fields = [];

		public static $InspectionSummary_fields  = [ 
														'summ_company_background',
														'summ_overview_inspection_work',
														'summ_facility_site_desc',
														'summ_people_interview_during_inspec',

														'sc_pr_req_excepted',
														'sc_pr_req_required',
														'sc_pr_req_accumulated',
														'sc_pr_req_percent',
														'sc_pr_score_excepted',
														'sc_pr_score_required',
														'sc_pr_score_accumulated',
														'sc_pr_score_percent',
														'sc_calulated_score',
														'sc_scoring_rules_final_rating',
													];
    	public static $select_leak_incident_history = [
    			'site_leak_incident_histories.id',
    			'site_leak_incident_histories.sitemaster_id',
    			'site_leak_incident_histories.title',
    			'site_leak_incident_histories.incident_date',
    			'site_leak_incident_histories.incident_type',
    			'site_leak_incident_histories.root_cause',
    			'site_leak_incident_histories.corrective_action_title',
    			'site_leak_incident_histories.corrective_action_description',
    			'site_leak_incident_histories.supplier_contact',
    			'site_leak_incident_histories.deadline_date',
    			'site_leak_prevention_assessments.status',
    			'site_leak_prevention_assessments.created_at',
    			'site_leak_prevention_assessments.updated_at',
    			];

		public static function getSitemasterStepData($name) {
	
			$data = new \stdClass;
			$fields = [];
			$fields = self::${$name .'_fields'};

			if (\Session::has('sitemasters.'. $name))	{
			$data = (object) \Session::get('sitemasters.'. $name);
			}
			else{
				foreach ($fields as $field){
				$data->{$field} = '';
				}
			}


			return $data;
		}

		/**
		 *
		 *  Get pr Inspection Data
		 *
		 **/

		public static function getPRInspectionStepData($name){
			$data = new \stdClass;
			$fields = [];
			$fields = self::${$name.'_fields'};
	 
			if(\Session::has('pr_.'.$name)){
					$data = (object) \Session::get('pr_'.$name);
			}else{
				foreach ($fields as $field) {
					$data->{$field} = '';
				}
			}

			return $data;
		}

		public static function setPRInspectionStepData($name, $step_data) {
			$data = new \stdClass;
			if($name!='InspectionQuestion')
			{	/*Calculating Inspection Questions Score*/
				if($name=='InspectionSummary')
				{	
					$sitemaster_data = \Session::get('sitemasters_inspection');
					$question_data = (array) $sitemaster_data['InspectionQuestion'];
					
					$step_data['sc_pr_req_excepted'] = count($question_data['ques_severity']);

					$sc_pr_req_data = array_count_values(array_filter($question_data['ques_response']));
					$sc_pr_score_data=array_count_values(array_filter($question_data['ques_severity']));
					$step_data['sc_pr_score_excepted'] = ($sc_pr_score_data['URGENT']*10)+($sc_pr_score_data['High']*5)+($sc_pr_score_data['Medium']*2)+($sc_pr_score_data['Low']*1);
						
					if(count($sc_pr_req_data))
					{
						$step_data['sc_pr_req_required']=array_sum($sc_pr_req_data);
						$step_data['sc_pr_req_accumulated']=isset($sc_pr_req_data['1'])?$sc_pr_req_data['1']:0;
						$step_data['sc_pr_req_percent']=round((($step_data['sc_pr_req_accumulated']/$step_data['sc_pr_req_required'])*100),2);
							//print "<pre>";print_r($sc_pr_req_data);exit;
						$sc_pr_score_required=0;$sc_pr_score_accumulated=0;
						
						foreach ((array_filter($question_data['ques_response'])) as $q_id => $res_value) {
							
							if($res_value==1)
							{	
								if($question_data['ques_severity'][$q_id]=='URGENT')
									$sc_pr_score_accumulated +=10;
								if($question_data['ques_severity'][$q_id]=='High')
									$sc_pr_score_accumulated +=5;
								if($question_data['ques_severity'][$q_id]=='Medium')
									$sc_pr_score_accumulated +=2;
								if($question_data['ques_severity'][$q_id]=='Low')
									$sc_pr_score_accumulated +=1;
							}
							if($res_value>0)
							{
								if($question_data['ques_severity'][$q_id]=='URGENT')
									$sc_pr_score_required +=10;
								if($question_data['ques_severity'][$q_id]=='High')
									$sc_pr_score_required +=5;
								if($question_data['ques_severity'][$q_id]=='Medium')
									$sc_pr_score_required +=2;
								if($question_data['ques_severity'][$q_id]=='Low')
									$sc_pr_score_required +=1;
							}

						}
						$step_data['sc_pr_score_required'] = $sc_pr_score_required;
						$step_data['sc_pr_score_accumulated'] = $sc_pr_score_accumulated;
						$step_data['sc_pr_score_percent'] =round((($sc_pr_score_accumulated/$sc_pr_score_required)*100),2);
						$step_data['sc_calulated_score'] = round((($step_data['sc_pr_score_percent']+$step_data['sc_pr_req_percent'])/2),2);

						if($step_data['sc_calulated_score']<60)
							$step_data['sc_scoring_rules_final_rating'] ='Eminent Risk';
						if($step_data['sc_calulated_score']>=60 && $step_data['sc_calulated_score']<75)
							$step_data['sc_scoring_rules_final_rating'] ='High Risk';
						if($step_data['sc_calulated_score']>=75 && $step_data['sc_calulated_score']<90)
							$step_data['sc_scoring_rules_final_rating'] ='Medium Risk';
						if($step_data['sc_calulated_score']>90)
							$step_data['sc_scoring_rules_final_rating'] ='Low Risk';

						/*To get similar data like offline inspection*/
						$step_data['sc_pr_req_percent']=$step_data['sc_pr_req_percent']/100;
						$step_data['sc_pr_score_percent']=$step_data['sc_pr_score_percent']/100;
						$step_data['sc_calulated_score']=$step_data['sc_calulated_score']/100;
					}
				}

				$fields = self::${$name .'_fields'};
				foreach ($fields as $field)  {
					$data->{$field} = $step_data[$field];       
				}

				if(isset($data->ins_main_name_alias_access) && !empty($data->ins_main_name_alias_access))
					$data->ins_main_name_alias_access = array_values($data->ins_main_name_alias_access);

				if(isset($data->ins_main_inspectors) && !empty($data->ins_main_inspectors))
					$data->ins_main_inspectors = array_values($data->ins_main_inspectors);

				if(isset($data->summ_people_interview_during_inspec) && !empty($data->summ_people_interview_during_inspec))
					$data->summ_people_interview_during_inspec = array_values($data->summ_people_interview_during_inspec);
				
				//print "<pre>";print_r($data);exit;
				\Session::set('sitemasters_inspection.'. $name, $data);
			}
			else
			{	//print "<pre>";print count($step_data['ques_severity']);exit;
				$sitemaster_data = \Session::get('sitemasters_inspection');
				$inspection_main_data = (array) $sitemaster_data['InspectionMain'];
				$step_data['inspection_num']=$inspection_main_data['inspection_num'];
				\Session::set('sitemasters_inspection.'. $name, $step_data);
			}	
			
		}

		public static function setSitemasterStepData($name, $step_data) {
			$data = new \stdClass;
			$fields = self::${$name .'_fields'};
				foreach ($fields as $field)  {
					$data->{$field} = $step_data[$field];       
				}
			\Session::set('sitemasters.'. $name, $data);
		}

		public static function getSitemasterEditData($id, $name)  {
			$data = new \stdClass;
			$sitemaster = \Sitemaster::find($id);
			$data->id = $id;
			$fields =self::${$name .'_fields'};		
			foreach ($fields as $field)
			{
				if (isset($sitemaster->{$field}))
				{
					$data->{$field} = $sitemaster->{$field};
				}
			}
    
			// There is no region_id field, it is region
			$data->region = $sitemaster->region->id;

			// There is no country_id field, it is country
			$data->country = $sitemaster->country->id;
		 return $data;			
		}

		public static function getSitemasterInspectionEditData($id,$inspection_num,$name)  {
			$data = new \stdClass;
			$sitemaster = \SiteInspectionsAnswer::where(['id'=>$inspection_num,'sitemaster_id'=>$id])->get();
			$data->id = $id;
			$data->inspection_num = $inspection_num;
			$inp_ques_ans = \SiteInspectionsQuestionAnswer::where(['inspection_id'=>$inspection_num,'sitemaster_id'=>$id])->get()->toArray();
			//print "<pre>";print_r($sitemaster[1]);exit;
			foreach ($inp_ques_ans as $key => $value) {
				$sitemaster_ans[$value['ques_reference']] = $value;
			}

			$fields =self::${$name .'_fields'};		
			foreach ($fields as $field)
			{	
				if (isset($sitemaster[0]->{$field}))
				{
					$data->{$field} = $sitemaster[0]->{$field};
				}
			}
			if($name=='InspectionQuestion')
			{	
				$data->question_data=$sitemaster_ans;
			}
			if(isset($data->ins_main_date))
			{
				$data->ins_main_date = $data->ins_main_date->format('Y-m-d');
			}
				//print "<pre>";print_r($data);exit;
					
		 return $data;			
		}

		/**
		 * Save the sitemaster edit data
		 *
		 * @param $id number
		 * @param $step string
		 * @param $data array
		*/
		public static function setSitemasterEditData($id, $step, $data)  {
			$sitemaster = \Sitemaster::findOrFail($id);
			
			if ($step == 'basic_information')
			{
				$sitemaster->site_name = $data['site_name'];
				$sitemaster->status = $data['status'];
				$sitemaster->supplier_type = json_encode($data['supplier_type']);
				$sitemaster->supplier_other_type = $data['supplier_other_type'];
				$sitemaster->address = $data['address'];
				$sitemaster->country_id = $data['country'];
				$sitemaster->region_id = $data['region'];
				$sitemaster->city = $data['city'];
				$sitemaster->postal_code = $data['postal_code'];
				$sitemaster->coordinates = $data['coordinates'];
				$sitemaster->country_state = $data['country_state'];
				$sitemaster->save();
			}
			elseif ($step == 'site_information')
			{	$sitemaster->lob = (isset($data['lob']))?json_encode($data['lob']):'';
				$sitemaster->process = (isset($data['process']))?json_encode($data['process']):'';
				$sitemaster->lob_other_type =   !empty($data['lob_other_type'])?$data['lob_other_type']:'';
				$sitemaster->process_other_type =   !empty($data['process_other_type'])?$data['process_other_type']:''; 
				$sitemaster->parent_site = $data['parent_site'];
				$sitemaster->primary_stakeholder = $data['primary_stakeholder'];
				$sitemaster->sec_stakeholder = $data['sec_stakeholder'];
				$sitemaster->channel_manager = $data['channel_manager'];
				//$sitemaster->vam = $data['vam'];
				$sitemaster->last_inspection_date = !empty($data['last_inspection_date'])?$data['last_inspection_date'] : NULL;
				$sitemaster->c_tpat_svi_number = $data['c_tpat_svi_number'];
				//$sitemaster->corrective_actions = $data['corrective_actions'];
				//$sitemaster->comments = $data['comments'];
				$sitemaster->supplier_handle = $data['supplier_handle'];
				//print "<pre>";print_r($sitemaster->process);exit;
				$sitemaster->save();
			}
			elseif ($step == 'contact_information') 
			{
				$sitemaster->contact_name = $data['contact_name'];
				$sitemaster->contact_email = $data['contact_email'];
				$sitemaster->other_contact_info = $data['other_contact_info'];
				$sitemaster->save();
			}
			// Send incident update notification
			//Emails::sendIncidentCreateUpdate($incident, 'updated');
			$sitemasterlogArray = ['sitemaster_id' => $sitemaster->id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SitemasterLog::insert($sitemasterlogArray);
		}

		public static function saveSitemasterData() {
			$sitemaster_data = \Session::get('sitemasters');
			// Get the data from each steps
			$basic_information = (array) $sitemaster_data['basic_information'];
			$site_information = (array) $sitemaster_data['site_information'];
			$contact_information = (array) $sitemaster_data['contact_information'];
			

			// First create the incident
			$sitemaster = \Sitemaster::create([
				'site_name'=> $basic_information['site_name'],
				'status'=> $basic_information['status'],
				'supplier_type'=>json_encode($basic_information['supplier_type']),
				'supplier_other_type'=>$basic_information['supplier_other_type'],
				'country_id'=> $basic_information['country'],
				'region_id'=> $basic_information['region'],
				'city'=> $basic_information['city'],
				'country_state'=> $basic_information['country_state'],
				'postal_code'=> $basic_information['postal_code'],
				'address'=> $basic_information['address'],
				'coordinates'=> $basic_information['coordinates'],
				'lob'=> json_encode($site_information['lob']),
				'process'=> json_encode($site_information['process']),
				'lob_other_type'=> !empty($site_information['lob_other_type'])?$site_information['lob_other_type']:'', 	
				'process_other_type'=> !empty($site_information['process_other_type'])?$site_information['process_other_type']:'',
				'parent_site'=> $site_information['parent_site'],
				'primary_stakeholder'=> $site_information['primary_stakeholder'],
				'sec_stakeholder'=> $site_information['sec_stakeholder'],
				'channel_manager'=> $site_information['channel_manager'],	
				//'vam'=> $site_information['vam'],	
				'last_inspection_date'=> !empty($site_information['last_inspection_date'])?$site_information['last_inspection_date'] : NULL,
				'c_tpat_svi_number'=> $site_information['c_tpat_svi_number'],
				//'corrective_actions'=> $site_information['corrective_actions'],	
				//'comments'=> $site_information['comments'],	
				'contact_name'=> $contact_information['contact_name'],
				'contact_email'=> $contact_information['contact_email'],
				'other_contact_info'=> $contact_information['other_contact_info'],
				'supplier_handle' => $site_information['supplier_handle'],
				'user_id' => \Auth::User()->id
			]);
			// Send incident create notification
			//Emails::sendIncidentCreateUpdate($supplier, 'created');
			\SitemasterLog::create([
	            'sitemaster_id' => $sitemaster->id,
	            'user_id' => \Auth::User()->id,
	            'created_at'=>  Carbon::parse('now')
	        ]);

			// Destroy the session data
			\Session::forget('sitemasters');
		}

		public static function setSitemasterInspectionEditData($id,$inspection_num,$step,$data)  {
			$sitemaster = \SiteInspectionsAnswer::findOrFail($inspection_num);
			if ($step == 'InspectionMain')
			{	//print "<pre>";print_r($sitemaster);print_r($data);exit;
				$sitemaster->ins_main_date = $data['ins_main_date'];
				$sitemaster->ins_main_num_sep_buliding_at_this_site = $data['ins_main_num_sep_buliding_at_this_site'];
				$sitemaster->ins_main_num_buliding_ms_related_functions = $data['ins_main_num_buliding_ms_related_functions'];
				$sitemaster->ins_main_inspectors =json_encode(array_values($data['ins_main_inspectors']));
				$sitemaster->ins_main_comments = $data['ins_main_comments'];
				$sitemaster->ins_main_num_full_time_emp_facility = $data['ins_main_num_full_time_emp_facility'];
				$sitemaster->ins_main_supp_subcontract_handling_ms_product_ip = $data['ins_main_supp_subcontract_handling_ms_product_ip'];
				$sitemaster->ins_main_name_alias_access = json_encode(array_values($data['ins_main_name_alias_access']));
				$sitemaster->ins_main_emp_ms_system_account = $data['ins_main_emp_ms_system_account'];
				$sitemaster->save();
			}
			elseif ($step == 'InspectionQuestion')
			{	

				/*For calculating score*/
				$question_data = $data;
					
					$step_data['sc_pr_req_excepted'] = count($question_data['ques_severity']);

					$sc_pr_req_data = array_count_values(array_filter($question_data['ques_response']));
					$sc_pr_score_data=array_count_values(array_filter($question_data['ques_severity']));
					$step_data['sc_pr_score_excepted'] = ($sc_pr_score_data['URGENT']*10)+($sc_pr_score_data['High']*5)+($sc_pr_score_data['Medium']*2)+($sc_pr_score_data['Low']*1);
						//
					if(count($sc_pr_req_data))
					{
						$step_data['sc_pr_req_required']=array_sum($sc_pr_req_data);
						$step_data['sc_pr_req_accumulated']=isset($sc_pr_req_data['1'])?$sc_pr_req_data['1']:0;
						$step_data['sc_pr_req_percent']=round((($step_data['sc_pr_req_accumulated']/$step_data['sc_pr_req_required'])*100),2);

						$sc_pr_score_required=0;$sc_pr_score_accumulated=0;
						
						foreach ((array_filter($question_data['ques_response'])) as $q_id => $res_value) {
							
							if($res_value==1)
							{	
								if($question_data['ques_severity'][$q_id]=='URGENT')
									$sc_pr_score_accumulated +=10;
								if($question_data['ques_severity'][$q_id]=='High')
									$sc_pr_score_accumulated +=5;
								if($question_data['ques_severity'][$q_id]=='Medium')
									$sc_pr_score_accumulated +=2;
								if($question_data['ques_severity'][$q_id]=='Low')
									$sc_pr_score_accumulated +=1;
							}
							if($res_value>0)
							{
								if($question_data['ques_severity'][$q_id]=='URGENT')
									$sc_pr_score_required +=10;
								if($question_data['ques_severity'][$q_id]=='High')
									$sc_pr_score_required +=5;
								if($question_data['ques_severity'][$q_id]=='Medium')
									$sc_pr_score_required +=2;
								if($question_data['ques_severity'][$q_id]=='Low')
									$sc_pr_score_required +=1;
							}

						}
						$step_data['sc_pr_score_required'] = $sc_pr_score_required;
						$step_data['sc_pr_score_accumulated'] = $sc_pr_score_accumulated;
						$step_data['sc_pr_score_percent'] =round((($sc_pr_score_accumulated/$sc_pr_score_required)*100),2);
						$step_data['sc_calulated_score'] = round((($step_data['sc_pr_score_percent']+$step_data['sc_pr_req_percent'])/2),2);

						if($step_data['sc_calulated_score']<60)
							$step_data['sc_scoring_rules_final_rating'] ='Eminent Risk';
						if($step_data['sc_calulated_score']>=60 && $step_data['sc_calulated_score']<75)
							$step_data['sc_scoring_rules_final_rating'] ='High Risk';
						if($step_data['sc_calulated_score']>=75 && $step_data['sc_calulated_score']<90)
							$step_data['sc_scoring_rules_final_rating'] ='Medium Risk';
						if($step_data['sc_calulated_score']>90)
							$step_data['sc_scoring_rules_final_rating'] ='Low Risk';

						/*To get similar data like offline inspection*/
						$step_data['sc_pr_req_percent']=$step_data['sc_pr_req_percent']/100;
						$step_data['sc_pr_score_percent']=$step_data['sc_pr_score_percent']/100;
						$step_data['sc_calulated_score']=$step_data['sc_calulated_score']/100;
					}
				$data +=$step_data;
				
				$sitemaster->sc_pr_req_excepted = $data['sc_pr_req_excepted'];
				$sitemaster->sc_pr_req_required = $data['sc_pr_req_required'];
				$sitemaster->sc_pr_req_accumulated = $data['sc_pr_req_accumulated'];
				$sitemaster->sc_pr_req_percent = $data['sc_pr_req_percent'];
				$sitemaster->sc_pr_score_excepted = $data['sc_pr_score_excepted'];
				$sitemaster->sc_pr_score_required = $data['sc_pr_score_required'];
				$sitemaster->sc_pr_score_accumulated = $data['sc_pr_score_accumulated'];
				$sitemaster->sc_pr_score_percent = $data['sc_pr_score_percent'];
				$sitemaster->sc_calulated_score = $data['sc_calulated_score'];
				$sitemaster->sc_scoring_rules_final_rating = $data['sc_scoring_rules_final_rating'];
				$sitemaster->save();

				$data['inspection_num']=$inspection_num;
				//print "<pre>";print_r($data);exit;
				$data_got = Self::setsiteinspection($id,$data);

			}
			elseif ($step == 'InspectionSummary') 
			{
				$sitemaster->summ_company_background = $data['summ_company_background'];
				$sitemaster->summ_overview_inspection_work = $data['summ_overview_inspection_work'];
				$sitemaster->summ_facility_site_desc = $data['summ_facility_site_desc'];
				$sitemaster->summ_people_interview_during_inspec = json_encode(array_values($data['summ_people_interview_during_inspec']));
				$sitemaster->save();
			}
			//print "<pre>";print_r(\DB::getQueryLog());exit;
			
			// Send incident update notification
			//Emails::sendIncidentCreateUpdate($incident, 'updated');
			$sitemasterlogArray = ['sitemaster_id' => $sitemaster->id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SitemasterLog::insert($sitemasterlogArray);
		}

		public static function saveInspectionData($id) 
		{
			$sitemaster_data = \Session::get('sitemasters_inspection');
			//print "<pre>";print_r($sitemaster_data);exit;
			// Get the data from each steps
			$inspection_main = (array) $sitemaster_data['InspectionMain'];
			$inspection_question = (array) $sitemaster_data['InspectionQuestion'];
			$inspection_summary = (array) $sitemaster_data['InspectionSummary'];
			
			$inspection_id = \SiteInspectionsAnswer::create([

					'ins_main_date'=>$inspection_main['ins_main_date'],
					'ins_main_num_sep_buliding_at_this_site'=>$inspection_main['ins_main_num_sep_buliding_at_this_site'],
					'ins_main_num_buliding_ms_related_functions'=>$inspection_main['ins_main_num_buliding_ms_related_functions'],
					'ins_main_inspectors'=>($inspection_main['ins_main_inspectors'])?json_encode($inspection_main['ins_main_inspectors']):null,
					'ins_main_comments'=>$inspection_main['ins_main_comments'],
					'ins_main_num_full_time_emp_facility'=>$inspection_main['ins_main_num_full_time_emp_facility'],
					'ins_main_supp_subcontract_handling_ms_product_ip'=>$inspection_main['ins_main_supp_subcontract_handling_ms_product_ip'],
					'ins_main_name_alias_access'=>($inspection_main['ins_main_name_alias_access'])?json_encode($inspection_main['ins_main_name_alias_access']):null,
					'ins_main_emp_ms_system_account'=>$inspection_main['ins_main_emp_ms_system_account'],

					'summ_company_background'=>$inspection_summary['summ_company_background'],
					'summ_overview_inspection_work'=>$inspection_summary['summ_overview_inspection_work'],
					'summ_facility_site_desc'=>$inspection_summary['summ_facility_site_desc'],
					'summ_people_interview_during_inspec'=>($inspection_summary['summ_people_interview_during_inspec'])?json_encode($inspection_summary['summ_people_interview_during_inspec']):null,

					'sc_pr_req_excepted'=>$inspection_summary['sc_pr_req_excepted'],
					'sc_pr_req_required'=>$inspection_summary['sc_pr_req_required'],
					'sc_pr_req_accumulated'=>$inspection_summary['sc_pr_req_accumulated'],
					'sc_pr_req_percent'=>$inspection_summary['sc_pr_req_percent'],
					'sc_pr_score_excepted'=>$inspection_summary['sc_pr_score_excepted'],
					'sc_pr_score_required'=>$inspection_summary['sc_pr_score_required'],
					'sc_pr_score_accumulated'=>$inspection_summary['sc_pr_score_accumulated'],
					'sc_pr_score_percent'=>$inspection_summary['sc_pr_score_percent'],
					'sc_calulated_score'=>$inspection_summary['sc_calulated_score'],
					'sc_scoring_rules_final_rating'=>$inspection_summary['sc_scoring_rules_final_rating'],
					'user_id'=> \Auth::User()->id,
					'sitemaster_id'=>$id
					]);
					//print "<pre>"; print $inspection_id;exit;
					$inspection_question['inspection_num']=$inspection_id->id;
					//print "<pre>";print($inspection_question);
					$data_got = Self::setsiteinspection($id,$inspection_question);
					 //print "<pre>";print_r(\DB::getQueryLog());exit;

			// Destroy the session data
			\Session::forget('sitemasters_inspection');
			return $inspection_id->id;
		}
		
	/**
     * Get all sitemasters by filters
     *
     * @param $filters array
     * @return array
     */
    public static function getFilteredSitemasters($filters)
    {		 
		$sitemasters = \Sitemaster::with('user', 'country', 'region','pr_inspection_main','insepction_pr');

		/*if (isset($filters['daterange']) && !empty($filters['daterange']))
		{
			list($start, $end) = explode(' - ', $filters['daterange']);

			$start = new \DateTime($start);
			$end = new \DateTime($end);

			$sitemasters->where(\DB::raw("date_format(incident_date,'%Y-%m-%d')"), '>=', $start->format('Y-m-d'))
					  ->where(\DB::raw("date_format(incident_date,'%Y-%m-%d')"), '<=', $end->format('Y-m-d'));
		}*/

		if (isset($filters['user']) && !empty($filters['user']))
		{
			$sitemasters->whereIn('user_id', $filters['user']);
		}
		
		if (isset($filters['site_supplier_type']) && !empty($filters['site_supplier_type']))
		{
			 
			foreach ($filters['site_supplier_type'] as $key => $value) {
	    		if($key == 0)
	    		    $sitemasters->where('supplier_type','like','%"'.$value.'"%');
	    		else
	    		    $sitemasters->orwhere('supplier_type','like','%"'.$value.'"%');
	    	}
		}
		
		if (isset($filters['channel_manager']) && !empty($filters['channel_manager']))
		{
			$sitemasters->whereIn('channel_manager', $filters['channel_manager']);
		}
		/*if (isset($filters['customer']) && !empty($filters['customer']))
		{
			foreach ($filters['customer'] as $key=>$customer)
			{
				$filters['customer'][$key] = strtolower($customer);
            }
            $sitemasters->whereIn('customer' , $filters['customer']);

		}

		if (isset($filters['category']) && !empty($filters['category']))
		{
			$sitemasters->whereIn('category', $filters['category']);
		}*/

		if (isset($filters['status']) && !empty($filters['status']))
		{
			if (count($filters['status']) == 1)
			{
				if ($filters['status'][0] == 'inactive')
				{	$sitemasters->whereIn('status', $filters['status']);
					//$sitemasters->whereRaw('(closed_at is not null AND closed_at <> "0000-00-00 00:00:00")');
				}
				else
				{$sitemasters->whereIn('status', $filters['status']);
					//$sitemasters->whereRaw('(closed_at is null OR closed_at = "0000-00-00 00:00:00")');
				}
			}
		}

		if (isset($filters['daterange']) && !empty($filters['daterange']))  // last_inspection_date
		{
			list($start, $end) = explode(' - ', $filters['daterange']);

			$start = new \DateTime($start);
			$end = new \DateTime($end);

			$sitemasters->where(\DB::raw("FORMAT(last_inspection_date,'yyyy-MM-dd')"), '>=', $start->format('Y-m-d'))
					  ->where(\DB::raw("FORMAT(last_inspection_date,'yyyy-MM-dd')"), '<=', $end->format('Y-m-d'));
		}
 		

 		if (isset($filters['region']) && !empty($filters['region']))
		{
			$sitemasters->whereIn('region_id', $filters['region']);
		}

		if (isset($filters['country']) && !empty($filters['country']))
		{
			$sitemasters->whereIn('country_id', $filters['country']);
		}

		if (isset($filters['sitemaster_id']) && !empty($filters['sitemaster_id']))
		{
            $sitemaster_id = $filters['sitemaster_id'];

            $sitemasters->where('id', intval($sitemaster_id));
		}

        if (\Auth::User()->isUser())
        {
            $sitemasters->where(function ($q) {
                
				$q->where('sitemasters.user_id', \Auth::User()->id);
				
			});
        }

        if (\Auth::User()->isSupervisor() && !\Auth::User()->isManager())
        {
          /* $incidents->whereHas('user', function($q) {
                $q->where('lsp_id', '=', \Auth::User()->lsp->id);
            });*/

           $regionChk = \UserRegion::select('region_id')
                                   ->where('user_id',\Auth::User()->id)
                                   ->lists('region_id');

           $sitemasters->whereIn('region_id', $regionChk);

           /*$lspChk    = \User::select('id')
                             ->where('lsp_id',\Auth::User()->lsp->id)
                             ->lists('id');
           $sitemasters->whereIn('user_id', $lspChk);*/
           
        }

   		//$sitemasters->where('id',76);
         
		$sitemasters = $sitemasters
					->orderBy('created_at', 'DESC')
					->get()//->toArray();
			 		->all();

	 // print "<pre>"; print_r($sitemasters); exit;
					

		//dd(\DB::getQueryLog());

		return $sitemasters;
    }


     /**
     *
     *
     **/
    public static function SaveActionPlan($data,$option=null){
    	
    	$action = Lists::getBusinessAction('leak_risk_plan','SiteBusinessAction');


    	$leak_create = [];
    	$leak_create['sitemaster_id'] = $data['sitemaster_id'];

    	foreach($data['asset_id'] as $kar=>$kav){

	    	/*Get Risk Id*/
	    	$risk = \SiteBusinessRisk::select('id','name');
	    	foreach ($kav as $key => $value) {
	    		if($key == 0)
	    		    $risk->where('asset_ids','like','%"'.$value.'"%');
	    		else
	    		    $risk->orwhere('asset_ids','like','%"'.$value.'"%');
	    	}
	    	$risk = $risk->lists('name','id');

       
	    	if($option == 'exist'){
		    	/* Selecting Leak prevention id for existing */
		    	$select_preven_arry = \SiteLeakPreventionAssessment::select('risk_id')
		    							->where('sitemaster_id',$data['sitemaster_id'])
		    							->where('leak_id',$data['LeakRiskAnalysis_id'][$kar])
		    							->lists('risk_id');
		        /*Deleting unselected Leak prevention from existing*/
		        $delete_id = array_diff($select_preven_arry,array_flip($risk));
		        if(!empty($delete_id)){
			       \SiteLeakPreventionAssessment::where('sitemaster_id',$data['sitemaster_id'])
			    							->where('leak_id',$data['LeakRiskAnalysis_id'][$kar])
			    							->whereIn('risk_id',$delete_id)
			    							->delete();
			    }

		    	//$risk = array_flip(array_diff(array_flip($risk), $select_preven_arry)); // Removed after asking to delete duplicate action entries
		    }	

 
	    	/*Insert in Leak Prevention Plan*/
	     	if(!empty($risk)){ 
		    	
		     	foreach($risk as $kay=>$val){

			     	foreach ($action[$kay] as $key => $action_value) {
			     	
			     		$chk_cnt = \SiteLeakPreventionAssessment::where('action_name','like','%'.$action_value['action_name'].'%')->where('sitemaster_id',$data['sitemaster_id'])->count();
			    		
			     		if($chk_cnt == 0){

				     		switch($option){
				    			case 'new':
				    				$leak_create['risk'] = $val;
									$leak_create['risk_id']   = $kay;
									$leak_create['action_id']   = $action_value['action_id'];
									$leak_create['action_name']   = $action_value['action_name'];
									$leak_create['action_description']  = $action_value['action_description'];
									$leak_create['leak_id']   = $data['LeakRiskAnalysis_id'][$kar];
						    		$leak_create['status']  = 'Not Started';
						    		\SiteLeakPreventionAssessment::create($leak_create);
					    		break;
					    		case 'exist':
					    			$leak_update['risk'] = $val;
									$leak_update['risk_id']   = $kay;
									$leak_update['action_id']   = $action_value['action_id'];
									$leak_update['action_name']   = $action_value['action_name'];
									$leak_update['action_description']  = $action_value['action_description'];
									$leak_update['sitemaster_id']   = $data['sitemaster_id'];
									$leak_update['leak_id']   = $data['LeakRiskAnalysis_id'][$kar];
						    		$leak_update['status']  = 'Not Started';
	 
					    			\SiteLeakPreventionAssessment::create($leak_update);
					    		break;
				    	   }
				    	}

			     	}

		    		

		    	}
		    }

	    }
	    

    }
    /*
         * Storing Self-Assessment Data
         *
         */
		public static function setselfassessment($id,$data) {
			
			$activities=Lists::getActivitiesList('SiteBusinessActivity');
			$sitemasters = [];
			$activitykey=0; 
				
				if(isset($data[$activitykey.'question']))
				{	
					$questions = $data[$activitykey.'question'];
					$self_comments = isset($data[$activitykey.'selfcomment']) ? $data[$activitykey.'selfcomment'] : [];
					$assessment_data = Sitemasters::get_assessment_data($id,$activitykey);
					 

					// Delete current SA anseres
		            $self = \SiteBusinessAnswer::where(['sitemaster_id'=>$id,'activity_id'=>$activitykey])
		                                        ->forceDelete();
		            // Save the self-assessment ansewrs 
		            foreach ($questions as $qid => $aid)
			            {
			                $self = new \stdClass;
			                $self->self_answer_id = intval($aid);
			                
			                \SiteBusinessAnswer::create([
			                    'sitemaster_id' => $id,
			                    'question_id' => $qid,
			                    'self_answer_id' => $self->self_answer_id,
			                    'self_comment' => isset($self_comments[$qid]) ? $self_comments[$qid] :' ',
			                    'onsite_answer_id'=>isset($assessment_data->onsite_answer_id[$qid])?$assessment_data->onsite_answer_id[$qid]:' ',
			                    'onsite_comment' =>isset($assessment_data->onsite_comment[$qid]) ? $assessment_data->onsite_comment[$qid] :' ',
			                    'ms_id'=>isset($assessment_data->ms_id[$qid])?$assessment_data->ms_id[$qid]:'',
			                    'activity_id' =>$activitykey

			                ]);
			                 

			                $sitemasters[] = $self;
			            }
	        	}
        		
        		 

       		//Updating Supplier_log
			$logArray = ['sitemaster_id' => $id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SiteMasterLog::insert($logArray);
            
            // Calculate the SA score             
            $sitemaster_tb = \Sitemaster::findOrFail($id);
            $sitemaster_tb->self_assessment_score = self::calculateScore($id, $sitemasters,'self_assessment');
            $sitemaster_tb->save();

        }
	     /*
	     * Storing Onsite-Assessment Data
	     *
	     */
        public static function setonsiteassessment($id,$data,$ms_id) {
			$activities=Lists::getActivitiesList('SiteBusinessActivity');
			$sitemasters = [];
			$activitykey=0;
			$question_list =  Lists::getBusinessQuestiondetail(); /* For Use Corrective Actions */


				if(isset($data[$activitykey.'question']))
				{	
					$questions = $data[$activitykey.'question'];
					$onsite_comments = isset($data[$activitykey.'onsitecomment']) ? $data[$activitykey.'onsitecomment'] : [];
					$assessment_data = Sitemasters::get_assessment_data($id,$activitykey);

					/* For Get Existing Corrective Actions */
					$getexistingCA   = \SiteLpCorrectiveAction::select('question_id')
															 ->where('site_master_id',$id)
															 ->where('assement_user_id',\Auth::user()->id)
															 ->lists('question_id');
					$ca_exist = [];
					$ca_new	  = [];
					
					// Delete current OSA answers
		            $self = \SiteBusinessAnswer::where(['sitemaster_id'=>$id,'activity_id'=>$activitykey])
		                                        ->forceDelete();
	                foreach ($questions as $qid => $aid)
			        {
		                $self = new \stdClass;
		                $self->onsite_answer_id = intval($aid);
		                
		                \SiteBusinessAnswer::create([
		                	'sitemaster_id' => $id,
		                    'question_id' => $qid,
		                    'onsite_answer_id' => $self->onsite_answer_id,
		                    'onsite_comment' => isset($onsite_comments[$qid]) ? $onsite_comments[$qid] : '',
		                    'self_answer_id'=>isset($assessment_data->self_answer_id[$qid])?$assessment_data->self_answer_id[$qid]:0,
		                    'self_comment' =>isset($assessment_data->self_comment[$qid]) ? $assessment_data->self_comment[$qid] : '',
		                    'ms_id' => $ms_id,
		                    'self_file_name'=>isset($assessment_data->self_file_name[$qid]) ? $assessment_data->self_file_name[$qid] : '',
		                    'self_file_description'=>isset($assessment_data->self_file_description[$qid]) ? $assessment_data->self_file_description[$qid] : '',
		                    'self_file_type'=>isset($assessment_data->self_file_type[$qid]) ? $assessment_data->self_file_type[$qid] : '',
		                    'activity_id' =>$activitykey
		                   ]);

						    if($self->onsite_answer_id == 3){ /*Forming Array For Corrective Actions */
			                	if(in_array($qid, $getexistingCA)){
			                		$ca_exist[$qid] =  [
														'site_master_id' => $id,
														'question_id' => $qid,
														'requirement_text' => $question_list[$qid]['name'],
														'category' => $question_list[$qid]['category_id'],
														'severity' => $question_list[$qid]['severity_text'],
														'assessment_comments' => isset($onsite_comments[$qid]) ? $onsite_comments[$qid] :' ',
														'initial_due_date' => Carbon::parse(self::due_date_calculation($question_list[$qid]['severity_text'])),
														'assement_user_id' => \Auth::user()->id,
														'updated_at'	   => Carbon::now()
			                							];
			                	}else{
			                		$ca_new[$qid] = [
			                							'site_master_id' => $id,
														'question_id' => $qid,
														'requirement_text' => $question_list[$qid]['name'],
														'category' => $question_list[$qid]['category_id'],
														'severity' => $question_list[$qid]['severity_text'],
														'assessment_comments' => isset($onsite_comments[$qid]) ? $onsite_comments[$qid] :' ',
														'initial_due_date' => Carbon::parse(self::due_date_calculation($question_list[$qid]['severity_text'])),
														'assement_user_id' => \Auth::user()->id,
														'created_at'		=> Carbon::now()
			                						];
			                	}
			                	
			                }

	                	$sitemasters[] = $self;
	            	}
	        	} 

	        	// Update/New CA for Leak Prevention Assesment
	        	$site_ca['exist'] = $ca_exist;
        		$site_ca['exist']['ex_id'] = $getexistingCA;
        		$site_ca['new']   = $ca_new;
        		$site_ca['delete'] = array_diff($site_ca['exist']['ex_id'], array_keys($site_ca['exist']));

        		//print "<pre>"; print_r(array_keys($site_ca['exist'])); print_r($site_ca['exist']['ex_id']); print_r(array_diff($site_ca['exist']['ex_id'], array_keys($site_ca['exist']))); exit;			
        	    self::lpSaveActionPlan($site_ca);  /*Calling function For Updating LP Corrective Actions */   
	    	
        
            //Updating Supplier_log
			$logArray = ['sitemaster_id' => $id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SiteMasterLog::insert($logArray);
            // Calculate the OSA score 
            $sitemaster_tb = \Sitemaster::findOrFail($id);
            $sitemaster_tb->onsite_assessment_score = self::calculateScore($id, $sitemasters,'onsite_assessment');
            $sitemaster_tb->save();
        }
        public static function get_assessment_data($id,$activitykey)
		{
			
			$data = new \stdClass;
        	$sitemasters = \SiteBusinessAnswer::where(['sitemaster_id'=>$id,'activity_id'=>$activitykey])
	        							->get();
			$fields = self::$questions_answers_fields;
        	foreach ($sitemasters as $sitemaster) 
        	{	
        		$data->id = $id;
	        	foreach ($fields as $field)
		        {
		            $data->{$field}[$sitemaster->question_id] = $sitemaster->{$field};
		           
		        }
		    }
	    
			return $data;
		}

		public static function get_inspection_data($id,$inspection_num)
		{
			
			$data = new \stdClass;
        	/*$sitemasters = \SiteInspectionAnswer::select('id','question_id','answer_id','comment','sitemaster_id','user_id')
        										->where(['sitemaster_id'=>$id,'user_id'=>\Auth::User()->id,'inspection_num'=>$inspection_num])
	        									->get();*/

 			$sitemasters = \SiteInspectionsQuestionAnswer::where(['sitemaster_id'=>$id,'user_id'=>\Auth::User()->id,'inspection_id'=>$inspection_num])
	        									->get();

			$fields = self::$inspection_answers_fields;
        	foreach ($sitemasters as $sitemaster) 
        	{	
        		$data->id = $id;
	        	foreach ($fields as $field)
		        {
		            $data->{$field}[$sitemaster->question_id] = $sitemaster->{$field};
		           
		        }
		    }

			return $data;
		}
		/**
		 *  Carbon Date Extend
		 *
		 **/
		public static function calculateweekends($now,$ext_date){

 			$weekends =	$now->diffInDaysFiltered(function(\DateTime $date) {
   				return $date->isWeekend();
			}, $ext_date); 

			 return $weekends;
 		}

 		public static function setsiteinspection($id,$data,$type=Null) {
		 	
			$sitemasters = [];
			$corective_actions = [];
			
				if(isset($data['ques_response']))
				{	
					$questions = $data['ques_response'];
					//$comments = isset($data['comment']) ? $data['comment'] : [];
					$assessment_data = Sitemasters::get_inspection_data($id,$data['inspection_num']);
					
					// Delete current OSA answers
		            $self = \SiteInspectionsQuestionAnswer::where(['sitemaster_id'=>$id,'user_id'=>\Auth::User()->id,'inspection_id'=>$data['inspection_num']])
		                                        ->forceDelete();
	                foreach ($questions as $qid => $aid)
			        {	//print "<pre>";print_r(array_filter($data));exit;
		                $self = new \stdClass;
		                $self->answer_id = intval($aid);
		                
		           
						\SiteInspectionsQuestionAnswer::create([
							'ques_reference' =>  $data['ques_reference'][$qid],
							'ques_severity' =>  $data['ques_severity'][$qid],
							'ques_response' =>    $data['ques_response'][$qid],
							'ques_mitigating_control' =>  $data['ques_mitigating_control'][$qid],
							'ques_issue_detail_comments' =>   $data['ques_issue_detail_comments'][$qid],
							'ques_corrective_action' =>$data['ques_corrective_action'][$qid],
							'user_id' =>  \Auth::User()->id,
							'inspection_id' =>  $data['inspection_num'],
							'sitemaster_id' =>  $id
						]);
		               if($self->answer_id == 2){
		               		$due_date = 'now';
		               		$dat_now  = new \Carbon\Carbon('now');

		               		if($data['ques_severity'][$qid] == 'URGENT'){
		               			$dat_exten = new \Carbon\Carbon('9 days');
		               			$res_date = self::calculateweekends($dat_now,$dat_exten);
		               			$res_date = $res_date+7;
		               			$due_date  = $res_date.' days'; // Urgent
		               		}

		               		if($data['ques_severity'][$qid] == 'High'){
		               			$dat_exten = new \Carbon\Carbon('21 days');
		               			$res_date = self::calculateweekends($dat_now,$dat_exten);
		               			$res_date = $res_date+15;
		               			$due_date  = $res_date.' days'; // High
		               		}  
		               		if($data['ques_severity'][$qid] == 'Medium'){
		               			$dat_exten = new \Carbon\Carbon('40 days');
		               			$res_date = self::calculateweekends($dat_now,$dat_exten);
		               			$res_date = $res_date+30;
		               			$due_date  = $res_date.' days'; // medium
		               		}  
		               		if($data['ques_severity'][$qid] == 'Low') {
		               			$dat_exten = new \Carbon\Carbon('80 days');
		               			$res_date = self::calculateweekends($dat_now,$dat_exten);
		               			$res_date = $res_date+60;
		               			$due_date  = $res_date.' days'; // low
		               		} 


		               		$dt = Carbon::parse($due_date); // Check for weekends
		               		if($dt->dayOfWeek === Carbon::SATURDAY) {
		               			    $res_date = $res_date+2;
   									$due_date  = $res_date.' days';
							}else if($dt->dayOfWeek === Carbon::SUNDAY) {
									 $res_date = $res_date+1;
   									 $due_date  = $res_date.' days';
							}
							 
		               		$corective_actions[] = [
			               		'sitemaster_id' =>  $id
								,'p_r_reference' => $data['ques_reference'][$qid]
								,'p_r_version' => $data['version'][$qid]
								,'p_r_text'   =>  $data['p_rtext'][$qid]
								,'inspector_comments' => $data['ques_issue_detail_comments'][$qid]
								,'inspector_user_id' => \Auth::User()->id
								,'intial_due_date' => Carbon::parse($due_date)
								,'inspection_num'=>$data['inspection_num']
								,'p_r_severity' => $data['ques_severity'][$qid]
							];
		               }
					  $sitemasters[] = $self;
	            	}	
	            	//\SiteInspectionsQuestionAnswer::insert(array_values($ques_data));
	            	$corrective_actions_olddata=\SiteCorrectiveAction::where(['sitemaster_id'=>$id,'inspector_user_id'=>\Auth::User()->id,'inspection_num'=>$data['inspection_num']])->get();
	            	
	            	$full_array=self::correctiveactionsarray($corrective_actions_olddata,$corective_actions);
	            	//\SiteCorrectiveAction::insert($corective_actions);
	            	 
	            	if(!empty($full_array['insert'])){\SiteCorrectiveAction::insert($full_array['insert']);}
	            	if(!empty($full_array['update'])){
	            		foreach ($full_array['update'] as $key => $value) {
	            			\SiteCorrectiveAction::where(['sitemaster_id'=>$id,'inspector_user_id' => \Auth::User()->id,'p_r_reference'=>$key,'inspection_num'=>$data['inspection_num']])->update(['inspector_comments'=>$value['inspector_comments']]);
	            		}
	            	}
	            	if(!empty($full_array['delete'])){
	            		foreach ($full_array['delete'] as $key => $value) {
	            			\SiteCorrectiveAction::where(['sitemaster_id'=>$id,'inspector_user_id' => \Auth::User()->id,'p_r_reference'=>$key,'inspection_num'=>$data['inspection_num']])->delete();
	            		}
	            	}

	        	}    
	    	//Updating Supplier_log
			$logArray = ['sitemaster_id' => $id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now')];
			\SiteMasterLog::insert($logArray);

			$prlogArray = ['sitemaster_id' => $id,'user_id' => \Auth::User()->id,'updated_at'=> Carbon::parse('now'),'type'=>$type.' Inspection done'];
			\SitePrLog::insert($prlogArray);
		}
		 

		public static function calculateScore($sitemaster_id, $sitemasters = null,$data)
	    {
	        if (!$sitemasters)
	        {
	            $sitemasters = \SiteBusinessAnswer::where('sitemaster_id', $sitemaster_id)->get()->all();
	        }

	        $score = $count = $final_score = 0;
	        if($data=='self_assessment')
		    {    
		        if ($sitemasters)
		        {
		            foreach ($sitemasters as $sitemaster)
		            {
		                if($sitemaster->self_answer_id == '1')
		                    $score += 1;
		                if($sitemaster->self_answer_id == '2')
		                    $score += 0.5;
		                if($sitemaster->self_answer_id == '3')
		                    $score += 0;
		                if($sitemaster->self_answer_id != '4')
		                    $count++;
		            }
		        }
		    }
		    else
		    {
		    	if ($sitemasters)
		        {
		            foreach ($sitemasters as $sitemaster)
		            {
		                if($sitemaster->onsite_answer_id == '1')
		                    $score += 1;
		                if($sitemaster->onsite_answer_id == '2')
		                    $score += 0.5;
		                if($sitemaster->onsite_answer_id == '3')
		                    $score += 0;
		                if($sitemaster->onsite_answer_id != '4')
		                    $count++;
		            }
		        }
		    }
		    $final_score = ($score / $count)*100;
		        

	        return $final_score;
	    }


	    public static function inspectionExportXLS($id) {

	    	$questions=\Question::select('id','text')->where('availability',4)->get();
	    	\Excel::create('P&R Inspection', function($excel) use($questions){

			    $excel->sheet('Inspection', function($sheet) use($questions){
			    	$sheet->getColumnDimension('A')->setWidth(20);
        			$sheet->getColumnDimension('B')->setWidth(2000);
			        $sheet->fromArray($questions);
			        

			    });

			})->export('xls');

	    }

	     public static function correctiveactionsarray($corrective_actions_olddata,$corective_actions)
	    {	
	    	
	    	$new_data=[];$old_data=[];$deleted_array=[];$insert_array=[];$update_array=[];

	    	
	    	foreach ($corrective_actions_olddata as $value) {

	    		$old_data[$value['p_r_reference']]=$value;
	    		
	    	}
	    	
	    	foreach ($corective_actions as $value) {

    			$new_data[$value['p_r_reference']]=$value;
    		
    		}

	    	foreach ($old_data as $old_key => $old_value) {
	    		
	    		if(!array_key_exists($old_key, $new_data))
	    		{
	    			$deleted_array[$old_value['p_r_reference']]=$old_value;
	    		}
	    		
	    	}
	    	
	    	
	    	foreach ($new_data as $new_key => $new_value) 
	    	{
	    		if(array_key_exists($new_key, $old_data))
	    		{
	    			$update_array[$new_value['p_r_reference']]=$new_value;
	    		}
	    		else
	    		{
	    			$insert_array[$new_value['p_r_reference']]=$new_value;
	    		}
	    		
	    	}
	    	$full_array['insert']=$insert_array;$full_array['delete']=$deleted_array;$full_array['update']=$update_array;
	    	return $full_array;
	    }




	    /**
	     *  Site Corrective Action
	     *
	     * @return Object
	     **/
	    
	    public static function SiteCA($id,$filters,$inspec_id){
	    
	    
	    	$caobj = \SiteCorrectiveAction::with('user')
	    										->select(Sitemasters::$CAselect)->where('sitemaster_id',$id);
	    
	    		
	    
	    	if(!empty($filters)){
	    		$input_data = explode("_",$filters);
	    	}elseif(!empty($userid)){
	    		$input_data = explode("_",array_keys($userid)[0]);
	    	}
	    
	    	if(!empty($input_data)){
	    		$caobj->where('inspector_user_id',$input_data[0]);
	    		$caobj->where('inspection_num',$input_data[1]);
	    	}else{
	    		$caobj->where('inspection_num',$inspec_id);
	    	}
	    
	    	$results = $caobj->get();
	    
	    	return $results;
	    
	    }
	    
	    /**
	     *
	     *
	     *return $object
	     **/
	    public static function SiteInspectionMain($id,$filters){
	    
	    	$inspec_main = \SiteInspectionsAnswer::select(Sitemasters::$InpectionMainSelect)
	    	->where('sitemaster_id',$id)->orderBy('id', 'DESC');
	    
	   		if(!empty($filters)){
	    		$input_data = explode("_",$filters);
	    	}elseif(!empty($userid)){
	    		$input_data = explode("_",array_keys($userid)[0]);
	    	}
	    
	    	if(!empty($input_data)){
	    		$inspec_main->where('user_id',$input_data[0]);
	    		$inspec_main->where('id',$input_data[1]);
	    	}
	    
	    	$results = $inspec_main->get();
	    
	    	return $results;
	    
	    }

	   /**
	     *  List Insepector
	     *
	     * @return Object
	     **/

	    public static function ListInsepector($id){
	    	 $results = [];
	    	//$caobj = \SiteCorrectiveAction::with('user')->select(\DB::raw('distinct inspector_user_id'))->where('sitemaster_id',$id)
	    	 							   
  			$caobj = \SiteCorrectiveAction::with('user','siteinspectionsanswer')
  										  // ->select(\DB::raw('distinct inspector_user_id,concat(\'Inspection \',inspector_user_id) as s'))->where('sitemaster_id',$id)
	    	 							  //->lists('s','inspector_user_id');
  			 							   ->select(\DB::raw('inspector_user_id, inspection_num'))->where('sitemaster_id',$id)
  			 							   ->groupby('inspector_user_id','inspection_num')
  			 							   ->orderby('inspection_num')
  										   ->get();
			$i=1;

			
  			foreach ($caobj as $key => $value) {
  				 //$results[$value->user->id] = $value->user->first_name.' '.$value->user->last_name;
  				$results['select_insepection'][$value->user->id.'_'.$value->inspection_num] = 'Inspection '.$i."@".$value->siteinspectionsanswer->ins_main_date->format('M/d/Y');
  				$results['insepection'][$value->user->id] = $value->inspection_num;

  				$i++;
  			}
	   
	   		
  			return $results;    	

	    }
	    
	    
	    /**
	     * Input $id
	     * 
	     *  @return Associated User for given Sitemast ID 
	     */
	    public static function GetAssociatedUser($id){
	    	$result = \User::where('user_vam_site_id','like','%'.$id.'%')
	    					->select('id','first_name','last_name','email','site_user_level','user_vam_site_id','deleted_at')
	    					->get();
	    	$results = []; $optionvam='';$optionlsp='';
	    	
	    	foreach($result as $key =>$value){
	    		if($value['site_user_level'] == 'vam'){
	    			$results['vam_user'][$key]['id'] =  $value['id'];
	    			$results['vam_user'][$key]['first_name'] =  $value['first_name'];
	    			$optionvam.= "<option>". $value['first_name'].' '.$value['last_name']."</option>";
	    		}else{
	    			$results['lsp_user'][$key]['id'] =  $value['id'];
	    			$results['lsp_user'][$key]['first_name'] =  $value['first_name'];
	    			$optionlsp.= "<option>". $value['first_name'].' '.$value['last_name']."</option>";
	    		}
	    	}
	
	    	$option['optionvam'] = $optionvam;
	    	$option['optionlsp'] = $optionlsp;
	    		
	    	
	    	//print "<pre>"; 	    	dd(\DB::getQuerylog($result));
	    	return $option;
	    }
	    
	    
	    /**
	     * Input $id
	     *
	     *  @return Delete inspection
	     */
	    
	    public static function deleteInspection($id){
	    
	    	\SiteInspectionsAnswer::where('id',$id)->delete(); // Inspection Main Detail
	    
	    	\SiteCorrectiveAction::where('inspection_num',$id)->delete(); // Inspection Corrective Action

	    	\SiteInspectionsQuestionAnswer::where('inspection_id',$id)->delete(); // Inspection Question Answers
	    
	    }

	    /**
	     *
	     * 
	     *
	     **/
	    public static function getBusinessLob(){
	    	$lob = \SiteLineofBusiness::select('id','name')->lists('name','id');

	    	return $lob;
	    }


	    /**
     * due_date_calculation
     * 
     **/
    
    public static function due_date_calculation($severity){
    
        $due_date = 'now';
        $dat_now  = new \Carbon\Carbon('now');
        $severity = ucfirst(strtolower(trim($severity)));
        if($severity == 'Urgent'){
            $dat_exten = new \Carbon\Carbon('9 days');
            $res_date = Sitemasters::calculateweekends($dat_now,$dat_exten);
            $res_date = $res_date+7;
            $due_date  = $res_date.' days'; // Urgent
        }
    
        if($severity  == 'High'){
            $dat_exten = new \Carbon\Carbon('21 days');
            $res_date = Sitemasters::calculateweekends($dat_now,$dat_exten);
            $res_date = $res_date+15;
            $due_date  = $res_date.' days'; // High
        }
        if($severity  == 'Medium'){
            $dat_exten = new \Carbon\Carbon('40 days');
            $res_date = Sitemasters::calculateweekends($dat_now,$dat_exten);
            $res_date = $res_date+30;
            $due_date  = $res_date.' days'; // medium
        }
        if($severity == 'Low') {
            $dat_exten = new \Carbon\Carbon('80 days');
            $res_date = Sitemasters::calculateweekends($dat_now,$dat_exten);
            $res_date = $res_date+60;
            $due_date  = $res_date.' days'; // low
        }
    
    
        $dt = Carbon::parse($due_date); // Check for weekends
        if($dt->dayOfWeek === Carbon::SATURDAY) {
            $res_date = $res_date+2;
            $due_date  = $res_date.' days';
        }else if($dt->dayOfWeek === Carbon::SUNDAY) {
            $res_date = $res_date+1;
            $due_date  = $res_date.' days';
        }
    
        return $due_date;
    }

    /**
     *  Update LP Site Corrective Action
     *
     *
     **/
    public static function lpSaveActionPlan($data){
    	
    	if(!empty($data['exist'])){
    		$up_id = [];
    		$sid   = null;
    		$uid   = null;
    		foreach ($data['exist'] as $ky => $val) {
    			if($ky != 'ex_id') {
    				$up_id[] = $val['question_id'];
    				\SiteLpCorrectiveAction::where('question_id',$val['question_id'])
    									   ->where('site_master_id',$val['site_master_id'])	
    									   ->where('assement_user_id',$val['assement_user_id'])
    									   ->update(['assessment_comments' => $val['assessment_comments']]);
    				
    				$sid = $val['site_master_id'];
    				$uid = $val['assement_user_id'];
    			 }
    		}
    		if(!empty($data['delete'])){	
    		 /* Delete LP Corrective Action */
    			//$dele_id = array_diff($data['exist']['ex_id'], $up_id);
    		    $dele_id =  $data['delete'];
    			\SiteLpCorrectiveAction::whereIn('question_id',$dele_id)
    									   ->where('site_master_id',$sid)	
    									   ->where('assement_user_id',$uid)
    									   ->delete();
    		}    					
    	}

    	if(!empty($data['new'])) {
    		\SiteLpCorrectiveAction::insert($data['new']);
    	}
  			//print "<pre>"; print_r(\DB::getQuerylog()); exit;
   }

    
    /**
     *  Get LP Site Corrective Action List
     *
     *
     **/

    public static function getLPCorrectiveAction($sid){
    	$ca = \SiteLpCorrectiveAction::with('user')->where('site_master_id',$sid)
    									   ->get()->all();
    
    	return $ca;
    }


    /**
     *
     *
     *
     **/

    public static function getPrCADetail($sid){

		    $prCA = \SiteCorrectiveAction::with('siteinspectionsanswer')
		    							 ->select(\DB::raw("inspection_num,p_r_severity,count(p_r_severity) as cnt,case when (vam_approval = 'accept') then 'closed' else 'open' end as status, format(created_at,'yyyy-MM-dd') as created_at"))
		                                 ->where('sitemaster_id',$sid)
		                                 ->groupby(\DB::raw("p_r_severity, (case when (vam_approval =  'accept') then 'closed' else 'open' end),inspection_num,created_at"))
		                                 ->orderby('inspection_num')
		                                 ->get()->all();

		    $ca_arry = [];
		    $insp_num = 0; $tot_opn_chng = 'no'; $tot_clsd_chng = 'no';  $totalcas_open  = 0;  $totalcas_closed  = 0; $insp_autid =1; 

	        foreach ($prCA as $key => $value) {

					//if($value->inspection_num != 34) continue;

		        	    if($insp_num !=  $value->inspection_num && $tot_opn_chng  =='no' )  $totalcas_open  = 0;

		        	    if($insp_num !=  $value->inspection_num && $tot_clsd_chng  =='no' )  $totalcas_closed  = 0;

		        		$insp_num = $value->inspection_num;
		        		$severity = trim(strtolower($value->p_r_severity));

		        		 
		        		if($value->status == 'open')
		        		     $totalcas_open =  $totalcas_open  + $value->cnt;
		        		if($value->status == 'closed')
		        		    $totalcas_closed =  $totalcas_closed  + $value->cnt;

		        		//print "<pre>"; print_r($value->siteinspectionsanswer); exit;

						$ca_arry[$insp_num]['inspection_num']                           = $insp_num;
						$ca_arry[$insp_num]['date']										= isset($value->siteinspectionsanswer)?$value->siteinspectionsanswer->ins_main_date:'';
						$ca_arry[$insp_num][$value->status][$severity]['status']        = $value->status;
						$ca_arry[$insp_num][$value->status][$severity]['cnt']           = $value->cnt;
					//	$ca_arry[$insp_num][$value->status][$severity]['date']          = $value->created_at;
					//	$ca_arry[$insp_num][$value->status][$severity]['p_r_severity']  = $severity;


						/*Total CA for Open and closed*/
						if($value->status == 'open')
							$ca_arry[$insp_num][$value->status]['open_totalcas']    		= $totalcas_open;
						if($value->status == 'closed')
							$ca_arry[$insp_num][$value->status]['closed_totalcas']      	= $totalcas_closed;

			 
						if($insp_num !=  $value->inspection_num && $value->status == 'open')   $tot_opn_chng = 'yes'; 
						if($insp_num !=  $value->inspection_num && $value->status == 'closed') $tot_clsd_chng = 'yes'; 
    
	        }           

		  
		  	return $ca_arry;
    }

 }

?>