<?php namespace MSLST\Constants;

class Dashboard {

	/**
	 * Constant representing number of audits to be shown
	 * on the audits area chart.
	 *
	 * @var integer
	 */
	const AREA_CHART_AUDITS_COUNT = 12;

	/**
	 * Constant representing number of incidents to be shown
	 * on the incidents area chart.
	 *
	 * @var integer
	 */
	const AREA_CHART_INCIDENTS_COUNT = 12;

	/**
	 * Constant representing number of recent users to be shown
	 * on the dashboard.
	 *
	 * @var integer
	 */
	const RECENT_USERS_DISPLAY_COUNT = 30;

	/**
	 * Constant representing alerts to be shown
	 * on the dashboard.
	 *
	 * @var integer
	 */
	const ALERTS_DISPLAY_COUNT = 4;

	/**
	 * Constant representing mysql date format for the
	 * recent users on the dashboard.
	 *
	 * @var string
	 */
	const RECENT_USERS_DATE_FORMAT = '%M %D, %Y %h:%i:%s %p';

	/**
	 * Constant representing mysql date format for alerts
	 * on the dashboard.
	 *
	 * @var string
	 */
	const ALERTS_DATE_FORMAT = '%b %D, %h:%i %p';

  /**
   * Constant representing count for old auit
   * on dashbord
   *
   * @var string
   */
  const OLD_AUDIT_DISPLAY_COUNT = 10;

	/**
	 * Constant representing left side widgets
	 * on dashbord
	 *
	 * @var array
	 */
	public static $LEFT_ORDER = ['incident_trend', 'audit_trend', 'recent_users', 'old_audits'];

	/**
	 * Constant representing right side widgets
	 * on dashbord
	 *
	 * @var array
	 */
	public static $RIGHT_ORDER = ['recent_audits', 'incident_status', 'incident_category','inspection_status','user_status'];

	/**
	 * Restricted Users in Recent user List 
	 * on dashbord
	 *
	 * @var array
	 */
	//public static $RESTRICTED_RECENT_USER_LIST = ['user.one@demo.com','monitor@scss.com','mscssit@microsoft.com','damco@scss.com','dhl@scss.com','expeditors@scss.com'];
	
	public static $RESTRICTED_RECENT_USER_LIST = ['226','262','76','304','285','284'];
}
