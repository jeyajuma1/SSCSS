<?php namespace MSLST\Constants;

class Email {

	/**
	 * Constant representing the site email setting.
	 *
	 * @var string
	 */
	const SITE_EMAIL = 'site_email';	

	/**
	 * Constant representing the site email sender setting.
	 *
	 * @var string
	 */
	const SITE_EMAIL_SENDER = 'site_email_sender';


	/**
	 * Constant representing the site Alert Option.
	 *
	 * @var string
	 */

	const SITE_ALERT_OPTION = 'site_alert_option';

    /**
	 * Constant representing the site Alert message.
	 *
	 * @var string
	 */

	const SITE_ALERT_MESSAGE = 'site_alert_message';

	/**
	 * Constant representing the site terms and conditions setting.
	 *
	 * @var string
	 */
	const SITE_ASK_AGREE_TNC = 'site_ask_agree_tnc';	

	/**
	 * Constant representing the user create email subject setting.
	 *
	 * @var string
	 */
	const ACCOUNT_EMAIL_SUBJECT_USER_CREATE = 'account_email_subject_user_create';	

	/**
	 * Constant representing the user create email body setting.
	 *
	 * @var string
	 */
	const ACCOUNT_EMAIL_BODY_USER_CREATE = 'account_email_body_user_create';	

	/**
	 * Constant representing the codeword reset email subject setting.
	 *
	 * @var string
	 */
	const ACCOUNT_EMAIL_SUBJECT_PASSWORD_RESET = 'account_email_subject_password_reset';	

	/**
	 * Constant representing the codeword reset email body setting.
	 *
	 * @var string
	 */
	const ACCOUNT_EMAIL_BODY_PASSWORD_RESET = 'account_email_body_password_reset';	

	/**
	 * Constant representing the location create email subject setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_SUBJECT_LOCATION_CREATE = 'audit_email_subject_location_create';	

	/**
	 * Constant representing the location edit email subject setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_SUBJECT_LOCATION_EDIT = 'audit_email_subject_location_edit';	

	/**
	 * Constant representing the location create email body setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_BODY_LOCATION = 'audit_email_body_location';	

	/**
	 * Constant representing the route create email subject setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_SUBJECT_ROUTE_CREATE = 'audit_email_subject_route_create';	

	/**
	 * Constant representing the route edit email subject setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_SUBJECT_ROUTE_EDIT = 'audit_email_subject_route_edit';	

	/**
	 * Constant representing the route create email body setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_BODY_ROUTE = 'audit_email_body_route';	

	/**
	 * Constant representing the lane create email subject setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_SUBJECT_LANE_CREATE = 'audit_email_subject_lane_create';	

	/**
	 * Constant representing the lane edit email subject setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_SUBJECT_LANE_EDIT = 'audit_email_subject_lane_edit';	

	/**
	 * Constant representing the lane create email body setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_BODY_LANE = 'audit_email_body_lane';	

	/**
	 * Constant representing the audit review request subject setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_SUBJECT_REVIEW_REQUEST = 'audit_email_subject_review_request';	

	/**
	 * Constant representing the audit review request body setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_BODY_REVIEW_REQUEST = 'audit_email_body_review_request';	

	/**
	 * Constant representing the audit review cleared subject setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_SUBJECT_REVIEW_CLEARED = 'audit_email_subject_review_cleared';	

	/**
	 * Constant representing the audit review cleared body setting.
	 *
	 * @var string
	 */
	const AUDIT_EMAIL_BODY_REVIEW_CLEARED = 'audit_email_body_review_cleared';	

	/**
	 * Constant representing the incident create email subject setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_SUBJECT_CREATE = 'incident_email_subject_create';	

	/**
	 * Constant representing the incident create email body setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_BODY_CREATE = 'incident_email_body_create';	

	/**
	 * Constant representing the incident status change email subject setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_SUBJECT_STATUS_CHANGE = 'incident_email_subject_status_change';	

	/**
	 * Constant representing the incident status chane email body setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_BODY_STATUS_CHANGE = 'incident_email_body_status_change';	

	/**
	 * Constant representing the incident edit email subject setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_SUBJECT_EDIT = 'incident_email_subject_edit';	

	/**
	 * Constant representing the incident edit email body setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_BODY_EDIT = 'incident_email_body_edit';	

	/**
	 * Constant representing the incident review request email subject setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_SUBJECT_REVIEW_REQUEST = 'incident_email_subject_review_request';	

	/**
	 * Constant representing the incident review request body setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_BODY_REVIEW_REQUEST = 'incident_email_body_review_request';	

	/**
	 * Constant representing the incident review cleared email subject setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_SUBJECT_REVIEW_CLEARED = 'incident_email_subject_review_cleared';	

	/**
	 * Constant representing the incident review cleared body setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_BODY_REVIEW_CLEARED = 'incident_email_body_review_cleared';	

	/**
	 * Constant representing the incident reminder email subject setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_SUBJECT_REMINDER = 'incident_email_subject_reminder';	

	/**
	 * Constant representing the incident reminder body setting.
	 *
	 * @var string
	 */
	const INCIDENT_EMAIL_BODY_REMINDER = 'incident_email_body_reminder';
	 
	/**
	 * Constant representing the monthly incident report email subject setting.
	 *
	 * @var string
	 */
	const MONTHLY_INCIDENT_REPORT_EMAIL_SUBJECT = 'monthly_incident_report_email_subject';
	
	/**
	 * Constant representing the  monthly incident report body setting.
	 *
	 * @var string
	 */
	const MONTHLY_INCIDENT_REPORT_EMAIL_BODY = 'monthly_incident_report_email_body';
	/**
	 * Constant representing the Factory incident create email subject setting.
	 *
	 * @var string
	 */
	const FACTORY_INCIDENT_EMAIL_SUBJECT_CREATE = 'factory_incident_email_subject_create';	


	/**
	 * Constant representing the Factory incident create email Body setting.
	 *
	 * @var string
	 */
	const FACTORY_INCIDENT_EMAIL_BODY_CREATE = 'factory_incident_email_body_create';


	/**
	 * Constant representing the Factory incident create email subject setting.
	 *
	 * @var string
	 */
	const SITE_INSPECTION_VAM_EMAIL_SUBJECT_CREATE = 'site_inspection_vam_subject_create';	


	/**
	 * Constant representing the Factory incident create email Body setting.
	 *
	 * @var string
	 */
	const SITE_INSPECTION_VAM_EMAIL_BODY_CREATE = 'site_inspection_vam_body_create';

	/**
	 * Constant representing the Factory incident create email subject setting.
	 *
	 * @var string
	 */
	const SITE_INSPECTION_CSM_EMAIL_SUBJECT_CREATE = 'site_inspection_csm_subject_create';	


	/**
	 * Constant representing the Factory incident create email Body setting.
	 *
	 * @var string
	 */
	const SITE_INSPECTION_CSM_EMAIL_BODY_CREATE = 'site_inspection_csm_body_create';
	
	const SITE_INSPECTION_VAM_EMAIL_SUBJECT_OPEN_CA_WEEKLY_REMAINDER = 'site_inspection_vam_subject_open_ca_weekly_remainder';

	const SITE_INSPECTION_VAM_EMAIL_BODY_OPEN_CA_WEEKLY_REMAINDER = 'site_inspection_vam_body_open_ca_weekly_remainder';

	const NEW_USER_ACCESS_REQUEST_EMAIL_SUBJECT = 'new_user_access_request_email_subject';

	const NEW_USER_ACCESS_REQUEST_EMAIL_SUBJECT_BODY = 'new_user_access_request_email_body';
	


}