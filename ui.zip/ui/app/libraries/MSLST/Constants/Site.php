<?php namespace MSLST\Constants;

class Site {

	/**
	 * Constant representing normal user home page.
	 *
	 * @var string
	 */
	const USER_HOME = 'profile';

	/**
	 * Constant representing location name prefix.
	 *
	 * @var string
	 */
	const LOCATION_PREFIX = 'L';

	/**
	 * Constant representing route name prefix.
	 *
	 * @var string
	 */
	const ROUTE_PREFIX = 'R';

	/**
	 * Constant representing incident name prefix.
	 *
	 * @var string
	 */
	const INCIDENT_PREFIX = 'INC';
	/**
	 * Constant representing factory incident name prefix.
	 *
	 * @var string
	 */
	
	const FACTORY_INCIDENT_PREFIX = 'FINC';

	/**
	 * Constant representing factory incident name prefix.
	 *
	 * @var string
	 */
	
	const SUPPLIER_PREFIX = 'SUP';


	/**
	 * Constant representing factory incident name prefix.
	 *
	 * @var string
	 */
	
	const SITEMASTER_PREFIX = 'SM';

	/**
	 * Constant representing user roles.
	 *
	 * @var array
	 */
	public static $USER_ROLES = [
		'admin' => 'Admin',
		'supervisor' => 'Supervisor',
		'user' => 'User',
		//'site_representative' => 'Manufacturing Site Representative'
	];

	/**
	 * Constant representing the highest level company.
	 *
	 * @var string
	 */
	const HIGHEST_LEVEL_COMPANY = 8;

	/**
	 * Constant representing TAPA.
	 *
	 * @var integer
	 */
	const TAPA_GROUP = 1;

	/**
	 * Constant representing C-TPAT.
	 *
	 * @var integer
	 */
	const C_TPAT_GROUP = 2;

	/**
	 * Constant representing AEO.
	 *
	 * @var integer
	 */
	const AEO_GROUP = 3;

	/**
	 * Constant representing certification groups.
	 *
	 * @var array
	 */
	public static $CERTIFICATION_GROUPS = [
		1 => 'TAPA',
		2 => 'C-TPAT',
		3 => 'AEO',
		4 => 'P+R'
	]; 

	/**
	 * Constant representing Location availability.
	 *
	 * @var integer
	 */
	const AVAILABILITY_LOCATION = 1;

	/**
	 * Constant representing Route availability.
	 *
	 * @var integer
	 */
	const AVAILABILITY_ROUTE = 2;

	/**
	 * Constant representing Location/Route availability.
	 *
	 * @var integer
	 */
	const AVAILABILITY_LOCATION_ROUTE = 3;
	
	const AVAILABILITY_SUPPLIERS_SITEMASTER= 4;

	const AVAILABILITY_SUPPLIERS= 5;

	/**
	 * Constant representing certification availability.
	 *
	 * @var array
	 */
	public static $CERTIFICATION_AVAILABILITIES = [
		self::AVAILABILITY_LOCATION => 'Location',
		self::AVAILABILITY_ROUTE => 'Route',
		self::AVAILABILITY_LOCATION_ROUTE => 'Location/Route',
		self::AVAILABILITY_SUPPLIERS_SITEMASTER => 'Site Master',
		self::AVAILABILITY_SUPPLIERS => 'Supplier'
	];

	/**
	 * Constant representing TAPA FSR A.
	 *
	 * @var integer
	 */
	const TAPA_FSR_A = 1;

	/**
	 * Constant representing TAPA FSR B.
	 *
	 * @var integer
	 */
	const TAPA_FSR_B = 2;

	/**
	 * Constant representing TAPA FSR C.
	 *
	 * @var integer
	 */
	const TAPA_FSR_C = 3;

	/**
	 * Constant representing TAPA TSR 1.
	 *
	 * @var integer
	 */
	const TAPA_TSR_1 = 4;

	/**
	 * Constant representing TAPA TSR 2.
	 *
	 * @var integer
	 */
	const TAPA_TSR_2 = 5;

	/**
	 * Constant representing TAPA TSR 3.
	 *
	 * @var integer
	 */
	const TAPA_TSR_3 = 6;

	/**
	 * Constant representing C-TPAT.
	 *
	 * @var integer
	 */
	const C_TPAT = 7;

	/**
	 * Constant representing AEO S.
	 *
	 * @var integer
	 */
	const AEO_S = 8;

	/**
	 * Constant representing AEO F.
	 *
	 * @var integer
	 */
	const AEO_F = 9;

	/**
	 * Constant representing AEO C.
	 *
	 * @var integer
	 */
	const AEO_C = 10; 
	
	const P_R = 4;

	/**
	 * Constant representing TAPA certifications.
	 *
	 * @var array
	 */
	public static $TAPA_CERTIFICATIONS = [
		self::TAPA_FSR_A => 'TAPA FSR A',
		self::TAPA_FSR_B => 'TAPA FSR B',
		self::TAPA_FSR_C => 'TAPA FSR C',
		self::TAPA_TSR_1 => 'TAPA TSR 1',
		self::TAPA_TSR_2 => 'TAPA TSR 2',
		self::TAPA_TSR_3 => 'TAPA TSR 3',
	]; 

	/**
	 * Constant representing C-TPAT certifications.
	 *
	 * @var array
	 */
	public static $C_TPAT_CERTIFICATIONS = [
		self::C_TPAT => 'C-TPAT',
	]; 

	/**
	 * Constant representing AEO certifications.
	 *
	 * @var array
	 */
	public static $AEO_CERTIFICATIONS = [
		self::AEO_S => 'AEO S',
		self::AEO_F => 'AEO F',
		self::AEO_C => 'AEO C',
	];
	
	public static $P_R_CERTIFICATIONS = [
		self::P_R => 'P+R',
		];

	/**
	 * Constant representing supplier activities.
	 *
	 * @var array
	 */

	public static $SUPPLIER_ACTIVITIES = [
		1 => 'Device and accessory Manufacturing',
	    2 => 'Consumer &  UX studies',
	    3 => 'Creative agencies',
	    4 => 'Appearance model making',
	    5 => 'Component Manufacturing',
	    6 => 'Print & Packaging',
	    7 => 'R&D'
	];

	/**
	 * Constant representing Line of Business
	 *
	 * @var array
	 */
	public static $LINE_OF_BUSINESS = [
	 				'FPP/Retail Software' => 'FPP/Retail Software',
					'Hardware' => 'Hardware',
					'MBS (Microsoft Business Solutions)' => 'MBS (Microsoft Business Solutions)',
					'MS Internal (Product Release, Corporate Procurement, etc.)' => 'MS Internal (Product Release, Corporate Procurement, etc.)',
					'MS Marketing (not managed by Ops)'=>'MS Marketing (not managed by Ops)',
					'MSN' => 'MSN',
					'OEM (Original Equipment Manufacturer)' => 'OEM (Original Equipment Manufacturer)',
					'Programs' => 'Programs',
					'RDM (Release & Data Management)' => 'RDM (Release & Data Management)',
					'VLO (Volume Licensing Operations)' => 'VLO (Volume Licensing Operations)',
					'Xbox Hardware' => 'Xbox Hardware',
					'Xbox Software' => 'Xbox Software',
					'Other (Please describe in Comment field)' =>'Other (Please describe in "Comment" field)'
					];
	/**
	 * Constant representing incident types.
	 *
	 * @var array
	 */
	public static $INCIDENT_TYPES = [
		0 => 'other',
		1 => 'plant',
		2 => 'care'
	];

	/**
	 * Constant representing Site Process
	 *
	 * @var array
	 **/
	public static $SITE_PROCESS = [
					'CD/DVD Duplication (CD-R; DVD-R)'	=>'CD/DVD Duplication (CD-R; DVD-R)',
					'CD/DVD Replication (CD-ROM; DVD-ROM)'	=> 'CD/DVD Replication (CD-ROM; DVD-ROM)',
					'Destruction' =>'Destruction',	
					'Kitting / assembly' => 'Kitting / assembly',	
					'MS internal service (mail services, etc.)'	=>'MS internal service (mail services, etc.)',
					'Print / packaging'	=>'Print / packaging',
					'Repair / refurbishment'	=>'Repair / refurbishment',
					'Returns / Reverse Logistics'	=>'Returns / Reverse Logistics',
					'Rework'	=>'Rework',
					'Other (Please describe in Comment field)'	=>'Other (Please describe in "Comment" field)'	
					];

	/**
	 * Constant represent a Supplier type
	 *
	 * @var array
	 **/
	public static $SUPPLIER_TYPE = [
					'ADC (Authorized Destruction Center)'=>'ADC (Authorized Destruction Center)',
					'ADP (Authorized Disk Provider)'=>'ADP (Authorized Disk Provider)',
					'AR (Authorized Replicator)'=>'AR (Authorized Replicator)',
					'ARC (Authorized Returns Center)'=>'ARC (Authorized Returns Center)',
					'Authorized Merchant (on-line digital delivery, only)'=>'Authorized Merchant (on-line digital delivery, only)',
					'Authorized Refurbished'=>'Authorized Refurbished',
					'Carrier / freight forwarder'=>'Carrier / freight forwarder',
					'CRC (COA Return Center)'=>'CRC (COA Return Center)',
					'DTV (Distribution Turnkey Vendor)'=>'DTV (Distribution Turnkey Vendor)',
					'Fulfillment Center'=>'Fulfillment Center',
					'MTV (Manufacturing Turnkey Vendor)'=>'MTV (Manufacturing Turnkey Vendor)',
					'SPV (Secure Print Vendor)'=>'SPV (Secure Print Vendor)',
					'Subcontractor'=>'Subcontractor',
					'Other (Please describe in Comment field)'=>'Other (Please describe in "Comment" field)'
				];
	/**
	 * Constant represent a Support Line of Business
	 *
	 * 
	 * @var array
	 */

	public static $SUPPORT_LOB = [
					"Phones" => "Phones",
					"Audio & Phones essentials" => "Audio & Phones essentials",
					"Surface" => "Surface",
					"Surface accessories" => "Surface accessories",
					"Surface Hub" =>"Surface Hub",
					"Xbox" => "Xbox",
					"Analog" => "Analog" ,
					"Band" => "Band",
					"Hololens" => "Hololens",
					"PC accessories" => "PC accessories" ,
					"Studios" => "Studios",
					"Other" => "Other"
					];

	/**
	 * Constant representing incident type labels.
	 *
	 * @var array
	 */
	public static $INCIDENT_TYPE_LABELS = [
		0 => 'Other',
		2 => 'Plant to Plant',
		3 => 'CARE'
	];

	/**
	 * Constant representing incident categories.
	 *
	 * @var array
	 */
	public static $INCIDENT_CATEGORIES = [
		'minor' => 'Minor',
		'medium' => 'Medium',
		'major' => 'Major'
	];
	/**
	 * Constant representing Urgent.
	 *
	 * @var integer
	 */
	const None = 0;
	/**
	 * Constant representing Urgent.
	 *
	 * @var integer
	 */
	const Urgent = 1;

	/**
	 * Constant representing High.
	 *
	 * @var integer
	 */
	const High = 2;

	/**
	 * Constant representing Medium
	 *
	 * @var integer
	 */
	const Medium = 3;

	/**
	 * Constant representing Low
	 *
	 * @var integer
	 */
	const Low = 4;

	/**
	 * Constant representing incident categories.
	 *
	 * @var array
	 */
	public static $QUESTIONS_SEVERITY = [
		self::None => '',
		self::Urgent => 'Urgent',
		self::High => 'High',
		self::Medium => 'Medium',
		self::Low => 'Low'
	];
	
	/**
	 * Constant representing minor incident uplimit.
	 *
	 * @var integer
	 */
	const INCIDENT_MINOR_THRESHOLD = 25000;

	/**
	 * Constant representing minor incident uplimit.
	 *
	 * @var integer
	 */
	const INCIDENT_MAJOR_THRESHOLD = 100000;


	/**
	 * Constant representing value Determined Values
	 *
	 *
	 * @var array
	 **/

	public static $Determined_status = [
										 1 => ['val'=>"Not in scope",'clas' =>'default'],
		               				     2 => ['val'=>"Compliant",'clas' =>'success'],
		               				     3 => ['val'=>"Partially compliant",'clas' =>'warning'],
		               				     4 => ['val'=>"Non compliant",'clas' =>'danger']
		               				   ];


}