@extends('layouts.master') @section('content')
<div class="container">
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<div class="error-panel panel panel-default">
				<div class="panel-heading">
					<h3 class="panel-title">The page you are looking for could not be found</h3>
				</div>
				<div class="panel-body">
					<p>It is possible that:</p>
					<ul>
						<li>The resource you are trying to access has been removed or
							deleted</li>
						<li>You may have clicked an expired link</li>
						<li>You may have typed the address(URL) incorrectly</li>
					</ul>
					<div class="pull-right">
						<div class="btn-group incident-btns">
							<button class="btn-gray" onclick="history.go(-1);">Go Back</button>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@stop
