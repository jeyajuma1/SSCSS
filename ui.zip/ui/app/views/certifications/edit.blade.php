@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
            Edit Certification
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <span class="font-bold">
                     Edit Certification
                 </span>
                </div>
                {{ Form::open(['route' => ['certifications.update', $certification->id], 'class' => 'form-horizontal', 'role' => 'form', 'id' => 'certification-edit', 'method' => 'put']) }}
                    <div class="panel-body">

                        @if($errors->all())
                        <div id="form-errors" class="alert alert-danger" role="alert">
                          <ul>
                            @foreach($errors->all() as $error)
                              <li>{{ $error }}</li>
                            @endforeach
                          </ul>
                        </div>
                        @endif

                        <div class="form-group">
                        	{{ Form::label('name', 'Name', ['class' => 'col-lg-2 control-label required']) }}
                            <div class="col-sm-6">
                              {{ Form::text('name', $certification->name, ['class' => 'form-control']) }}
                            </div>
                        </div>
                        <div class="form-group">
                            {{ Form::label('group', 'Group', ['class' => 'col-lg-2 control-label']) }}
                            <div class="col-sm-6">
                              <span id="group" class="form-control category-span">{{ $certification_group }}</span>
                            </div>
                        </div>
                        <div class="form-group">
                            {{ Form::label('availability', 'Availability', ['class' => 'col-lg-2 control-label required']) }}
                            <div class="col-sm-6">
                            	{{ Form::select('availability', $certification_availabilities, $certification->availability, ['class' => 'form-control']) }}
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'href' => '/certifications']) }}
                    </div>
                {{ Form::close() }}
            </div>
            <!-- /.col-lg-12 -->
        </div>
    <!-- /.row -->
	</div>
<!-- /#page-wrapper -->
</div>
@stop