@extends('layouts.master')

@section('content')
<div id="page-wrapper">
     <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Inspection Summary</h1>
                @else
                  <h1 class="page-header">Create Inspection Summary</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">P+R Inspection</div>
                    {{ Form::open(['route' => ($edit ? ['sitemaster.inspectionupdate', $data->id,$data->inspection_num,1] : ['sitemaster.inspectionprstore',$data->id,'online']), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal sitemaster-form', 'role' => 'form', 'id' => 'sitemaster-form-basic']) }}
                    {{ Form::hidden('step', 3) }}
                    <div class="panel-body">
                         <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard" style="margin-left:10px">
                                        <a >
                                          <span>Inspection Main</span>
                                        </a>
                                        <a>
                                          <span>Questions</span>
                                        </a>
                                        <a  class="current">
                                          <span>Summary</span>
                                        </a>
                                  </div>

                                  <div class="form-group">
                                    {{ Form::label('summ_company_background', 'Company Background; Type of product/service provided by supplier to Microsoft; Key customers; Historical information (prior inspections, reported losses, etc.); any other relevant information', ['class' => 'col-lg-6 control-label ']) }}
                                    <div class="col-lg-6">
                                      {{ Form::textarea('summ_company_background', $data->summ_company_background, ['class' => 'form-control','rows' => 3,"cols" => 120,]) }}
                                    </div>
                                  </div> 

                                  <div class="form-group">
                                    {{ Form::label('summ_overview_inspection_work', 'Overview of Inspection Work and Recommended controls', ['class' => 'col-lg-6 control-label ']) }}
                                    <div class="col-lg-6">
                                      {{ Form::textarea('summ_overview_inspection_work', $data->summ_overview_inspection_work, ['class' => 'form-control','rows' => 3,"cols" => 120,]) }}
                                    </div>
                                  </div> 

                                  <div class="form-group">
                                    {{ Form::label('summ_facility_site_desc', 'Facility and site description, including security features; any other relevant information', ['class' => 'col-lg-6 control-label ']) }}
                                    <div class="col-lg-6">
                                      {{ Form::textarea('summ_facility_site_desc', $data->summ_facility_site_desc, ['class' => 'form-control','rows' => 3,"cols" => 120,]) }}
                                    </div>
                                  </div> 
                                  <div class="form-group">
                                    <div class="row">
                                      {{ Form::label('summ_people_interview_during_inspec', 'People Interviewed during Inspection', ['class' => 'col-lg-6 control-label required']) }}
                                      {{ Form::label('summ_people_interview_during_inspec_name', 'Name', ['class' => 'colsm3s']) }}
                                      {{ Form::label('summ_people_interview_during_inspec_title', 'Title / Role', ['class' => 'colsm3s']) }}
                                       <button id="peopleinterviewed" class="onlinebtn" type="button"><b>+</b></button>
                                    </div>
                                    <?php 
                                    $i=1;
                                    $summ_people_interview_during_inspec=json_decode($data->summ_people_interview_during_inspec);?> 
                                    @if(isset($data->summ_people_interview_during_inspec) && count($summ_people_interview_during_inspec))
                                      @foreach($summ_people_interview_during_inspec as $sum_key => $summ_people_interview_during_inspec_data)

                                        <div class="row activty-rows" id="activty-rows<?php echo $i?>"style="margin-bottom: 15px;">
                                        <div class="col-sm-1 activty-cols" style="display:none;">
                                          <span class="form-control activty-counts" >{{$i}}</span>
                                        </div>
                                          <div class="col-lg-6">
                                           
                                          </div>
                                            <div class="col-lg-3" style="padding: 0px;width: 205px;margin-left: 15px;">
                                            <!--   {{ Form::text("summ_people_interview_during_inspec[$sum_key][name]",$summ_people_interview_during_inspec_data->name, ['class' => 'form-control']) }} -->
                                              <input type="text" name="summ_people_interview_during_inspec[<?php echo $i;?>][name]" id="summ_people_interview_during_inspec[<?php echo $i;?>][name]" class="form-control inter_inspec" value="{{$summ_people_interview_during_inspec_data->name}}" >            
                                              </input>  
                                            </div>
                                            <div class="col-lg-3" style="padding: 0px;width: 205px;margin-left: 15px;">
                                             <input type="text" name="summ_people_interview_during_inspec[<?php echo $i;?>][title]" id="summ_people_interview_during_inspec[<?php echo $i;?>][title]" class="form-control inter_inspec1" value="{{$summ_people_interview_during_inspec_data->title}}"> 
                                            </div>
                                            <div class="col-lg-1" style="width:20px;margin-left: 12px;">
                                             <span class="glyphicon glyphicon-remove people_interviewd_remove"  style="cursor:pointer;float:right;margin:10px 0px 0px 0px;"  id="people_interviewd_remove<?php echo $i; ?>"  aria-hidden="true"></span>                                  
                                          </div>
                                        </div>
                                         <?php $i=$i+1; ?>
                                      @endforeach
                                    @else
                            <div class="row">                                 
                            <div class="col-lg-6"> </div>  
                            <div class="row activty-rows" id="activty-rows1" style="float:left;margin-left:15px; margin-bottom: -12px;">
                            <div class="col-sm-1 activity-cols" style=" display:none;">
                              <span class="form-control activty-counts" >1</span>
                            </div>  
                            <div class="col-lg-3" style="width:205px;">
                              <div class="form-group">
                              <input type="text" name="summ_people_interview_during_inspec[1][name]" id="summ_people_interview_during_inspec[1][name]" class="form-control inter_inspec" >            
                                    </input>         
                              </div>
                            </div> 
                      <div class="col-lg-3" style="width: 205px;margin-left: 15px;">
                        <div class="form-group">
                          <input type="text" name="summ_people_interview_during_inspec[1][title]" id="summ_people_interview_during_inspec[1][title]" class="form-control inter_inspec1" > </input>
                                          </div>
                        </div>
                      </div>
                     <!-- <div class="col-lg-1">
                              <span class="glyphicon glyphicon-remove ins_main_remove" style="cursor:pointer;"  id="ins_main_remove0" alt="'0'" aria-hidden="true"></span>
                     </div> --> 
                    </div>
                           
                                    </div>
                                    @endif 
                                   
                                           <div class="row">
                        <div class="col-lg-6"> </div>
                          <div id="insfirmname" style="float: left;width:462px;margin-top:0px;">                                            
                          </div>                      
                          </div>   
                                  </div>
                                    {{ Form::hidden("sc_pr_req_excepted",'', ['class' => "form_control"]) }}
                                    {{ Form::hidden("sc_pr_req_required",'', ['class' => "form_control"]) }}
                                    {{ Form::hidden("sc_pr_req_accumulated",'', ['class' => "form_control"]) }}
                                    {{ Form::hidden("sc_pr_req_percent", '', ['class' => "form_control"]) }}
                                    {{ Form::hidden("sc_pr_score_excepted",'', ['class' => "form_control"]) }}
                                    {{ Form::hidden("sc_pr_score_required",'', ['class' => "form_control"]) }}
                                    {{ Form::hidden("sc_pr_score_accumulated",'', ['class' => "form_control"]) }}
                                    {{ Form::hidden("sc_pr_score_percent",'', ['class' => "form_control"]) }}
                                    {{ Form::hidden("sc_calulated_score",'', ['class' => "form_control"]) }}
                                    {{ Form::hidden("sc_scoring_rules_final_rating",'', ['class' => "form_control"]) }}


                         </div> <!-- /.row -->
                    </div> <!-- /.panel-body -->
                     <!--div class="panel-footer">
                          <div class="clearfix">
                            <div class="pull-left">
                              {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }}
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Confirm', ['type' => 'submit', 'class' => 'btn btn-primary','id'=>'summaryform']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.index'),'id'=>'sitemaster_cancel']) }}
                            </div>
                          </div>
                     </div-->
                     <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.show', $data->id),'id'=>'sitemaster_cancel_edit']) }}
                        @else
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.index'),'id'=>'sitemaster_cancel']) }}
                        @endif
                    </div>


                    {{form::close()}}
                </div><!-- /.panel-default -->
            </div> <!-- /.col-lg-12 -->
        </div> <!-- /.row -->



    </div>
     <!-- /.main-content -->
</div>
            <!-- /.col-lg-12 -->                          
@stop
