@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row" style="width:1330px">
            <div class="col-lg-9">
               <h1> @if($type=='online')P&R Inspection @else P&R Inspection Summary @endif </h1>
                
            </div> 
            @if(empty($data) || $type == 'offline') 
            <div class="col-lg-3 btn-xs" style="padding-top:10px">
                <div class="panel panel-info">
                    
                    @if(Session::has('no-file'))
                        {{ Form::label("questionerror", Session::get('no-file'), ['class' => 'control-label btn-danger']) }}
                    @endif
                </div>
            </div>
            @endif
          </div>
              
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default" style="width:1300px">
                    <div class="panel-heading">Questionnaire
                       @if(!empty($data->answer_id) && in_array(-1,$data->answer_id))  <span class="label label-danger notify_ans"> <i class="fa fa-info-circle"></i> Note: Questions with red background color are not answered.</span> @endif
                    </div>
                   {{ Form::open(['route' => ['sitemaster.inspectionstore',$sitemaster->id,$type], 'method' => 'post', 'class' => 'supplier-assessment-form', 'role' => 'form', 'id' => 'form-summary', 'files' => true]) }}
                    {{Form::hidden('inspection_num',Input::get('inspection_num'))}}
                    <div class="panel-body">
                        <?php $i=array(1,2,3,4,5,6,7,8);?>
                        <ul class="nav nav-tabs">
                            <li class="active" id="inspection-tab"><a href="#inspection1" data-toggle="tab">Partner Security
</a></li> 
                            <li  id="inspection-tab"><a href="#inspection2" data-toggle="tab">Site Access</a></li> 
                            <li  id="inspection-tab"><a href="#inspection3" data-toggle="tab">MS IP Control</a></li> 
                            <li id="inspection-tab"><a href="#inspection4" data-toggle="tab">Components Control</a></li> 
                            <li id="inspection-tab"><a href="#inspection5" data-toggle="tab">Cargo Security</a></li> 
                            <li id="inspection-tab"><a href="#inspection6" data-toggle="tab">Information Systems</a></li> 
                            <li  id="inspection-tab"><a href="#inspection7" data-toggle="tab">Digital IP Security</a></li> 
                            <li id="inspection-tab"><a href="#inspection8" data-toggle="tab">Leak Prevention</a></li>        
                         </ul>  

                         
                        
                        <div class="tab-content panel-group">
                             
                            @if(!empty($questions))
                                @foreach($i as $index=>$item)
                                <div @if($item==1)class="tab-pane active"@else class="tab-pane"@endif id="inspection{{$item}}">
                                    @foreach($questions as $question) 
                                        @if($item==(int)$question['reference'])
                                        <?php $id = $question['id']; ?>
                                        <div class="row">
                                        </br>
                                            <div class="form-group col-lg-10"> {{-- */ $classsName = ''; /* --}}   @if(isset($data->answer_id[$id]) && $data->answer_id[$id] == -1) {{-- */ $classsName = 'alert_notifyInsp alert-danger'; /* --}} @endif  
                                                {{ Form::label("question$id",$question['reference'].' '.$question['text'], ['class' => 'control-label '.$classsName]) }}
                                                <a href="javascript:void(0);" class="comment-link{{$id}}">Comment</a>
                                                {{ Form::textarea("comment[$id]", ((isset($data->comment) && isset($data->comment[$id])) ? $data->comment[$id] : ''), ['class' => 'form-control insepectiontextarea', 'rows' => 3,"cols" => 120, 'id' => "comment$id" ]) }}
                                            </div>                               
                                            <div class="form-group col-lg-2">
                                                {{ Form::select("question[$id]", $answers, ((isset($data->answer_id) && isset($data->answer_id[$id])) ? $data->answer_id[$id] : null), ['class' => 'form-control', 'id' => "question$id"]) }}
                                                <?php //print($data->answer_id[$id]);?>
                                                 
                                                {{ Form::hidden("severity[$id]",  $question['severity'], ['class' => "form_control"]) }}
                                                {{ Form::hidden("reference[$id]",  $question['reference'], ['class' => "form_control" ]) }}
                                                {{ Form::hidden("version[$id]",  $question['version'], ['class' => "form_control"]) }}
                                                {{ Form::hidden("subsection[$id]",  $question['subsection'], ['class' => "form_control"]) }}
                                                {{ Form::hidden("p_rtext[$id]",  $question['text'], ['class' => "form_control"]) }}
                                            </div>
                                        </div>
                                        <div class="Inpsepectionbox box-default">
                                        </div>
                                        @endif
                                    @endforeach
                                </div>
                                @endforeach
                            @else
                                <p>There are no questions & answers.</p>
                            @endif   
                                
                        </div>
                    
                </div>
                        
                        <div class="panel-footer">
                        {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary site_inspection']) }}
                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default','alt' => route('sitemaster.show', $sitemaster->id),'id'=>'sitemaster_cancel']) }}
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            </div>
            <!-- /.col-lg-12 -->
        
    </div>
</div>
            <!-- /.col-lg-12 -->                          
@stop
