@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        
          <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Inspection Question</h1>
                @else
                  <h1 class="page-header">Create Inspection Question</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
              
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default" style="width:1300px">
                    <div class="panel-heading">Questionnaire
                       @if(!empty($data->answer_id) && in_array(-1,$data->answer_id))  <span class="label label-danger notify_ans"> <i class="fa fa-info-circle"></i> Note: Questions with red background color are not answered.</span> @endif
                    </div>
                    {{ Form::open(['route' => ($edit ? ['sitemaster.inspectionupdate', $data->id,$data->inspection_num,1] : ['sitemaster.inspectionprstore',$data->id,'online']), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal sitemaster-form', 'role' => 'form', 'id' => 'sitemaster-form-basic']) }}
                    {{ Form::hidden('step', 2) }}                                                       
                    {{Form::hidden('inspection_num',Input::get('inspection_num'))}}

                    <div class="panel-body">
                            <div class="wizard" style="margin-left:10px">
                                        <a>
                                          <span>Inspection Main</span>
                                        </a>
                                        <a class="current">
                                          <span>Questions</span>
                                        </a>
                                        <a>
                                          <span>Summary</span>
                                        </a>
                            </div>
                        <?php $i=array(1,2,3,4,5,6,7);?>
                        <ul class="nav nav-tabs">
                            <li class="active" id="inspection-tab"><a href="#inspection1" data-toggle="tab">Partner Security</a></li> 
                            <li  id="inspection-tab"><a href="#inspection2" data-toggle="tab">Site Access</a></li> 
                            <li  id="inspection-tab"><a href="#inspection3" data-toggle="tab">MS IP Control</a></li> 
                            <li id="inspection-tab"><a href="#inspection4" data-toggle="tab">Components Control</a></li> 
                            <li id="inspection-tab"><a href="#inspection5" data-toggle="tab">Cargo Security</a></li> 
                            <li id="inspection-tab"><a href="#inspection6" data-toggle="tab">Information Systems</a></li> 
                            <li  id="inspection-tab"><a href="#inspection7" data-toggle="tab">Digital IP Security</a></li> 
                            <!--li id="inspection-tab"><a href="#inspection8" data-toggle="tab">Leak Prevention</a></li-->        
                         </ul>  

                         
                        
                        <div class="tab-content panel-group">
                             <?php $ques_no=0;//print "<pre>";print_r($i);exit;?>
                            @if(!empty($questions))
                                @foreach($i as $index=>$item)
                                <div @if($item==1)class="tab-pane active"@else class="tab-pane"@endif id="inspection{{$item}}">
                                    @foreach($questions as $question) 
                                        @if($item==(int)substr($question['reference'], 0, 1))
                                        <?php $id = $question['reference']; ?>
                                        <div class="row">
                                        </br>
                                            <div class="form-group col-lg-12"> {{-- */ $classsName = ''; /* --}}   @if(isset($data->answer_id[$id]) && $data->answer_id[$id] == -1) {{-- */ $classsName = 'alert_notifyInsp alert-danger'; /* --}} @endif  
                                                {{ Form::label("question$id",$question['reference'].'  '.$question['text'], ['class' => 'control-label','style'=>'text-align:left']) }}
                                                
                                                <?php $ques_no++;?>
                                                <!--{{ Form::select("question[$id]", $answers, ((isset($data->answer_id) && isset($data->answer_id[$id])) ? $data->answer_id[$id] : null), ['class' => 'form-control', 'id' => "question$id"]) }}-->
                                                <?php //print($data->answer_id[$id]);?>
                                                 
                                                {{ Form::hidden("ques_severity[$id]",  $question['severity_text'], ['class' => "form_control"]) }}
                                                {{ Form::hidden("ques_reference[$id]",  $question['reference'], ['class' => "form_control" ]) }}
                                                {{ Form::hidden("version[$id]",  $question['version'], ['class' => "form_control"]) }}
                                                {{ Form::hidden("subsection[$id]",  $question['subsection'], ['class' => "form_control"]) }}
                                                {{ Form::hidden("p_rtext[$id]",  $question['text'], ['class' => "form_control"]) }}
                                            </div>
                                        </div>
                                        <div class="box {{$PR_Severity[ucfirst(strtolower($question['severity_text']))]}}">
                                            <?php //echo $ques_no; ?>
                                            <div class="box-header">
                                              <div class="col-lg-3">  
                                                {{ Form::label("ques_response$id", 'Response', ['class' => 'control-label ']) }}
                                              </div>
                                              <div class="col-lg-3">
                                                {{ Form::label("ques_mitigating_control$id", 'Mitigating Control ', ['class' => 'control-label ']) }}
                                              </div>
                                              <div class="col-lg-3">
                                                {{ Form::label("ques_issue_detail_comments$id", 'Issue Details & Comments', ['class' => 'control-label ']) }}
                                              </div>
                                              <div class="col-lg-3">
                                                {{ Form::label("ques_corrective_action$id", 'Corrective Action', ['class' => 'control-label ']) }}
                                              </div>
                                            </div> 
                                            <div class="box-body">
                                              <div>
                                               {{-- */ $inspec_resp_val = ''; $resp_val = []; /* --}}
                                                
                                                @if(isset($data->question_data[$id]) &&  isset($data->question_data[$id]['ques_response']))
                                                    @if(!preg_match('/([0-9]+)/', $data->question_data[$id]['ques_response']) && !empty(trim($data->question_data[$id]['ques_response'])))
                                                           {{-- */  $resp_val = ['Not Applicable'=>'0','Meets Requirement'=>'1','Does not Meet Requirement'=>'2'];  /* --}}
                                                           {{-- */  $inspec_resp_val = $resp_val[$data->question_data[$id]['ques_response']];  /* --}}
                                                    @else
                                                           {{-- */ $inspec_resp_val = $data->question_data[$id]['ques_response']; $resp_val = []; /* --}}
                                                    @endif
                                                @endif

                                                <div class="col-lg-3">
                                                  {{ Form::select("ques_response[$id]",[''=>'','1'=>'Meets Requirement','2'=>'Does not Meet Requirement','0'=>'Not Applicable'],$inspec_resp_val, ['class' => 'form-control']) }}
                                                </div>
                                                <div class="col-lg-3">
                                                  {{ Form::select("ques_mitigating_control[$id]",[''=>'','Yes'=>'Yes','No'=>'No'],((isset($data->question_data[$id]['ques_mitigating_control']) && isset($data->question_data[$id])) ? $data->question_data[$id]['ques_mitigating_control'] : ''), ['class' => 'form-control']) }}
                                                </div>
                                                <div class="col-lg-3">
                                                  {{ Form::text("ques_issue_detail_comments[$id]",((isset($data->question_data[$id]) && isset($data->question_data[$id]['ques_issue_detail_comments'])) ? $data->question_data[$id]['ques_issue_detail_comments'] : ''), ['class' => 'form-control']) }}
                                                </div>
                                                <div class="col-lg-3">
                                                  {{ Form::text("ques_corrective_action[$id]",((isset($data->question_data[$id]) && isset($data->question_data[$id]['ques_corrective_action'])) ? $data->question_data[$id]['ques_corrective_action'] : ''), ['class' => 'form-control']) }}
                                                </div>
                                              </div>
                                              <!--div>
                                                <a href="javascript:void(0);" class="comment-link{{$id}}">Comment</a>
                                                {{ Form::textarea("comment[$id]", ((isset($data->comment) && isset($data->comment[$id])) ? $data->comment[$id] : ''), ['class' => 'form-control insepectiontextarea', 'rows' => 3,"cols" => 120, 'id' => "comment$id" ]) }}
                                              </div-->
                                            </div>  
                                                </div>
                                        <div class="Inpsepectionbox box-default">
                                        </div>
                                        @endif
                                        
                                    @endforeach
                                </div>
                                @endforeach
                            @else
                                <p>There are no questions & answers.</p>
                            @endif   
                                
                        </div>
                    
                </div>
                        
                        <!--div class="panel-footer">
                        {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary site_inspection']) }}
                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default','alt' => route('sitemaster.show', $sitemaster->id),'id'=>'sitemaster_cancel']) }}
                        </div-->

                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.show', $data->id),'id'=>'sitemaster_cancel_edit']) }}
                        @else
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.index'),'id'=>'sitemaster_cancel']) }}
                        @endif
                    </div>
                    {{ Form::close() }}
                </div>
            </div>
            </div>
            <!-- /.col-lg-12 -->
        
    </div>
</div>
            <!-- /.col-lg-12 -->                          
@stop
