@extends('layouts.master')

@section('content')
<div id="page-wrapper">
      <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
                Summary
            </h1>
        </div>
      </div>
      <!-- /.row -->
           <!-- /.row -->
    <div class="row">
      <!-- /.col-lg-12 -->
      <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"><h4>Data not yet saved. Please review the information and confirm once done.</h4></div>
            </div>
            {{ Form::open(['route' => 'sitemaster.store', 'method' => 'post', 'class' => 'supplier-form', 'role' => 'form', 'id' => 'form-summary', 'files' => true]) }}
            {{ Form::hidden('step',3) }}
              <div class="panel-body">
                   <!-- /.row -->

                  <div class="row incident-show">
                    <div class="col-lg-7">
                       <div class="panel panel-default">
                          <div class="panel-heading">
                              <i class="fa fa-bar-chart-o fa-fw"></i> Basic Information
                              <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('sitemaster.create', 0) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                          </div>
                          <!-- /.panel-heading -->
                          <div class="panel-body">
                            <div class="table-responsive">
                              <table class="table">
                                  <tbody>
                  									 <tr  style="vertical-align: top;">
                    									<td>	
                    										<b>Site Name</b><br/>
                    										<p> @if(!empty( $data['basic_information']->site_name)) {{ $data['basic_information']->site_name }} @else  Not Specified @endif </p>
                    									</td>
                    									<td>	
                    										<b>Region</b><br/>
                    										<p> @if(!empty($data['basic_information']->region)) {{ $region[$data['basic_information']->region] }} @else  Not Specified @endif</p>
                    									</td>
                    									<td>
                    										<b>Postal Address</b><br/>
                    										<p>@if(!empty($data['basic_information']->address)) {{$data['basic_information']->address}}@else  Not Specified @endif</p>
                    									</td>
                                     </tr>
								
                      								<tr>
                      									<td>
                                            <b>Supplier Type</b><br/>
                                            <p>@if(!empty($data['basic_information']->supplier_type)) {{ str_replace('Other (Please describe in Comment field)','',implode(",",$data['basic_information']->supplier_type)) }}@else  Not Specified @endif

                                               @if(!empty($data['basic_information']->supplier_other_type)){{ $data['basic_information']->supplier_other_type}} @endif
                                             </p>
                                        </td>
                                        <td>
                                            <b>Country</b><br/>
                                            <p>@if(!empty($data['basic_information']->country)){{$country[$data['basic_information']->country] }}@else  Not Specified @endif</p>
                                        </td>
                      									<td>	
                      										<b>Postal Code</b><br/>
                      										<p>@if(!empty($data['basic_information']->postal_code)){{$data['basic_information']->postal_code}}@else  Not Specified @endif</p>
                      									</td>
                      	              </tr>
								
                      								<tr>
                      									<td>
                      										<b>Status</b><br/>
                      										<p>@if(!empty($data['basic_information']->status))
                      										{{ ($data['basic_information']->status) }}
                      										@else
                      											Not Specified
                      										@endif
                      										</p>
                      									</td>
                      									<td>
                      										<b>City</b><br/>
                      										<p>@if(!empty($data['basic_information']->city)){{$data['basic_information']->city}}@else  Not Specified @endif</p>
                      									</td>
                      									<td>
                                            <b>GPS Coordinate</b><br/>
                                            <p>@if(!empty($data['basic_information']->coordinates)){{ $data['basic_information']->coordinates }} @else  Not Specified @endif</p>
                                        </td>
                      								</tr>
								                    </tbody>
							                </table>
                							<table class="table" >
                  								<tbody>
                  								  <tr>
                                    <td>
                                      <div id="sitemaster_map" class="detail-view-map span12 col-sm-12">
                											</div>
                                    </td>
                                    </tr>
                                  </tbody>
                              </table>
                            </div>
                          </div>
                        <!-- /.panel-body -->
                      </div>
                    <!-- /.panel -->
                       <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bar-chart-o fa-fw"></i> Site Information
                                <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('sitemaster.create', 1) }}">
                                          Edit
                                      </button>
                                  </div>
                                </div>
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <tbody>
                                            <tr>
                            									<td>
                                                  <b>Line of Business</b><br/>
                                                  <p>@if(!empty($data['site_information']->lob))
                                                  {{ str_replace('Other (Please describe in Comment field)','',implode(",",$data['site_information']->lob))}}@else  Not Specified @endif
                                                  @if(!empty($data['site_information']->lob_other_type)){{ $data['site_information']->lob_other_type}} @endif </p>
                                              </td>
                            									<td>
                            										<b>Process</b><br/>
                            										<p>@if(!empty($data['site_information']->process))
                                                {{ str_replace('Other (Please describe in Comment field)','',implode(",",$data['site_information']->process))}}@else  Not Specified @endif
                                                @if(!empty($data['site_information']->process_other_type)){{ $data['site_information']->process_other_type}} @endif
                                                </p>
                            									</td>
                            									<td>
                                                  <b>Parent Site</b><br/>
                                                  <p>@if(!empty($data['site_information']->parent_site))
                                                  	{{$data['site_information']->parent_site}}
                                                  	@else
                                                    Not Specified
                                                    @endif
                            	                    </p>
                                              </td>
                                            </tr>
								                            <tr>
                            									<td>	
                            										<b>Primary Stakeholder</b><br/>
                            										<p>
                            										@if(!empty($data['site_information']->primary_stakeholder))
                            										{{$data['site_information']->primary_stakeholder}}
                            										@else
                            											Not Specified
                            										@endif
                            										</p>
                            									</td>
                            									<td>	
                            										<b>Secondary Stakeholder</b><br/>
                            										<p>@if(!empty($data['site_information']->sec_stakeholder)){{$data['site_information']->sec_stakeholder}}@else  Not Specified @endif</p>
                            									</td>
                            									<td>
                            										<b>Channel Manager</b><br/>
                            										<p>@if(!empty($data['site_information']->channel_manager)){{$data['site_information']->channel_manager}}@else  Not Specified @endif</p>
                            									</td>
                                            </tr>
                                            <tr>
                                              <td>
                                                  <b>VAM</b><br/>
                                                  <p>@if(!empty($data['site_information']->vam)){{$data['site_information']->vam}}@else  Not Specified @endif</p>
                                              </td>
                                              <td>
                                                <b>Last P+R Inspection Date</b><br/>
                                                <p>@if(!empty($data['site_information']->last_inspection_date)){{$data['site_information']->last_inspection_date}}@else  Not Specified @endif</p>
                                              </td>
                                              <td>
                                                  <b>C-TPAT SVI Number</b><br/>
                                                  <p>@if(!empty($data['site_information']->c_tpat_svi_number))
                                                    {{$data['site_information']->c_tpat_svi_number}}
                                                    @else
                                                    Not Specified
                                                    @endif
                                                  </p>
                                              </td>
                                            </tr>	
                                            <tr>
                                              <td>
                                                  <b>Corrective Actions</b><br/>
                                                  <p>@if(!empty($data['site_information']->corrective_actions))
                                                    {{$data['site_information']->corrective_actions}}
                                                    @else
                                                    Not Specified
                                                    @endif
                                                  </p>
                                              </td>
                                              <td>
                                                  <b>Comments</b><br/>
                                                  <p>@if(!empty($data['site_information']->comments)){{$data['site_information']->comments}}@else  Not Specified @endif</p>
                                              </td>
                                            </tr> 
                                        </tbody>
                                    </table>
                                 </div>
                            </div>
                            <!-- /.panel-body -->
                       </div>
                       <!-- /.panel -->

                       <div class="panel panel-default">
                          <div class="panel-heading">
                              <i class="fa fa-bar-chart-o fa-fw"></i> Contact Information
                              <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('sitemaster.create', 2) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                          </div>
                          <!-- /.panel-heading -->
                          <div class="panel-body">
                              <div class="table-responsive">
                                  <table class="table">
                                      <tbody>
                                         <tr>
                            								<td>
                            									<b>Contact Name</b><br/>
                            									@if(!empty($data['contact_information']->contact_name))
                            									<p>{{$data['contact_information']->contact_name}}</p>
                            									@else 
                            										Not Specified
                            									@endif									
                            								</td>						
                            								<td>
                            									<b>Contact Email</b><br/>
                            									@if(!empty($data['contact_information']->contact_email))
                            									<p>{{$data['contact_information']->contact_email}}</p>
                            									@else 
                            										Not Specified
                            									@endif
                            								</td>
                                            <td>
                                              <b>Other Contact Info</b><br/>
                                              @if(!empty($data['contact_information']->other_contact_info))
                                              <p>{{$data['contact_information']->other_contact_info}}</p>
                                              @else 
                                                Not Specified
                                              @endif
                                            </td>
                                          </tr>	
                                      </tbody>
                                  </table>
                               </div>
                          </div>
                          <!-- /.panel-body -->
                       </div>
                       <!-- /.panel -->
                    </div>
                       <!-- /.col-lg-7 -->

                    <!-- /.col-lg-5 -->
                    <div class="col-lg-5">
                      <div class="panel panel-default">
                          <div class="panel-heading">
                              <i class="fa fa-bar-chart-o fa-fw"></i>
                                Leak Prevention Assessments
                          </div>
                          <div class="panel-body">
                            <div class="alert alert-warning">
                               @if($data['site_information']->supplier_handle)
                                    Microsoft Confidential components/products.
                               @else
                                    This supplier does not handle any Microsoft components/products.
                               @endif
                            </div>
                          </div>
                       </div>
                    </div>
                    <!-- /.col-lg-5 -->

                  </div>
              </div>
               <div class="panel-footer summary_footer">
                          <div class="clearfix">
                            <div class="pull-left">
                              {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }}
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Confirm', ['type' => 'submit', 'class' => 'btn btn-primary','id'=>'summaryform']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('sitemaster.index'),'id'=>'sitemaster_cancel']) }}
                            </div>
                          </div>
             </div>



            </div>
            <!-- /.panel-body -->
      </div>
         <!-- /.col-lg-12  -->
    </div>
    <!-- /.row  -->




        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<!--<script src="//js.api.here.com/ee/2.5.4/jsl.js?with=all" type="text/javascript" charset="utf-8"></script>-->
<script type="text/javascript" charset="utf-8" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
  var Sitemasters = {
    mapElement: 'sitemaster_map',
    coordinates: '{{$coordinates}} '
  };

  var incident_history_json = null;
  var incident_prevention_json = null;
  var business_activity = null;
  var business_assets = null;
  var business_lob = null;
  var business_risk = null;
  var business_actions= null;
  var leak_risk_analysis = null;
  var corrective_actions = null;
  var lp_corrective_actions = null;
  var accessname = null;
</script>
@stop
