@extends('layouts.master')

@section('content')
 
<script type="text/javascript">
    var Dashboard = {};
    Dashboard.userrole = '{{Auth::User()->role}}';
    Dashboard.audits = JSON.parse('{{ $audits }}');
    @if(Auth::User()->access_incidents)
    Dashboard.incidents = JSON.parse('{{ $incidents }}');
    Dashboard.incidentStatus = JSON.parse('{{ $incident_status }}');
    Dashboard.incidentCategory = JSON.parse('{{ $incident_category }}');
    @endif
    Dashboard.userStatus = JSON.parse('{{ $user_status }}');
    Dashboard.inspect_audit_status = {};
    Dashboard.incidentLsp = JSON.parse('{{ $incident_lsp }}');
    @if(\Auth::User()->isAdmin())
     // Dashboard.inspect_audit_status = JSON.parse('{{ $inspect_audit_status }}');
   @endif   

    
</script>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">Dashboard</h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    <div class="row">
          <div class="col-lg-8">
            <ul id="draggableLeftPanel" class="list-unstyled">

                    <!-- /.panel -->
             @if(isset($site_inspec_notification[0])    )
               @if(\Auth::User()->site_user_level == 'vam' &&  !empty(\Auth::User()->site_user_level) )
                <li  id="inspect_audit_status" class="panel panel-default" data-sort="{{ array_search('inspect_audit_status', $right_order) }}">
                    <div class="ibox animated flipInX ui-sortable-handle">
                        <div class="ibox-title">
                          <h5><i class="fa fa-table fa-fw"></i> <span class="font-bold">Inspection Status - VAM Approvals</span></h5>
                          <div class="ibox-tools">
                            <i class="fa fa-arrows"></i>
                          </div>
                        </div>
                        <div class="ibox-content">
                            <div class="panel-body vam_inspection_table">
                                 <table class="table table-hover ca_summary_tale table-bordered">
                                    <thead>
                                          <tr>
                                              <th>ID</th>
                                              <th>Site Name</th>
                                              <th>Reason request</th>
                                             <!--<th>CA completed</th>-->
                                              <th>% completed</th>
                                              <th>Total CAs </th>
                                              <th>Inspection Date</th>
                                           </tr>
                                    </thead>
                                    <tbody>
                                       @foreach($site_inspec_notification as $key=>$value)

                                              <tr class="clickable-row sitemasters-item" data-sid="{{$value['sitemaster_id']}}" data-uid="{{$value->siteinspectionsanswer['user_id'].'_'.$value['inspection_num'] }}">
                                                  <td>{{$value['sitemaster_id']}}</td>
                                                  <td title="{{$value->sitemaster['site_name']}}" class="ca_sitename">{{$value->sitemaster['site_name']}}</td>
                                                  <td>Closure request</td>
                                                 <!-- <td><span class="pie">{{$value['closed']}},{{$value['opens']}}</span></td>-->
                                                  <td>  <?php $a = $value['closed']/($value['closed'] + $value['opens'])*100;  echo floor($a)."%"; ?> <span class="pie">{{$value['closed']}},{{$value['opens']}}</span></td>
                                                  <td>  {{$value['closed'] + $value['opens']}}</td>  
                                                  <td>  {{($value->sitemaster['last_inspection_date'])?$value->sitemaster['last_inspection_date']->format('M/d/Y'):'NA'}}</td>
                                              </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                            </div> <!-- /.panel-body -->
                        </div> <!-- /.ibox-content -->
                    </div> 
                </li>
               @elseif(\Auth::User()->site_user_level == 'csm' )
                <li id="inspect_audit_status" class="panel panel-default" data-sort="{{ array_search('inspect_audit_status', $right_order) }}">
                     <div class="ibox animated flipInX ui-sortable-handle">
                        <div class="ibox-title">
                          <h5><i class="fa fa-table fa-fw"></i> <span class="font-bold"> Inspection Status - Request Due Date Extension</span></h5>
                          <div class="ibox-tools">
                            <i class="fa fa-arrows"></i>
                          </div>
                        </div>
                        <div class="ibox-content">
                            <div class="panel-body vam_inspection_table">
                                 <table class="table table-hover ca_summary_tale table-bordered">
                                    <thead>
                                          <tr>
                                              <th>ID</th>
                                              <th>Site Name</th>
                                              <th>Reason Request</th>
                                              <th>% Completed</th>
                                              <th>Next Scheduled Visit</th>
                                              <th>Remaining Time (in Days)</th>
                                           </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($site_inspec_notification as $key=>$value)
                                          @if($value['opens'] != 0) 
                                           <tr class="clickable-row" data-sid="{{$value['sitemaster_id']}}" data-uid="{{$value->siteinspectionsanswer['user_id'].'_'.$value['inspection_num'] }}">
                                                <td>{{$value['sitemaster_id']}}</td>
                                                <td>{{$value->sitemaster['site_name']}}</td>
                                                <td>Due Date Extension</td>
                                                <td> <?php $a = $value['closed']/($value['closed'] + $value['opens'])*100;  echo floor($a)."%"; ?>  <span class="pie">{{$value['closed']}},{{$value['opens']}}</span>  </td>
                                                <td> {{($value->sitemaster['next_site_visit'])? $value->sitemaster['next_site_visit']->format('Y-M-d'):'NA'}}</td>
                                                <td>  {{($value->sitemaster['next_site_visit'])? $value->sitemaster['next_site_visit']->diffInDays(\Carbon\Carbon::now()):'NA' }}</td>
                                            </tr>
                                           @endif
                                         @endforeach
                                    </tbody>
                                </table>
                            </div> <!-- /.panel-body -->
                        </div> <!-- /.ibox-content -->
                    </div> 
                 </li>
               @endif
             @endif  
              @if((Auth::User()->access_incidents || Auth::User()->isAdmin()  )  && ($incidents != '[]'))
              <li id="incident_trend" class="panel panel-default" data-sort="{{ array_search('incident_trend', $left_order) }}">
                <div class="ibox animated flipInX ui-sortable-handle">
                    <div class="ibox-title">
                      <h5><i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold">Incidents</span></h5>
                      <div class="ibox-tools">
                        <i class="fa fa-arrows"></i>
                      </div>
                    </div>
                    <div class="ibox-content">
                        <div class="panel-body">
                          
                              <div class="pull-right">
                                  <div class="btn-group inc-dash-date">
                                      {{Form::select('incidentcharttype' ,array('line'=>'Line','area'=>'Area','bar'=>'Bar'),'line',array('id'=>'incidentcharttype'))}}
                                      {{Form::select('incidenttype' ,array('number'=>'Number','value'=>'Value'),'default',array('id'=>'incidenttype'))}}
                                      {{--Form::select('incidentsdate' ,array('1#month'=>'1 Month','3#month'=>'3 Month','6#month'=>'6 Month','1#year'=>'1 Year'),'1#year',array('id'=>'incidentsdate'))--}}
                                      {{Form::select('incidentsdate' ,array('3#month'=>'3 Month','6#month'=>'6 Month','1#year'=>'1 Year'),'1#year',array('id'=>'incidentsdate'))}}
                                      {{--Form::select('fy_incident' ,json_decode($incidents)->fy_date,'',array('id'=>'fy_incident'))--}}
                                   </div>
                                   <div class="btn-group">
                                    <button type="button"  href="{{ route('incidents.index') }}" class="btn btn-xs btn-primary">View Incidents</button>
                                  </div>
                              </div>

                               <div id="incidents-area-chartdiv">
                                   <canvas id="incidents-area-chart"  height="140" ></canvas>
                               </div>
                    
                               <div id="incident_fy_slider"></div>
                        </div> <!-- /.panel-body -->
                    </div> <!-- /.ibox-content -->
                </div> 
              </li>
            @endif

           @if((Auth::user()->access_audits || Auth::User()->isAdmin()  )  && ($audits != '[]'))
              <!-- /.panel -->
              <li id="audit_trend" class="panel panel-default" data-sort="{{ array_search('audit_trend', $left_order) }}">

                  <div class="ibox animated flipInX ui-sortable-handle">
                    <div class="ibox-title">
                      <h5><i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold">Audits</span></h5>
                      <div class="ibox-tools">
                        <i class="fa fa-arrows"></i>
                      </div>
                    </div>
                    <div class="ibox-content">
                        <div class="panel-body">
                          
                              <div class="pull-right">
                                  <div class="btn-group inc-dash-date">
                                      {{Form::select('auditcharttype' ,array('line'=>'Line','area'=>'Area','bar'=>'Bar'),'line',array('id'=>'auditcharttype'))}}
                                      {{Form::select('auditdate' ,array('3#month'=>'3 Month','6#month'=>'6 Month','1#year'=>'1 Year'),'1#year',array('id'=>'auditdate'))}}
                                   </div>
                                   <div class="btn-group">
                                    <button type="button"  href="{{ action('AuditsController@getIndex') }}" class="btn btn-xs btn-primary">View Audits</button>
                                  </div>
                              </div>

                              <div id="audits-area-chartdiv">
                                    <canvas id="audits-area-chart"  height="140"></canvas>
                              </div>
                              <div id="audit_fy_slider"></div>

                        </div> <!-- /.panel-body -->
                    </div> <!-- /.ibox-content -->
                  </div>
                  <!-- /.ibox  -->
              </li>
              <!-- /.panel -->
            @endif
             <!-- /. Panel Recent user Result -->
              @if(\Auth::User()->isAdmin())
               <li id="recent_users" class="panel panel-default" data-sort="{{ array_search('recent_users', $left_order) }}">
                   <div class="ibox animated flipInX">
                      <div class="ibox-title">
                        <h5><i class="fa fa-list-alt fa-fw"></i> <span class="font-bold">Recent Users</span></h5>
                        <div class="ibox-tools">
                          <i class="fa fa-arrows"></i>
                        </div>

                      </div>
                      <div class="ibox-content">
                          <div class="panel-body">
                              <div class="pull-right">
                                   <div class="btn-group">
                                     <button type="button" class="btn btn-primary btn-xs" href="{{ route('users.index') }}">View Users</button>
                                  </div>
                              </div>
                              <div class="row">
                                <div class="col-lg-12">
                                   <div class="list-group">
                                        @foreach($recent_users as $user)
                                        <a href="{{ route('users.edit', $user->user_id) }}" class="list-group-item">
                                            <i class="fa fa-user fa-fw"></i> <small>{{ $user->user->name }}</small>
                                            <span class="pull-right text-muted small"><em>{{ $user->login }}</em>
                                            </span>
                                        </a>
                                        @endforeach
                                    </div><!-- /.list-group -->
                                </div>
                              </div>                                  
                          </div> <!-- /.panel-body -->
                      </div> <!-- /.ibox-content -->
                  </div>
 
               </li>
               <!-- /.panel -->
               @endif
              <!-- /. Panel Recent user Result -->

               <!-- /. Panel CA Summary Result -->
               @if(\Auth::User()->site_user_level == 'vam' ||  \Auth::User()->site_user_level == 'csm' || Auth::User()->isAdmin()) 
               <li id="ca_summary" class="panel panel-default"  data-sort="{{array_search('ca_summary', $left_order)}}">
                  <div class="ibox animated flipInX">
                    <div class="ibox-title">
                      <h5><i class="fa fa-table fa-fw"></i> <span class="font-bold">CA Summary</span></h5>
                      <div class="ibox-tools">
                        <i class="fa fa-arrows"></i>
                      </div>
                    </div>
                    <div class="ibox-content">
                        <div class="panel-body">
                             <table class="table table-hover ca_summary_tale table-bordered">
                                <thead>
                                      <tr>
                                          <th width="35%">Site Name</th>
                                          <th>Open CA</th>
                                          <th>Overdue CAs</th>
                                          <th>Total CAs</th>
                                          <th>Inspection result</th>
                                          <th>Inspection date</th>
                                       </tr>
                                </thead>
                                <tbody>
                                   @foreach($site_ca_summary as $ky=>$val)
                                      <tr data-sid="{{$val['sitemaster_id']}}" data-uid="{{$val['inspector_user_id'].'_'.$val['inspection_num']}}"  >
                                          <td title="{{$val['site_name']}}" class="ca_sitename">{{$val['site_name']}}</td>
                                          <td>{{$val['total_open_ca']+$val['over_due_cas']}}</td>
                                          <td>{{$val['over_due_cas']}}</td>
                                          <td>{{$val['total_ca']}}</td>
                                         <td>{{$val['inspection_result']}}</td>
                                          <td>{{date('M/d/Y',strtotime($val['ins_main_date']))}}</td>
                                      </tr>
                                   @endforeach 
                                </tbody>
                            </table>
                        </div> <!-- /.panel-body -->
                    </div> <!-- /.ibox-content -->
                  </div> 
               </li>
               @endif
                <!-- /. Panel CA Summary Result -->
            </ul>
        </div>
        <!-- /.col-lg-8 -->
        <div class="col-lg-4">
            <ul id="draggableRightPanel" class="list-unstyled">
             
              <!-- /.panel -->  
              @if((Auth::user()->access_incidents || Auth::User()->isAdmin()) && ($incident_status != '[]'))
              <li id="incident_status" class="panel panel-default" data-sort="{{ array_search('incident_status', $right_order) }}">
                  
                  <div class="ibox animated flipInX">
                    <div class="ibox-title">
                      <h5><i class="fa fa-pie-chart fa-fw"></i> <span class="font-bold">Incident Status</span></h5>
                      <div class="ibox-tools">
                        <div class="btn-group">
                                      {{Form::select('fy_inc_status' ,array('2012'=>'FY12','2013'=>'FY13','2014'=>'FY14','2015'=>'FY15','2016'=>'FY16',),'2016',array('id'=>'fy_inc_status'))}}
                        </div>
                        <i class="fa fa-arrows"></i>
                      </div>
                    </div>
                    <div class="ibox-content">
                        <div class="panel-body">
                                
                               <div id="incident-status-donut-chart"></div>

                               <a class="btn btn-primary btn-block" href="{{ route('incidents.index') }}">View Details</a>
                        </div> <!-- /.panel-body -->
                    </div> <!-- /.ibox-content -->
                  </div>

 
                  <!-- /.panel-body -->
              </li>
              @endif
              @if((Auth::user()->access_incidents || Auth::User()->isAdmin())  && ($incident_lsp != '[]'))
              <li id="incident_lsp" class="panel panel-default" data-sort="{{ array_search('incident_lsp', $right_order) }}">
                  <div class="ibox animated flipInX">
                    <div class="ibox-title">
                      <h5><i class="fa fa-pie-chart fa-fw"></i> <span class="font-bold">Incident LSP</span></h5>
                      <div class="ibox-tools">
                        <div class="btn-group">
                               {{Form::select('incidenttype_lsp' ,array('number'=>'Number','value'=>'Value'),'default',array('id'=>'incidenttype_lsp'))}}
                               {{Form::select('fy_incident_lsp' ,array('2012'=>'FY12','2013'=>'FY13','2014'=>'FY14','2015'=>'FY15','2016'=>'FY16',),'2016',array('id'=>'fy_inc_lsp'))}}
                        </div>
                        <i class="fa fa-arrows"></i>
                      </div>
                    </div>
                    <div class="ibox-content">
                        <div class="panel-body">
                                
                                 <div id="incident-lsp-donut-chart"></div>

                               <a class="btn btn-primary btn-block" href="{{ route('incidents.index') }}">View Details</a>
                        </div> <!-- /.panel-body -->
                    </div> <!-- /.ibox-content -->
                  </div>
                  <!-- /.panel-body -->
              </li>
              @endif
              <!-- /.panel -->
              @if((Auth::user()->access_incidents || Auth::User()->isAdmin() )  && ($incident_category != '[]'))
              <li id="incident_category" class="panel panel-default" data-sort="{{ array_search('incident_category', $right_order) }}">
                  <div class="ibox animated flipInX">
                    <div class="ibox-title">
                      <h5><i class="fa fa-pie-chart fa-fw"></i> <span class="font-bold">Incident Category</span></h5>
                      <div class="ibox-tools">
                        <div class="btn-group">
                               {{Form::select('fy_incident_category' ,array('2012'=>'FY12','2013'=>'FY13','2014'=>'FY14','2015'=>'FY15','2016'=>'FY16',),'2016',array('id'=>'fy_incident_category'))}}
                        </div>
                        <i class="fa fa-arrows"></i>
                      </div>
                    </div>
                    <div class="ibox-content">
                        <div class="panel-body">
                                
                                <div id="incident-category-donut-chart"></div>

                               <a class="btn btn-primary btn-block" href="{{ route('incidents.index') }}">View Details</a>
                        </div> <!-- /.panel-body -->
                    </div> <!-- /.ibox-content -->
                  </div>
                  <!-- /.panel-body -->
              </li>
              <!-- /.panel -->
            @endif

               <!-- /.panel -->
              @if(\Auth::User()->isAdmin())
                <li id="user_status" class="panel panel-default" data-sort="{{ array_search('user_status', $right_order) }}">
                    <div class="ibox animated flipInX">
                        <div class="ibox-title">
                          <h5><i class="fa fa-pie-chart fa-fw"></i> <span class="font-bold"> User Status</span></h5>
                          <div class="ibox-tools">
                            <i class="fa fa-arrows"></i>
                          </div>
                        </div>
                        <div class="ibox-content">
                            <div class="panel-body">
                                   <div id="user-status-donut-chart"></div>
                                   <a class="btn btn-primary btn-block" href="{{ route('users.index') }}">View Details</a>
                            </div> <!-- /.panel-body -->
                        </div> <!-- /.ibox-content -->
                    </div>
                    <!-- /.panel-body -->
                </li>
              @endif

              @if((Auth::user()->access_incidents || Auth::user()->access_audits || Auth::User()->isAdmint()) && !empty($alerts))
              <li id="recent_audits" class="panel panel-default" data-sort="{{ array_search('recent_audits', $right_order) }}">
                   <div class="ibox animated flipInX">
                        <div class="ibox-title">
                          <h5><i class="fa fa-bullhorn fa-fw"></i> <span class="font-bold">Recent Activity</span></h5>
                          <div class="ibox-tools">
                            <i class="fa fa-arrows"></i>
                          </div>
                        </div>
                        <div class="ibox-content">
                            <div class="panel-body recent-audits">
                                   <div id="alerts-box" class="list-group">
                                        @foreach($alerts as $alert)
                                        <div class="timeline-item">
                                            <div class="row">
                                            <a href="{{ $alert['url'] }}">
                                                <div class="col-xs-3 date">
                                                    <i class="fa fa-file-text"></i>
                                                    {{ $alert['date'] }}                                                
                                                </div>
                                                <div class="col-xs-7 content" style="border-left: 1px solid #e7eaec;">
                                                  <p class="m-b-xs" style=' text-transform: capitalize;'><strong>{{ $alert['type'] }}</strong><br/>
                                                    {{ $alert['text'] }}</p>
                                                </div>
                                              </a>
                                            </div>
                                        </div>
                                        @endforeach
                                    </div> 
                                   <a class="btn btn-primary btn-block"  href="javascript:void(0);" id="more-alerts" >View Older Alerts</a>
                            </div> <!-- /.panel-body -->
                        </div> <!-- /.ibox-content -->
                    </div>

                   
              </li> <!---->
              @endif
              <!-- /.panel -->
            </ul>
        </div>
        <!-- /.col-lg-4 -->
    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->

@stop