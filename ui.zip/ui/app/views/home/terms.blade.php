@extends('layouts.master')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-6 col-md-offset-3">
            <div class="privacy-panel panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">Terms and conditions</h3>
                </div>
                <div class="panel-body">
                    @if($errors->all())
                    <div id="form-errors" class="alert alert-danger" role="alert">
                      <ul>
                        @foreach($errors->all() as $error)
                          <li>{{ $error }}</li>
                        @endforeach
                      </ul>
                    </div>
                    @endif

                    {{ Form::open(['action' => 'HomeController@postTerms', 'method' => 'post']) }}
                        <div>
                            <div class="form-group">
                            To use the service, you need to read and agree to the Privacy Policy<br />
                            Read the privacy policy <a href="http://microsoft.com/mobile/privacy" target="_blank">here</a>
                            </div>
                            <div class="form-group">
                            {{ Form::checkbox('agree', 1, false) }} I agree to the privacy policy
                            </div>
                            {{ Form::button('Accept', ['type' => 'submit', 'class' => 'btn btn-md btn-success']) }}
                            {{ Form::button('Reject', ['type' => 'button', 'class' => 'btn btn-md', 'href' => '/logout']) }}
                        </div>
                        {{ Form::token() }}
                    {{ Form::close() }}
                </div>
            </div>
        </div>
    </div>
</div>
@stop