@extends('layouts.master')

<?php $has_password = \MSLST\Helpers\Common::hasPassword(Request::segment(2)); ?>

@section('content')

<div class="loginColumns animated fadeInDown">
            <div class="row">

                <div class="col-md-3"></div>
                <div class="col-md-6">
                    <div class="ibox-content">
                        <h2>
                             @if($has_password)
                                Password recovery 
                             @else
                                 Create Password
                             @endif
                        </h2>

                        @if(Session::get('error'))
                        <div id="form-errors" class="alert alert-danger" role="alert">
                            <span>
                                {{ trans(Session::get('error')) }}
                            </span>
                        </div>
                        <!-- end form-errors -->
                        @endif

                        <div class="bs-callout bs-callout-warning">
                            <h4>Password Policy</h4>
                            <ul>
                                <li>Must have at least 8 characters</li>
                                <li>Must contain lowercase and uppercase characters: A-Z, a-z</li>
                                <li>Must contain digits: 0-9</li>
                                <li>Must contain a special character: `!@#$%^&amp;*()_+{}:"|&lt;&gt;>?/.,\'][=-</li>
                            </ul>
                        </div>

                        {{ Form::open(['route' => 'password.update', 'method' => 'put', 'autocomplete' => 'off']) }}
                            <fieldset>
                                <div class="form-group">
                                {{ Form::email('email', '', ['class' => 'form-control', 'placeholder' => 'Please insert your email address', 'autofocus' => 'autofocus', 'autocomplete' => 'off']) }}
                                </div>
                                <div class="form-group">
                                {{ Form::password('password', ['class' => 'form-control', 'placeholder' => 'Please insert your new password', 'autocomplete' => 'off']) }}
                                </div>
                                <div class="form-group">
                                {{ Form::password('password_confirmation', ['class' => 'form-control', 'placeholder' => 'Please confirm your new password', 'autocomplete' => 'off']) }}
                                </div>
                                @if($has_password)
                                    {{ Form::button('Reset', ['type' => 'submit', 'class' => 'btn btn-success btn-block']) }}
                                @else
                                    {{ Form::button('Activate account', ['type' => 'submit', 'class' => 'btn btn-primary full-width m-b']) }}
                                @endif
                            </fieldset>
                            {{ Form::hidden('token', $token) }}
                            {{ Form::token() }}
                        {{ Form::close() }}
                    </div>
                </div>
            </div>

</div>


@stop