@extends('layouts.master')

@section('content')


<div class="UserRequestAccesscolumns animated fadeInDown">
            <div class="row">
                <div class="col-md-12">
                     <div class="ibox">
                          <div class="ibox-title">
                            <h5>User Access Request</h5>
                            <div class="ibox-tools">
                                   {{ HTML::link('/', 'Back to login') }}
                            </div>
                          </div>
              <div class="ibox-content">
                <div class="panel-heading">
                   @if($errors->all())
                            <div id="form-errors" class="alert alert-danger" role="alert">
                              <ul>
                                @foreach($errors->all() as $error)
                                  <li>{{ $error }}</li>
                                @endforeach
                              </ul>
                            </div>
                        @elseif(Session::has('success'))
                          <div id="form-success" class="alert alert-success" role="alert">
                              <span>
                                  {{ trans(Session::get('success')) }}
                              </span>
                          </div>
                        <!-- end form-errors -->
                  @endif
                  <div class="pull-right">
                   (*) Mandatory Field
                  </div>
                </div>
                <!-- /.panel-heading -->

               <div class="panel-body">
                        
                        
                        {{ Form::open(['route' => 'accessrequest_store', 'method' => 'post', 'autocomplete' => 'off']) }}
                            <?php $supplier_type=["ADC (Authorized Destruction Center)"=>"ADC (Authorized Destruction Center)","ADP (Authorized Disk Provider)"=>"ADP (Authorized Disk Provider)","AR (Authorized Replicator)"=>"AR (Authorized Replicator)","ARC (Authorized Returns Center)"=>"ARC (Authorized Returns Center)","Authorized Merchant (on-line digital delivery, only)"=>"Authorized Merchant (on-line digital delivery, only)","Authorized Refurbished"=>"Authorized Refurbished","Carrier /Freight forwarder /LSP"=>"Carrier /Freight forwarder /LSP","CRC (COA Return Center)"=>"CRC (COA Return Center)","DTV (Distribution Turnkey Vendor)"=>"DTV (Distribution Turnkey Vendor)","Fulfillment Center"=>"Fulfillment Center","MTV (Manufacturing Turnkey Vendor)"=>"MTV (Manufacturing Turnkey Vendor)","SPV (Secure Print Vendor)"=>"SPV (Secure Print Vendor)","Subcontractor"=>"Subcontractor","Other"=>"Other"]; ?>
                            <div class="col-lg-6">
                              <div class="form-group row">
                                {{ Form::label('first_name', 'First Name *', ['class' => 'col-lg-4 control-label required']) }}
                                <div class="col-lg-6">
                                  {{ Form::text('first_name', '', ['class' => 'form-control']) }}
                                </div>
                              </div>
                              <div class="form-group row">
                                {{ Form::label('last_name', 'Last Name *', ['class' => 'col-lg-4 control-label required']) }}
                                <div class="col-lg-6">
                                  {{ Form::text('last_name', '', ['class' => 'form-control']) }}
                                </div>
                              </div>
                              <div class="form-group row">
                                {{ Form::label('company_name', 'Company Name *', ['class' => 'col-lg-4 control-label required']) }}
                                <div class="col-lg-6">{{ Form::text('company_name', '', ['class' => 'form-control']) }}
                                </div>
                              </div>
                              <div class="form-group row">
                                {{ Form::label('addressline1', 'Address Line 1', ['class' => 'col-lg-4 control-label']) }}
                                <div class="col-lg-6">{{ Form::text('addressline1', '', ['class' => 'form-control']) }}
                                </div>
                              </div>
                              <div class="form-group row">
                                {{ Form::label('addressline2', 'Address Line 2', ['class' => 'col-lg-4 control-label']) }}
                                <div class="col-lg-6"> {{ Form::text('addressline2', '', ['class' => 'form-control']) }}
                                </div>
                              </div>
                             <div class="form-group row">
                                {{ Form::label('city', 'City', ['class' => 'col-lg-4 control-label']) }}
                                <div class="col-lg-6"> {{ Form::text('city', '', ['class' => 'form-control']) }}
                                </div>
                              </div>
                              <div class="form-group row">
                                {{ Form::label('country', 'Country', ['class' => 'col-lg-4 control-label']) }}
                                <div class="col-lg-6"> {{ Form::text('country', '', ['class' => 'form-control']) }}
                                </div>
                              </div>
                              
                            </div>
                            <div class="col-lg-6">
                              <div class="form-group row">
                                {{ Form::label('email', 'Email *', ['class' => 'col-lg-4 control-label required']) }}
                                <div class="col-lg-6"> {{ Form::text('email', '', ['class' => 'form-control']) }}
                                </div>
                              </div>
                              <div class="form-group row">
                                {{ Form::label('microsoft_contact', 'Microsoft Contact *', ['class' => 'col-lg-4 control-label required']) }}
                                <div class="col-lg-6">{{ Form::text('microsoft_contact', '', ['class' => 'form-control']) }}
                                </div>
                              </div>
                              
                              <div class="form-group row">
                                {{ Form::label('microsoft_contact_email', 'Microsoft Contact Email *', ['class' => 'col-lg-4 control-label required']) }}
                                <div class="col-lg-6">{{ Form::text('microsoft_contact_email', '', ['class' => 'form-control']) }}
                                </div>
                              </div>
                              <!--div class="form-group row">
                                {{ Form::label('supplier_type', 'Supplier Type', ['class' => 'col-lg-4 control-label required']) }}
                                <div class="col-lg-6">{{ Form::select('supplier_type[]',$supplier_type,'', ['class' => 'form-control','multiple' => 'Multiple']) }}
                                  <div class="other_supplier_type">{{ Form::text('othersupplier_type', '', ['class' => 'form-control']) }}</div>
                                  is_array($data->supplier_type)?$data->supplier_type:json_decode($data->supplier_type)
                                </div>
                              </div-->
                              <div class="form-group row">
                                    {{ Form::label('supplier_type', 'Supplier Type *', ['class' => 'col-lg-4 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::select('supplier_type[]',$supplier_type,'', ['class' => 'form-control bus_assests_sel selectpicker','multiple' => 'Multiple','title'=>'Select Supplier Type']) }}
                                    </div>
                                  </div>
                                   <div class="form-group row" id="supplier_type_other_type_id">
                                    {{ Form::label('supplier_other_type', 'Supplier Other Type *', ['class' => 'col-lg-4 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('supplier_other_type','', ['class' => 'form-control','maxlength'=>250]) }}
                                    </div>
                                  </div>
                              
                            <div class="form-group row">
                                <div class="col-lg-3">
                                {{ Form::button('Submit', ['type' => 'submit', 'class' => 'btn btn-primary btn-block']) }}
                              </div>
                            </div>
                            </div>
                            {{ Form::token() }}
                        {{ Form::close() }}   
                    </div>

                <!-- /.panel-body -->
              </div>
 </div>
                </div>
            </div>

</div>


@stop