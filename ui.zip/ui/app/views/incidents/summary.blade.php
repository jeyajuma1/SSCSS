@extends('layouts.master')

@section('content')
<div id="page-wrapper">
      <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
                Summary
            </h1>
        </div>
      </div>
      <!-- /.row -->
           <!-- /.row -->
    <div class="row">
      <!-- /.col-lg-12 -->
      <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"><h4>Data not yet saved. Please review the information and confirm once done.</h4></div>
            </div>
            {{ Form::open(['route' => 'incidents.store', 'method' => 'post', 'class' => 'incident-form', 'role' => 'form', 'id' => 'form-summary', 'files' => true]) }}
            {{ Form::hidden('step', 4) }}
              <div class="panel-body">
                   <!-- /.row -->

                  <div class="row incident-show">
                    <div class="col-lg-8">
                       <div class="panel panel-default">
                          <div class="panel-heading">
                              <i class="fa fa-bar-chart-o fa-fw"></i> Basic Information
                              <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('incidents.create', 0) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                          </div>
                          <!-- /.panel-heading -->
                          <div class="panel-body">
                            <div class="table-responsive">
                              <table class="table">
                                  <tbody>
                                      <tr>
                                          <td>
                                              <b>Description</b><br />
                                              <p>{{ $data['basic_information']->short_description }}</p>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                            <table class="incidents-basic-table">
                                              <tbody>
                                                <tr>
                                                  <td><b>Type of Loss</b></td>
                                                  <td><b>Category</b></td>
                                                  <td><b>Facility</b></td>
                                                </tr>
                                                <tr>
                                                  <td>
                                                  @if($data['basic_information']->type_of_loss == 'Other' && (!empty($data['basic_information']->type_of_other_loss)))
                                                             {{ $data['basic_information']->type_of_other_loss }}
                                                  @else
                                                              {{ $data['basic_information']->type_of_loss }}
                                                  @endif
                                                </td>
                                                  <td>{{$category}}</td>
                                                  <td>{{ $data['basic_information']->facility }}</td>
                                                </tr>
                                                <tr>
                                                  <td><b>Incident Date</b></td>
                                                  <td><b>Country</b></td>
                                                  <td><b>City</b></td>
                                                </tr>
                                                <tr>
                                                  <td>{{ $data['basic_information']->incident_date }}</td>
                                                  <td>{{ $country[$data['basic_information']->country] }}</td>
                                                  <td>{{ $data['basic_information']->location_city }}</td>
                                                </tr>
                                                <tr>
                                                  <td><b>Address</b></td>
                                                  <td colspan="2"><b>GPS Coordinates</b></td>
                                                </tr>
                                                <tr>
                                                  <td>{{ $data['basic_information']->location_address }}</td>
                                                  <td colspan="2">{{  $data['basic_information']->coordinates }}</td>
                                                </tr>
                                              </tbody>
                                            </table>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                              <div id="incident_map" class="detail-view-map span12 col-sm-12">
                                              </div>
                                          </td>
                                      </tr>
                                  </tbody>
                              </table>
                             </div>
                          </div>
                            <!-- /.panel-body -->
                       </div>
                       <!-- /.panel -->
                       <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bar-chart-o fa-fw"></i> Customer/Transportation
                                <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('incidents.create', 1) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table">
                                        <tbody>
                                            <tr class="active">
                                                <td colspan="3"><b>Customer details</b></td>
                                            </tr>
                                            <tr>
                                                <td><b>Consignee</b></td>
                                                <td><b>Customer</b></td>
                                                <td><b>Delivery note number</b></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                @if(!empty($data['customer_transportation']->consignee))
                                                   {{$data['customer_transportation']->consignee}}
                                                @else
                                                   NA
                                                @endif
                                                </td>
                                                <td>
                                                @if(!empty($data['customer_transportation']->customer))
                                                   {{$data['customer_transportation']->customer}}
                                                @else
                                                   NA
                                                @endif
                                                </td>
                                                <td> 
                                                @if(!empty($data['customer_transportation']->delivery_note_number))
                                                   {{$data['customer_transportation']->delivery_note_number}}
                                                @else
                                                   NA
                                                @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="3"><b>CMR</b></td>
                                            </tr>
                                            <tr>
                                                <td colspan="3"> 
                                                @if(!empty($data['customer_transportation']->cmr))
                                                   {{$data['customer_transportation']->cmr}}
                                                @else
                                                   NA
                                                @endif
                                                </td>
                                            </tr>
                                           <tr>
                                                <td colspan="3">&nbsp;</td>
                                            </tr>
                                            <tr class="active">
                                                <td colspan="3"><b>Transportation details</b></td>
                                            </tr>
                                            <tr>
                                                <td><b>Pick Up from Origin (Date &amp; Time)</b></td>
                                                <td><b>Location of the incident's reporting</b></td>
                                                <td><b>Driver name</b></td>
                                            </tr>
                                            <tr>
                                                <td>{{ $data['customer_transportation']->pickup_date }} , {{ $data['customer_transportation']->pickup_time }}</td>
                                                <td> 
                                                @if(!empty($data['customer_transportation']->location_of_reporter))
                                                   {{$data['customer_transportation']->location_of_reporter}}
                                                @else
                                                   NA
                                                @endif
                                                </td>
                                                <td>
                                                @if(!empty($data['customer_transportation']->driver_name))
                                                   {{$data['customer_transportation']->driver_name}}
                                                @else
                                                   NA
                                                @endif</td>
                                            </tr>
                                            <tr>
                                                <td><b>Transportation vehicle's details</b></td>
                                                <td><b>Carriers and contractors involved</b></td>
                                                <td><b>Routing</b></td>
                                            </tr>
                                            <tr>
                                                <td> 
                                                @if(!empty($data['customer_transportation']->vehicle_details))
                                                   {{$data['customer_transportation']->vehicle_details}}
                                                @else
                                                   NA
                                                @endif
                                                </td>
                                                <td> 
                                                @if(!empty($data['customer_transportation']->carriers_and_contractors))
                                                   {{$data['customer_transportation']->carriers_and_contractors}}
                                                @else
                                                   NA
                                                @endif
                                                </td>
                                                <td>
                                                 @if(!empty($data['customer_transportation']->routing))
                                                   {{$data['customer_transportation']->routing}}
                                                @else
                                                   NA
                                                @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>Airline</b></td>
                                                <td><b>HAWB</b></td>
                                                <td><b>MAWB</b></td>
                                            </tr>
                                            <tr>
                                                <td> 
                                                @if(!empty($data['customer_transportation']->airline))
                                                   {{$data['customer_transportation']->airline}}
                                                @else
                                                   NA
                                                @endif
                                               </td>
                                                <td>
                                                @if(!empty($data['customer_transportation']->hawb))
                                                   {{$data['customer_transportation']->hawb}}
                                                @else
                                                   NA
                                                @endif
                                              </td>
                                                <td>
                                                @if(!empty($data['customer_transportation']->mawb))
                                                   {{$data['customer_transportation']->mawb}}
                                                @else
                                                   NA
                                                @endif
                                                </td>
                                            </tr>
                                            <tr>
                                                <td ><b>Originating Facility</b></td>
                                                <td ><b>Destination Facility</b></td>
                                                <td ><b>Methods Of Transportation</b></td>
                                            </tr>
                                            <tr>
                                                <td>{{ $data['customer_transportation']->originating_facility }}</td>
                                                <td>{{ $data['customer_transportation']->destination_facility }}</td>
                                                <td>{{ $data['customer_transportation']->method_of_transportation }}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                 </div>
                            </div>
                            <!-- /.panel-body -->
                       </div>
                       <!-- /.panel -->

                       <div class="panel panel-default">
                          <div class="panel-heading">
                              <i class="fa fa-bar-chart-o fa-fw"></i> Units/Investigation
                              <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('incidents.create', 2) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                          </div>
                          <!-- /.panel-heading -->
                          <div class="panel-body">
                              <div class="table-responsive">
                                  <table class="table">
                                      <tbody>
                                          <tr class="active">
                                              <td colspan="3"><b>Details of units missing</b></td>
                                          </tr>
                                          <tr>
                                              <td><b>Type Of Device</b></td>
                                          </tr>
                                          <tr>
                                            <td>
                                              @if(!empty($data['units_investigation']->type_of_other_device))
                                                 {{ $data['units_investigation']->type_of_other_device }}  
                                              @else
                                                 {{implode(', ',$data['units_investigation']->type_of_device)}} 
                                              @endif
                                            </td>
                                          </tr>
                                          <tr>
                                              <td><b>Product/item Description</b></td>
                                              <td><b>Number of Units Missing</b></td>
                                              <td><b>Value per Unit (USD)</b></td>
                                          </tr>
                                          @foreach(range(0,count($data['units_investigation']->product_description)-1) as $ky=>$val)
                                            <?php
                                                $products[$ky]['description'] = $data['units_investigation']->product_description[$ky];
                                                $products[$ky]['units']       = $data['units_investigation']->number_of_units_missing[$ky];
                                                $products[$ky]['value']       = !empty($data['units_investigation']->value_per_unit[$ky])?$data['units_investigation']->value_per_unit[$ky]:"NA";
                                            ?>
                                          @endforeach

                                          @foreach($products as $ky=>$product)
                                          <tr>
                                              <td style="border: 1px solid #ccc">{{ $product['description'] }}</td>
                                              <td style="border: 1px solid #ccc">{{ $product['units'] }}</td>
                                              <td style="border: 1px solid #ccc">{{ $product['value'] }}</td>
                                          </tr>
                                          @endforeach

                                          <tr>
                                              <td><b>Number of Plts/Crts Missing</b></td>
                                              <td class="text-danger"  colspan="2"><b>Total Value of lost Units (USD)</b></td>
                                          </tr>
                                          <tr>
                                              <td>
                                                @if(!empty($data['units_investigation']->number_of_plts_missing))
                                                   {{$data['units_investigation']->number_of_plts_missing}}
                                                @else
                                                   NA
                                                @endif
                                              </td>
                                              <td class="text-danger"  colspan="2">
                                                @if(!empty($data['units_investigation']->total_value_of_lost_units))
                                                   {{$data['units_investigation']->total_value_of_lost_units}}
                                                @else
                                                   NA
                                                @endif
                                              </td>
                                          </tr>
                                          <tr>
                                             <td colspan="3">&nbsp;</td>
                                        </tr>
                                          <tr class="active">
                                              <td colspan="3"><b>Official investigation details</b></td>
                                          </tr>
                                          <tr>
                                              <td><b>The name of the investigation authority</b></td>
                                              <td colspan="2"><b>The investigation file number</b></td>
                                          </tr>
                                          <tr>
                                              <td>
                                                @if(!empty($data['units_investigation']->name_of_investigation_authority))
                                                   {{$data['units_investigation']->name_of_investigation_authority}}
                                                @else
                                                   NA
                                                @endif
                                              </td>
                                              <td colspan="2">
                                                @if(!empty($data['units_investigation']->investigation_file_number))
                                                   {{$data['units_investigation']->investigation_file_number}}
                                                @else
                                                   NA
                                                @endif
                                              </td>
                                          </tr>
                                          <tr>
                                              <td colspan="3"><b>DQI Number</b></td>
                                          </tr>
                                          <tr>
                                              <td colspan="3">
                                                  @if(!empty($data['units_investigation']->dq))
                                                     {{$data['units_investigation']->dq}}
                                                  @else
                                                     NA
                                                  @endif
                                              </td>
                                          </tr>
                                          <tr>
                                              <td colspan="3"><b>First Findings, Lessons learned, Short Term Actions, Loss Type (Pilferage, Theft, Robbery, etc.)</b></td>
                                          </tr>
                                          <tr>
                                              <td colspan="3"> 
                                                @if(!empty($data['units_investigation']->first_findings))
                                                   {{$data['units_investigation']->first_findings}}
                                                @else
                                                   NA
                                                @endif
                                              </td>
                                          </tr>
                                          <tr>
                                              <td colspan="3"><b>Final investigation findings, root cause analysis & long term corrective actions</b></td>
                                          </tr>
                                          <tr>
                                              <td colspan="3">
                                                @if(!empty($data['units_investigation']->final_investigation_findings))
                                                   {{$data['units_investigation']->final_investigation_findings}}
                                                @else
                                                   NA
                                                @endif
                                              </td>
                                          </tr>
										                      <tr>
                                              <td colspan="3"><b>Contact information for the investigating law enforcement agency</b></td>
                                          </tr>
                                          <tr>
                                              <td colspan="3">
                                                @if(!empty($data['units_investigation']->contact_information))
                                                   {{$data['units_investigation']->contact_information}}
                                                @else
                                                   NA
                                                @endif
                                              </td>
                                          </tr>
                                      </tbody>
                                  </table>
                               </div>
                          </div>
                          <!-- /.panel-body -->
                       </div>
                       <!-- /.panel -->
                    </div>
                       <!-- /.col-lg-8 -->
                    <div class="col-lg-4">
                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bar-chart-o fa-fw"></i> Attachments
                                <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('incidents.create', 3) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                            </div>
                            <div class="panel-body">
                                <div class="table-responsive">
                                       <table class="table">
                                        <tbody>
                                        @if(!empty($data['attachments']->attachment))
                                            <tr>
                                                <td ><b> Other Attachment</b></td>
                                            </tr>
                                             @foreach($data['attachments']->attachment as $key=>$attachment)   
                                              <tr>                 
                                                <td>
                                                  {{ str_limit($attachment['file_description'], 40) }}<br/>
                                                  <span>{{ $data['attachments']->description[$key] }}</span>
                                                </td>
                                               </tr>
                                              @endforeach
                                            @else
                                              <tr>
                                                <td>No attachments.</td>
                                              </tr>
                                         @endif
                                        <tr>
                                          <td><b>IMEI List</b></td>
                                        </tr>
                                        <tr>
                                         <td>
                                            @if(!empty($data['attachments']->imei_list['file_description']))
                                            {{$data['attachments']->imei_list['file_description']}}
                                            @else
                                             NA
                                            @endif
                                          </td>
                                        </tr>
                                         <tr>
                                          <td><b> S/N List</b></td>
                                        </tr>
                                        <tr>
                                          <td>
                                            @if(!empty($data['attachments']->sn_list['file_description']))
                                            {{$data['attachments']->sn_list['file_description']}}
                                             @else
                                             NA
                                            @endif
                                          </td>
                                        </tr>
                                           
                                        </tbody>
                                    </table>
                                 </div>
                            </div>
                            <!-- /.panel-body -->
                        </div>
                    </div>

                  </div>
              </div>
               <div class="panel-footer summary_footer">
                          <div class="clearfix">
                            <div class="pull-left">
                             <!-- {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }} -->
                                <a href="{{'3'}}" class ='btn btn-default' alt='Back'>Back</a>
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Confirm', ['type' => 'submit', 'class' => 'btn btn-primary','id'=>'summaryform']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.index'),'id'=>'incident_cancel']) }}
                            </div>
                          </div>
             </div>



            </div>
            <!-- /.panel-body -->
      </div>
         <!-- /.col-lg-12  -->
    </div>
    <!-- /.row  -->




        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<!-- <script src="//js.api.here.com/ee/2.5.4/jsl.js?with=all" type="text/javascript" charset="utf-8"></script> -->
<script type="text/javascript" charset="utf-8" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
  var Incidents = {
    mapElement: 'incident_map',
    coordinates: '{{ $data["basic_information"]->coordinates }}'
  };
</script>
@stop
