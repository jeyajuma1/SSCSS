@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Incident</h1>
                @else
                  <h1 class="page-header">Create Incident</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Attachments</div>
                    {{ Form::open(['route' => ($edit ? ['incidents.update', $data->id] : 'incidents.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'incident-form', 'role' => 'form', 'id' => 'incident-form-attachments', 'files' => true]) }}
                        {{ Form::hidden('step', 3) }}
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard">
                                    <a>
                                      <span>Basic Information</span>
                                    </a>
                                    <a>
                                      <span>Customer/Transportation</span>
                                    </a>
                                    <a>
                                      <span>Units/Investigation</span>
                                    </a>
                                    <a class="current">
                                      <span>Attachments</span>
                                    </a>
                                  </div>


                                  @if($errors->all())
                                    <div id="form-errors" class="alert alert-danger" role="alert">
                                      <ul>
                                        @foreach($errors->all() as $error)
                                          <li>{{ $error }}</li>
                                        @endforeach
                                      </ul>
                                    </div>
                                  @endif

                                  <div class="attachments">
								  <div class="col-lg-3">
                                          <div class="form-group">
                                            {{ Form::label('imei_list', 'IMEI List', ['class' => 'control-label']) }}
                                            {{ Form::file('imei_list') }}
                                            @if(isset($data->imei_attachment) && !empty($data->imei_attachment))
                                              {{ str_limit($data->imei_filename, 40) }}
                                            @endif
                                          </div>
                                      </div>
									  <div class="col-lg-3">
                                          <div class="form-group">
                                            {{ Form::label('sn_list', 'S/N List', ['class' => 'control-label']) }}
                                            {{ Form::file('sn_list') }}
                                            @if(isset($data->sn_attachment) && !empty($data->sn_attachment))
                                              {{ str_limit($data->sn_filename, 40) }}
                                            @endif
                                          </div>
                                      </div>
                                    @if($edit && isset($data->attachment))
                                      <?php $i = 0; ?>
                                      @foreach($data->attachment as $id)
                                        <div class="row current_{{ $id }}">
                                          <div class="col-lg-10">
                                              <div class="form-group">
                                                {{ Form::label('file', 'File: ', ['class' => 'control-label']) }}
                                                <a href="{{ route('incidents.download', [$id, $data->id, 'attachment']) }}">{{ str_limit($data->filename[$i], 40) }}</a>
                                                <a href="javascript:void(0);" class="file-remove pull-right" onclick="MsLstIncidents.deleteAttachmentFile('{{$id}}')"><i class="fa fa-trash fa-fw"></i> Remove</a>
                                                {{ Form::hidden("current_file[$id]", 1) }}
                                              </div>
                                          </div>
                                        </div>
                                        <div class="row current_{{ $id }}">
                                            <div class="col-lg-10">
                                                <div class="form-group">
                                                  {{ Form::label("current_description[$id]", 'Description', ['class' => 'control-label']) }}
                                                  {{ Form::textarea("current_description[$id]", $data->description[$i], ['class' => 'form-control', 'rows' => 3]) }}
                                                 </div>
                                            </div>
                                        </div>
                                        <?php $i++; ?>
                                        @endforeach
                                    @endif
                                    <div class="row">
                                        <div class="col-lg-10">
                                            <div class="form-group">
                                              {{ Form::label('file[0]', 'File', ['class' => 'control-label']) }}
                                              {{ Form::file('file[0]',array('id'=>'incidentattachment')) }}
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-lg-10">
                                            <div class="form-group">
                                              {{ Form::label('description[0]', 'Description', ['class' => 'control-label']) }}
                                              {{ Form::textarea('description[0]', null, ['class' => 'form-control', 'rows' => 3]) }}
                                             </div>
                                        </div>
                                    </div>
                                    <div class="hidden file-index">0</div>
                                  </div>

                                  <div class="row">
                                    <div class="col-lg-10">
                                        {{ Form::button('Add another attachment', ['type' => 'button', 'class' => 'btn btn-primary active pull-left attachment-add-btn']) }}
                                    </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.show', $data->id),'id'=>'incident_cancel_edit']) }}
                        @else
                          <div class="clearfix">
                            <div class="pull-left">
                              <a href="{{($edit ? ['incidents.update', $data->id] : '2')}}" class ='btn btn-default' alt='Back'>Back</a>
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.index'),'id'=>'incident_cancel']) }}
                            </div>
                          </div>
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<script type="text/javascript">
  var Incidents = {'coordinates': null, 'mapElement': null};
    var Products = {};
    Products['description'] = {};
  Products['units'] = {};
  Products['value'] = {};
</script>
@stop