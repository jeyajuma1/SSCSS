@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
            Add Investigation
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->


    @if(Session::has('success'))
    <div id="form-success" class="alert alert-warning" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div>
    <!-- end form-success -->
    @endif
    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                     Add Investigation  
                </div>
                {{ Form::open(['route' => ['investigation.store'], 'class' => 'form-horizontal', 'role' => 'form', 'id' => 'investigation-add', 'method' => 'put']) }}
                    <div class="panel-body">

                        @if($errors->all())
                        <div id="form-errors" class="alert alert-danger" role="alert">
                          <ul>
                            @foreach($errors->all() as $error)
                              <li>{{ $error }}</li>
                            @endforeach
                          </ul>
                        </div>
                        @endif
                        <div class="form-group">
                            {{ Form::label('name', 'Investigation Name', ['class' => 'col-lg-2 control-label required']) }}
                            <div class="col-sm-6">
                              {{ Form::text('name', '', ['class' => 'form-control']) }}
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'href' => '/incident/investigation/']) }}
                    </div>
                {{ Form::close() }}
            </div>
            <!-- /.col-lg-12 -->
        </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->

</div>
@stop