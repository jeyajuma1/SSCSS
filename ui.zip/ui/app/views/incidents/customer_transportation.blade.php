@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Incident</h1>
                @else
                  <h1 class="page-header">Create Incident</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Customer/Transportation</div>
                    {{ Form::open(['route' => ($edit ? ['incidents.update', $data->id] : 'incidents.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal incident-form', 'role' => 'form', 'id' => 'incident-form-transportation']) }}
                      {{ Form::hidden('step', 1) }}
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard">
                                    <a>
                                      <span>Basic Information</span>
                                    </a>
                                    <a class="current">
                                      <span>Customer/Transportation</span>
                                    </a>
                                    <a>
                                      <span>Units/Investigation</span>
                                    </a>
                                    <a>
                                      <span>Attachments</span>
                                    </a>
                                  </div>

                                  @if($errors->all())
                                  <div id="form-errors" class="alert alert-danger" role="alert">
                                    <ul>
                                      @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                      @endforeach
                                    </ul>
                                  </div>
                                  @endif

                                  <div class="row">
                                    <div class="col-lg-12">
                                          <div class="form-group">
                                            <h4>Customer Details</h4>
                                          </div>
                                    </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-lg-5">
                                          <div class="form-group">
                                            {{ Form::label('consignee', 'Consignee', ['class' => 'control-label required']) }}
                                            {{ Form::text('consignee', $data->consignee, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('customer', 'Customer', ['class' => 'control-label required']) }}
                                            {{ Form::text('customer', $data->customer, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                      <div class="col-lg-1">
                                      </div>
                                      <div class="col-lg-5">
                                          <div class="form-group">
                                            {{ Form::label('delivery_note_number', 'Delivery Note Number', ['class' => 'control-label']) }}
                                            {{ Form::text('delivery_note_number', $data->delivery_note_number, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('cmr', 'CMR', ['class' => 'control-label']) }}
                                            {{ Form::text('cmr', $data->cmr, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                  </div>
                                  <div class="row">
                                    <div class="col-lg-12">
                                          <div class="form-group">
                                            <h4>Transportation Details</h4>
                                          </div>
                                    </div>
                                  </div>
                                  <div class="row">
                                      <div class="col-lg-5">
                                          <div class="form-group clearfix">
                                            {{ Form::label('pickup_date', 'Pick Up from Origin (Date &amp; Time)', ['class' => 'control-label required']) }}
                                            <div class="col-md-12 date-time-boxes">
                                              <div class="col-md-5 date-time-boxes">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                                    {{ Form::text('pickup_date', $data->pickup_date, ['class' => 'form-control input-small']) }}
                                                </div>
                                              </div>
                                              <div class="col-md-2 text-center incident-at">
                                                <span> at </span>
                                              </div>
                                              <div class="col-md-5 date-time-boxes">
                                                <div class="input-group bootstrap-timepicker">
                                                    <span class="input-group-addon"><i class="fa fa-clock-o"></i></span>
                                                    {{ Form::text('pickup_time', $data->pickup_time, ['class' => 'form-control input-small']) }}
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('location_of_reporter', 'Location of the incident\'s reporting', ['class' => 'control-label required']) }}
                                            {{ Form::text('location_of_reporter', $data->location_of_reporter, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('driver_name', 'Driver\'s name', ['class' => 'control-label']) }}
                                            {{ Form::text('driver_name', $data->driver_name, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('vehicle_details', 'Transportation vehicle\'s details', ['class' => 'control-label']) }}
                                            {{ Form::text('vehicle_details', $data->vehicle_details, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('carriers_and_contractors', 'Carriers and contractors involved', ['class' => 'control-label']) }}
                                            {{ Form::text('carriers_and_contractors', $data->carriers_and_contractors, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('method_of_transportation', 'Methods Of Transportation', ['class' => 'control-label required']) }}
                                            {{ Form::select('method_of_transportation',[''=>'----Select----','Air Freight'=>'Air Freight','Road Freight'=>'Road Freight','Rail Freight'=>'Rail Freight','Sea Freight'=>'Sea Freight'],$data->method_of_transportation, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                      <div class="col-lg-1">
                                      </div>
                                      <div class="col-lg-5">
                                          <div class="form-group">
                                            {{ Form::label('routing', 'Routing', ['class' => 'control-label']) }}
                                            {{ Form::text('routing', $data->routing, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('airline', 'Airline', ['class' => 'control-label']) }}
                                            {{ Form::text('airline', $data->airline, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('hawb', 'HAWB', ['class' => 'control-label']) }}
                                            {{ Form::text('hawb', $data->hawb, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('mawb', 'MAWB', ['class' => 'control-label']) }}
                                            {{ Form::text('mawb', $data->mawb, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('originating_facility', 'Origin Facility', ['class' => 'control-label required']) }}
                                            {{ Form::text('originating_facility', $data->originating_facility, ['class' => 'form-control']) }}
                                          </div>
                                            <div class="form-group">
                                            {{ Form::label('destination_facility', 'Destination Facility', ['class' => 'control-label required']) }}
                                            {{ Form::text('destination_facility',$data->destination_facility, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.show', $data->id),'id'=>'incident_cancel_edit']) }}
                        @else
                          <div class="clearfix">
                            <div class="pull-left">
                              <a href="{{($edit ? ['incidents.update', $data->id] : '0')}}" class ='btn btn-default' alt='Back'>Back</a>
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.index'),'id'=>'incident_cancel']) }}
                            </div>
                          </div>
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<script type="text/javascript">
  var Incidents = {'coordinates': null, 'mapElement': null}; 
  var Products = {};
    Products['description'] = {};
  Products['units'] = {};
  Products['value'] = {};
  
</script>
@stop