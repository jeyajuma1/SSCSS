@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Factory Incident</h1>
                @else
                  <h1 class="page-header">Create Factory Incident</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Incident Details</div>
                    {{ Form::open(['route' => ($edit ? ['factory.incidents.update', $data->id] : 'factory.incidents.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal factory-incident-detail-form', 'role' => 'form', 'id' => 'factory-incident-detail-form']) }}
                      {{ Form::hidden('step', 1) }}
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard">
                                    <a>
                                      <span>Basic Information</span>
                                    </a>
                                    <a class="current">
                                      <span>Incident Details</span>
                                    </a>
                                    <a class="investigation-wizard">
                                      <span>Investigation/Attachments</span>
                                    </a>
                                  </div>

                                  @if($errors->all())
                                  <div id="form-errors" class="alert alert-danger" role="alert">
                                    <ul>
                                      @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                      @endforeach
                                    </ul>
                                  </div>
                                  @endif

                                  <div class="row">
                                    <div class="col-lg-12">
                                          <div class="form-group">
                                            <h4>Incident Details</h4>
                                          </div>
                                    </div>
                                  </div>

                                    <div class="row">
                                      <div class="col-lg-5">
                                          <div class="form-group">
                                            {{ Form::label('persons_involved', 'Person(s) name(s) Involved', ['class' => 'control-label required']) }}
                                            {{ Form::text('persons_involved', $data->persons_involved, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('loss_discovered_by', 'Loss Discovered By (name & title)', ['class' => 'control-label required']) }}
                                            {{ Form::text('loss_discovered_by', $data->loss_discovered_by, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                      <div class="col-lg-1">
                                      </div>
                                      <div class="col-lg-5">
                                          <div class="form-group">
                                            <?php 
                                              $location_sitepremises = ['Receiving area (Production inventory received short /over)' => 'Receiving area (Production inventory received short /over)','Engineering (Production inventory theft/loss)' => 'Engineering (Production inventory theft/loss)',
'Engineering (Pre-production inventory theft/loss)' => 'Engineering (Pre-production inventory theft/loss)','Warehouse/I-hub (Component inventory cycle counted short/ over)' => 'Warehouse/I-hub (Component inventory cycle counted short/ over)','Manufacturing area(Production beta line loss)'=>'Manufacturing area(Production beta line loss)','Manufacturing area(Pre-production beta line loss)' => 'Manufacturing area(Pre-production beta line loss)',
'Warehouse/Storage(Production inventory cycle counted short /over)' => 'Warehouse/Storage(Production inventory cycle counted short /over)','Scraped Material (Cycle counted short / over)' => 'Scraped Material (Cycle counted short / over)',
'Shipping area (Customer cliam shortage)' => 'Shipping area (Customer cliam shortage)','Office area' => 'Office area' ,
'Shift change' => 'Shift change','Other' => 'Other'];
                                            ?>
                                            {{ Form::label('location_of_incident_within_sitepremises', 'Location of incident within site premises', ['class' => 'control-label']) }}
                                            {{ Form::select('location_of_incident_within_sitepremises',$location_sitepremises,$data->location_of_incident_within_sitepremises, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            &nbsp;
                                          </div>
                                      </div>
                                  </div>

                                   <div class="row">
                                    <div class="col-lg-12">
                                          <div class="form-group">
                                            <h4>Product Details</h4>
                                          </div>
                                    </div>
                                  </div>

                                   <div class="row product-row">
                                      <div class="col-lg-1">
                                        <label class="control-label">&nbsp;</label>
                                        <span class="form-control product-count">#1</span>
                                      </div>
                                      <div class="col-lg-4">
                                          <div class="form-group">
                                            {{ Form::label('product_description0', 'Product /item description', ['class' => 'control-label required']) }}
                                            {{ Form::text('product_description[0]', null , ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('product_family0', 'Product family', ['class' => 'control-label required']) }}
                                            <?php $product_famly = ['Lumia(Phone)' => 'Lumia(Phone)','Surface(PC)'  => 'Surface(PC)','Xbox(Gaming)' => 'Xbox(Gaming)','High value sub-assembly' => 'High value sub-assembly','Component parts' =>'Component parts','Other' => 'Other']; ?>
                                            {{ Form::select('product_family[0]', $product_famly,null, ['class' => 'form-control']) }}
                                            <div class="col-lg-12 product_family_other" id="product_family_other0"></div>
                                          </div>
                                      </div>
                                      <div class="col-cust-1">
                                      </div>
                                      <div class="col-lg-2">
                                          <div class="form-group">
                                            {{ Form::label('part_number0', 'Part number', ['class' => 'control-label required']) }}
                                            {{ Form::text('part_number[0]', null, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                              {{ Form::label('number_of_unit_missing0', 'Number of units missing', ['class' => 'control-label required']) }}
                                              {{ Form::text('number_of_unit_missing[0]', null, ['class' => 'form-control']) }}
                                          </div>
                                      </div>
                                      <div class="col-cust-1">
                                      </div>
                                      <div class="col-lg-2">
                                          <div class="form-group">
                                            {{ Form::label('serial_number0', 'Serial number', ['class' => 'control-label required']) }}
                                            {{ Form::text('serial_number[0]',null, ['class' => 'form-control']) }}
                                          </div>
                                          <div class="form-group">
                                            {{ Form::label('value_per_unit0', 'Value per unit(USD)', ['class' => 'control-label required']) }}
                                            {{ Form::text('value_per_unit[0]', null, ['class' => 'form-control']) }}
                                        </div>
                                      </div>
                                  </div>

                                  <div class="row">
                                   <div class="col-cust-2">
                                    &nbsp;
                                   </div>
                                    <div class="col-lg-7">
                                          {{ Form::button('Add another item',['type'=>'button' ,'class'=>'btn btn-primary' ,'id'=>'additem'])}}
                                    </div>
                                  </div>

                                  <div class="row">
                                    <div class="col-lg-4">
                                      <div class="form-group">
                                          {{ Form::label('total_value_of_loss_unit','Total value of units(USD)',['class'=>'control-label required'])}}
                                          {{ Form::text('total_value_of_loss_unit',$data->total_value_of_loss_unit,['class'=>'form-control'])}}
                                      </div>
                                    </div>
                                  </div>
 
 

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('factory.incidents.show', $data->id),'id'=>'incident_cancel_edit']) }}
                        @else
                          <div class="clearfix">
                            <div class="pull-left">
                              <a href="{{($edit ? ['factory.incidents.update', $data->id] : '0')}}" class ='btn btn-default' alt='Back'>Back</a>
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.index'),'id'=>'incident_cancel']) }}
                            </div>
                          </div>
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<script type="text/javascript">
  var Incidents = {'coordinates': null, 'mapElement': null};
</script>

@if(!empty($data->product_description))
      <?php $product_description = $data->product_description; ?>
      <?php $part_number = $data->part_number; ?>
      <?php $serial_number = $data->serial_number; ?>
      <?php $product_family = $data->product_family; ?>
      <?php $number_of_unit_missing = $data->number_of_unit_missing; ?>
      <?php $value_per_unit = $data->value_per_unit; ?>


@if(is_array($data->product_description))
      <?php $product_description = json_encode($product_description); ?>
      <?php $part_number = json_encode($part_number); ?>
      <?php $serial_number = json_encode($serial_number); ?>
      <?php $product_family = json_encode($product_family); ?>
      <?php $number_of_unit_missing = json_encode($number_of_unit_missing); ?>
      <?php $value_per_unit = json_encode($value_per_unit); ?>
@endif

<script type="text/javascript">
    var Products = {};
    Products['product_description'] = JSON.parse('{{$product_description}}');
    Products['part_number'] = JSON.parse('{{$part_number}}');
    Products['serial_number'] = JSON.parse('{{$serial_number}}');
    Products['product_family'] = JSON.parse('{{$product_family}}');
    Products['number_of_unit_missing'] = JSON.parse('{{$number_of_unit_missing}}');
    Products['value_per_unit'] = JSON.parse('{{$value_per_unit}}');
</script>
@endif
@stop