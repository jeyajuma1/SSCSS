@extends('layouts.master')

@section('content')
<div id="page-wrapper">
      <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
                Factory Incident

                <div class="pull-right">
                <div class="btn-group incident-btns">
                    {{ Form::open(['route' => ['incidents.index','type'=>'factory'], 'method' => 'get']) }}
                        {{ Form::hidden('type','factory') }}
                        {{ Form::button('Go Back', ['type' => 'submit', 'class' => 'btn-gray']) }}
                    {{ Form::close() }}

                    @if (\Auth::User()->isAdmin())
                        {{ Form::open(['route' => ['factory.incidents.close', $incidents->id], 'method' => 'patch']) }}
                            @if(! $incidents->closed_at)
                                {{ Form::button('Close Incident', ['type' => 'submit', 'class' => 'btn-gray incident-close-button']) }}
                            @else
                                {{ Form::button('Open Incident', ['type' => 'submit', 'class' => 'btn-gray incident-open-button']) }}
                            @endif
                        {{ Form::close() }}

                        {{ Form::open(['route' => ['factory.incidents.destroy', $incidents->id], 'method' => 'delete']) }}
                            {{ Form::button('Delete', ['type' => 'submit', 'class' => 'btn-blue incident-delete-button']) }}
                        {{ Form::close() }}
                    @endif
                </div>
            </div>
            </h1>
        </div>
      </div>
      <!-- /.row -->
           <!-- /.row -->
    <div class="row">
      <!-- /.col-lg-12 -->
      <div class="col-lg-12">
              <div class="panel-body">
                   <!-- /.row -->

                  @if(Session::has('success'))
                  <div id="form-success" class="alert alert-success" role="alert">
                      <span>
                          {{ trans(Session::get('success')) }}
                      </span>
                  </div>
                  <!-- end form-success -->
                  @endif

                  <div class="row incident-show">
                    <div class="col-lg-8">

                       <div class="panel panel-default">
                          <div class="panel-heading">
                              <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold">Basic Information</span>
                              <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('factory.incidents.edit', [$incidents->id]) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                          </div>
                          <!-- /.panel-heading -->
                          <div class="panel-body">
                            <div class="table-responsive">
                              <table class="incidents-basic-table">
                                  <tbody>
                                      <tr class="font-darkblue-first">
                                          <td>
                                              Description
                                          </td>
                                        
                                      </tr>
                                      <tr>
                                          <td>
                                             {{ $incidents->short_description }}
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                            <table class="incidents-basic-table">
                                              <tbody>
                                                <tr class="font-darkblue">
										 			                          <td>Facility</td>
                                                    <td>Date of event</td>
                                                    <td>Region</td>
                                                </tr>
												                        <tr>
												                            <td>{{$incidents->facility}}</td>
                                                    <td>{{$incidents->incident_event_date->format('Y-m-d')}}</td>
                                                    <td>{{$incidents->region->name}}</td>
                                                </tr>
                                                <tr class="font-darkblue">
                                                  <td>Country</td>
												                          <td>City</td>
                                                  <td>GPS Coordinates</td>
                                                </tr>
                                                <tr>
                                                  <td class='basic_valign'>{{$incidents->country->name }}</td> 
                                                  <td class='basic_valign'>{{$incidents->city }}</td>
												                           <td class='basic_valign'>{{$incidents->coordinates }}</td>
                                                </tr>
                                                 <tr class="font-darkblue">
                                                  <td>Address</td>
                                                </tr>
                                                <tr>
                                                  <td>{{$incidents->location_address }}</td>
                                                </tr>

                                              </tbody>
                                            </table>
                                          </td>
                                      </tr>
                                      <tr>
                                          <td>
                                              <div id="incident_map" class="detail-view-map span12 col-sm-12">
                                              </div>
                                          </td>
                                      </tr>
                                  </tbody>
                              </table>
                             </div>
                          </div>
                            <!-- /.panel-body -->
                       </div>



                       <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold">Incident Details</span>
                                <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('factory.incidents.edit', [$incidents->id,1]) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                            </div>
                          <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="incidents-basic-table">
                                        <tbody>
                                            <tr class="active">
                                                <td colspan="3">Customer details</td>
                                            </tr>
                                            <tr class="font-darkblue">
                                                <td>Person(s) name(s) Involved</td>
                                                <td>Loss Discovered By (name & title)</td>
                                                <td>Location of incident within sitepremises</td>
                                            </tr>
                                            <tr>
                                                <td>{{ $incidents->persons_involved }}</td>
                                                <td>{{ $incidents->loss_discovered_by }}</td>
                                                <td>{{ $incidents->location_of_incident_within_sitepremises }}</td>
                                            </tr>
                                          </tbody>
                                    </table>
                                     <table class="incidents-basic-table">
                                        <tbody>  
                                            <tr class="font-darkblue">
                                                <td style="width:400px;">Product /item description</td>
                                                <td>Part number</td>
                                                <td>Serial number</td>
                                            </tr>
                                            @foreach($products as $ky=>$value)
                                              <tr>
                                                <td>{{$value['product_description']}}</td>
                                                <td>{{$value['part_number'] }}</td>
                                                <td>{{$value['serial_number'] }}</td>
                                            </tr>
                                            @endforeach
                                            <tr class="font-darkblue">
                                                <td>Product family</td>
                                                <td>Number of units missing</td>
                                                <td>Value per unit(USD)</td>
                                            </tr>

                                            @foreach($products as $ky=>$value)
                                            <tr>
                                                <td>{{ $value['product_family'] }}</td>
                                                <td class="font-red">{{ $value['number_of_unit_missing'] }}</td>
                                                <td class="font-red">{{ $value['value_per_unit'] }}</td>
                                            </tr>
                                            @endforeach
                                            <tr class="font-darkblue">
                                             <td colspan="3">Total value of units(USD)</td>
                                            </tr>
                                            <tr>
                                              <td class="font-red" colspan="2" >{{ $incidents->product->total_value_of_loss_unit }}</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                 </div>
                            </div>                            
                            <!-- /.panel-body -->
                       </div>


                       <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold">Investigation/Attachments</span>
                                <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('factory.incidents.edit', [$incidents->id,2]) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="incidents-basic-table">
                                        <tbody>
                                            <tr class="active">
                                                <td colspan="3">Investigation details</td>
                                            </tr>
                                            <tr class="font-darkblue">
                                                <td>Name of the investigation authority</td>
                                                <td>Contact information</td>
                                                <td>Investigation file number</td>
                                            </tr>
                                            <tr>
                                                <td>{{ $incidents['investigation']->name_of_investigation_authority }}</td>
                                                <td>{{ $incidents['investigation']->contact_information }}</td>
                                                <td>{{ $incidents['investigation']->investigation_file_number }}</td>
                                            </tr>
                                             
                                            <tr class="font-darkblue">
                                                <td>Incident refered to</td>
                                                <td>On Date time</td>
                                                <td>Investigation description and actions taken</td>
                                            </tr>
                                            <tr>
                                                <td>{{ $incidents['investigation']->incident_refered_to }}</td>
                                                <td>{{ $incidents['investigation']->ondatetime->format('M d, Y h:i A') }}</td>
                                                <td>{{ $incidents['investigation']->investigation_description_and_action_taken }}</td>
                                            </tr>
                                            <tr class="font-darkblue">
                                                <td colspan="3">Final investigation findings, root cause analysis & corrective actions</td>
                                            </tr>
                                            <tr>
                                               <td > 
                                                    {{ $incidents['investigation']->final_investigation_findings_cause_analysis_corrective_actions }}
                                                </td>
                                            </tr>
                                            <tr class="font-darkblue">
                                               <td  colspan="3">Current investigation status</td>
                                            </tr>
                                            <tr>
                                                <td> 
                                                    <?php $color = [1=>'primary',2=>'danger',3=>'success',4=>'info',5=>'warning'] ?>
                                                    @if(empty($color[$incidents->investigation->current_investigation_status])) <?php $colr = 1; ?> @else <?php $colr = $incidents->investigation->current_investigation_status ?> @endif
                                                    <select  class="selectpicker investigation_status" name='investigation_status'>
                                                           <option data-content="&lt;span class='label label-{{$color[$colr]}}'&gt;{{$incidents->investigation->investigationname}}&lt;/span&gt;" value='{{$incidents->investigation->investigationname}}'>{{$incidents->investigation->investigationname}}</option>
                                                    </select>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                 </div>
                            </div>
                            <!-- /.panel-body -->
                       </div>
                     </div>
                   <!-- /.col-lg-8 -->
                    <div class="col-lg-4">
                       <div class="panel panel-default">
                          <div class="panel-body">
                              <div class="table-responsive">
                                  <table class="incidents-basic-table">
                                      <tbody>
                                          <tr class="font-darkblue-first">
                                              <td>
                                                  Created by
                                              </td>
                                          </tr>
                                          <tr> 
                                              <td class="incidentviewtd">
                                                  <span>{{ $incidents->user->name }}</span>
                                              </td>
                                          </tr>
                                          <tr class="font-darkblue">
                                              <td>
                                                  Created On
                                              </td>
                                          </tr>
                                          <tr> 
                                              <td class="incidentviewtd">
                                                  <span>{{ $incidents->created_at->format('M d, Y h:i A') }}</span>
                                              </td>
                                          </tr>
                                          <tr class="font-darkblue">
                                              <td>
                                                  Incident status
                                              </td>
                                          </tr>
                                           <tr> 
                                              <td class="incidentviewtd">
                                                @if($status['code'])
                                                   <span class="label label-success">
                                                @else
                                                   <span class="label label-danger">
                                                @endif
                                                 {{ $status['label'] }}
                                                   </span>
                                              </td>
                                          </tr>

                                          @if(!empty($incidents->closed_at))
                                          <tr class="font-darkblue">
                                              <td>
                                                  Closed On 
                                              </td>
                                          </tr>
                                           <tr> 
                                              <td class="incidentviewtd">
                                                  <span>{{$incidents->closed_at->format('M d, Y h:i A')}}</span>
                                              </td>
                                          </tr>
                                          @endif
                                          <tr class="font-darkblue">
                                              <td>
                                                  Incident ID
                                              </td>
                                          </tr>
                                          <tr> 
                                              <td class="incidentviewtd">
                                                  <span>{{ $incidents->name }}</span>
                                              </td>
                                          </tr>
                                      </tbody>
                                  </table>
                              </div>
                          </div>
                          <!-- /.panel-body -->
                      </div>
                      <!-- /.panel -->

                        <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold">Attachments</span>
                                <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('factory.incidents.edit', [$incidents->id,2]) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                            </div>
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="incidents-basic-table">
                                        <tbody>
                                          @if($has_attachments)
                                              @foreach($incidents->attachment as $key=>$attachment)
                                              <tr>
                                                <td>
                                                  <a href="{{ route('incidents.download', [$attachment->id, $incidents->id, 'factoryincident']) }}">{{ str_limit($attachment->file_description, 40) }}</a><br />
                                                   <span>{{ $attachment->description }}</span>
                                                </td> 
                                              </tr>
                                              @endforeach
                                          @else
                                            <tr>
                                              <td>No attachments.</td>
                                            </tr>
                                            @endif
                      
                                        </tbody>
                                    </table>
                                 </div>
                            </div>
                            <!-- /.panel-body -->
                        </div>

                          <!-- /.panel -->
                          <div class="panel panel-default">
                              <div class="panel-heading">
                                  <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold">History Log</span>
                              </div>
                              <div class="panel-body">
                                  <div class="table-responsive">
                                      <table class="tbody-small">
                                          <tbody class="font-black-small">
                                            @foreach($incidents->incidentlog as $log)
                                             <tr>
                                                  <td>
                                                      @if($log->created_at  != Null)
                                                          {{ $log->created_at->format('M d, Y h:i A') }} - Created by
                                                      @elseif($log->updated_at != Null)
                                                          {{ $log->updated_at->format('M d, Y h:i A') }} - Edited by
                                                      @endif
                                                      {{ $log->user->name }}
                                                  </td>
                                              </tr>
                                              @endforeach
                                          </tbody>
                                      </table>
                                   </div>
                              </div>
                              <!-- /.panel-body -->
                          </div>
                          <!-- /.panel -->
                    </div>

                  </div>
              </div>
            </div>
            <!-- /.panel-body -->
      </div>
         <!-- /.col-lg-12  -->
    </div>
    <!-- /.row  -->




        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<!--<script type="text/javascript" charset="UTF-8" src="//js.api.here.com/ee/2.5.4/jsl.js?with=all"></script>-->
<script type="text/javascript" charset="UTF-8"  src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>

<script type="text/javascript">
  var FactoryIncidents = {
    mapElement: 'incident_map',
    coordinates: '{{ $coordinates }}'
  };
  
</script>
@stop
