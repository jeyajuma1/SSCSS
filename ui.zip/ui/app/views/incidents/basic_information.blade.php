@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Incident</h1>
                @else
                  <h1 class="page-header">Create Incident</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Basic Information</div>
                    {{ Form::open(['route' => ($edit ? ['incidents.update', $data->id] : 'incidents.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal incident-form', 'role' => 'form', 'id' => 'incident-form-basic']) }}
                        {{ Form::hidden('step', 0) }}
                        <div class="panel-body">
                            <!-- end form-errors -->
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard">
                                    <a class="current">
                                      <span>Basic Information</span>
                                    </a>
                                    <a>
                                      <span>Customer/Transportation</span>
                                    </a>
                                    <a>
                                      <span>Units/Investigation</span>
                                    </a>
                                    <a>
                                      <span>Attachments</span>
                                    </a>
                                  </div>

                                  @if($errors->all())
                                  <div id="form-errors" class="alert alert-danger" role="alert">
                                    <ul>
                                      @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                      @endforeach
                                    </ul>
                                  </div>
                                  @endif

                                  <div class="form-group incident-type-select-parent"> <?php $seltype = array_flip(MSLST_Site::$INCIDENT_TYPES); $dattype = '';  if(!empty($seltype[$data->type])) $dattype = $seltype[$data->type]; ?>
                                    <a id="p2p-care-link" href="javascript:void(0);" class="col-sm-4 control-label">Is this a Plant-to-Plant or CARE incident ?</a>
                                    <div class="col-sm-4 incident-type-select">
                                       {{ Form::select('type', [1 => 'Plant to Plant', 2 => 'CARE'], $dattype, ['class' => 'form-control']) }}
                                       {{ Form::hidden('plant_care', $data->plant_care) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('short_description', 'Description', ['class' => 'col-sm-2 control-label']) }}
                                    <div class="col-sm-6">
                                      {{ Form::textarea('short_description', $data->short_description, ['rows' => 3, 'class' => 'form-control']) }}
                                    </div>
                                  </div>			  
                								  <div class="form-group">
                									{{ Form::label('type_of_loss', 'Type of Loss', ['class' => 'col-sm-2 control-label required']) }}
                										<div class="col-sm-6">
                										{{ Form::select('type_of_loss',[''=>'----Select----','Hijack'=>'Hijack','Lost cargo'=>'Lost cargo','Theft'=>'Theft','Other'=>'Other'],$data->type_of_loss, ['class' => 'form-control']) }}
                										</div>
                								  </div> 
              								  <div class="form-group typeofotherloss">
              										{{ Form::label('type_of_other_loss', 'Specify the loss type', ['class' => 'col-sm-2 control-label ']) }}
              										<div class="col-sm-6">
              										  {{ Form::text('type_of_other_loss', $data->type_of_other_loss, ['class' => 'form-control']) }}
              										</div>
                                  </div> 
                                  <div class="form-group">
                                    {{ Form::label('incident_date', 'Date of incident', ['class' => 'col-sm-2 control-label required']) }}
                                    <div class="col-sm-6">
                                      <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                        {{ Form::text('incident_date', $data->incident_date, ['class' => 'form-control']) }}
                                      </div>
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('region', 'Region', ['class' => 'col-sm-2 control-label required']) }}
                                    <div class="col-sm-6">
                                    	{{ Form::select('region', $regions, $data->region, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('country', 'Country', ['class' => 'col-sm-2 control-label required']) }}
                                    <div class="col-sm-6">
                                      {{ Form::select('country', $countries, $data->country, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('location_city', 'City', ['class' => 'col-sm-2 control-label required']) }}
                                    <div class="col-sm-6">
                                      {{ Form::text('location_city', $data->location_city, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
								  <div class="form-group">
                                    {{ Form::label('facility', 'Facility', ['class' => 'col-sm-2 control-label']) }}
                                    <div class="col-sm-6">
                                      {{ Form::text('facility', $data->facility, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('location_address', 'Address', ['class' => 'col-sm-2 control-label']) }}
                                    <div class="col-sm-6">
                                      {{ Form::text('location_address', $data->location_address, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('coordinates', 'Coordinates', ['class' => 'col-sm-2 control-label required']) }}
                                    <div class="col-sm-4">
                                      {{ Form::text('coordinates', $data->coordinates, ['class' => 'form-control', 'placeholder' => 'Coordinate format: latitude, longitude', 'id' => 'coordinates']) }}
                                    </div>
                                    <div class="col-sm-2">
                                      <input type="hidden" id="myField" value="" />
                                      {{ Form::button('Validate', ['type' => 'button', 'class' => 'form-control btn btn-primary', 'id' => 'incident-coordinate-check']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    <div class="col-sm-6 col-sm-offset-2" id="incident-coordinate-pick"></div>
                                  </div>
                                  <div class="form-group">
                                    <div class="col-sm-6 col-sm-offset-2 description">
                                    (Example: 42.374335,-71.116991 (Decimal Degrees) or N30 17.477,W97 44.315 (GPS) or N42 21 30,W71 06 14 (Degrees, Minutes &amp; Seconds) or 19N 326727 4691707 (UTM))
                                    </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.show', $data->id),'id'=>'incident_cancel_edit']) }}
                        @else
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('incidents.index'),'id'=>'incident_cancel']) }}
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<!--<script type="text/javascript" charset="UTF-8" src="//js.api.here.com/ee/2.5.4/jsl.js?with=all"></script>-->
<script type="text/javascript" charset="utf-8" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
  var Incidents = {'coordinates': null, 'mapElement': null};
  Incidents.regions = '{{ $regions_json }}';
  Incidents.country = '{{ Input::old("country")?:$data->country }}';
  Incidents.type = '{{ $data->type }}';
    var Products = {};
    Products['description'] = {};
  Products['units'] = {};
  Products['value'] = {};
</script>
@stop
