@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
            Incident #{{$incident->id}} @if($incident->review_requested == 1)
                                    <span class="glyphicon glyphicon-exclamation-sign icon-red"></span>
                          @endif
            <div class="pull-right">
                <div class="btn-group incident-btns">
                    {{ Form::hidden('incident_id',$incident->id) }}
                    {{ Form::open(['route' => 'incidents.index', 'method' => 'get']) }}
                        {{ Form::button('Go Back', ['type' => 'submit', 'class' => 'btn-gray']) }}
                    {{ Form::close() }}

                    {{ Form::open(['route' => ['incidents.export', $incident->id], 'method' => 'get']) }}
                        {{ Form::button('Export as XLS', ['type' => 'submit', 'class' => 'btn-gray']) }}
                    {{ Form::close() }}
                     
                    @if(preg_match('/\b(Re open|deny|open)\b/i',$incident->closure_state)) 
                         @if (\MSLST\Helpers\Common::canRequestAccess('incident', null, $incident))
                            {{ Form::button('Request for closure', ['type' => 'submit', 'class' => 'btn-blue request_close']) }}
                         @endif
                    @elseif(preg_match('/\b(Requested|Accept)\b/i',$incident->closure_state))
                        @if (\Auth::User()->isAdmin() || \Auth::User()->isManager())
                             @if($incident->closure_state != 'open' )  
                                @if(!$incident->closed_at)
                                   <!-- {{ Form::button('Close Incident', ['type' => 'submit', 'class' => 'btn-blue close_incident']) }}-->
                                @else
                                    {{ Form::button('Re-open Incident', ['type' => 'submit', 'class' => 'btn-blue reopen_incident']) }}
                                @endif
                             @endif
                        @endif
                    @endif

                    @if (\Auth::User()->isAdmin())
                        @if($incident->review_requested == 0)
                            {{ Form::open(['route' => ['incidents.review', $incident->id,'request'], 'method' => 'patch']) }}
                                {{ Form::button('Request Review', ['type' => 'submit', 'class' => 'btn-gray incident-review-button']) }}
                                {{ Form::hidden('review_message', '') }}
                            {{ Form::close() }}
                        @else
                            {{ Form::open(['route' => ['incidents.review', $incident->id,'clear'], 'method' => 'patch']) }}
                                {{ Form::button('Clear Review', ['type' => 'submit', 'class' => 'btn-gray']) }}
                            {{ Form::close() }}
                        @endif

                        <!--
                        {{ Form::open(['route' => ['incidents.close', $incident->id], 'method' => 'patch']) }}
                            @if(! $incident->closed_at)
                                {{ Form::button('Close Incident', ['type' => 'submit', 'class' => 'btn-blue']) }}
                            @else
                                {{ Form::button('Open Incident', ['type' => 'submit', 'class' => 'btn-blue']) }}
                            @endif
                        {{ Form::close() }}
                        -->

                        {{ Form::open(['route' => ['incidents.destroy', $incident->id], 'method' => 'delete']) }}
                            {{ Form::button('Delete', ['type' => 'submit', 'class' => 'btn-blue incident-delete-button']) }}
                        {{ Form::close() }}
                    @endif
                </div>
            </div>
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    @if(Session::has('success'))
    <div id="form-success" class="alert alert-success" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div>
    <!-- end form-success -->
    @endif

    <div class="row incident-show">
        <div class="col-lg-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold">Basic Information</span>
                    @if (\MSLST\Helpers\Common::canAccessEdit(null, 'incident', null, $incident))
                    <div class="pull-right">
                        <div class="btn-group">
                         @if(!isset($incident->closed_at) || (\Auth::User()->isAdmin()))
                            <button type="button" class="btn btn-default btn-xs" href="{{ route('incidents.edit', [$incident->id]) }}">
                                Edit
                            </button>
                         @endif
                        </div>
                    </div>
                    @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="incidents-basic-table">
                            <tbody>
                                <tr class="font-darkblue-first">
                                    <td>
                                        Description</td>
                                    </tr>
                                    <tr>
                                        <td>
                                            @if(!empty($incident->short_description))
                                            {{ $incident->short_description }}
                                            @else
                                             Not Specified
                                            @endif
                                        </td>
                                   
                                </tr>
                                <tr>
                                    <td>
                                    	<table class="incidents-basic-table">
                                    		<tbody>
                                    			<tr class="font-darkblue">
                                                    <td>Type of Loss</td>
                                    				<td>Category</td>
                                    				<td>Facility</td>
                                    			</tr>
                                    			<tr>
                                                    <td>
                                                        @if($incident->type_of_loss == 'Other' && (!empty($incident->type_of_other_loss)))
                                                            {{ $incident->type_of_other_loss }}
                                                        @elseif(($incident->type_of_loss == 'Other' && empty($incident->type_of_other_loss)) || !empty($incident->type_of_loss))
                                                            {{ $incident->type_of_loss }}
                                                        @else
                                                            Not Specified
                                                        @endif
                                                    </td>
                                    				<td>{{ ucfirst($incident->category) }}</td>
                                    				<td>
                                                        @if(!empty($incident->facility))
                                                            {{ $incident->facility }}
                                                        @else
                                                            Not Specified
                                                        @endif
                                                    </td>
                                    			</tr>
                                    			<tr class="font-darkblue">
                                                    <td>Incident Date</td>
                                    				<td>Country</td>
                                    				<td>City</td>
                                    			</tr>
                                    			<tr>
                                                    <td>{{ $incident->incident_date->format('M d, Y') }}</td>
                                    				<td>{{ $incident->country->name }}</td>
                                    				<td>
                                                        @if(!empty($incident->location_city))
                                                            {{ $incident->location_city }}
                                                        @else
                                                            Not Specified
                                                        @endif
                                                    </td>
                                    			</tr>
                                    			<tr class="font-darkblue">
                                                    <td>Address</td>
													<td>LSP</td>
                                    				<td colspan="2">GPS Coordinates</td>
                                    			</tr>
                                    			<tr>
                                                    <td>
                                                        @if(!empty($incident->location_address))
                                                            {{ $incident->location_address }}
                                                        @else
                                                            Not Specified
                                                        @endif
                                                    </td>
                                    				<td>@if(!empty($incident->user->lsp->name))
                                                            {{ $incident->user->lsp->name }} 
                                                        @else
                                                            Not Specified
                                                        @endif
                                                    </td>
													<td colspan="2">{{ $incident->coordinates }}</td>
                                    			</tr>
                                    		</tbody>
                                    	</table>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3">
                                        <div id="incident_map" class="detail-view-map span12 col-sm-12">
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold"> Customer/Transportation</span>
                    @if (\MSLST\Helpers\Common::canAccessEdit(null, 'incident', null, $incident))
                    <div class="pull-right">
                        <div class="btn-group">
                        @if(!isset($incident->closed_at) || (\Auth::User()->isAdmin()))
                            <button type="button" class="btn btn-default btn-xs" href="{{ route('incidents.edit', [$incident->id, 1]) }}">
                                Edit
                            </button>
                        @endif
                        </div>
                    </div>
                    @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="incidents-basic-table">
                            <tbody>
                                <tr class="active">
                                    <td colspan="3">Customer details</td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>Consignee</td>
                                    <td>Customer</td>
                                    <td>Delivery note number</td>
                                </tr>
                                <tr>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->consignee))
                                            {{ $incident->consignee }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->customer))
                                            {{ $incident->customer }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->delivery_note_number))
                                            {{ $incident->delivery_note_number }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td colspan="3">CMR</td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="incidentviewtd">
                                        @if(!empty($incident->cmr))
                                            {{ $incident->cmr }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>
                                 <tr>
                                    <td colspan="3">&nbsp;</td>
                                </tr>
                                <tr class="active">
                                    <td colspan="3">Transportation details</td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>Pick Up from Origin (Date &amp; Time)</td>
                                    <td>Location of the incident's reporting</td>
                                    <td>Driver name</td>
                                </tr>
                                <tr>
                                    <td class="incidentviewtd">{{ $incident->pick_up->format('M d, Y h:i A') }}</td>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->location_of_reporter))
                                            {{ $incident->location_of_reporter }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->driver_name))
                                            {{ $incident->driver_name }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>Transportation vehicle's details</td>
                                    <td>Carriers and contractors involved</td>
                                    <td>Routing</td>
                                </tr>
                                <tr>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->vehicle_details))
                                            {{ $incident->vehicle_details }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->carriers_and_contractors))
                                            {{ $incident->carriers_and_contractors }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->routing))
                                            {{ $incident->routing }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>Airline</td>
                                    <td>HAWB</td>
                                    <td>MAWB</td>
                                </tr>
                                <tr>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->airline))
                                            {{ $incident->airline }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->hawb))
                                            {{ $incident->hawb }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->mawb))
                                            {{ $incident->mawb }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td >Origin Facility</td>
                                    <td >Destination Facility</td>
                                    <td >Methods Of Transportation</td>
                                </tr>
                                <tr>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->originating_facility))
                                            {{ $incident->originating_facility }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                     <td class="incidentviewtd">
                                        @if(!empty($incident->destination_facility))
                                            {{ $incident->destination_facility }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                     <td class="incidentviewtd">
                                        @if(!empty($incident->method_of_transportation))
                                            {{ $incident->method_of_transportation }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold">Units/Investigation</span>
                    @if (\MSLST\Helpers\Common::canAccessEdit(null, 'incident', null, $incident))
                    <div class="pull-right">
                        <div class="btn-group">
                         @if(!isset($incident->closed_at) || (\Auth::User()->isAdmin()))
                            <button type="button" class="btn btn-default btn-xs" href="{{ route('incidents.edit', [$incident->id, 2]) }}">
                                Edit
                            </button>
                         @endif
                        </div>
                    </div>
                    @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="incidents-basic-table">
                            <tbody>
                                <tr class="active">
                                    <td colspan="3">Details of units missing</td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>Type of Device</td>
                                </tr>
                                <tr>
                                    <td>
                                        @if($incident->type_of_device == 'Other' && (!empty($incident->type_of_other_device)))
                                            <?php $sa = json_decode($incident->type_of_other_device);  ?>
                                            {{$sa[0]}}
                                        @elseif(($incident->type_of_device == 'Other' && (empty($incident->type_of_other_device))) || !empty($incident->type_of_device))
                                            <?php $sa = json_decode($incident->type_of_device); ?>
                                            {{$sa[0]}}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>
                                 <tr class="font-darkblue">
                                    <td>Product/item Description</td>
                                    <td>Number of Units Missing</td>
                                    <td>Value per Unit (USD)</td>
                                </tr>
                                @foreach($products as $product)
                                <tr>
                                    <td>{{ $product['description'] }}</td>
                                    <td class="font-red">{{ $product['units'] }}</td>
                                    <td class="font-red">{{ $product['value'] }}</td>
                                </tr>
                                @endforeach

                                  <tr class="font-darkblue">
                                    <td>Number of Plts/Crts Missing</td>
                                    <td colspan="2">Total Value of lost Units (USD)</td>
                                </tr> 
                                <tr>
                                    <td class="font-red incidentviewtd"> @if($incident->type_of_device!='["Proto Device"]'){{$incident->product->number_of_plts_missing }}@else NA @endif</td>
                                    <td class="font-red incidentviewtd" colspan="2" >@if($incident->type_of_device!='["Proto Device"]'){{ $incident->product->total_value_of_lost_units }}@else NA @endif</td>
                                </tr>
								<tr>
                                    <td colspan="3">&nbsp;</td>
                                </tr>
                                <tr class="active">
                                    <td colspan="3">Official investigation details</td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>The name of the investigation authority</td>
                                    <td colspan="2">The investigation file number</td>
                                </tr>
                                <tr>
                                    <td class="incidentviewtd">
                                        @if(!empty($incident->official_investigation->name_of_investigation_authority))
                                            {{ $incident->official_investigation->name_of_investigation_authority }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                    <td colspan="2" class="incidentviewtd">
                                        @if(!empty($incident->official_investigation->investigation_file_number))
                                            {{ $incident->official_investigation->investigation_file_number }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td colspan="3">DQI Number</td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="incidentviewtd">
                                        @if(!empty($incident->official_investigation->dq))
                                            {{ $incident->official_investigation->dq }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>

                                <tr class="font-darkblue">
                                    <td colspan="3">Contact information for the investigating law enforcement agency</td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="incidentviewtd">
                                        @if(!empty($incident->official_investigation->contact_information))
                                            {{ $incident->official_investigation->contact_information }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td colspan="3">First Findings, Lessons learned, Short Term Actions, Loss Type (Pilferage, Theft, Robbery, etc.)</td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="incidentviewtd">
                                        @if(!empty($incident->first_findings))
                                            {{ $incident->first_findings }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td colspan="3">Final investigation findings, root cause analysis & long term corrective actions</td>
                                </tr>
                                <tr>
                                    <td colspan="3" class="incidentviewtd">
                                        @if(!empty($incident->official_investigation->final_investigation_findings))
                                            {{ $incident->official_investigation->final_investigation_findings }}
                                        @else
                                            Not Specified
                                        @endif
                                    </td>
                                </tr>

                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
            <!-- /.panel -->
            <div class="panel panel-green">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i>Current investigation status
                    @if (\MSLST\Helpers\Common::canAccessEdit(null, 'incident', null, $incident))
                    <div class="pull-right">
                        <div class="btn-group">
                        &nbsp;
                        </div>
                    </div>
                    @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table">
                        <table class="incidents-basic-table">
                            <tbody>
                                 <!--tr  class="active">
                                    <td colspan='2'>Current investigation status</td>
                                    
                                </tr-->
                                <tr>
                                    <td >
                                       <?php $color = [1 => 'default',2=>'primary',3=>'warning',4=>'danger',5=>'info',6=>'success',7=>'info',8=>'success']; ?>
                                        <select  class="selectpicker investigation_status" name='investigation_status' style="width:300px;">
                                            @if(!empty($InvestigationStus))
                                                  @foreach($InvestigationStus as $ky=>$info)
                                                    @if(empty($color[$ky])) <?php $colr = 5; ?> @else <?php $colr = $ky ?> @endif

                                                  <option data-content="&lt;span class='label label-{{$color[$colr]}}'&gt;{{$info}}&lt;/span&gt;" value='{{$ky}}' @if($incident->incident_investigation->id == $ky) selected=selected @endif >{{$info}}</option>
                                                  @endforeach
                                            @else
                                                  <option data-content="&lt;span class='label label-{{$color[$incident->incident_investigation->id]}}'&gt;{{$incident->incident_investigation->name}}&lt;/span&gt;" value='{{$incident->incident_investigation->id}}'>{{$incident->incident_investigation->name}}</option>
                                            @endif
                                        </select>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-8 -->
        <div class="col-lg-4">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="table-responsive">
                       <table class="incidents-basic-table">
                            <tbody>
                               @if(preg_match('/\b(Requested)\b/i',$incident->closure_state) && (\Auth::User()->isManager() || \Auth::User()->isAdmin()))
                                <tr class="font-darkblue-first">
                                    <td>
	                                      <div class="alert alert-warning">
	                                                 <table class="closure_state_table">
	                                      						<tr>
	                                                                <td>Incident closure requested 
	                                                                @if($incident->closure_state == 'accept')
	                                                                	{{-- */$inc_clos_com =  $incident->closure_comment;/* --}}
	                                                                @else
	                                                                	{{-- */$inc_clos_com =  $incident->request_closure_comment;/* --}}
	                                                                @endif
	                                                                <br/>
	                                                                <a data-original-title="{{$inc_clos_com}}" data-toggle="tooltip" title="" class="tooltip_closur">(view user comment)</a>
	                                                                </td>
	                                                                <td>
                   													 
                    													   {{ Form::open(['route' => 'incidents.request_closure', 'method' => 'post']) }}
                    													   			{{ Form::hidden('id',$incident->id) }}
		                    													    {{ Form::hidden('closure_comments','') }}
		                    													    {{ Form::hidden('state','close') }}
                        															{{ Form::button('Accept', ['type' => 'submit', 'class' => 'btn btn-success btn_accept']) }}
                  														   {{ Form::close() }}
                    													   
                    													   {{ Form::open(['route' => 'incidents.request_closure', 'method' => 'post']) }}
                    													   		    {{ Form::hidden('id',$incident->id) }}
		                    													    {{ Form::hidden('closure_comments',' because of insufficient or incomplete information') }}
		                    													    {{ Form::hidden('state','deny') }}
                        															{{ Form::button('Deny', ['type' => 'submit', 'class' => 'btn btn-danger']) }}
                  														    {{ Form::close() }} 
	                                                                </td>
	                                                            </tr>
	                                                 </table>
	                            		  </div>	                            		  
                                    </td>
                                </tr>
                                @endif
                                <tr class="font-darkblue-first">
                                    <td>
                                        Created by
                                    </td>
                                </tr>
                                <tr> 
                                    <td class="incidentviewtd">
                                        <span>{{ $incident->user->name }}</span>
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>
                                        Created On
                                    </td>
                                </tr>
                                <tr> 
                                    <td class="incidentviewtd">
                                        <span>{{ $incident->created_at->format('M d, Y h:i A') }}</span>
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>
                                        Incident status
                                    </td>
                                </tr>
                                 <tr> 
                                    <td class="incidentviewtd">
                                        @if($status['code'])
                                        <span class="label label-success">
                                        @else
                                        <span class="label label-danger">
                                        @endif
                                            {{ $status['label'] }}
                                        </span>
                                    </td>
                                </tr>

                                @if(!empty($incident->closed_at))
                                <tr class="font-darkblue">
                                    <td>
                                        Closed On 
                                    </td>
                                </tr>
                                 <tr> 
                                    <td class="incidentviewtd">
                                        <span>{{$incident->closed_at->format('M d, Y h:i A')}}</span>
                                    </td>
                                </tr>
                                @endif
                                <tr class="font-darkblue">
                                    <td>
                                        Incident ID
                                    </td>
                                </tr>
                                <tr> 
                                    <td class="incidentviewtd">
                                        <span>{{ $incident->name }}</span>
                                    </td>
                                </tr>
                               <!--  <tr class="font-darkblue">
                                    <td>
                                         Closure request
                                    </td>
                                </tr>
                                <tr> 
                                    <td class="incidentviewtd">
                                        <span>{{ ucfirst($incident->closure_state)}}</span>
                                    </td>
                                </tr>-->
                                
                                @if (\Auth::User()->isAdmin())
                                <tr class="font-darkblue">
                                    <td>
                                        Additional Owners
                                    </td>
                                </tr>
                                 <tr> 
                                    <td class="incidentviewtd">
                                        <span>{{ Form::select('owners', $users, $owners,['multiple' => true]) }}</span>
                                    </td>
                                </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold"> Attachments</span>
                    @if (\MSLST\Helpers\Common::canAccessEdit(null, 'incident', null, $incident))
                    <div class="pull-right">
                        <div class="btn-group">
                          @if(!isset($incident->closed_at) || (\Auth::User()->isAdmin()))
                            <button type="button" class="btn btn-default btn-xs" href="{{ route('incidents.edit', [$incident->id, 3]) }}">
                                Edit
                            </button>
                          @endif
                        </div>
                    </div>
                    @endif
                </div>
                <div class="panel-body">
                    <div class="table-responsive" >
                         <table class="incidents-basic-table">
                            <tbody>
                                @if($has_attachments)
                                    @foreach($incident->attachment as $attachment)
                                        @if($attachment->attachment_type == 'attachment')
                                             <tr class="font-blackList">
                                                <td>
                                                    <a href="{{ route('incidents.download', [$attachment->id, $incident->id, 'attachment']) }}">{{ str_limit($attachment->file_description, 40) }}</a><br />
                                                    <span>{{ $attachment->description }}</span>
                                                </td>
                                            </tr>
                                        @elseif($attachment->attachment_type == 'closeincident' && (\Auth::User()->isAdmin()))
                                          <tr class="font-blackList">
                                                    <td>
                                                        <a href="{{ route('incidents.download', [$attachment->id, $incident->id, 'attachment']) }}">{{ str_limit($attachment->file_description, 40) }}</a><br />
                                                        <span>{{ $attachment->description }}</span>
                                                    </td>
                                             </tr>
                                        @endif
                                    @endforeach
                                @else
                                    <tr>
                                        <td>No attachments.</td>
                                    </tr>
                                @endif
                                <tr class="font-darkblue">
                                    <td>IMEI List</td>
                                </tr>
                                <tr>
                                  <td class='incidentviewtd'>
                                    {{strip_tags($imei_list,'<a>')}}
                                  </td>
                                </tr>
                                <tr class="font-darkblue">
                                     <td>S/N List</td>
                                </tr>
                                <tr>
                                     <td class='incidentviewtd'>
                                     {{strip_tags($sn_list,'<a>')}}</td>
                                </tr>
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold">History Log</span>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="tbody-small">
                            <tbody class="font-black-small">
                                @foreach($incident->incident_log as $log)
                                <tr>
                                    <td>
                                        @if($log->created_at != NULL )
                                            {{ $log->created_at->format('M d, Y h:i A') }} - Created by
                                        @elseif($log->updated_at != NULL )
                                            {{ $log->updated_at->format('M d, Y h:i A') }} - Edited by
                                        @elseif($log->requested_at != NULL )
                                            {{  date('M d, Y h:i A',strtotime($log->requested_at))  }} - Review requested by
                                        @elseif($log->cleared_at != NULL )
                                            {{  date('M d, Y h:i A',strtotime($log->cleared_at))  }} - Review cleared by
                                        @elseif($log->closure_requested_at != NULL )
                                            {{  date('M d, Y h:i A',strtotime($log->closure_requested_at))  }} - Incident closure requested by
                                        @elseif($log->closure_accepted_at != NULL )
                                            {{  date('M d, Y h:i A',strtotime($log->closure_accepted_at))  }} - Closure request accepted by
                                        @elseif($log->closure_denied_at != NULL )
                                            {{  date('M d, Y h:i A',strtotime($log->closure_denied_at))  }} - Closure request denied by
                                        @elseif($log->closure_re_open_at != NULL )
                                            {{  date('M d, Y h:i A',strtotime($log->closure_re_open_at))  }} - Closure request re-open by
                                        @endif
                                           <i>{{ ucfirst($log->user->name) }}</i>
                                        @if($log->closure_denied_at != NULL )
                                            because of insufficient or incomplete information.
                                        @endif   
                                        
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->


            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold">Investigative notes</span>
                     @if (\MSLST\Helpers\Common::canAccessEdit(null, 'incident', null, $incident))
                      <div class="pull-right">
                        <div class="btn-group">
                        @if(!isset($incident->closed_at) || (\Auth::User()->isAdmin()))
                            <button type="button" class="btn btn-default btn-xs" id="new_incident_findings" alt='{{$incident->id}}' >
                                Add
                            </button>
                        @endif
                        </div>
                    </div>
                    @endif
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <tbody>
                                @foreach($findings as $log)
                              
                                <tr>
                                    <td class="col-md-10">
                                            <span>{{ $log->findings }}</span><br/>
                                            <span>
                                                 <small> <i>
                                                   @if($log->updated_at != NULL)
                                                      Updated by {{ucfirst($log->User->first_name)." ".$log->User->last_name}} on {{date('M d,Y',strtotime($log->updated_at)) }} 
                                                   @elseif($log->created_at != NULL)
                                                        Created by {{ucfirst($log->User->first_name)." ".$log->User->last_name}} on {{date('M d,Y',strtotime($log->created_at)) }}
                                                   @endif
                                                   </i></small>
                                            </span>
                                    </td>
                                    <td class="col-md-1">
                                         @if (\MSLST\Helpers\Common::canAccessEdit(null, 'incident', null, $incident))
                                            <span class="fa fa-pencil-square-o editaction" aria-hidden="true" id="findingedit" alt='{{$log->id}}' title="Edit"></span>
                                            <span class="glyphicon glyphicon-trash deleteaction" aria-hidden="true" id="findingdelete" alt='{{$log->id}}' title="Delete"></span>
                                         @endif
                                        {{Form::hidden('newfinding',$log->findings,array('id'=>'newfindings'.$log->id))}} 
                                    </td>
                                </tr>
                                @endforeach
                                {{Form::hidden('incidentid',$incident->id,array('id'=>'incidentid'))}}
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-4 -->
    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->

<!--script src="//js.api.here.com/ee/2.5.4/jsl.js?with=all" type="text/javascript" charset="utf-8"></script-->
<script type="text/javascript" charset="utf-8" src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
	var Incidents = {
		mapElement: 'incident_map',
		coordinates: '{{ $coordinates }}'
	};
    var Products = {};
        Products['description'] = {};
        Products['units'] = {};
        Products['value'] = {};
</script>

@stop
