@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header">
                Audit
                <div class="btn-group pull-right incident-btns">
                    {{ Form::button('<i class="fa fa-plus "></i> Add Location', ['type' => 'button', 'class' => 'btn btn-primary', 'href' => route('locations.create')]) }}
                    {{ Form::button('<i class="fa fa-plus "></i> Add Route', ['type' => 'button', 'class' => 'btn btn-primary', 'href' => route('routes.create')]) }}
                </div>
            </h2>
        </div>
        <!-- /.col-lg-12 -->
    </div>

     @if(Session::has('success'))
    <div id="form-success" class="alert alert-success" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div>
    <!-- end form-success -->
    @endif

    <div class="row">
        <div class="col-lg-12">
              <div class="ibox float-e-margins animated flipInX">
                    <div class="ibox-title">
                        <h5>
                            <i class="fa fa-filter" aria-hidden="true"></i> Filters
                        </h5>
                        <div class="ibox-tools">
                            <a class="collapse-link"> <i class="fa fa-chevron-up"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                        <div class="row">
                             <div class="panel panel-default sitemasters-panel">
                                <div class="panel-heading">
                                      {{ Form::open(['action' => 'AuditsController@getIndex', 'method' => 'get', 'id' => 'audits-list-form', 'role' => 'form', 'class' => 'form-inline']) }}
                                        <div class="form-group-row">
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon">Type</span>
                                                    {{ Form::select('type', ['locations' => 'Locations', 'routes' => 'Routes'], Input::get('type'), ['class' => 'form-control']) }}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                                    {{ Form::text('daterange', Input::get('daterange'), ['class' => 'form-control']) }}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon">Auditor</span>
                                                    {{ Form::select('auditor[]', $auditors, Input::get('auditor'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon">LSP</span>
                                                    {{ Form::select('lsp[]', $lsps, Input::get('lsp'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                </div>                               
                                            </div>
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon">Region</span>
                                                   {{ Form::select('region[]', $regions, Input::get('region'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                </div>                               
                                            </div>
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon">Country</span>
                                                   {{ Form::select('country[]', $countries, Input::get('country'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                </div>                              
                                            </div>
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon">Score</span>
                                                    {{ Form::select('score[]', ['g' => '&gt;= 80', 'y' => '&gt;= 60 and &lt; 80', 'r' => '&lt; 60'], Input::get('score'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                </div>                               
                                            </div>
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon">Review</span>
                                                    {{ Form::select('review[]', ['1' => 'Requested', '0' => 'Not Requested'], Input::get('review'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                </div>                              
                                            </div>
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon">Status</span>
                                                    {{ Form::select('status[]', ['active' => 'Active', 'inactive' => 'Inactive'], Input::get('status'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                                </div>                              
                                            </div>
                                            <div class="form-group">
                                                <div class="input-group">
                                                    <span class="input-group-addon">Audit ID</span>
                                                    {{ Form::text('aid', Input::get('aid'), ['class' => 'form-control']) }}
                                                </div>                              
                                            </div>
                                            <div class="form-group text-left hidden">
                                                {{ Form::button('Filter', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                                                {{ Form::button('Reset', ['type' => 'reset', 'class' => 'btn btn-primary', 'id' => 'audit-filter-reset']) }}
                                            </div>
                                        </div>
                                        {{ Form::close() }}
                                </div>
                             </div>
                        </div>
                    </div>
              </div>

 
              <div class="ibox float-e-margins animated flipInX">
                                <div class="ibox-title">
                                    <h5>
                                        <i class="fa fa-table" aria-hidden="true"></i> Audit
                                    </h5>
                                    <div class="ibox-tools">
                                         
                                    </div>
                                </div>
                                <div class="ibox-content">
                                    <div class="row">
                                         <div class="col-lg-12">
                                             <div class="panel panel-default sitemasters-panel">
                                                <div class="panel-body">
                                                     <table class="table table-hover table-bordered" id="audits-list">
                                                            @if ($type == 'Route')
                                                            <thead id="route-head">
                                                                <th></th>
                                                                <th>Type</th>
                                                                <th>Date</th>
                                                                <th>LSP</th>
                                                                <th>Country</th>
                                                                <th>Origin</th>
                                                                <th>Destination</th>
                                                                <th>Status</th>
                                                                <th>Auditor</th>
                                                                <th>Score</th>
                                                            </thead>
                                                            <tbody>
                                                                @foreach($audits as $audit)
                                                                <tr class="clickable-row route-item @if($audit->status == 'inactive') warning @endif" title="{{ucfirst($audit->status)}}" data-id="{{ $audit->id }}" data-status="{{(int)$audit->tapa_needed}}">
                                                                    <td>
                                                                    @if($audit->review == 1)
                                                                        <span class="glyphicon glyphicon-exclamation-sign icon-red"></span>
                                                                    @endif
                                                                    </td>
                                                                    <td>{{ $type }}</td>
                                                                    <td>{{ $audit->created_at->format('Y-m-d') }}</td>
                                                                    <td>{{ $audit->lsp->name }}</td>
                                                                    <td>{{ $audit->start_country->name }}</td>
                                                                    <td>{{ utf8_decode($audit->start_site) }}</td>
                                                                    <td>{{ utf8_decode($audit->end_site) }}</td>
                                                                    <td>{{ ucfirst($audit->status) }}</td>
                                                                    <td>{{ $audit->user->name }}</td>
                                                                    <td 
                                                                    @if($audit->score >= 80)
                                                                        class="success"
                                                                    @elseif($audit->score >= 60)
                                                                        class="warning"
                                                                    @else
                                                                        class="danger"
                                                                    @endif
                                                                    >
                                                                    @if(!$audit->tapa_needed)
                                                                        <small>Audit Pending</small>
                                                                    @else
                                                                        {{ round($audit->score, 2) }}
                                                                    @endif
                                                                    </td>
                                                                </tr>
                                                                @endforeach
                                                            </tbody>
                                                            @else
                                                            <thead id="location-head">
                                                                <th></th>
                                                                <th>Type</th>
                                                                <th>Date</th>
                                                                <th>LSP</th>
                                                                <th>Country</th>
                                                                <th>Sitename</th>
                                                                <th>Status</th>
                                                                <th>Auditor</th>
                                                                <th>Score</th>
                                                            </thead>
                                                            <tbody>
                                                                @foreach($audits as $audit)
                                                                <tr class="clickable-row location-item @if($audit->status == 'inactive') warning @endif" title="{{ucfirst($audit->status)}}" data-id="{{ $audit->id }}" data-status="{{(int)$audit->tapa_needed}}" data-seldate="{{$audit->created_at->format('Ymd')}}">
                                                                    <td>
                                                                    @if($audit->review == 1)
                                                                        <span class="glyphicon glyphicon-exclamation-sign icon-red"></span>
                                                                    @endif
                                                                    </td>
                                                                    <td>{{ $type }}</td>
                                                                    <td>{{ $audit->created_at->format('Y-m-d') }}</td>
                                                                    <td>@if(isset($audit->lsp->name)) {{ $audit->lsp->name }} @else  &nbsp; @endif</td>
                                                                    <td>@if(isset($audit->country->name)) {{ $audit->country->name }} @else  &nbsp; @endif</td>
                                                                    <td>{{ utf8_decode($audit->site) }}</td>
                                                                    <td>{{ ucfirst($audit->status) }}</td>
                                                                    <td>{{ $audit->user->name }}</td>
                                                                    <td 
                                                                    @if($audit->score >= 80)
                                                                        class="success"
                                                                    @elseif($audit->score >= 60)
                                                                        class="warning"
                                                                    @else
                                                                        class="danger"
                                                                    @endif
                                                                    >@if(!$audit->tapa_needed)<small>Audit Pending</small>@else{{ round($audit->score, 2) }} @endif</td>
                                                                </tr>
                                                                @endforeach
                                                            </tbody>
                                                            @endif
                                                    </table>
                                                </div>
                                             </div>
                                         </div>
                                    </div>
                                </div>
              </div>
        </div>
    </div>

</div>
 
<!-- /#page-wrapper -->
@stop