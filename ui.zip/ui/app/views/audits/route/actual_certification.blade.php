@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Route</h1>
                @else
                  <h1 class="page-header">Create Route</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Actual Certification</div>
                    {{ Form::open(['route' => ($edit ? ['routes.update', $data->id] : 'routes.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal audit-form', 'role' => 'form', 'id' => 'route-form-actual', 'files' => true]) }}
                        {{ Form::hidden('step', 2) }}   
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard">
                                    <a>
                                      <span>Route Details</span>
                                    </a>
                                    <a>
                                      <span>Needed Certification</span>
                                    </a>
                                    <a class="current">
                                      <span>Actual Certification</span>
                                    </a>
                                    <a>
                                      <span>Questions</span>
                                    </a>
                                    <a>
                                      <span>Comments</span>
                                    </a>
                                  </div>

                                  @if($errors->all())
                                  <div id="form-errors" class="alert alert-danger" role="alert">
                                    <ul>
                                      @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                      @endforeach
                                    </ul>
                                  </div>
                                  @endif

                                  <div class="form-group">
                                    <div class="row">
                                        <h4 class="col-sm-6 col-sm-offset-1">
                                        Facility Security Standards 
                                        </h4>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6 col-sm-offset-1 description">
                                        Please select the international security standards this storage facility is compliant with: 
                                        </div>
                                    </div>
                                  </div>

                                  <div class="form-group certification-post">
                                    <div class="col-sm-4">
                                        <div class="row">
                                            <div class="col-sm-12 certification-label">
                                              {{ HTML::image('/images/tapa.png', 'TAPA') }}
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12 certification-content">
                                                <div class="btn-group btn-group-vertical list-certification" data-toggle="buttons">
                                                  @if(!$edit)
                                                  <label class="btn btn-primary active">
                                                    {{ Form::radio('tapa', 0, ($edit ? $data->tapa == 0 : true), ['id' => 'tapa_none']) }}
                                                     None
                                                  </label>
                                                  @endif
                                                  
                                                  <?php $active = ($data->tapa == $tapa_tsr_1 ? 'active' : ''); ?>
                                                  @if($edit)
                                                  <label class="btn btn-primary {{ $active }}">
                                                    {{ Form::radio('tapa', $tapa_tsr_1, boolval($active), ['id' => 'tapa_tsr_1']) }}
                                                     TAPA TSR 1
                                                  </label>
                                                  @else
                                                  <label class="btn btn-primary">
                                                    {{ Form::radio('tapa', $tapa_tsr_1, boolval($active), ['id' => 'tapa_tsr_1']) }}
                                                     TAPA TSR 1
                                                  </label>
                                                  @endif
                                                  
                                                  <?php $active = ($data->tapa == $tapa_tsr_2 ? 'active' : ''); ?>
                                                  @if($edit)
                                                  <?php $attributes = ['id' => 'tapa_tsr_2']; ?>
                                                  <?php $disabled = ($data->tapa == $tapa_tsr_1 ? ['disabled' => 'disabled'] : []); ?>
                                                  <label class="btn btn-primary {{ $active }} {{ $disabled ? 'disabled' : '' }}">
                                                    {{ Form::radio('tapa', $tapa_tsr_2, boolval($active), $attributes + $disabled) }}
                                                     TAPA TSR 2
                                                  </label>
                                                  @else
                                                  <label class="btn btn-primary">
                                                    {{ Form::radio('tapa', $tapa_tsr_2, boolval($active), ['id' => 'tapa_tsr_2']) }}
                                                     TAPA TSR 2
                                                  </label>
                                                  @endif


                                                  <?php $active = ($data->tapa == $tapa_tsr_3 ? 'active' : ''); ?>
                                                  @if($edit)
                                                  <?php $attributes = ['id' => 'tapa_tsr_3']; ?>
                                                  <?php $disabled = (($data->tapa == $tapa_tsr_1 || $data->tapa == $tapa_tsr_2) ? ['disabled' => 'disabled'] : []); ?>
                                                  <label class="btn btn-primary {{ $active }} {{ $disabled ? 'disabled' : '' }}">
                                                    {{ Form::radio('tapa', $tapa_tsr_3, boolval($active), $attributes + $disabled) }}
                                                     TAPA TSR 3
                                                  </label>
                                                  @else
                                                  <label class="btn btn-primary">
                                                    {{ Form::radio('tapa', $tapa_tsr_3, boolval($active), ['id' => 'tapa_tsr_3']) }}
                                                     TAPA TSR 3
                                                  </label>
                                                  @endif
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <p>&nbsp;</p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12 certification-upload tapa-certificate-upload">
                                                {{ Form::file('tapa_certificate') }}
                                                <div class="description">Please attach TAPA certificate [Only PDF, JPG, DOC and DOCX file types are allowed.]</div>
                                            </div>
                                        </div>                                            
                                    </div>
                                    @if (!$edit || $data->ctpat !== 'na')
                                    <div class="col-sm-4">
                                        <div class="row">
                                            <div class="col-sm-12 certification-label">
                                                {{ HTML::image('/images/ctpat.png', 'C-TPAT') }}
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12 certification-content">
                                                <div class="btn-group btn-group-vertical list-certification" data-toggle="buttons">
                                                  @if(!$edit)
                                                  <label class="btn btn-primary active">
                                                    {{ Form::radio('ctpat', 0, ($edit ? $data->ctpat == 0 : true), ['id' => 'ctpat_none']) }}
                                                     None
                                                  </label>
                                                  @endif

                                                  <label class="btn btn-primary {{ $edit ? 'active' : '' }}">
                                                    {{ Form::radio('ctpat', $c_tpat, ($edit ? $data->ctpat == $c_tpat : false), ['id' => 'ctpat']) }}
                                                     C-TPAT
                                                  </label>
                                                  
                                                  @if($edit)
                                                  <label class="btn btn-primary">
                                                    {{ Form::radio('ctpat', 'na', ($edit ? $data->ctpat == 'na' : false), ['id' => 'ctpat_na']) }}
                                                     Not Applicable
                                                  </label>
                                                  @else
                                                  <label class="btn btn-primary">
                                                    {{ Form::radio('ctpat', 'na', ($data->ctpat == 'na' ? true : false), ['id' => 'ctpat_na']) }}
                                                     Not Applicable
                                                  </label>

                                                  @endif
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="col-sm-6 certification-number col-sm-offset-3">
                                                  {{ Form::text('svi_num', ($edit ? $data->svi_num : ''), ['id'=>'svi_num','class' => 'form-control required-field', 'placeholder' => 'SVI Number','maxlength'=>'24']) }}
                                                </div>
                                            </div>
                                        </div>                                            
                                        <div class="row">
                                            <div class="col-sm-12 certification-upload ctpat-certificate-upload">
                                                {{ Form::file('ctpat_certificate') }}
                                                <div class="description">Please attach C-TPAT certificate [Only PDF, JPG, DOC and DOCX file types are allowed.]</div>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                    @if (!$edit || $data->aeo !== 'na')
                                    <div class="col-sm-4">
                                        <div class="row">
                                            <div class="col-sm-12 certification-label">
                                                {{ HTML::image('/images/aeo.png', 'AEO') }}
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12 certification-content">
                                                <div class="btn-group btn-group-vertical list-certification" data-toggle="buttons">
                                                  @if(!$edit)
                                                  <label class="btn btn-primary active">
                                                    {{ Form::radio('aeo', '0', ($edit ? $data->aeo == 0 : true), ['id' => 'aeo_none']) }}
                                                     None
                                                  </label>
                                                  @endif

                                                  <label class="btn btn-primary {{ ($edit ? ($data->aeo == $aeo_s ? 'active' : '') : '') }}">
                                                    {{ Form::radio('aeo', $aeo_s, ($edit ? $data->aeo == $aeo_s : false), ['id' => 'aeo_s']) }}
                                                     AEO S
                                                  </label>
                                                  
                                                  <label class="btn btn-primary {{ ($edit ? ($data->aeo == $aeo_f ? 'active' : '') : '') }}">
                                                    {{ Form::radio('aeo', $aeo_f, ($edit ? $data->aeo == $aeo_f : false), ['id' => 'aeo_f']) }}
                                                     AEO F
                                                  </label>

                                                  <label class="btn btn-primary {{ ($edit ? ($data->aeo == $aeo_c ? 'active' : '') : '') }}">
                                                    {{ Form::radio('aeo', $aeo_c, ($edit ? $data->aeo == $aeo_c : false), ['id' => 'aeo_c']) }}
                                                     AEO C
                                                  </label>

                                                  @if($edit)
                                                  <label class="btn btn-primary">
                                                    {{ Form::radio('aeo', 'na', ($edit ? $data->aeo == 'na' : false), ['id' => 'aeo_na']) }}
                                                     Not Applicable
                                                  </label>
                                                  @else
                                                  <label class="btn btn-primary">
                                                    {{ Form::radio('aeo', 'na', ($data->aeo == 'na' ? true : false), ['id' => 'aeo_na']) }}
                                                     Not Applicable
                                                  </label>
                                                  @endif
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <div class="col-sm-6 certification-number col-sm-offset-3">
                                                    {{ Form::text('aeo_num', ($edit ? $data->aeo_num : ''), ['id'=>'aeo_num','class' => 'form-control required-field', 'placeholder' => 'AEO Number','maxlength'=>24]) }}
                                                </div>
                                            </div>
                                        </div>                                            
                                        <div class="row">
                                            <div class="col-sm-12 certification-upload aeo-certificate-upload">
                                                {{ Form::file('aeo_certificate') }}
                                                <div class="description">Please attach AEO certificate [Only PDF, JPG, DOC and DOCX file types are allowed.]</div>
                                            </div>
                                        </div>                                            
                                    </div>
                                    @endif
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('routes.show', $data->id),'id'=>"audit_cancel" ]) }}
                        @else
                          <div class="clearfix">
                            <div class="pull-left">
                              <!-- {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }} -->
                              <a href="{{($edit ? ['routes.update', $data->id] : '1')}}" class='btn btn-default'>Back</a>
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('audits.index'),'id'=>"audit_cancel" ]) }}
                            </div>
                          </div>
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
@stop