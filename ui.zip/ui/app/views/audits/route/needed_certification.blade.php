@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Route</h1>
                @else
                  <h1 class="page-header">Create Route</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Needed Certification</div>
                    {{ Form::open(['route' => ($edit ? ['routes.update', $data->id] : 'routes.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal audit-form', 'role' => 'form', 'id' => 'route-form-needed']) }}
                        {{ Form::hidden('step', 1) }}                    
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard">
                                    <a>
                                      <span>Route Details</span>
                                    </a>
                                    <a class="current">
                                      <span>Needed Certification</span>
                                    </a>
                                    <a>
                                      <span>Actual Certification</span>
                                    </a>
                                    <a>
                                      <span>Questions</span>
                                    </a>
                                    <a>
                                      <span>Comments</span>
                                    </a>
                                  </div>

                                  <div class="form-group certification-pre">
                                    {{ Form::label('certification', 'Certification', ['class' => 'col-sm-2 control-label required']) }}
                                    <div class="col-sm-6">
                                         <?php $tapa_Opt1 = true;  $tapa_Opt2 = false;  $tapa_Opt3 = false; ?>
                                            @if($data->tapa_needed == $tapa_tsr_2)
                                              <?php $tapa_Opt1 = false;  $tapa_Opt2 = true;  $tapa_Opt3 = false;?>
                                            @elseif($data->tapa_needed == $tapa_tsr_3)
                                              <?php $tapa_Opt1 = false;  $tapa_Opt2 = false;  $tapa_Opt3 = true;?>
                                            @endif
                                        <div class="btn-group list-certification" data-toggle="buttons">
                                          <label class="btn btn-primary @if($tapa_Opt1 == true) active @endif">
                                            {{ Form::radio('tapa_needed', $tapa_tsr_1, $tapa_Opt1, ['id' => 'tapa_tsr_1']) }} TAPA TSR 1
                                          </label>
                                          <label class="btn btn-primary @if($tapa_Opt2 == true) active @endif">
                                            {{ Form::radio('tapa_needed', $tapa_tsr_2, $tapa_Opt2, ['id' => 'tapa_tsr_2']) }} TAPA TSR 2
                                          </label>
                                          <label class="btn btn-primary @if($tapa_Opt3 == true) active @endif">
                                            {{ Form::radio('tapa_needed', $tapa_tsr_3, $tapa_Opt3, ['id' => 'tapa_tsr_3']) }} TAPA TSR 3
                                          </label>
                                        </div>
                                    </div>
                                  </div>
                                  <div class="form-group certification-post">
                                    <div class="col-sm-6 col-sm-offset-2 description">
                                    According to the contractual Security Appendix, what is the required TAPA TSR level for this route?
                                    </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('locations.show', $data->id),'id'=>"audit_cancel" ]) }}
                        @else
                          <div class="clearfix">
                            <div class="pull-left">
                             <!-- {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }} -->
                              <a href="{{($edit ? ['routes.update', $data->id] : '0')}}" class='btn btn-default'>Back</a>
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('audits.index'),'id'=>"audit_cancel" ]) }}
                            </div>
                          </div>
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
@stop