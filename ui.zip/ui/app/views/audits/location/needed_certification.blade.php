@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Location</h1>
                @else
                  <h1 class="page-header">Create Location</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Needed Certification</div>
                    {{ Form::open(['route' => ($edit ? ['locations.update', $data->id] : 'locations.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal audit-form', 'role' => 'form', 'id' => 'location-form-needed']) }}
                        {{ Form::hidden('step', 1) }}                    
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard">
                                    <a>
                                      <span>Location Details</span>
                                    </a>
                                    <a class="current">
                                      <span>Needed Certification</span>
                                    </a>
                                    <a>
                                      <span>Actual Certification</span>
                                    </a>
                                    <a>
                                      <span>Questions</span>
                                    </a>
                                    <a>
                                      <span>Comments</span>
                                    </a>
                                  </div>

                                  <div class="form-group certification-pre">
                                    {{ Form::label('certification', 'Certification', ['class' => 'col-sm-2 control-label required']) }}
                                    <div class="col-sm-6">
                                           <?php $active = 'active'; $inactive =  'inactive';  $tapa_aOpt = true;  $tapa_cOpt = false;  ?>
                                            @if($data->tapa_needed == $tapa_fsr_c)
                                              <?php $active = 'inactive'; $inactive ='active';   $tapa_cOpt = true;  $tapa_aOpt = false; ?>
                                            @endif
                                        <div class="btn-group list-certification" data-toggle="buttons">
                                          <label class="btn btn-primary {{$active}}">
                                            {{ Form::radio('tapa_needed', $tapa_fsr_a, $tapa_aOpt , ['id' => 'tapa_fsr_a']) }} TAPA FSR A
                                          </label>
                                          <label class="btn btn-primary {{$inactive}}">
                                            {{ Form::radio('tapa_needed', $tapa_fsr_c, $tapa_cOpt , ['id' => 'tapa_fsr_c']) }} TAPA FSR C
                                          </label>
                                        </div>
                                    </div>
                                  </div>
                                  <div class="form-group certification-post">
                                    <div class="col-sm-6 col-sm-offset-2 description">
                                    According to the contractual Security Appendix, what is the required TAPA FSR level for this location?
                                    </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('locations.show', $data->id),'id'=>"audit_cancel" ]) }}
                        @else
                          <div class="clearfix">
                            <div class="pull-left">
                              <!-- {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }} -->
                              <a href="{{($edit ? ['locations.update', $data->id] : '0')}}" class ='btn btn-default' alt='Back'>Back</a>
                            </div>
                            <div class="pull-right">
                              {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                              {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('audits.index'),'id'=>"audit_cancel" ]) }}
                            </div>
                          </div>
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
@stop