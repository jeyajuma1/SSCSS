@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
            View Location
                          @if($location->review == 1)
                                    <span class="glyphicon glyphicon-exclamation-sign icon-red"></span>
                          @endif
            <div class="pull-right">
                <div class="btn-group audit-btns">
                    {{ Form::open(['route' => 'audits.index', 'method' => 'get']) }}
                        {{ Form::hidden('type', 'locations') }}
                        {{ Form::button('Go Back', ['type' => 'submit', 'class' => 'btn-gray']) }}
                    {{ Form::close() }}

                    @if (\Auth::User()->isAdmin())
                        @if($location->review == 0)
                            {{ Form::open(['route' => ['locations.review', $location->id ,'request'], 'method' => 'patch']) }}
                                {{ Form::button('Request Review', ['type' => 'submit', 'class' => 'btn-gray location-review-button']) }}
                                {{ Form::hidden('review_message', '') }}
                            {{ Form::close() }}
                        @else
                            {{ Form::open(['route' => ['locations.review', $location->id, 'clear'], 'method' => 'patch']) }}
                                {{ Form::button('Clear Review', ['type' => 'submit', 'class' => 'btn-gray']) }}
                                {{ Form::hidden('review_message', '') }}
                            {{ Form::close() }}
                        @endif

                        {{ Form::open(['route' => ['locations.destroy', $location->id], 'method' => 'delete']) }}
                            {{ Form::button('Remove', ['type' => 'submit', 'class' => 'btn-gray location-delete-button']) }}
                        {{ Form::close() }}
                    @endif

                    {{ Form::open(['route' => ['locations.show', $location->id]]) }}
                        {{ Form::button('Print', ['type' => 'button', 'class' => 'btn-blue', 'onclick' => 'javascript:window.print()']) }}
                    {{ Form::close() }}

                 @if (\Auth::User()->isAdmin() || \Auth::User()->isSupervisor() || \Auth::User()->isManager())
                   @if($location->status == 'active')
                    {{ Form::open(['route' => ['locations.status', $location->id,'inactive'] , 'method'=>'patch']) }}
                        {{ Form::button('Make Inactive',['type' => 'submit' , 'class' =>'btn-blue location-inactive-button' ]) }}
                    {{ Form::close() }}
                   @elseif($location->status == 'inactive')
                    {{ Form::open(['route' => ['locations.status', $location->id,'active'] , 'method'=>'patch']) }}
                        {{ Form::button('Make Active',['type' => 'submit' , 'class' =>'btn-blue location-active-button' ]) }}
                    {{ Form::close() }}
                   @endif
                @endif
                </div>
            </div>
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->

    @if(Session::has('success'))
    <div id="form-success" class="alert alert-success" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div>
    <!-- end form-success -->
    @endif

    <div class="row audit-show">
        <div class="col-lg-8">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i> <span class="font-bold">Location Information</span>
                   
                    @if (\MSLST\Helpers\Common::canAccessEdit(null, 'location', null, $location))
                    <div class="pull-right">
                        <div class="btn-group">
                            <button type="button" class="btn btn-default btn-xs" href="{{ route('locations.edit', [$location->id]) }}">
                                Edit
                            </button>
                        </div>
                    </div>
                    @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="incidents-basic-table">
                            <tbody>
                                <tr class="font-darkblue-first">
                                    <td>
                                        Location                                        
                                    </td>
                                    <td>
                                        Address                                       
                                    </td>
                                    <td>
                                        GPS Coordinates                                       
                                    </td>
                                </tr>

                                <tr>
                                     <td>
                                 {{ $location->site }}
                                    </td>
                                    <td>
                                   
                                        {{ $location->address }}
                                    </td>
                                    <td>
                                        {{ $location->coordinates }}
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3">
                                        <div id="location_map" class="detail-view-map span12 col-sm-12">
                                        </div>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold">Current Certifications</span>
                    @if (\MSLST\Helpers\Common::canAccessEdit(null, 'location', null, $location))
                    <div class="pull-right">
                        <div class="btn-group">
                            <button type="button" class="btn btn-default btn-xs" href="{{ route('locations.edit', [$location->id, 2]) }}">
                                Edit
                            </button>
                        </div>
                    </div>
                    @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="incidents-basic-table">
                        	<thead>
                        		<tr class="font-darkblue">
	                        		<td>TAPA</td>
	                        		<td>C-TPAT</td>
	                        		<td>AEO</td>
                        		</tr>
                        	</thead>
                            <tbody>
                                <tr>
                                    <td>
                                    	Needed Certification: {{ $current_certifications['tapa_needed'] }}<br />
                                    	Actual Certification: {{ $current_certifications['tapa_actual'] }}
                                    </td>
                                    <td>
                                    	{{ $current_certifications['c_tpat'] }}
                                    </td>
                                    <td>
                                    	{{ $current_certifications['aeo'] }}
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        &nbsp;
                                    </td>
                                    <td>
                                        @if($location->ctpat_number != "")
                                            SVI Number: {{ $location->ctpat_number }}
                                        @else
                                            SVI Number: NA
                                        @endif
                                    </td>
                                    <td>
                                        @if($location->aeo_number)
                                            AEO Number: {{ $location->aeo_number }}
                                        @else
                                            AEO Number: NA
                                        @endif
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold">Questions &amp; Answers</span>
                    @if (\MSLST\Helpers\Common::canAccessEdit(null, 'location', null, $location))
                    <div class="pull-right">
                        <div class="btn-group">
                            <button type="button" class="btn btn-default btn-xs" href="{{ route('locations.edit', [$location->id, 3]) }}">
                                Edit
                            </button>
                        </div>
                    </div>
                    @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    @if(!empty($audits))
					<div class="panel-group" id="accordion">
						@foreach($audits as $category => $list)
							<div class="panel panel-default">
								<div class="panel-heading">
								    <h4 class="panel-title">
								    	<a data-toggle="collapse" data-parent="#accordion" href="#{{ md5($category) }}">
								      		{{ $category }}
								    	</a>
								    </h4>
								</div>
								<div id="{{ md5($category) }}" class="panel-collapse collapse">
								  	<div class="panel-body">
										<div class="panel-group" id="accordion_{{ md5($category) }}">
											@foreach($list as $question_category => $questions)
												<div class="panel panel-default">
													<div class="panel-heading">
													    <h4 class="panel-title">
													    	<a data-toggle="collapse" data-parent="#accordion_{{ md5($category) }}" href="#{{ md5($category.$question_category) }}">
													      		{{ $question_category }}
													    	</a>
													    </h4>
													</div>
													<div id="{{ md5($category.$question_category) }}" class="panel-collapse collapse">
													  	<div class="panel-body">
													  		{{--*/ $i=1; /*--}}
														    @foreach($questions as $question)
									                            <div class="question-wrapper">
									                                <div class="question-circle {{ $question['class'] }}" title="{{ $legend[$question['class']] }}" data-toggle="tooltip" data-placement="bottom">
									                                    &nbsp;
									                                </div>
									                                <div class="answer-wrapper">
										                                <h5>
										                                	<span class="{{ $question['class'] }}">
										                                		{{ $i++ }}
										                                	</span>. {{ $question['text'] }}
										                                </h5>
										                                <div class="answer">
										                                    @if (isset($question['comment']) && $question['comment'] != '')
											                                    <div class="comment">
											                                        <p>{{ $question['comment'] }}</p>
											                                    </div>
										                                    @else
										                                    	<p>&nbsp;</p>
										                                    @endif
										                                </div>
									                                </div>
									                            </div>
														    @endforeach
													  	</div>
													</div>
												</div>
											@endforeach
										</div>
								  	</div>
								</div>
							</div>
						@endforeach
					</div>
                    @else
                        <p>There are no questions & answers.</p>
                    @endif
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold">Comments</span>
                    @if (\MSLST\Helpers\Common::canAccessEdit(null, 'location', null, $location))
                    <div class="pull-right">
                        <div class="btn-group">
                            <button type="button" class="btn btn-default btn-xs" href="{{ route('locations.edit', [$location->id, 4]) }}">
                                Edit
                            </button>
                        </div>
                    </div>
                    @endif
                </div>
                <!-- /.panel-heading -->
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="incidents-basic-table">
                            <tbody>
                                <tr>
                                	<td>
                                		{{ $location->comment }}
                                	</td>
                                </tr>
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-8 -->
        <div class="col-lg-4">
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="incidents-basic-table">
                       




<tbody>
                                <tr class="font-darkblue-first">
                                    <td>
                                        Created by
                                    </td>
                                </tr>
                                <tr> 
                                    <td class="incidentviewtd">
<span>{{ $location->user->name }}</span>
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>
                                        Created On
                                    </td>
                                </tr>
                                <tr> 
                                    <td class="incidentviewtd">
<span>{{ $location->created_at->format('M d, Y h:i A') }}</span>
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>
                                        Audit Age
                                    </td>
                                </tr>
                                 <tr> 
                                    <td class="incidentviewtd">
                                       <span>{{ $location->audit_age}} 

                                    </td>
                                </tr>

                                <tr class="font-darkblue">
                                    <td>
                                        LSP
                                    </td>
                                </tr>
                                 <tr> 
                                    <td class="incidentviewtd">
<span>{{ $location->lsp->name }}</span>
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>
                                        Audit ID
                                    </td>
                                </tr>
                                <tr> 
                                    <td class="incidentviewtd">
<span>{{ $location->name }}</span>
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>
                                        Storage Value
                                    </td>
                                </tr>
                                <tr> 
                                    <td class="incidentviewtd">
<span>{{ $location->value ? $location->value . 'USD': "NA" }}</span>
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>
                                       Status
                                    </td>
                                </tr>
                                <tr> 
                                    <td class="incidentviewtd">
<span class="label @if($location->status == 'active') label-success @else label-danger @endif">
{{ucfirst($location->status)}}
</span>
                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>
                                        Score
                                    </td>
                                </tr>
                                <tr> 
                                    <td class="incidentviewtd">
@if($location->score >= 80)
<span class="label label-success">
@elseif($location->score >= 60)
<span class="label label-warning">
@else
<span class="label label-danger">
@endif
@if(!$location->tapa_needed)
Audit Pending
@else
{{ round($location->score, 2) }}
@endif
</span>                                    </td>
                                </tr>
                                <tr class="font-darkblue">
                                    <td>
                                        Last Edit Date
                                    </td>
                                </tr>
                                <tr> 
                                    <td class="incidentviewtd">
<span>{{ $location->updated_at->format('M d, Y h:i A') }}</span>
                                    </td>
                                </tr>



                                @if (\Auth::User()->isAdmin())
                                <tr class="font-darkblue">
                                    <td>
                                        Additional Owners
                                    </td>
                                </tr>
                                 <tr> 
                                    <td class="incidentviewtd">
<span>{{ Form::select('owners', $users, $owners,['multiple' => true]) }}</span>
                                    </td>
                                </tr>
                                @endif
                            </tbody>




                        </table>
                    </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold">Attachments</span>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                      <table class="incidents-basic-table">
                            <tbody>
                            	@if($location->certification->count() > 0)
	                            	@foreach($location->certification as $attachment)
		                                <tr>
		                                    <td>
		                                        <a href="{{ route('audits.download', [$attachment->pivot->id, $location->id, 'location']) }}">{{ str_limit($attachment->pivot->filename?:$attachment->pivot->certificate_file, 40) }}</a><br />
		                                    </td>
		                                </tr>
	                                @endforeach
	                            @else
                            		<tr>
                            			<td>No attachments.</td>
                            		</tr>
                                @endif
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
            <div class="panel panel-default">
                <div class="panel-heading">
                    <i class="fa fa-bar-chart-o fa-fw"></i><span class="font-bold">History Log</span>
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="tbody-small">
                            <tbody class="font-black-small">
                                 <?php //print "<pre>"; print_r($location->location_log); exit; ?>
                             	@foreach($location->location_log as $log)

                                <tr>
                                    <td>
                                        @if($log->created_at != Null )
                                            {{ $log->created_at->format('M d, Y h:i A') }} - Created by {{ $log->user->name }}
                                        @elseif($log->updated_at != Null )
                                            {{ $log->updated_at->format('M d, Y h:i A') }} - Edited by {{ $log->user->name }}
                                        @elseif($log->requested_at != Null )
                                            {{  date('M d, Y h:i A',strtotime($log->requested_at))  }} - Review requested by {{ $log->user->name }}
                                        @elseif($log->cleared_at != Null )
                                            {{  date('M d, Y h:i A',strtotime($log->cleared_at))  }} - Review cleared by {{ $log->user->name }}
                                        @endif
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                     </div>
                </div>
                <!-- /.panel-body -->
            </div>
            <!-- /.panel -->
        </div>
        <!-- /.col-lg-4 -->
    </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->

<!--<script type="text/javascript" charset="UTF-8" src="//js.api.here.com/ee/2.5.4/jsl.js?with=all"></script>-->
 <script type="text/javascript" charset="UTF-8"  src="http://ecn.dev.virtualearth.net/mapcontrol/mapcontrol.ashx?v=7.0"></script>
<script type="text/javascript">
	var Locations = {
		mapElement: 'location_map',
		coordinates: '{{ $coordinates }}'
	};
</script>

@stop
