@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Location</h1>
                @else
                  <h1 class="page-header">Create Location</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Comments</div>
                    {{ Form::open(['route' => ($edit ? ['locations.update', $data->id] : 'locations.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'audit-form', 'role' => 'form', 'id' => 'location-form-comments']) }}
                        {{ Form::hidden('step', 4) }}   
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard">
                                    <a>
                                      <span>Location Details</span>
                                    </a>
                                    <a>
                                      <span>Needed Certification</span>
                                    </a>
                                    <a>
                                      <span>Actual Certification</span>
                                    </a>
                                    <a>
                                      <span>Questions</span>
                                    </a>
                                    <a class="current">
                                      <span>Comments</span>
                                    </a>
                                  </div>


                                   <div class="form-group audit-comments">
                                     {{ Form::label("comments", 'Comments', ['class' => 'control-label']) }}
                                     {{ Form::textarea('comments', $data->comments, ['class' => 'form-control', 'rows' => 3, 'placeholder' => 'Add your comments related to the entire audit process.']) }}
                                   </div>

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('locations.show', $data->id),'id'=>"audit_cancel" ]) }}
                        @else
                          <div class="clearfix">
                            <div class="pull-left">
                             <!-- {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }} -->
                              <a href="{{($edit ? ['locations.update', $data->id] : '3')}}" class ='btn btn-default' alt='Back'>Back</a>
                            </div>
                            <div class="pull-right">
                              {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                              {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('audits.index'),'id'=>"audit_cancel" ]) }}
                            </div>
                          </div>
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
@stop