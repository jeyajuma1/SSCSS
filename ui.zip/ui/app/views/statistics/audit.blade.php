@extends('layouts.master')
@section('content')
<div id="page-wrapper">
            <div class="row">
                 @if(Session::has('message'))
                        <div class="bs-callout bs-callout-info">
                            <h4> {{ Session::get('message') }}</h4>
                        </div>
                 @endif
				<div class="col-lg-12">
				    @if(Input::get('type') == 'chart')
                    <h1 class="page-header">
					   Audits
					   @if(count(json_decode($data_result)) != 0 )
                       {{ Form::open(['action' => 'StatisticsController@getExportXLS', 'method' => 'post', 'id' => 'stat_excel', 'name' => 'stat_excel']) }}
                            <input type="hidden" name="data_chart" id="data_chart" value="" />
                            <input type='hidden' name='data_json' id='data_json' value='{{$data_result}}' />
                             <input type='hidden' name='data_type' id='data_type' value='' />
                            <div class="btn-group pull-right audit-btns" id="export_xls">
                            <button href="#" class="btn btn-primary" type="button">Export as XLS</button>
                            </div>
                       {{Form::close()}}
                       @endif
                    </h1>
					@endif
                </div>
                <!-- /.col-lg-12 -->

            </div>
            <!-- /.row -->
            <div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default statistics-panel">
						@if(Input::get('type') == 'chart')
                        <div class="panel-heading">
                           <?php $Any = array(''=>'Any'); ?>
                           {{ Form::open(['action' => 'StatisticsController@getAudit', 'method' => 'get', 'id' => 'statistics_search', 'name' => 'statistics_search' ,'class' =>'form-inline','role'=>'form']) }}
                             <div class="form-group-row">
                                {{ Form::select('statistics-switch', array('audits'=>'Audits','incidents'=>'Incidents'), 'audits', ['class' => 'form-control', 'id' => 'statistics-switch']) }}
                                {{ Form::hidden('type', Input::get('type'), ['class' => 'form-control', 'id' => 'type']) }}
                             </div>
                             <div class="form-group-row">
                                <div class="form-group">
                                    {{ Form::select('report',array('location'=>'Locations','route'=>'Routes'),Input::get('report'),['class' => 'form-control']) }}
                                </div>
                            </div>
                            <div class="form-group-row">
                                <div class="form-group">
                                    <div class="input-group">
                                        <span class="input-group-addon"><i class="fa fa-filter"></i> Filters</span>
                                            {{ Form::select('filters[]', $filter_labels_chart, Input::get('filters'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                                    </div>
                                </div>
                            </div>
                            <div class="form-group-row">
                                <div class="form-group-row statistics-filter-control form-inline" id="Statistics_first_field">
                                </div>
                                <div class="form-group-row statistics-filter-control form-inline" id="Statistics_middle_field">
                                    <div class="form-group daterange-filter">
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
                                             {{Form::text('daterange',Input::get('daterange'),['class'=>'form-control'])}}
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group-row statistics-filter-control form-inline" id="Statistics_Second_field">
                                </div>
                            </div>
                            <input type="hidden" value="" name="flt_sel" id="flt_sel" />
                            <input type="hidden" value="chart" name="seltype" id="seltype" />
							{{ Form::close() }}
                             <div class="form-group-row statistics-filter-control form-inline">
                                    <div id="score-filter">
                                      <div class="form-group score-filter" >
                                        <div class="input-group">
                                            <span class="input-group-addon">Score</span>
                                               {{Form::select('score',array(''=>'Any','green'=>'&gt;= 80 (green)','yellow'=>'&gt;= 60 and &lt; 80 (yellow)','red'=>'&lt; 60  (red)'),Input::get('score'),['class'=>'form-control'])}}
                                        </div>
                                      </div>
                                    </div>
                                    <div  id="review-filter">
                                     <div class="form-group review-filter">
                                        <div class="input-group">
                                            <span class="input-group-addon">Review</span>
                                             {{Form::select('review',array(''=>'Any',1=>'Requested',0=>'Not Requested'),Input::get('review'),['class'=>'form-control'])}}
                                        </div>
                                     </div>
                                    </div>
                                    <div id="lsp-filter">
                                      <div class="form-group lsp-filter">
                                        <div class="input-group">
                                            <span class="input-group-addon">LSP</span>
                                            {{Form::select('lsp',$Any + $lsp_list,Input::get('lsp'),['class'=>'form-control'])}}
                                        </div>
                                      </div>
                                    </div>
                                    <div id="region-filter">
                                      <div class="form-group region-filter" >
                                        <div class="input-group">
                                            <span class="input-group-addon">Region</span>
                                            {{Form::select('region',$Any + $region_list,Input::get('region'),['class'=>'form-control'])}}
                                        </div>
                                      </div>
                                    </div>
                                    <div id="country-filter">
                                      <div class="form-group country-filter" >
                                        <div class="input-group">
                                            <span class="input-group-addon">Country</span>
                                                {{Form::select('country',$Any + $country_list,Input::get('country'),['class'=>'form-control'])}}
                                        </div>
                                      </div>
                                    </div>
                                   <div id="monthrange-filter">
                                      <div class="form-group monthrange-filter" >
                                        <div class="input-group">
                                            <span class="input-group-addon">Start Range</span>
                                                {{Form::select('start_month',$monthrangeOpt,Input::get('start_month'),['class'=>'form-control'])}}
                                            <span class="input-group-addon">End Range</span>
                                                {{Form::select('end_month',$monthrangeOpt,Input::get('end_month'),['class'=>'form-control'])}}
                                        </div>
                                      </div>
                                    </div>
                                </div>
                        </div>
						@endif
                        <div class="panel-body">
                            @if(Input::get('type') == 'map')
								<div id="map-wrapper">
									<div id="map_canvas" style="position: fixed;right:0; height: 100%; width: 100%; background-color: grey; border: solid 0px #B3B3B3; margin-bottom: 10px;"></div>
									<div id="map-controls" class="col-md-3">

									   <div class="panel panel-default panel-customize">
									   <div class="panel-heading">
										Audits
									   </div>
									   <div class="panel-body">
									   <?php $Any = array(''=>'Any'); ?>
									   {{ Form::open(['action' => 'StatisticsController@getAudit', 'method' => 'get', 'id' => 'statistics_search', 'name' => 'statistics_search' ,'class' =>'form-inline','role'=>'form']) }}
										 <div class="form-group-row">
											{{ Form::select('statistics-switch', array('incidents'=>'Incidents','audits'=>'Audits','suppliers' =>'Suppliers','sitemaster' =>'Sites'), 'audits', ['class' => 'form-control', 'id' => 'statistics-switch']) }}
											{{ Form::hidden('type', Input::get('type'), ['class' => 'form-control', 'id' => 'type']) }}
										 </div>
										 <div class="form-group-row">
											<div class="form-group">
												{{ Form::select('report',array('location'=>'Locations','route'=>'Routes'),Input::get('report')?:'location',['class' => 'form-control']) }}
											</div>
										</div>
										<div class="form-group-row">
											<div class="form-group">
												<div class="input-group">
													<span class="input-group-addon"><i class="fa fa-filter"></i> Filters</span>
														{{ Form::select('filters[]', $filter_labels_map, Input::get('filters'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
												</div>
											</div>
										</div>
										<div class="form-group-row">
											<div class="form-group-row statistics-filter-control form-inline" id="Statistics_first_field">
											</div>
											<div class="form-group-row statistics-filter-control form-inline" id="Statistics_middle_field">
												<div class="form-group daterange-filter">
													<div class="input-group">
														<span class="input-group-addon"><i class="fa fa-calendar"></i></span>
														 {{Form::text('daterange',Input::get('daterange'),['class'=>'form-control'])}}
													</div>
												</div>
											</div>
											<div class="form-group-row statistics-filter-control form-inline" id="Statistics_Second_field">
											</div>
										</div>
										<input type="hidden" value="" name="flt_sel" id="flt_sel" />
                    <input type="hidden" value="map" name="seltype" id="seltype" />
										{{ Form::close() }}
										 <div class="form-group-row statistics-filter-control form-inline">
												<div id="score-filter">
												  <div class="form-group score-filter" >
													<div class="input-group">
														<span class="input-group-addon">Score</span>
														   {{Form::select('score',array(''=>'Any','green'=>'&gt;= 80  (green)','yellow'=>'&gt;= 60 and &lt; 80  (yellow)','red'=>'&lt; 60 (red)'),Input::get('score'),['class'=>'form-control'])}}
													</div>
												  </div>
												</div>
												<div  id="review-filter">
												 <div class="form-group review-filter">
													<div class="input-group">
														<span class="input-group-addon">Review</span>
														 {{Form::select('review',array(''=>'Any',1=>'Requested',0=>'Not Requested'),Input::get('review'),['class'=>'form-control'])}}
													</div>
												 </div>
												</div>
												<div id="lsp-filter">
												  <div class="form-group lsp-filter">
													<div class="input-group">
														<span class="input-group-addon">LSP</span>
														{{Form::select('lsp',$Any + $lsp_list,Input::get('lsp'),['class'=>'form-control'])}}
													</div>
												  </div>
												</div>
												<div id="region-filter">
												  <div class="form-group region-filter" >
													<div class="input-group">
														<span class="input-group-addon">Region</span>
														{{Form::select('region',$Any + $region_list,Input::get('region'),['class'=>'form-control'])}}
													</div>
												  </div>
												</div>
												<div id="country-filter">
												  <div class="form-group country-filter" >
													<div class="input-group">
														<span class="input-group-addon">Country</span>
															{{Form::select('country',$Any + $country_list,Input::get('country'),['class'=>'form-control'])}}
													</div>
												  </div>
												</div>
												<!--<div id="monthrange-filter">
												  <div class="form-group monthrange-filter" >
													<div class="input-group">
														<span class="input-group-addon">Start Range</span>
															{{Form::select('start_month',$monthrangeOpt,Input::get('start_month'),['class'=>'form-control'])}}
														<span class="input-group-addon">End Range</span>
															{{Form::select('end_month',$monthrangeOpt,Input::get('end_month'),['class'=>'form-control'])}}
													</div>
												  </div>
												</div>-->
											</div>
										  </div>
										</div>
									</div>
								</div>
                               <!-- <div class="statistics-map-legend">
                                    <ul>
                                        <li><span class="map-legend-green"></span> greater than 80</li>
                                        <li><span class="map-legend-yellow"></span> between 80 and 60 </li>
                                        <li><span class="map-legend-red"></span> less than 60</li>
                                    </ul>
                                </div> -->
                            @else
                            <!--div id="statistics-audits-chart"></div-->
                            <div class="panel-body">       
                              <div class="statistics-audits-chartdiv" >                
                                    <canvas id="statistics-audits-chart" ></canvas>
                              </div>
                            </div>
                            @endif
                        </div>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
            <!-- /.row -->

                <!-- Modal -->
            <div class="modal fade bs-example-modal-sm" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title" id="myModalLabel">Warning</h4>
                  </div>
                  <div class="modal-body" >
                    Data is too large to display, please narrow it down
                  </div>
                  <div class="modal-footer">
                    <input type="hidden" value="" name="dellane" id="dellane">
                    <button type="button" class="btn btn-primary" id="delete_yes" data-dismiss="modal">Yes</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">No</button>
                  </div>
                </div>
              </div>
            </div>

            <canvas id='drawingArea' style="display:hidden;"></canvas>

        </div>
        <!-- /#page-wrapper -->

    </div>
    <!-- /#wrapper -->

{{ HTML::script('https://code.jquery.com/jquery-1.11.1.min.js') }}
<script type="text/javascript">
         var Statistics = {};
        Statistics.audit_report = JSON.parse('{{$data_result}}');

        if(Statistics.audit_report.length !=0 && Statistics.audit_report != null ){
            Statistics.audit_reportlabel =  JSON.parse('{{$data_label}}');
            Statistics.data = JSON.parse('{{json_encode($data)}}');
            //Statistics.auditXaxais = '{{Input::get('filters.0')}}';
			Statistics.auditXaxais = JSON.parse('{{$data_label}}');
            Statistics.auditYaxais = JSON.parse('{{$auditYaxais}}');
            Statistics.auditChartJSXaxais = JSON.parse('{{$chartjsXaxis}}');
            Statistics.auditChartJSYaxais = JSON.parse('{{$chartjsYaxis}}');
        }
        Statistics.auditfltSel ="{{Input::get('flt_sel')}}";
        Statistics.plottype      = 'chart';
</script>
@if(Input::get('type') == 'map')
{{ HTML::script('//js.api.here.com/ee/2.5.4/jsl.js?with=all') }}
{{ HTML::script('js/maps/cluster.js') }}
    @if(Input::get('report') == 'location' && Input::get('type') == 'map')
    <script type="text/javascript">
            var cordinates = {{$location_res}} ;
            Statistics.plottype      = 'map';
            showNokiaMapLocationsByAddresses(cordinates, 'map_canvas');
    </script>
    @elseif(Input::get('report') == 'route' && Input::get('type') == 'map')
    <script type="text/javascript">
            var cordinates = {{$routes_res}};
            Statistics.plottype      = 'map';
            showNokiaMapRoutesByAddresses(cordinates, 'map_canvas');
    </script>
    @endif
@endif

@if(!empty(Input::get('filters')) && in_array('monthrange',Input::get('filters'),true))
<style type="text/css">
.panel-customize {
    width : 500px !important;
}
</style>
@endif

@if(Input::get('type') == 'map')
<style type="text/css">
    #page-wrapper {
        padding : 0px 15px !important;
        min-height :100% !important;
        height: auto !important;
    }
    #wrapper {
       min-height :100% !important;
       height: auto !important;
    }
    #map_canvas{
       /*height: 830px !important;*/
    }
    footer{
        background :none repeat scroll 0 0 rgba(0, 0, 0, 0.4) !important;
        position:relative;
        padding: 0 15px 5px !important;
    }
    .footer-wrap {
        position: absolute;
        bottom: 0px;
    }
    .container p {
        margin: 0px !important;
    }
    .container .footer-links {
        padding-bottom: 0px !important;
    }
    .footer-links a {
        color :#001b51 !important;
    }

</style>
@endif

@stop
