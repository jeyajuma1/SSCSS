@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
            Add Region
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <span class="font-bold">
                     Add a new region  
                 </span>
                </div>
                {{ Form::open(['route' => 'regions.store', 'class' => 'form-horizontal', 'role' => 'form', 'id' => 'region-add']) }}
                    <div class="panel-body">

                        @if($errors->all())
                        <div id="form-errors" class="alert alert-danger" role="alert">
                          <ul>
                            @foreach($errors->all() as $error)
                              <li>{{ $error }}</li>
                            @endforeach
                          </ul>
                        </div>
                        @endif

                        <div class="form-group">
                            {{ Form::label('name', 'Region Name', ['class' => 'col-lg-2 control-label required']) }}
                            <div class="col-sm-6">
                              {{ Form::text('name', '', ['class' => 'form-control','id'=>'region_name']) }}
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'href' => '/regions']) }}
                    </div>
                {{ Form::close() }}
            </div>
            <!-- /.col-lg-12 -->
        </div>
    <!-- /.row -->
    </div>
<!-- /#page-wrapper -->
</div>
@stop