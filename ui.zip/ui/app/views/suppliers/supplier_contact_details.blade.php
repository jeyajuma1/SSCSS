@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Supplier</h1>
                @else
                  <h1 class="page-header">Create Supplier</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Supplier Contact Details</div>
                    {{ Form::open(['route' => ($edit ? ['suppliers.update', $data->id] : 'suppliers.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal supplier-form', 'role' => 'form', 'id' => 'supplier-form-supplier_contact_details']) }}
                      {{ Form::hidden('step', 2) }}
                        <div class="panel-body" style="width:900px">
                            <div class="row">
                                <div class="col-lg-12">
                                 <div class="wizard" style="margin-left:10px">
                                    <a>
                                      <span>Basic Information</span>
                                    </a>
                                    <a>
                                      <span>Supplier Information</span>
                                    </a>
                                    <a  class="current">
                                      <span>Supplier Contact Details</span>
                                    </a>
                                  </div>

                                  @if($errors->all())
                                  <div id="form-errors" class="alert alert-danger" role="alert">
                                    <ul>
                                      @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                      @endforeach
                                    </ul>
                                  </div>
                                  @endif
                									<div class="form-group" style="margin-top:30px">
                										{{ Form::label('contact_email_address', 'Email Address', ['class' => 'col-lg-3 control-label required']) }}
                										<div class="col-lg-5">
                										{{ Form::text('contact_email_address', $data->contact_email_address, ['class' => 'form-control','maxlength'=>150]) }}
                										</div>
                									</div>
                                  <div class="form-group">
                										{{ Form::label('contact_telephone_number', 'Contact Number', ['class' => 'col-lg-3 control-label required']) }}
                										<div class="col-lg-5">
                										  {{ Form::text('contact_telephone_number', $data->contact_telephone_number, ['class' => 'form-control','maxlength'=>20]) }}
                										</div>
                									 </div>
                								</div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('suppliers.show', $data->id),'id'=>'supplier_cancel_edit']) }}
                        @else
                          <div class="clearfix">
                            <div class="pull-left">
                              {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }}
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('suppliers.index'),'id'=>'supplier_cancel']) }}
                            </div>
                          </div>
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<script type="text/javascript">
  var Suppliers = {'coordinates': null, 'mapElement': null};
  var incident_history_json = null;
  var incident_prevention_json  = null;
  var business_activity  = null;
  var business_assets  = null;
  var business_risk  = null;
  var business_actions  = null;
  var leak_risk_analysis = null;
</script>
@stop