@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Supplier</h1>
                @else
                  <h1 class="page-header">Create Supplier</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->

        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Basic Information</div>
                    {{ Form::open(['route' => ($edit ? ['suppliers.update', $data->id] : 'suppliers.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal supplier-form', 'role' => 'form', 'id' => 'supplier-form-basic']) }}
                        {{ Form::hidden('step', 0) }}
                        <div class="panel-body">
                            <!-- end form-errors -->
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard" style="margin-left:70px">
                                    <a class="current">
                                      <span>Basic Information</span>
                                    </a>
                                    <a>
                                      <span>Supplier Information</span>
                                    </a>
                                    <a>
                                      <span>Supplier Contact Details</span>
                                    </a>
                                  </div>

                                  @if($errors->all())
                                  <div id="form-errors" class="alert alert-danger" role="alert">
                                    <ul>
                                      @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                      @endforeach
                                    </ul>
                                  </div>
                                  @endif

                                   <div class="form-group">
                                    {{ Form::label('vendor_number', 'Vendor Number', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                      {{ Form::text('vendor_number', $data->vendor_number, ['class' => 'form-control','maxlength'=>100]) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('vendor_name', 'Supplier Name', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('vendor_name', $data->vendor_name, ['class' => 'form-control','maxlength'=>100]) }}
                                    </div>
                                  </div>
                                   <div class="form-group">
                                    {{ Form::label('site_name', 'Site Name', ['class' => 'col-sm-3 control-label ']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('site_name', $data->site_name, ['class' => 'form-control','maxlength'=>150]) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('region', 'Region', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-3">
                                    	{{ Form::select('region', $regions, $data->region, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('country', 'Country', ['class' => 'col-sm-3 control-label required ']) }}
                                    <div class="col-sm-3">
                                      {{ Form::select('country', $countries, $data->country, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('city', 'City', ['class' => 'col-sm-3 control-label required']) }}
                                    <div class="col-sm-6">
                                      {{ Form::text('city', $data->city, ['class' => 'form-control','maxlength'=>50]) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('address', 'Address', ['class' => 'col-sm-3 control-label']) }}
                                    <div class="col-sm-6">
                                      {{ Form::textarea('address', $data->address, ['rows'=>2,'class' => 'form-control','maxlength'=>250]) }}
                                    </div>
                                  </div>
								                  <div class="form-group">
                                    {{ Form::label('postal_code', 'Postal Code', ['class' => 'col-sm-3 control-label ']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('postal_code', $data->postal_code, ['class' => 'form-control','maxlength'=>50]) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('coordinates', 'Coordinates', ['class' => 'col-sm-3 control-label required ']) }}
                                    <div class="col-sm-4">
                                      {{ Form::text('coordinates', $data->coordinates, ['class' => 'form-control', 'placeholder' => 'Coordinate format: latitude, longitude', 'id' => 'coordinates','maxlength'=>250]) }}
                                    </div>
                                    <div class="col-sm-2">
                                      {{ Form::button('Validate', ['type' => 'button', 'class' => 'form-control btn btn-primary', 'id' => 'supplier-coordinate-check']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    <div class="col-sm-6 col-sm-offset-3" id="supplier-coordinate-pick"></div>
                                  </div>
                                  <div class="form-group">
                                    <div class="col-sm-6 col-sm-offset-3 description">
                                    (Example: 42.374335,-71.116991 (Decimal Degrees) or N30 17.477,W97 44.315 (GPS) or N42 21 30,W71 06 14 (Degrees, Minutes &amp; Seconds) or 19N 326727 4691707 (UTM))
                                    </div>
                                  </div>

                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('suppliers.show', $data->id),'id'=>'supplier_cancel_edit']) }}
                        @else
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('suppliers.index'),'id'=>'supplier_cancel']) }}
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<script src="https://js.api.here.com/ee/2.5.4/jsl.js?with=all" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
  var Suppliers = {'coordinates': null, 'mapElement': null};
  Suppliers.regions = '{{ $regions_json }}';
  Suppliers.country = '{{ Input::old("country")?:$data->country }}';
 
  var incident_history_json = null;
  var incident_prevention_json  = null;
  var business_activity  = null;
  var business_assets  = null;
  var business_risk  = null;
  var business_actions  = null;
  var leak_risk_analysis = null;
</script>
@stop
