@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="main-content">
        <div class="row">
            <div class="col-lg-12">
                @if($edit)
                  <h1 class="page-header">Edit Supplier</h1>
                @else
                  <h1 class="page-header">Create Supplier</h1>
                @endif
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Supplier Information</div>
                    {{ Form::open(['route' => ($edit ? ['suppliers.update', $data->id] : 'suppliers.store'), 'method' => ($edit ? 'put' : 'post'), 'class' => 'form-horizontal supplier-form', 'role' => 'form', 'id' => 'supplier-form-supplier_information']) }}
                      {{ Form::hidden('step', 1) }}
                        <div class="panel-body" style="width:900px">
                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="wizard" style="margin-left:10px">
                                    <a>
                                      <span>Basic Information</span>
                                    </a>
                                    <a class="current">
                                      <span>Supplier Information</span>
                                    </a>
                                    <a>
                                      <span>Supplier Contact Details</span>
                                    </a>
                                  </div>

                                  @if($errors->all())
                                  <div id="form-errors" class="alert alert-danger" role="alert">
                                    <ul>
                                      @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                      @endforeach
                                    </ul>
                                  </div>
                                  @endif
                                  
                                   <div class="form-group">
                                     {{ Form::label('supplier_handle', 'Does the supplier handle unannounced components/ products containing device ID (size, look, specifications, etc.)?', ['class' => 'col-lg-7 control-label required']) }}
                                    <div class="col-lg-2">
                                     {{ Form::checkbox('supplier_handle',1,$data->supplier_handle) }}
                                    </div>
                                  </div>

								                  <div class="form-group">
                                    {{ Form::label('supplier_type', 'Supplier Type', ['class' => 'col-lg-3 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('supplier_type', $data->supplier_type, ['class' => 'form-control','maxlength'=>100]) }}
                                    </div>
                                  </div>
								                  <div class="form-group">
                                    {{ Form::label('supplier_role', 'Supplier Role', ['class' => 'col-lg-3 control-label ']) }}
                                    <div class="col-lg-2">
                                      {{ Form::select('supplier_role',['Bidder'=>'Bidder','Vendor'=>' Vendor'],$data->supplier_role, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
							                    <div class="form-group">
                                    {{ Form::label('site_technology', 'Site Technology', ['class' => 'col-lg-3 control-label ']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('site_technology', $data->site_technology, ['class' => 'form-control','maxlength'=>100 ]) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('relationship', 'Relationship', ['class' => 'col-lg-3 control-label ']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('relationship', $data->relationship, ['class' => 'form-control','maxlength'=>100]) }}
                                    </div>
                                  </div>
								                  <div class="form-group">
                                    {{ Form::label('category', 'Category', ['class' => 'col-lg-3 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('category', $data->category, ['class' => 'form-control','maxlength'=>100]) }}
                                    </div>
                                  </div>
								                  <div class="form-group">
                                    {{ Form::label('tier', 'Tier', ['class' => 'col-lg-3 control-label ']) }}
                                    <div class="col-lg-2">
                                      {{ Form::select('tier',[''=>'----Select----','0'=>'0','1'=>' 1','2'=>'2','3'=>'3'], $data->tier, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                        @if($edit)
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('suppliers.show', $data->id),'id'=>'supplier_cancel_edit']) }}
                        @else
                          <div class="clearfix">
                            <div class="pull-left">
                              {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }}
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Continue', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('suppliers.index'),'id'=>'supplier_cancel']) }}
                            </div>
                          </div>
                        @endif
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<script type="text/javascript">
  var Suppliers = {'coordinates': null, 'mapElement': null};
  var incident_history_json = null;
  var incident_prevention_json  = null;
  var business_activity  = null;
  var business_assets  = null;
  var business_risk  = null;
  var business_actions  = null;
  var leak_risk_analysis = null;
  </script>
@stop