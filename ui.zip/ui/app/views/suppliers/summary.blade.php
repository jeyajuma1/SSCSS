@extends('layouts.master')

@section('content')
<div id="page-wrapper">
      <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
                Summary
            </h1>
        </div>
      </div>
      <!-- /.row -->
           <!-- /.row -->
    <div class="row">
      <!-- /.col-lg-12 -->
      <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading"><h4>Data not yet saved. Please review the information and confirm once done.</h4></div>
            </div>
            {{ Form::open(['route' => 'suppliers.store', 'method' => 'post', 'class' => 'supplier-form', 'role' => 'form', 'id' => 'form-summary', 'files' => true]) }}
            {{ Form::hidden('step',3) }}
              <div class="panel-body">
                   <!-- /.row -->

                  <div class="row incident-show">
                    <div class="col-lg-7">
                       <div class="panel panel-default">
                          <div class="panel-heading">
                              <i class="fa fa-bar-chart-o fa-fw"></i> Basic Information
                              <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('suppliers.create', 0) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                          </div>
                          <!-- /.panel-heading -->
                          <div class="panel-body">
                            <div class="table-responsive">
                              <table class="table">
                                  <tbody>
                    									 <tr  style="vertical-align: top;">
                              									<td>	
                              										<b>Vendor Number</b><br/>
                              										<p> @if(isset( $data['basic_information']->vendor_number)) {{ $data['basic_information']->vendor_number }} @else  Not Specified @endif </p>
                              									</td>
                              									<td>	
                              										<b>Region</b><br/>
                              										<p> @if(isset($data['basic_information']->region)) {{ $region[$data['basic_information']->region] }} @else  Not Specified @endif</p>
                              									</td>
                              									<td>
                              										<b>Postal Address</b><br/>
                              										<p>@if(isset($data['basic_information']->address)) {{$data['basic_information']->address}}@else  Not Specified @endif</p>
                              									</td>
                                       </tr>
								
        							                 <tr>
        								                    <td>
                                                <b>Supplier Name</b><br/>
                                                <p>@if(isset($data['basic_information']->vendor_name)){{ ($data['basic_information']->vendor_name) }}@else  Not Specified @endif</p>
                                            </td>
        									
                                            <td>
                                                <b>Country</b><br/>
                                                <p>@if(isset($data['basic_information']->country)){{$country[$data['basic_information']->country] }}@else  Not Specified @endif</p>
                                            </td>
                          									<td>	
                          										<b>Postal Code</b><br/>
                          										<p>@if(isset($data['basic_information']->postal_code)){{$data['basic_information']->postal_code}}@else  Not Specified @endif</p>
                          									</td>
                                       </tr>
								
                        							 <tr>
                        									<td>
                        										<b>Site Name</b><br/>
                        										<p>@if(!empty($data['basic_information']->site_name))
                        										{{ ($data['basic_information']->site_name) }}
                        										@else
                        											Not Specified
                        										@endif
                        										</p>
                        									</td>
                        									<td>
                        										<b>City</b><br/>
                        										<p>@if(!empty($data['basic_information']->city)){{$data['basic_information']->city}}@else  Not Specified @endif</p>
                        									</td>
                        									
                        									<td>
                                                                <b>GPS Coordinate</b><br/>
                                                                <p>@if(!empty($data['basic_information']->coordinates)){{ $data['basic_information']->coordinates }} @else  Not Specified @endif</p>
                                          </td>
                        							 </tr>
								                  </tbody>
								              </table>
                              <table class="table" >
                                  <tbody>
                                      <tr>
                                          <td>
                                           <div id="supplier_map" class="detail-view-map span12">
                                            </div>
                                          </td>
                                      </tr>
                                  </tbody>
                              </table>
                             </div>
                          </div>
                            <!-- /.panel-body -->
                       </div>
                       <!-- /.panel -->
                       <div class="panel panel-default">
                            <div class="panel-heading">
                                <i class="fa fa-bar-chart-o fa-fw"></i> Supplier Information
                                <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('suppliers.create', 1) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                            </div>
                            <!-- /.panel-heading -->
                            <div class="panel-body">
                                <div class="table-responsive">
                                    <table class="table">
                                      <tbody>
                                      <tr>
                                        <td>
                                          <b>Supplier Type</b><br/>
                                          <p>@if(!empty($data['supplier_information']->supplier_type)){{$data['supplier_information']->supplier_type}}@else  Not Specified @endif</p>
                                        </td>
                                        <td>
                                          <b>Supplier Role</b><br/>
                                          <p>@if(!empty($data['supplier_information']->supplier_role)){{$data['supplier_information']->supplier_role}}@else  Not Specified @endif</p>
                                        </td>
                                        <td>
                                            <b>Site Technology</b><br/>
                                            <p>@if(!empty($data['supplier_information']->site_technology))
                                            {{$data['supplier_information']->site_technology}}
                                            @else
                                            Not Specified
                                            @endif
                                            </p>
                                        </td>
                                      </tr>

                                      <tr>
                                        <td>	
                                          <b>Relationship</b><br/>
                                          <p>
                                          @if(!empty($data['supplier_information']->relationship))
                                          {{$data['supplier_information']->relationship}}
                                          @else
                                          Not Specified
                                          @endif
                                          </p>
                                        </td>
                                        <td>	
                                          <b>Category</b><br/>
                                          <p>@if(!empty($data['supplier_information']->category)){{$data['supplier_information']->category}}@else  Not Specified @endif</p>
                                        </td>
                                        <td>
                                          <b>Tier</b><br/>
                                          <p>@if(!empty($data['supplier_information']->tier)){{$data['supplier_information']->tier}}@else  Not Specified @endif</p>
                                        </td>
                                      </tr>	
                                      </tbody>
                                    </table>
                                 </div>
                            </div>
                            <!-- /.panel-body -->
                       </div>
                       <!-- /.panel -->

                       <div class="panel panel-default">
                          <div class="panel-heading">
                              <i class="fa fa-bar-chart-o fa-fw"></i> Supplier Contact Details
                              <div class="pull-right">
                                  <div class="btn-group">
                                      <button type="button" class="btn btn-default btn-xs" href="{{ route('suppliers.create', 2) }}">
                                          Edit
                                      </button>
                                  </div>
                              </div>
                          </div>
                          <!-- /.panel-heading -->
                          <div class="panel-body">
                              <div class="table-responsive">
                                  <table class="table">
                                      <tbody>
                                         <tr>
                                    								<td>
                                    									<b>Telephone Number</b><br/>
                                    									@if(!empty($data['supplier_contact_details']->contact_telephone_number))
                                    									<p>{{$data['supplier_contact_details']->contact_telephone_number}}</p>
                                    									@else 
                                    										Not Specified
                                    									@endif									
                                    								</td>						
                                    								
                                    								<td>
                                    									<b>Email Address</b><br/>
                                    									@if(!empty($data['supplier_contact_details']->contact_email_address))
                                    									<p>{{$data['supplier_contact_details']->contact_email_address}}</p>
                                    									@else 
                                    										Not Specified
                                    									@endif
                                    								</td>
                                         </tr>	
                                      </tbody>
                                  </table>
                               </div>
                          </div>
                          <!-- /.panel-body -->
                       </div>
                       <!-- /.panel -->
                    </div>
                       <!-- /.col-lg-7 -->
                        <!-- /.col-lg-5 -->
                    <div class="col-lg-5">
                       
                      <div class="panel panel-default">
                          <div class="panel-heading">
                              <i class="fa fa-bar-chart-o fa-fw"></i>
                                Leak Prevention Assessments
                          </div>
                          <div class="panel-body">
                            <div class="alert alert-warning">
                               @if($data['supplier_information']->supplier_handle)
                                    This supplier handles Microsoft components/products.
                               @else
                                    This supplier does not handle any Microsoft components/products.
                               @endif
                            </div>
                          </div>
                       </div>
                    </div>

                  </div>
              </div>
               <div class="panel-footer summary_footer">
                          <div class="clearfix">
                            <div class="pull-left">
                              {{ Form::button('Back', ['type' => 'button', 'class' => 'btn btn-default', 'id'=>"btn-back" ]) }}
                            </div>
                            <div class="pull-right">
                            {{ Form::button('Confirm', ['type' => 'submit', 'class' => 'btn btn-primary','id'=>'summaryform']) }}
                            {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'alt' => route('suppliers.index'),'id'=>'supplier_cancel']) }}
                            </div>
                          </div>
             </div>



            </div>
            <!-- /.panel-body -->
      </div>
         <!-- /.col-lg-12  -->
    </div>
    <!-- /.row  -->




        <!-- /.row -->
    </div>
    <!-- /#page-wrapper -->
</div>
<script src="//js.api.here.com/ee/2.5.4/jsl.js?with=all" type="text/javascript" charset="utf-8"></script>
<script type="text/javascript">
  var Suppliers = {
    mapElement: 'supplier_map',
    coordinates: '{{ $coordinates }}'
  };
  
  var incident_history_json = null;
  var incident_prevention_json  = null;
  var business_activity  = null;
  var business_assets  = null;
  var business_risk  = null;
  var business_actions  = null;
  var leak_risk_analysis = null;
</script>
@stop
