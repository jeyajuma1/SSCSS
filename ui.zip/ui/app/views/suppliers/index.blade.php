@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
            Suppliers
			<div class="btn-group pull-right incident-btns">
                {{ Form::button('Add Supplier', ['type' => 'button', 'class' => 'btn btn-primary', 'href' => route('suppliers.create')]) }}
            </div>
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
	@if(Session::has('success'))
    <div id="form-success" class="alert alert-success" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div>
    <!-- end form-success -->
    @endif
      <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default suppliers-panel">
                <div class="panel-heading">
                    {{ Form::open(['route' => 'suppliers.index', 'method' => 'get', 'id' => 'suppliers-list-form', 'class' => 'form-inline', 'role' => 'form']) }}
                    <div class="form-group-row">
					@if(Auth::user()->isAdmin() || Auth::User()->isManager() || Auth::user()->isSupervisor())
                        <div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">User</span>
                                {{ Form::select('user[]', $users, Input::get('user'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                            </div>
                        </div>
						@endif
						<div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">Region</span>
                                {{ Form::select('region[]', $regions, Input::get('region'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                            </div>                               
                        </div>
						<div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">&nbsp;&nbsp;Country&nbsp;&nbsp;</span>
                                {{ Form::select('country[]', $countries, Input::get('country'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                            </div>                              
                        </div>
						<div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">Vendor Number</span>
                                {{ Form::text('vendor_number', Input::get('vendor_number'), ['class' => 'form-control supplier-id']) }}
                            </div>                              
                        </div>
						<div class="form-group" id="customer-group">
                            <div class="input-group">
                                <span class="input-group-addon">Category</span>
                                {{ Form::select('category[]', $category, Input::get('category'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                            </div>
                        </div>
						<div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">Supplier Name</span>
                                {{ Form::select('vendor_name[]', $vendor_name, Input::get('vendor_name'), ['multiple' => 'multiple', 'class' => 'form-control']) }}
                            </div>
                        </div>
						<div class="form-group">
                            <div class="input-group">
                                <span class="input-group-addon">Keywords</span>
                                {{ Form::text('keywords', Input::get('keywords'), ['class' => 'form-control supplier-id']) }}
                            </div>
                        </div>
						
                        <div class="form-group text-left hidden">
                            {{ Form::button('Filter', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Reset', ['type' => 'reset', 'class' => 'btn btn-primary', 'id' => 'supplier-filter-reset']) }}
                        </div>
                    </div>
                    {{ Form::close() }}
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-striped" id="supplierslist">
                        <thead id="suppliers-head">
							<th>Vendor No.</th>
                            <th>Supplier Name</th>
							<th>Supplier Role</th>
							<th>Region</th>
							<th>Country</th>
							<th>City</th>
                            <th>Address</th>							
							<th>Supplier Type</th>
                            <th title="Leak Prevention Status">LP Status</th>
                        </thead>
                        <tbody>
                        <?php 
                                //print "<pre>"; print_r($suppliers->overall_status);exit;
                        ?>
                            @foreach($suppliers as $supplier)
                            <tr class="clickable-row supplier-item"  data-id="{{ $supplier->id }}">
                                <td>{{ $supplier->vendor_number }}</td>
								<td>{{ $supplier->vendor_name }}</td>
								<td>{{ $supplier->supplier_role }}</td>
                                <td>@if(isset($supplier->region->name)) {{ $supplier->region->name }} @else  &nbsp; @endif</td>
								<td>{{ $supplier->country->name }}</td>
								<td>{{ $supplier->city }}</td>
                                <td class="autotip" title="{{$supplier->address}}">{{$supplier->address}}</td>
								<td>{{ $supplier->supplier_type }}</td>
                                 <?php $overall_status = ceil($supplier->overall_status);     ?>
                                    @if($overall_status == 0)
                                       <?php $tdclass= "label  label-default"; $overallstatus = "Not in scope"; ?>
                                    @elseif($overall_status >= 85)
                                        <?php $tdclass= "label label-success"; $overallstatus = "Compliant"; ?>
                                    @elseif($overall_status >= 50 && $overall_status <= 85) 
                                        <?php $tdclass= "label label-warning"; $overallstatus = "Partially compliant"; ?>
                                    @elseif($overall_status <= 50) 
                                        <?php $tdclass= "label  label-danger"; $overallstatus = "Non compliant"; ?>
                                    @endif
                                <td>
                                   <label  class="{{$tdclass}}">{{$overallstatus}}</label>
                                </td>

                            </tr>
                            @endforeach
                        </tbody>
                       </table>
                    </div>
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->

@stop