@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
            Add Country
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <span class="font-bold">
                     Add a new country  
                 </span>
                </div>
                {{ Form::open(['route' => 'countries.store', 'class' => 'form-horizontal', 'role' => 'form', 'id' => 'country-add']) }}
                    <div class="panel-body">

                        @if($errors->all())
                        <div id="form-errors" class="alert alert-danger" role="alert">
                          <ul>
                            @foreach($errors->all() as $error)
                              <li>{{ $error }}</li>
                            @endforeach
                          </ul>
                        </div>
                        @endif

                        <div class="form-group">
                            {{ Form::label('region', 'Region', ['class' => 'col-lg-2 control-label required']) }}
                            <div class="col-sm-6">
                              {{ Form::select('region', $regions, '', ['class' => 'form-control']) }}
                            </div>
                        </div>
                        <div class="form-group">
                            {{ Form::label('name', 'Country Name', ['class' => 'col-lg-2 control-label required']) }}
                            <div class="col-sm-6">
                              {{ Form::text('name', '', ['class' => 'form-control','id'=>'country_name']) }}
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                        {{ Form::button('Cancel', ['type' => 'button', 'class' => 'btn btn-default', 'href' => '/countries']) }}
                    </div>
                {{ Form::close() }}
            </div>
            <!-- /.col-lg-12 -->
        </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->

</div>
@stop