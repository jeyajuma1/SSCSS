@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h1 class="page-header">
            Countries
            <div class="btn-group pull-right">
            	{{ Form::button('Add New Country', ['type' => 'button', 'class' => 'btn-gray', 'href' => route('countries.create')]) }}
            </div>
            </h1>
        </div>
        <!-- /.col-lg-12 -->
    </div>
    <!-- /.row -->
    
    @if(Session::has('success'))
    <div id="form-success" class="alert alert-success" role="alert">
        <span>
            {{ trans(Session::get('success')) }}
        </span>
    </div>
    <!-- end form-success -->
    @endif

    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
				
                     Countries  
			 
                </div>
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-hover table-striped" id="countries-list">
                        <thead>
                            <th>Name</th>
                            <th>Region</th>
                            <th></th>
                        </thead>
                        <tbody>
                        	@foreach($countries as $country)
                            <tr>
                                <td>{{ $country->name }}</td>
                                <td> @if(isset($country->region->name)){{ $country->region->name }} @else &nbsp; @endif </td>
                                <td class="action-buttons" nowrap>
                                {{ Form::open(['route' => ['countries.edit', $country->id], 'method' => 'get']) }}
                                	{{ Form::button('Edit', ['type' => 'submit', 'class' => 'btn btn-primary btn-xs']) }}
			                    {{ Form::close() }}
                                {{ Form::open(['route' => ['countries.destroy', $country->id], 'method' => 'delete']) }}
                                	{{ Form::button('Remove', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs country-delete-button']) }}
			                    {{ Form::close() }}
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
    <!-- /.row -->
</div>
<!-- /#page-wrapper -->
@stop