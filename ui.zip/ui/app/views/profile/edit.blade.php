@extends('layouts.master')

@section('content')
<div id="page-wrapper">
    <div class="container main-content">
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">My Profile</h1>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
        
        <div class="row">
            <div class="col-lg-12">
                <div class="panel panel-default">
                    <div class="panel-heading">My Profile Information</div>
                    {{ Form::open(['route' => ['profile.update', $user->id], 'method' => 'put', 'autocomplete' => 'off', 'class' => 'form-horizontal', 'role' => 'form']) }}
                        <div class="panel-body">
                            
                            @if(Session::has('success'))
                            <div id="form-success" class="alert alert-success" role="alert">
                              <span>
                                {{ Session::get('success') }}
                              </span>
                            </div>
                            <!-- end form-success -->
                            @endif

                            @if($errors->all())
                            <div id="form-errors" class="alert alert-danger" role="alert">
                              <ul>
                                @foreach($errors->all() as $error)
                                  <li>{{ $error }}</li>
                                @endforeach
                              </ul>
                            </div>
                            <!-- end form-errors -->
                            @endif

                            <div class="row">
                                <div class="col-lg-12">
                                  <div class="form-group">
                                    {{ Form::label('first_name', 'First Name', ['class' => 'col-lg-2 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('first_name', $user->first_name, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('last_name', 'Last Name', ['class' => 'col-lg-2 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('last_name', $user->last_name, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('email', 'Email', ['class' => 'col-lg-2 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::email('email', $user->email, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('title', 'Title', ['class' => 'col-lg-2 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::text('title', $user->title, ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    <h4 class="col-lg-10 col-md-offset-2">Change Password</h4>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('current_password', 'Current Password', ['class' => 'col-lg-2 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::password('current_password', ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('password', 'New Password', ['class' => 'col-lg-2 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::password('password', ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                  <div class="form-group">
                                    {{ Form::label('password_confirmation', 'Confirm New Password', ['class' => 'col-lg-2 control-label required']) }}
                                    <div class="col-lg-6">
                                      {{ Form::password('password_confirmation', ['class' => 'form-control']) }}
                                    </div>
                                  </div>
                                </div>
                            </div>
                        </div>
                        <div class="panel-footer">
                            {{ Form::button('Save', ['type' => 'submit', 'class' => 'btn btn-primary']) }}
                            {{ Form::button('Reset', ['type' => 'reset', 'class' => 'btn btn-default']) }}
                        </div>
                    {{ Form::close() }}
                </div>
            </div>
            <!-- /.col-lg-12 -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.main-content -->
</div>
<!-- /#page-wrapper -->
@stop