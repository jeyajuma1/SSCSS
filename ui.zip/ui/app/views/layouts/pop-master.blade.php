<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Microsoft Supply Chain Security Solutions</title>
	{{ HTML::style('css/style.min.css') }}

    <script type='text/javascript' src="/js/ie/modernizr.min.js"></script>
    <script type='text/javascript' src="/js/ie/css3-mediaqueries.js"></script> 

    <!-- For IE8 -->
    <!--[if lt IE 10]>
      <script src="/js/ie/html5shiv.min.js"></script>
      <script src="/js/ie/respond.min.js"></script>
    <![endif]-->
</head>
<body class="{{ MSLST_Common::pageClasses() }}" id="loginBody">
    
    <div id="wrapper">
 
        @yield('content')


    </div>
    <!-- /#wrapper -->

    {{ HTML::script('js/scripts.min.js') }}

</body>
</html>