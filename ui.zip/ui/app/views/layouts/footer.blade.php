
<!--
<div class="container footer-wrap footer-bottom">
    <footer>
        <div class="row">
            <div class="col-lg-12">
                <p class="pull-right clear">
                    @if(!preg_match('/map/',Request::server('REQUEST_URI')))
                     <img src="/images/msfooterlogo.png" width='75' />
                    @endif
                </p>
                <p class="footer-links pull-right clear">
                    {{ HTML::link('/', 'Home') }}
                    &middot;
                    {{ HTML::link('mailto:mscss@microsoft.com', 'Contact Us') }}
                    &middot;
                    {{ HTML::link('//download.fds-ncom.nokia.com/downloads/Externals+Privacy+Policy_v.2_2011+01+27.pdf', 'Privacy Policy') }}
                    &nbsp;&nbsp;
                    <span class="small">&copy; 2015 @if(!preg_match('/map/',Request::server('REQUEST_URI'))) Microsoft @else <img src="/images/footerlogo.png" width='75' /> @endif </span>
                </p>
            </div>
        </div>
    </footer>
</div> -->


<div class="footer footer-bottom">
            <div class="pull-right">
                <div class="footer-links">
                    {{ HTML::link('/', 'Home') }}
                    &middot;
                    {{ HTML::link('mailto:mscss@microsoft.com', 'Contact Us') }} <a>&nbsp;Privacy Policy</a>
                     &middot;
                    {{ HTML::link('//download.fds-ncom.nokia.com/downloads/Externals+Privacy+Policy_v.2_2011+01+27.pdf', 'Privacy Policy') }}
                    &nbsp;&nbsp;
                    <span class="small">&copy; 2015 @if(!preg_match('/map/',Request::server('REQUEST_URI'))) Microsoft @else <img src="/images/footerlogo.png" width='75' /> @endif </span>
                     
                </div>

            </div>

</div>
<!-- /#container -->
