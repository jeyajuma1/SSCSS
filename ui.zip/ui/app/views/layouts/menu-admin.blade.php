<div class="row border-bottom white-bg">
    <nav class="navbar navbar-static-top" role="navigation">
        <div class="navbar-header">
            <button aria-controls="navbar" aria-expanded="false"
                data-target="#navbar" data-toggle="collapse"
                class="navbar-toggle collapsed" type="button">
                <i class="fa fa-reorder"></i>
            </button>

        </div>
        <div class="navbar-collapse collapse" id="navbar">
            <ul class="nav navbar-nav">
                <li {{ MSLST_Common::activeURI('dashboard*') }}>
                    <a href="/dashboard">Dashboard</a>
                </li>
                <li {{ MSLST_Common::activeURI('statistics*') }}>
                    <a href="#" class="dropdown-toggle statistics-menu-item" data-toggle="dropdown" id="statistics-menu">Statistics&nbsp;<span class="caret"></span></a>
                    <ul class="dropdown-menu" role="menu" aria-labelledby="statistics-menu" id="statistics-drop">
                        <li>
                            <a href="/statistics/audit?type=chart">Chart</a>
                        </li>
                        <li>
                            <a href="/statistics/incidents?type=map&incident_type=logistic">Map</a>
                        </li>
                    </ul>
                </li>
                <li {{ MSLST_Common::activeURI('incidents*') }}>
                <a href="/incidents">Incidents</a>
            </li>
            <li {{ MSLST_Common::activeURI('audits*', ['locations*', 'routes*']) }}>
                <a href="/audits">Audits</a>
            </li>
            @if(Auth::User()->access_lanes )
            <li {{ MSLST_Common::activeURI('lanes*') }}>
                <a href="/lanes">Lanes</a>
            </li>
            @endif            
            @if(Auth::User()->access_suppliers )
            
            @endif
            @if(Auth::User()->access_sitemasters )
             <li {{ MSLST_Common::activeURI('sitemaster*', ['sitemaster*']) }}>
                <a href="#" class="dropdown-toggle sitemaster-menu-item" data-toggle="dropdown" id="sitemaster-menu">Site Master <span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu" aria-labelledby="sitemaster-menu" id="sitemaster-drop">
                    <li>
                        <a   href="/sitemaster">Site</a>
                    </li>
                    <li>
                        <a  data-toggle="modal" data-target="#inspect_model">Documents</a>
                    </li> 
                </ul>
            </li>
            @endif
            <li {{ MSLST_Common::activeURI('users*') }}>
                <a href="/users">Users</a>
            </li>
            <li {{ MSLST_Common::optionsURI() }}>
                <a href="#" class="dropdown-toggle settings-menu-item" data-toggle="dropdown" id="settings-menu">Options<span class="caret"></span></a>
                <ul class="dropdown-menu" role="menu" aria-labelledby="settings-menu" id="settings-drop">
                    <li>
                        <a href="/regions">Regions</a>
                    </li>
                    <li>
                        <a href="/countries">Countries</a>
                    </li>
                    <li>
                        <a href="/lsps">LSPs</a>
                    </li>
                    <li>
                        <a href="/certifications">Certifications</a>
                    </li>
                    <li>
                        <a href="/questions">Questions</a>
                    </li>
                
                    <li>
                        <a href="/settings">Settings</a>
                    </li>
                </ul>
            </li>

            </ul>
            <ul class="nav navbar-top-links navbar-right">
                <li><a  data-toggle="modal" data-target="#myModal"> <i class="fa fa-file-pdf-o"></i>User
                        Manual
                </a></li>
            </ul>
        </div>
    </nav>
</div>




<!--


<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav" id="side-menu">
		    <li class="pull-right" style='margin-right:15px;'>
			    <a  data-toggle="modal" data-target="#myModal">User Manual</a>
			</li>
            <li {{ MSLST_Common::activeURI('dashboard*') }}>
                <a href="/dashboard">Dashboard</a>
            </li> 
            <li {{ MSLST_Common::activeURI('statistics*') }}>
                <a href="#" class="dropdown-toggle statistics-menu-item" data-toggle="dropdown" id="statistics-menu">Statistics&nbsp;<span class="fa fa-angle-down"></span></a>
                <ul class="dropdown-menu" role="menu" aria-labelledby="statistics-menu" id="statistics-drop">
                    <li>
                        <a href="/statistics/audit?type=chart">Chart</a>
                    </li>
                    <li>
                        <a href="/statistics/incidents?type=map&incident_type=logistic">Map</a>
                    </li>
                </ul>
            </li>
            <li {{ MSLST_Common::activeURI('incidents*') }}>
                <a href="/incidents">Incidents</a>
            </li>
            <li {{ MSLST_Common::activeURI('audits*', ['locations*', 'routes*']) }}>
                <a href="/audits">Audits</a>
            </li>
            @if(Auth::User()->access_lanes )
            <li {{ MSLST_Common::activeURI('lanes*') }}>
                <a href="/lanes">Lanes</a>
            </li>
            @endif            
			@if(Auth::User()->access_suppliers )
            
			@endif
			@if(Auth::User()->access_sitemasters )
			 <li {{ MSLST_Common::activeURI('sitemaster*', ['sitemaster*']) }}>
                <a href="#" class="dropdown-toggle sitemaster-menu-item" data-toggle="dropdown" id="sitemaster-menu">Site Master <span class="fa fa-angle-down"></span></a>
                <ul class="dropdown-menu" role="menu" aria-labelledby="sitemaster-menu" id="sitemaster-drop">
                    <li>
                        <a   href="/sitemaster">Site</a>
                    </li>
                    <li>
                        <a  data-toggle="modal" data-target="#inspect_model">Documents</a>
                    </li> 
                </ul>
            </li>
			@endif
            <li {{ MSLST_Common::activeURI('users*') }}>
                <a href="/users">Users</a>
            </li>
            <li {{ MSLST_Common::optionsURI() }}>
                <a href="#" class="dropdown-toggle settings-menu-item" data-toggle="dropdown" id="settings-menu">Options<span class="fa fa-angle-down"></span></a>
                <ul class="dropdown-menu" role="menu" aria-labelledby="settings-menu" id="settings-drop">
                    <li>
                        <a href="/regions">Regions</a>
                    </li>
                    <li>
                        <a href="/countries">Countries</a>
                    </li>
                    <li>
                        <a href="/lsps">LSPs</a>
                    </li>
                    <li>
                        <a href="/certifications">Certifications</a>
                    </li>
                    <li>
                        <a href="/questions">Questions</a>
                    </li>
                
                    <li>
                        <a href="/settings">Settings</a>
                    </li>
                </ul>
                
            </li>
        </ul>
        
    </div>
     
</nav> 

              -->              

<div class="modal inmodal" id="myModal" tabindex="-1" role="dialog" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content animated bounceInRight">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <i class="fa fa-file-o modal-icon"></i>
            <h4 class="modal-title">User Manual Document</h4>
         </div>
         <div class="modal-body">
            <div id="nestable2" class="dd">
               <ol class="dd-list">
                  <li data-id="1" class="dd-item dd-collapsed">
                     <div class="dd-handle">
                        <span class="label label-danger"><i class="fa fa-file-pdf-o"></i></span> {{ HTML::decode(HTML::link('/UserManual/UserManual_Admin.pdf', ' UserManual For Admin', [ 'target' => '_blank'] )) }}
                     </div>
                  </li>
                  <li data-id="2" class="dd-item dd-collapsed">
                     <div class="dd-handle">
                        <span class="label label-danger"><i class="fa fa-file-pdf-o"></i></span> {{ HTML::decode(HTML::link('/UserManual/UserManual_MS.pdf', ' UserManual For MS Supervisor', [ 'target' => '_blank'] )) }}
                     </div>
                  </li>
                  <li data-id="3" class="dd-item dd-collapsed">
                     <div class="dd-handle">
                        <span class="label label-danger"><i class="fa fa-file-pdf-o"></i></span> {{ HTML::decode(HTML::link('/UserManual/UserManual_LSP.pdf', ' UserManual For LSP Supervisor', [ 'target' => '_blank'] )) }}
                     </div>
                  </li>
                  <li data-id="4" class="dd-item dd-collapsed">
                     <div class="dd-handle">
                        <span class="label label-danger"><i class="fa fa-file-pdf-o"></i></span>  {{ HTML::decode(HTML::link('/UserManual/UserManual_User.pdf', ' UserManual For User', [ 'target' => '_blank'] )) }}
                     </div>
                  </li>
                  <li data-id="5" class="dd-item dd-collapsed">
                     <div class="dd-handle">
                        <span class="label label-success"><i class="fa fa-file-excel-o"></i></span> {{ HTML::decode(HTML::link('/UserManual/SCS Inspection Guide FY17.xlsx', ' Inspection Guide', [ 'target' => '_blank'] )) }} 
                     </div>
                  </li>
               </ol>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
         </div>
      </div>
   </div>
</div>
  
<div class="modal inmodal" id="inspect_model" tabindex="-1" role="dialog" aria-hidden="true">
   <div class="modal-dialog">
      <div class="modal-content animated bounceInRight">
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
            <i class="fa fa-file-o modal-icon"></i>
            <h4 class="modal-title">SCS Inspection Document</h4>
         </div>
         <div class="modal-body">
            <div id="nestable2" class="dd">
               <ol class="dd-list">
                  <li data-id="5" class="dd-item dd-collapsed">
                     <div class="dd-handle">
                        <span class="label label-success"><i class="fa fa-file-excel-o"></i></span> {{ HTML::decode(HTML::link('/UserManual/SCS Inspection Guide FY17.xlsx', ' Inspection Guide', [ 'target' => '_blank'] )) }} 
                     </div>
                  </li>
               </ol>
            </div>
         </div>
         <div class="modal-footer">
            <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
         </div>
      </div>
   </div>
</div>

<!-- /.navbar-static-side -->
