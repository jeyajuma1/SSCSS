<!DOCTYPE html>
<html lang="en">
<head>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
     <meta http-equiv="X-UA-Compatible" content="IE=edge">
	 <title>Microsoft Supply Chain Security Solutions</title>
     <link rel="stylesheet" type="text/css" href="style.min.css"/>
 </head>
<body class="{{ MSLST_Common::pageClasses() }}" >
    <div class="wrapper">
        @include('layouts.pdf-main')
        @yield('content')
    </div>
    <!-- /#wrapper -->
     {{ HTML::script('js/scripts.min.js') }}
</body>
</html>