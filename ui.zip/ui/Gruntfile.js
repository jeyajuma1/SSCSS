/*
 * Gruntfile for MSLST
 */

'use strict';

module.exports = function(grunt) {

    grunt.initConfig({
        cssmin: {
          combine: {
            files: {
		    'public/css/plugins.css': [
                    'public/css/plugins/bootstrap.min.css',
                    'public/css/plugins/font-awesome.min.css',
                    'public/css/plugins/bootstrap-switch.min.css',
					'public/css/plugins/sb_admin.css',
                    'public/css/plugins/dataTables.bootstrap.css',
                    'public/css/plugins/daterangepicker.min.css',
                    'public/css/plugins/morris.min.css',
                    'public/css/plugins/summernote.css',
                    'public/css/plugins/summernote-bs3.css',
                    'public/css/plugins/select2.css',
                    'public/css/plugins/select2-bootstrap.css',
                    'public/css/plugins/timepicker.min.css',
                    'public/css/plugins/jquery-ui.min.css',
                    'public/css/plugins/bootstrap-select.css',
                    'public/css/plugins/bootstrap-duallistbox.css',
                    'public/css/plugins/fileinput.css',
                    'public/css/plugins/animate.css',
                    'public/css/plugins/ion.rangeSlider.css',
                    'public/css/plugins/ion.rangeSlider.skinFlat.css'
                ]
            }
          },
          minify: {
            options: {
		    keepSpecialComments: 0
            },
            files: {
		            'public/css/style.min.css': ['public/css/plugins.css', 'public/css/src/main.css']
            }
          }
        },
        uglify: {
          minify: {
            options: {
                sourceMap: true
            },
            files: {
                'public/js/scripts.min.js': [
                    'public/js/plugins/core/jquery.min.js',
                    'public/js/plugins/core/jquery-migrate.min.js',
                    'public/js/plugins/core/bootstrap.min.js',
                    'public/js/plugins/core/raphael.min.js',
                    'public/js/plugins/core/moment.min.js',
                    'public/js/plugins/datatables/jquery.dataTables.js',
                    'public/js/plugins/datatables/dataTables.bootstrap.js',
                    'public/js/plugins/bootstrap-editable.min.js',
                    'public/js/plugins/bootstrap-switch.min.js',
                    'public/js/plugins/daterangepicker.min.js',
                    'public/js/plugins/jquery.metisMenu.js',
                    'public/js/plugins/jquery-ui.min.js',
                    'public/js/plugins/morris.js',
                    'public/js/plugins/Chart.js',
                    'public/js/plugins/select2.min.js',
                    'public/js/plugins/summernote.min.js',
                    'public/js/plugins/timepicker.min.js',
                    'public/js/plugins/bootbox.min.js',
                    'public/js/plugins/spin.min.js',
                    'public/js/plugins/jquery.spin.js',
                    'public/js/plugins/jquery-ui.min.js',
                    'public/js/plugins/bootstrap-select.js',
                    'public/js/plugins/placeholders.min.js',
                    'public/js/plugins/jquery.bootstrap-duallistbox.js',
                    'public/js/plugins/canvg/rgbcolor.js',
                    'public/js/plugins/canvg/StackBlur.js',
                    'public/js/plugins/canvg/canvg.js',
                    'public/js/plugins/jquery.peity.min.js',
                    'public/js/plugins/fileinput.js',
                    'public/js/plugins/ion.rangeSlider.min.js',
                    'public/js/maps/utils.js',
                    'public/js/maps/bing_utils.js',
					'public/js/maps/cluster.js',
                    'public/js/lanes.js',
                    'public/js/main.js'
                ]
            }
          }
        },
		// 'closure-compiler': {
		// 	scripts: {
		// 	  closurePath: 'c:/xampp/apps/google-closure',
		// 	  js: 'public/js/scripts.js',
		// 	  jsOutputFile: 'public/js/scripts.min.js',
		// 	  options: {
		// 		compilation_level: 'ADVANCED_OPTIMIZATIONS',
		// 		language_in: 'ECMASCRIPT5'
		// 	  }
		// 	}
		// },
        watch: {
            css: {
                files: ['public/css/src/main.css'],
                tasks: ['cssmin', 'clean'],
                options: {
                    livereload: true,
                },
            },
            js: {
                files: ['public/js/main.js',
                        'public/js/maps/bing_utils.js'],
                tasks: ['uglify'],
                options: {
                    livereload: true,
                },
            }
        },
        clean: ["public/css/plugins.css"]
    });

    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    // grunt.loadNpmTasks('grunt-closure-compiler');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-contrib-clean');

    grunt.registerTask('default', [
        'cssmin:combine',
        'cssmin:minify',
        'uglify:minify',
        // 'closure-compiler:scripts',
        'clean'
    ]);

};
